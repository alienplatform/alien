import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { EnvironmentVariableType } from "./environmentvariabletype.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type EnvironmentVariableInput = {
    /**
     * Environment variable key/name
     */
    key: string;
    /**
     * Environment variable value
     */
    value: string;
    /**
     * Variable type (plain or secret)
     */
    type: EnvironmentVariableType;
    targetFunctions?: Array<string> | null | undefined;
    /**
     * Agent ID for agent-level variables. null or omitted for project-level
     */
    agentId?: string | null | undefined;
    /**
     * Optional comment describing the variable
     */
    comment?: string | null | undefined;
};
/** @internal */
export declare const EnvironmentVariableInput$inboundSchema: z.ZodType<EnvironmentVariableInput, z.ZodTypeDef, unknown>;
/** @internal */
export type EnvironmentVariableInput$Outbound = {
    key: string;
    value: string;
    type: string;
    targetFunctions?: Array<string> | null | undefined;
    agentId?: string | null | undefined;
    comment?: string | null | undefined;
};
/** @internal */
export declare const EnvironmentVariableInput$outboundSchema: z.ZodType<EnvironmentVariableInput$Outbound, z.ZodTypeDef, EnvironmentVariableInput>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnvironmentVariableInput$ {
    /** @deprecated use `EnvironmentVariableInput$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnvironmentVariableInput, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnvironmentVariableInput$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnvironmentVariableInput$Outbound, z.ZodTypeDef, EnvironmentVariableInput>;
    /** @deprecated use `EnvironmentVariableInput$Outbound` instead. */
    type Outbound = EnvironmentVariableInput$Outbound;
}
export declare function environmentVariableInputToJSON(environmentVariableInput: EnvironmentVariableInput): string;
export declare function environmentVariableInputFromJSON(jsonString: string): SafeParseResult<EnvironmentVariableInput, SDKValidationError>;
//# sourceMappingURL=environmentvariableinput.d.ts.map