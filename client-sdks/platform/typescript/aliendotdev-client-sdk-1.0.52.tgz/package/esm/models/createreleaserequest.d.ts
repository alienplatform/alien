import * as z from "zod/v4";
import { GitMetadata, GitMetadata$Outbound } from "./gitmetadata.js";
import { StackByPlatform, StackByPlatform$Outbound } from "./stackbyplatform.js";
export type CreateReleaseRequest = {
    gitMetadata?: GitMetadata | null | undefined;
    stack: StackByPlatform;
    rootDirectory?: string | null | undefined;
    /**
     * Project ID or name
     */
    project: string;
};
/** @internal */
export type CreateReleaseRequest$Outbound = {
    gitMetadata?: GitMetadata$Outbound | null | undefined;
    stack: StackByPlatform$Outbound;
    rootDirectory?: string | null | undefined;
    project: string;
};
/** @internal */
export declare const CreateReleaseRequest$outboundSchema: z.ZodType<CreateReleaseRequest$Outbound, CreateReleaseRequest>;
export declare function createReleaseRequestToJSON(createReleaseRequest: CreateReleaseRequest): string;
//# sourceMappingURL=createreleaserequest.d.ts.map