import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type ListCommandNamesResponse = {
    names: Array<string>;
};
/** @internal */
export declare const ListCommandNamesResponse$inboundSchema: z.ZodType<ListCommandNamesResponse, unknown>;
export declare function listCommandNamesResponseFromJSON(jsonString: string): SafeParseResult<ListCommandNamesResponse, SDKValidationError>;
//# sourceMappingURL=listcommandnamesresponse.d.ts.map