import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const DomainStatus: {
    readonly PendingZoneCreation: "pending-zone-creation";
    readonly PendingVerification: "pending-verification";
    readonly Verified: "verified";
    readonly Failed: "failed";
    readonly Deleting: "deleting";
};
export type DomainStatus = ClosedEnum<typeof DomainStatus>;
export type Domain = {
    /**
     * Unique identifier for the domain.
     */
    id: string;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    domain: string;
    isSystem: boolean;
    hostedZoneId?: string | null | undefined;
    nameServers?: Array<string> | null | undefined;
    status: DomainStatus;
    error?: any | null | undefined;
    createdAt: Date;
    verifiedAt?: Date | null | undefined;
};
/** @internal */
export declare const DomainStatus$inboundSchema: z.ZodEnum<typeof DomainStatus>;
/** @internal */
export declare const Domain$inboundSchema: z.ZodType<Domain, unknown>;
export declare function domainFromJSON(jsonString: string): SafeParseResult<Domain, SDKValidationError>;
//# sourceMappingURL=domain.d.ts.map