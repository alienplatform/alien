import * as z from "zod/v4";
export type CreateAgentTokenRequest = {
    /**
     * Optional description for the agent token
     */
    description: string | null;
    /**
     * Optional expiration date for the agent token
     */
    expiresAt?: Date | undefined;
};
/** @internal */
export type CreateAgentTokenRequest$Outbound = {
    description: string | null;
    expiresAt?: string | undefined;
};
/** @internal */
export declare const CreateAgentTokenRequest$outboundSchema: z.ZodType<CreateAgentTokenRequest$Outbound, CreateAgentTokenRequest>;
export declare function createAgentTokenRequestToJSON(createAgentTokenRequest: CreateAgentTokenRequest): string;
//# sourceMappingURL=createagenttokenrequest.d.ts.map