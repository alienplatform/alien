import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * Automatically select agent manager based on project settings
 */
export declare const AutoSelect: {
    readonly Auto: "auto";
};
/**
 * Automatically select agent manager based on project settings
 */
export type AutoSelect = ClosedEnum<typeof AutoSelect>;
/** @internal */
export declare const AutoSelect$inboundSchema: z.ZodNativeEnum<typeof AutoSelect>;
/** @internal */
export declare const AutoSelect$outboundSchema: z.ZodNativeEnum<typeof AutoSelect>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AutoSelect$ {
    /** @deprecated use `AutoSelect$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `AutoSelect$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
//# sourceMappingURL=autoselect.d.ts.map