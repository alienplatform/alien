import * as z from "zod/v4";
export type GenerateDeepstoreTokenRequest = {
    /**
     * Project ID or name to scope token access to. When omitted, the token is scoped to all projects accessible by the current user.
     */
    project?: string | undefined;
};
/** @internal */
export type GenerateDeepstoreTokenRequest$Outbound = {
    project?: string | undefined;
};
/** @internal */
export declare const GenerateDeepstoreTokenRequest$outboundSchema: z.ZodType<GenerateDeepstoreTokenRequest$Outbound, GenerateDeepstoreTokenRequest>;
export declare function generateDeepstoreTokenRequestToJSON(generateDeepstoreTokenRequest: GenerateDeepstoreTokenRequest): string;
//# sourceMappingURL=generatedeepstoretokenrequest.d.ts.map