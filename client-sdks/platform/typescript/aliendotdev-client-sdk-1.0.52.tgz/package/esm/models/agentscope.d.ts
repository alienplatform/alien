import * as z from "zod/v4";
import { AgentRole } from "./agentrole.js";
/**
 * Agent-scoped configuration
 */
export type AgentScope = {
    type: "agent";
    /**
     * ID of the agent this is scoped to
     */
    agentId: string;
    /**
     * ID of the project this agent belongs to
     */
    projectId: string;
    /**
     * Role for agent-scoped service accounts
     */
    role: AgentRole;
};
/** @internal */
export type AgentScope$Outbound = {
    type: "agent";
    agentId: string;
    projectId: string;
    role: string;
};
/** @internal */
export declare const AgentScope$outboundSchema: z.ZodType<AgentScope$Outbound, AgentScope>;
export declare function agentScopeToJSON(agentScope: AgentScope): string;
//# sourceMappingURL=agentscope.d.ts.map