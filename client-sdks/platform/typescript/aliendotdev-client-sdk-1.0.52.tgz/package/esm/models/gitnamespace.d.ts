import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const GitNamespaceType: {
    readonly Team: "team";
    readonly User: "user";
};
export type GitNamespaceType = ClosedEnum<typeof GitNamespaceType>;
export declare const Provider: {
    readonly Github: "github";
};
export type Provider = ClosedEnum<typeof Provider>;
export type GitNamespace = {
    id: number | null;
    name: string;
    slug: string;
    installationId: number | null;
    type: GitNamespaceType;
    provider: Provider;
    createdAt: Date;
};
/** @internal */
export declare const GitNamespaceType$inboundSchema: z.ZodEnum<typeof GitNamespaceType>;
/** @internal */
export declare const Provider$inboundSchema: z.ZodEnum<typeof Provider>;
/** @internal */
export declare const GitNamespace$inboundSchema: z.ZodType<GitNamespace, unknown>;
export declare function gitNamespaceFromJSON(jsonString: string): SafeParseResult<GitNamespace, SDKValidationError>;
//# sourceMappingURL=gitnamespace.d.ts.map