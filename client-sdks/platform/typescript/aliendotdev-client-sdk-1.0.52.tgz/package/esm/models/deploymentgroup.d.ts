import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type DeploymentGroup = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Deployment group name.
     */
    name: string;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    /**
     * Maximum number of agents allowed in this deployment group
     */
    maxAgents: number;
    createdAt: Date;
};
/** @internal */
export declare const DeploymentGroup$inboundSchema: z.ZodType<DeploymentGroup, unknown>;
export declare function deploymentGroupFromJSON(jsonString: string): SafeParseResult<DeploymentGroup, SDKValidationError>;
//# sourceMappingURL=deploymentgroup.d.ts.map