import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type AgentDeploymentGroupInfo = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Deployment group name.
     */
    name: string;
};
/** @internal */
export declare const AgentDeploymentGroupInfo$inboundSchema: z.ZodType<AgentDeploymentGroupInfo, unknown>;
export declare function agentDeploymentGroupInfoFromJSON(jsonString: string): SafeParseResult<AgentDeploymentGroupInfo, SDKValidationError>;
//# sourceMappingURL=agentdeploymentgroupinfo.d.ts.map