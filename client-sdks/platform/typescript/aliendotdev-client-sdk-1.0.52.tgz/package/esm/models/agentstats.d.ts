import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type AgentStats = {
    /**
     * Total number of agents matching filters
     */
    total: number;
    /**
     * Count of agents by status (only includes statuses with non-zero counts)
     */
    byStatus: {
        [k: string]: number;
    };
    /**
     * Count of agents by platform (only includes platforms with non-zero counts)
     */
    byPlatform: {
        [k: string]: number;
    };
};
/** @internal */
export declare const AgentStats$inboundSchema: z.ZodType<AgentStats, unknown>;
export declare function agentStatsFromJSON(jsonString: string): SafeParseResult<AgentStats, SDKValidationError>;
//# sourceMappingURL=agentstats.d.ts.map