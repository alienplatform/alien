import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { DeploymentPageBackground } from "./deploymentpagebackground.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Type of token used to authenticate this request
 */
export declare const DeploymentInfoTokenType: {
    readonly Agent: "agent";
    readonly DeploymentGroup: "deployment-group";
};
/**
 * Type of token used to authenticate this request
 */
export type DeploymentInfoTokenType = ClosedEnum<typeof DeploymentInfoTokenType>;
/**
 * Represents the target cloud platform.
 */
export declare const DeploymentInfoPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type DeploymentInfoPlatform = ClosedEnum<typeof DeploymentInfoPlatform>;
/**
 * Agent details (present when using an agent-scoped token)
 */
export type DeploymentInfoAgent = {
    name: string;
    /**
     * Represents the target cloud platform.
     */
    platform: DeploymentInfoPlatform;
};
/**
 * Deployment group details (present when using a deployment-group token)
 */
export type DeploymentInfoDeploymentGroup = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    name: string;
};
export type DeploymentInfoProject = {
    name: string;
    workspace: string;
    deploymentPageBackground?: DeploymentPageBackground | null | undefined;
};
/**
 * Status of a package build
 */
export declare const CliStatus: {
    readonly Pending: "pending";
    readonly Building: "building";
    readonly Ready: "ready";
    readonly Failed: "failed";
    readonly Canceled: "canceled";
};
/**
 * Status of a package build
 */
export type CliStatus = ClosedEnum<typeof CliStatus>;
/**
 * Information about a single binary artifact
 */
export type DeploymentInfoBinaries = {
    /**
     * SHA256 checksum
     */
    sha256: string;
    /**
     * File size in bytes
     */
    size: number;
    /**
     * Download URL for the binary
     */
    url: string;
};
/**
 * Outputs from a CLI package build
 */
export type CliOutputs = {
    /**
     * Binary information for each target platform
     */
    binaries: {
        [k: string]: DeploymentInfoBinaries;
    };
};
/**
 * Install script URLs for each OS
 */
export type InstallScripts = {
    windows: string;
    mac: string;
    linux: string;
};
export type DeploymentInfoCli = {
    /**
     * Status of a package build
     */
    status: CliStatus;
    version?: string | undefined;
    /**
     * Outputs from a CLI package build
     */
    outputs?: CliOutputs | undefined;
    error?: any | null | undefined;
    /**
     * Install script URLs for each OS
     */
    installScripts: InstallScripts;
};
/**
 * Status of a package build
 */
export declare const CloudformationStatus: {
    readonly Pending: "pending";
    readonly Building: "building";
    readonly Ready: "ready";
    readonly Failed: "failed";
    readonly Canceled: "canceled";
};
/**
 * Status of a package build
 */
export type CloudformationStatus = ClosedEnum<typeof CloudformationStatus>;
/**
 * Outputs from a CloudFormation package build
 */
export type CloudformationOutputs = {
    /**
     * AWS Console quick-launch URL
     */
    launchStackUrl: string;
    /**
     * SHA256 checksum of the template
     */
    sha256: string;
    /**
     * Template size in bytes
     */
    size: number;
    /**
     * S3 URL to the CloudFormation template
     */
    templateUrl: string;
};
export type DeploymentInfoCloudformation = {
    /**
     * Status of a package build
     */
    status: CloudformationStatus;
    version?: string | undefined;
    /**
     * Outputs from a CloudFormation package build
     */
    outputs?: CloudformationOutputs | undefined;
    error?: any | null | undefined;
    /**
     * CloudFormation launch URL
     */
    launchUrl: string;
};
/**
 * Status of a package build
 */
export declare const TerraformStatus: {
    readonly Pending: "pending";
    readonly Building: "building";
    readonly Ready: "ready";
    readonly Failed: "failed";
    readonly Canceled: "canceled";
};
/**
 * Status of a package build
 */
export type TerraformStatus = ClosedEnum<typeof TerraformStatus>;
/**
 * GPG public key for Terraform provider signature verification
 */
export type DeploymentInfoGpgPublicKey = {
    /**
     * ASCII-armored public key
     */
    asciiArmor: string;
    /**
     * GPG key ID
     */
    keyId: string;
};
/**
 * Information about a single Terraform provider package for a specific platform
 */
export type DeploymentInfoPlatforms = {
    /**
     * Download URL for the provider zip
     */
    downloadUrl: string;
    /**
     * Filename of the provider zip
     */
    filename: string;
    /**
     * SHA256 checksum of the zip file
     */
    shasum: string;
    /**
     * URL to the shasums signature file
     */
    shasumsSignatureUrl: string;
    /**
     * URL to the shasums file
     */
    shasumsUrl: string;
    /**
     * Size of the zip file in bytes
     */
    size: number;
};
/**
 * Outputs from a Terraform provider package build
 */
export type TerraformOutputs = {
    /**
     * GPG public key for Terraform provider signature verification
     */
    gpgPublicKey: DeploymentInfoGpgPublicKey;
    /**
     * Provider packages for each target platform
     */
    platforms: {
        [k: string]: DeploymentInfoPlatforms;
    };
};
export type DeploymentInfoTerraform = {
    /**
     * Status of a package build
     */
    status: TerraformStatus;
    version?: string | undefined;
    /**
     * Outputs from a Terraform provider package build
     */
    outputs?: TerraformOutputs | undefined;
    error?: any | null | undefined;
    /**
     * Terraform provider source (without https://)
     */
    providerSource: string;
};
export type Packages = {
    /**
     * True if all enabled packages are ready for deployment
     */
    ready: boolean;
    cli?: DeploymentInfoCli | undefined;
    cloudformation?: DeploymentInfoCloudformation | undefined;
    terraform?: DeploymentInfoTerraform | undefined;
};
export type DeploymentInfo = {
    /**
     * Type of token used to authenticate this request
     */
    tokenType: DeploymentInfoTokenType;
    /**
     * Agent details (present when using an agent-scoped token)
     */
    agent?: DeploymentInfoAgent | undefined;
    /**
     * Deployment group details (present when using a deployment-group token)
     */
    deploymentGroup?: DeploymentInfoDeploymentGroup | undefined;
    project: DeploymentInfoProject;
    packages: Packages;
};
/** @internal */
export declare const DeploymentInfoTokenType$inboundSchema: z.ZodEnum<typeof DeploymentInfoTokenType>;
/** @internal */
export declare const DeploymentInfoPlatform$inboundSchema: z.ZodEnum<typeof DeploymentInfoPlatform>;
/** @internal */
export declare const DeploymentInfoAgent$inboundSchema: z.ZodType<DeploymentInfoAgent, unknown>;
export declare function deploymentInfoAgentFromJSON(jsonString: string): SafeParseResult<DeploymentInfoAgent, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoDeploymentGroup$inboundSchema: z.ZodType<DeploymentInfoDeploymentGroup, unknown>;
export declare function deploymentInfoDeploymentGroupFromJSON(jsonString: string): SafeParseResult<DeploymentInfoDeploymentGroup, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoProject$inboundSchema: z.ZodType<DeploymentInfoProject, unknown>;
export declare function deploymentInfoProjectFromJSON(jsonString: string): SafeParseResult<DeploymentInfoProject, SDKValidationError>;
/** @internal */
export declare const CliStatus$inboundSchema: z.ZodEnum<typeof CliStatus>;
/** @internal */
export declare const DeploymentInfoBinaries$inboundSchema: z.ZodType<DeploymentInfoBinaries, unknown>;
export declare function deploymentInfoBinariesFromJSON(jsonString: string): SafeParseResult<DeploymentInfoBinaries, SDKValidationError>;
/** @internal */
export declare const CliOutputs$inboundSchema: z.ZodType<CliOutputs, unknown>;
export declare function cliOutputsFromJSON(jsonString: string): SafeParseResult<CliOutputs, SDKValidationError>;
/** @internal */
export declare const InstallScripts$inboundSchema: z.ZodType<InstallScripts, unknown>;
export declare function installScriptsFromJSON(jsonString: string): SafeParseResult<InstallScripts, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoCli$inboundSchema: z.ZodType<DeploymentInfoCli, unknown>;
export declare function deploymentInfoCliFromJSON(jsonString: string): SafeParseResult<DeploymentInfoCli, SDKValidationError>;
/** @internal */
export declare const CloudformationStatus$inboundSchema: z.ZodEnum<typeof CloudformationStatus>;
/** @internal */
export declare const CloudformationOutputs$inboundSchema: z.ZodType<CloudformationOutputs, unknown>;
export declare function cloudformationOutputsFromJSON(jsonString: string): SafeParseResult<CloudformationOutputs, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoCloudformation$inboundSchema: z.ZodType<DeploymentInfoCloudformation, unknown>;
export declare function deploymentInfoCloudformationFromJSON(jsonString: string): SafeParseResult<DeploymentInfoCloudformation, SDKValidationError>;
/** @internal */
export declare const TerraformStatus$inboundSchema: z.ZodEnum<typeof TerraformStatus>;
/** @internal */
export declare const DeploymentInfoGpgPublicKey$inboundSchema: z.ZodType<DeploymentInfoGpgPublicKey, unknown>;
export declare function deploymentInfoGpgPublicKeyFromJSON(jsonString: string): SafeParseResult<DeploymentInfoGpgPublicKey, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoPlatforms$inboundSchema: z.ZodType<DeploymentInfoPlatforms, unknown>;
export declare function deploymentInfoPlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentInfoPlatforms, SDKValidationError>;
/** @internal */
export declare const TerraformOutputs$inboundSchema: z.ZodType<TerraformOutputs, unknown>;
export declare function terraformOutputsFromJSON(jsonString: string): SafeParseResult<TerraformOutputs, SDKValidationError>;
/** @internal */
export declare const DeploymentInfoTerraform$inboundSchema: z.ZodType<DeploymentInfoTerraform, unknown>;
export declare function deploymentInfoTerraformFromJSON(jsonString: string): SafeParseResult<DeploymentInfoTerraform, SDKValidationError>;
/** @internal */
export declare const Packages$inboundSchema: z.ZodType<Packages, unknown>;
export declare function packagesFromJSON(jsonString: string): SafeParseResult<Packages, SDKValidationError>;
/** @internal */
export declare const DeploymentInfo$inboundSchema: z.ZodType<DeploymentInfo, unknown>;
export declare function deploymentInfoFromJSON(jsonString: string): SafeParseResult<DeploymentInfo, SDKValidationError>;
//# sourceMappingURL=deploymentinfo.d.ts.map