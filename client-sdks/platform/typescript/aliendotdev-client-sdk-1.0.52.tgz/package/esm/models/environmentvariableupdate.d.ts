import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { EnvironmentVariableType } from "./environmentvariabletype.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type EnvironmentVariableUpdate = {
    /**
     * Environment variable key/name
     */
    key?: string | undefined;
    /**
     * Environment variable value
     */
    value?: string | undefined;
    /**
     * Variable type (plain or secret)
     */
    type?: EnvironmentVariableType | undefined;
    targetFunctions?: Array<string> | null | undefined;
    /**
     * Agent ID for agent-level variables. null or omitted for project-level
     */
    agentId?: string | null | undefined;
    /**
     * Optional comment describing the variable
     */
    comment?: string | null | undefined;
};
/** @internal */
export declare const EnvironmentVariableUpdate$inboundSchema: z.ZodType<EnvironmentVariableUpdate, z.ZodTypeDef, unknown>;
/** @internal */
export type EnvironmentVariableUpdate$Outbound = {
    key?: string | undefined;
    value?: string | undefined;
    type?: string | undefined;
    targetFunctions?: Array<string> | null | undefined;
    agentId?: string | null | undefined;
    comment?: string | null | undefined;
};
/** @internal */
export declare const EnvironmentVariableUpdate$outboundSchema: z.ZodType<EnvironmentVariableUpdate$Outbound, z.ZodTypeDef, EnvironmentVariableUpdate>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnvironmentVariableUpdate$ {
    /** @deprecated use `EnvironmentVariableUpdate$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnvironmentVariableUpdate, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnvironmentVariableUpdate$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnvironmentVariableUpdate$Outbound, z.ZodTypeDef, EnvironmentVariableUpdate>;
    /** @deprecated use `EnvironmentVariableUpdate$Outbound` instead. */
    type Outbound = EnvironmentVariableUpdate$Outbound;
}
export declare function environmentVariableUpdateToJSON(environmentVariableUpdate: EnvironmentVariableUpdate): string;
export declare function environmentVariableUpdateFromJSON(jsonString: string): SafeParseResult<EnvironmentVariableUpdate, SDKValidationError>;
//# sourceMappingURL=environmentvariableupdate.d.ts.map