import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Target platform for the agent
 */
export declare const ImportAgentRequestPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Target platform for the agent
 */
export type ImportAgentRequestPlatform = ClosedEnum<typeof ImportAgentRequestPlatform>;
export declare const ImportAgentRequestType: {
    readonly Cloudformation: "cloudformation";
};
export type ImportAgentRequestType = ClosedEnum<typeof ImportAgentRequestType>;
/**
 * Import source configuration
 */
export type Source = {
    type: ImportAgentRequestType;
    /**
     * CloudFormation stack name to import
     */
    stackName: string;
    /**
     * AWS region where the stack exists
     */
    region: string;
};
/**
 * Request schema for importing an agent from existing infrastructure
 */
export type ImportAgentRequest = {
    /**
     * Agent name.
     */
    name: string;
    /**
     * Target platform for the agent
     */
    platform: ImportAgentRequestPlatform;
    /**
     * ID of deployment group this agent belongs to
     */
    deploymentGroupId: string;
    /**
     * Project ID or name
     */
    project: string;
    /**
     * Agent manager ID (required for import operations)
     */
    agentManagerId: string;
    /**
     * Import source configuration
     */
    source: Source;
};
/** @internal */
export declare const ImportAgentRequestPlatform$outboundSchema: z.ZodEnum<typeof ImportAgentRequestPlatform>;
/** @internal */
export declare const ImportAgentRequestType$outboundSchema: z.ZodEnum<typeof ImportAgentRequestType>;
/** @internal */
export type Source$Outbound = {
    type: string;
    stackName: string;
    region: string;
};
/** @internal */
export declare const Source$outboundSchema: z.ZodType<Source$Outbound, Source>;
export declare function sourceToJSON(source: Source): string;
/** @internal */
export type ImportAgentRequest$Outbound = {
    name: string;
    platform: string;
    deploymentGroupId: string;
    project: string;
    agentManagerId: string;
    source: Source$Outbound;
};
/** @internal */
export declare const ImportAgentRequest$outboundSchema: z.ZodType<ImportAgentRequest$Outbound, ImportAgentRequest>;
export declare function importAgentRequestToJSON(importAgentRequest: ImportAgentRequest): string;
//# sourceMappingURL=importagentrequest.d.ts.map