import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Request to acquire deployment state
 */
export type AcquireDeploymentRequest = {
    /**
     * Unique session identifier (e.g., cli-hostname-uuid)
     */
    session: string;
    /**
     * Force acquire even if locked by another session (admin only)
     */
    force?: boolean | undefined;
    /**
     * Allow frozen resource changes during update (requires elevated permissions)
     */
    allowFrozenChanges?: boolean | undefined;
    /**
     * Set retry_requested flag if agent is in failed state
     */
    retry?: boolean | undefined;
    /**
     * Trigger redeployment if agent is running (with same release and fresh env vars)
     */
    redeploy?: boolean | undefined;
    /**
     * Allow acquisition for heartbeat/monitoring when agent is running (does not trigger redeployment)
     */
    heartbeat?: boolean | undefined;
};
/** @internal */
export declare const AcquireDeploymentRequest$inboundSchema: z.ZodType<AcquireDeploymentRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type AcquireDeploymentRequest$Outbound = {
    session: string;
    force?: boolean | undefined;
    allowFrozenChanges?: boolean | undefined;
    retry?: boolean | undefined;
    redeploy?: boolean | undefined;
    heartbeat?: boolean | undefined;
};
/** @internal */
export declare const AcquireDeploymentRequest$outboundSchema: z.ZodType<AcquireDeploymentRequest$Outbound, z.ZodTypeDef, AcquireDeploymentRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AcquireDeploymentRequest$ {
    /** @deprecated use `AcquireDeploymentRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AcquireDeploymentRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `AcquireDeploymentRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AcquireDeploymentRequest$Outbound, z.ZodTypeDef, AcquireDeploymentRequest>;
    /** @deprecated use `AcquireDeploymentRequest$Outbound` instead. */
    type Outbound = AcquireDeploymentRequest$Outbound;
}
export declare function acquireDeploymentRequestToJSON(acquireDeploymentRequest: AcquireDeploymentRequest): string;
export declare function acquireDeploymentRequestFromJSON(jsonString: string): SafeParseResult<AcquireDeploymentRequest, SDKValidationError>;
//# sourceMappingURL=acquiredeploymentrequest.d.ts.map