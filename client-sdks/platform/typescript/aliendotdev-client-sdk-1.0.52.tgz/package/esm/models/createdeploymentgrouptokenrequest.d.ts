import * as z from "zod/v4";
export type CreateDeploymentGroupTokenRequest = {
    /**
     * Description for the API key
     */
    description?: string | undefined;
};
/** @internal */
export type CreateDeploymentGroupTokenRequest$Outbound = {
    description?: string | undefined;
};
/** @internal */
export declare const CreateDeploymentGroupTokenRequest$outboundSchema: z.ZodType<CreateDeploymentGroupTokenRequest$Outbound, CreateDeploymentGroupTokenRequest>;
export declare function createDeploymentGroupTokenRequestToJSON(createDeploymentGroupTokenRequest: CreateDeploymentGroupTokenRequest): string;
//# sourceMappingURL=createdeploymentgrouptokenrequest.d.ts.map