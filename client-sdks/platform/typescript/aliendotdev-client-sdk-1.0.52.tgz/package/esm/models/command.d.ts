import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Command states in the ARC protocol lifecycle
 */
export declare const CommandState: {
    readonly PendingUpload: "PENDING_UPLOAD";
    readonly Pending: "PENDING";
    readonly Dispatched: "DISPATCHED";
    readonly Succeeded: "SUCCEEDED";
    readonly Failed: "FAILED";
    readonly Expired: "EXPIRED";
};
/**
 * Command states in the ARC protocol lifecycle
 */
export type CommandState = ClosedEnum<typeof CommandState>;
/**
 * Deployment model captured from agent at creation time
 */
export declare const CommandDeploymentModel: {
    readonly Push: "push";
    readonly Pull: "pull";
};
/**
 * Deployment model captured from agent at creation time
 */
export type CommandDeploymentModel = ClosedEnum<typeof CommandDeploymentModel>;
export type Command = {
    /**
     * Unique identifier for the command.
     */
    id: string;
    /**
     * Unique identifier for the agent.
     */
    agentId: string;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    /**
     * Command name (e.g., 'analyze-repository', 'sync-data')
     */
    name: string;
    /**
     * Command states in the ARC protocol lifecycle
     */
    state: CommandState;
    /**
     * Deployment model captured from agent at creation time
     */
    deploymentModel: CommandDeploymentModel;
    /**
     * Current attempt number
     */
    attempt: number | null;
    /**
     * Optional deadline for command execution
     */
    deadline: Date | null;
    /**
     * Size of command params in bytes
     */
    requestSizeBytes: number | null;
    /**
     * Size of command response in bytes
     */
    responseSizeBytes: number | null;
    /**
     * When the command was created
     */
    createdAt: Date;
    /**
     * When the command was dispatched to the agent
     */
    dispatchedAt: Date | null;
    /**
     * When the command completed
     */
    completedAt: Date | null;
    /**
     * Error details if command failed
     */
    error: {
        [k: string]: any | null;
    } | null;
};
/** @internal */
export declare const CommandState$inboundSchema: z.ZodEnum<typeof CommandState>;
/** @internal */
export declare const CommandDeploymentModel$inboundSchema: z.ZodEnum<typeof CommandDeploymentModel>;
/** @internal */
export declare const Command$inboundSchema: z.ZodType<Command, unknown>;
export declare function commandFromJSON(jsonString: string): SafeParseResult<Command, SDKValidationError>;
//# sourceMappingURL=command.d.ts.map