import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const DeploymentContextCurrentStackManagementEnum: {
    readonly Auto: "auto";
};
export type DeploymentContextCurrentStackManagementEnum = ClosedEnum<typeof DeploymentContextCurrentStackManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextCurrentStackOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextCurrentStackOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextCurrentStackOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextCurrentStackOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextCurrentStackOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextCurrentStackOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextCurrentStackOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextCurrentStackOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextCurrentStackOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextCurrentStackOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextCurrentStackOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextCurrentStackOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextCurrentStackOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextCurrentStackOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextCurrentStackOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextCurrentStackOverrideUnion = DeploymentContextCurrentStackOverride | string;
export type DeploymentContextCurrentStackManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<DeploymentContextCurrentStackOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextCurrentStackExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextCurrentStackExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextCurrentStackExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextCurrentStackExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextCurrentStackExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextCurrentStackExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextCurrentStackExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextCurrentStackExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextCurrentStackExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextCurrentStackExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextCurrentStackExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextCurrentStackExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextCurrentStackExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextCurrentStackExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextCurrentStackExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextCurrentStackExtendUnion = DeploymentContextCurrentStackExtend | string;
export type DeploymentContextCurrentStackManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<DeploymentContextCurrentStackExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type DeploymentContextCurrentStackManagementUnion = DeploymentContextCurrentStackManagement1 | DeploymentContextCurrentStackManagement2 | DeploymentContextCurrentStackManagementEnum;
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextCurrentStackProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextCurrentStackProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextCurrentStackProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextCurrentStackProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextCurrentStackProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextCurrentStackProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextCurrentStackProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextCurrentStackProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextCurrentStackProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextCurrentStackProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextCurrentStackProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextCurrentStackProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextCurrentStackProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextCurrentStackProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextCurrentStackProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextCurrentStackProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextCurrentStackProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextCurrentStackProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextCurrentStackProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextCurrentStackProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextCurrentStackProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextCurrentStackProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextCurrentStackProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextCurrentStackProfileUnion = DeploymentContextCurrentStackProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type DeploymentContextCurrentStackPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: DeploymentContextCurrentStackManagement1 | DeploymentContextCurrentStackManagement2 | DeploymentContextCurrentStackManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<DeploymentContextCurrentStackProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type DeploymentContextCurrentStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type DeploymentContextCurrentStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const DeploymentContextCurrentStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type DeploymentContextCurrentStackLifecycle = ClosedEnum<typeof DeploymentContextCurrentStackLifecycle>;
export type DeploymentContextCurrentStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: DeploymentContextCurrentStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<DeploymentContextCurrentStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: DeploymentContextCurrentStackLifecycle;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type DeploymentContextCurrentStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: DeploymentContextCurrentStackPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: DeploymentContextCurrentStackResources;
    };
};
export declare const DeploymentContextPlatformLocal: {
    readonly Local: "local";
};
export type DeploymentContextPlatformLocal = ClosedEnum<typeof DeploymentContextPlatformLocal>;
/**
 * Local platform environment information
 */
export type DeploymentContextEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: DeploymentContextPlatformLocal;
};
export declare const DeploymentContextEnvironmentInfoPlatformAzure: {
    readonly Azure: "azure";
};
export type DeploymentContextEnvironmentInfoPlatformAzure = ClosedEnum<typeof DeploymentContextEnvironmentInfoPlatformAzure>;
/**
 * Azure-specific environment information
 */
export type DeploymentContextEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: DeploymentContextEnvironmentInfoPlatformAzure;
};
export declare const DeploymentContextEnvironmentInfoPlatformGcp: {
    readonly Gcp: "gcp";
};
export type DeploymentContextEnvironmentInfoPlatformGcp = ClosedEnum<typeof DeploymentContextEnvironmentInfoPlatformGcp>;
/**
 * GCP-specific environment information
 */
export type DeploymentContextEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: DeploymentContextEnvironmentInfoPlatformGcp;
};
export declare const DeploymentContextEnvironmentInfoPlatformAws: {
    readonly Aws: "aws";
};
export type DeploymentContextEnvironmentInfoPlatformAws = ClosedEnum<typeof DeploymentContextEnvironmentInfoPlatformAws>;
/**
 * AWS-specific environment information
 */
export type DeploymentContextEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: DeploymentContextEnvironmentInfoPlatformAws;
};
/**
 * Represents the target cloud platform.
 */
export declare const DeploymentContextCurrentPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type DeploymentContextCurrentPlatform = ClosedEnum<typeof DeploymentContextCurrentPlatform>;
export declare const DeploymentContextPreparedStackManagementEnum: {
    readonly Auto: "auto";
};
export type DeploymentContextPreparedStackManagementEnum = ClosedEnum<typeof DeploymentContextPreparedStackManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextPreparedStackOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextPreparedStackOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextPreparedStackOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextPreparedStackOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextPreparedStackOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextPreparedStackOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextPreparedStackOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextPreparedStackOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextPreparedStackOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextPreparedStackOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextPreparedStackOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextPreparedStackOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextPreparedStackOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextPreparedStackOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextPreparedStackOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextPreparedStackOverrideUnion = DeploymentContextPreparedStackOverride | string;
export type DeploymentContextPreparedStackManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<DeploymentContextPreparedStackOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextPreparedStackExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextPreparedStackExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextPreparedStackExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextPreparedStackExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextPreparedStackExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextPreparedStackExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextPreparedStackExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextPreparedStackExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextPreparedStackExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextPreparedStackExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextPreparedStackExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextPreparedStackExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextPreparedStackExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextPreparedStackExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextPreparedStackExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextPreparedStackExtendUnion = DeploymentContextPreparedStackExtend | string;
export type DeploymentContextPreparedStackManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<DeploymentContextPreparedStackExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type DeploymentContextPreparedStackManagementUnion = DeploymentContextPreparedStackManagement1 | DeploymentContextPreparedStackManagement2 | DeploymentContextPreparedStackManagementEnum;
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type DeploymentContextPreparedStackProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: DeploymentContextPreparedStackProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: DeploymentContextPreparedStackProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type DeploymentContextPreparedStackProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type DeploymentContextPreparedStackProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: DeploymentContextPreparedStackProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: DeploymentContextPreparedStackProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type DeploymentContextPreparedStackProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type DeploymentContextPreparedStackProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type DeploymentContextPreparedStackProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type DeploymentContextPreparedStackProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: DeploymentContextPreparedStackProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: DeploymentContextPreparedStackProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type DeploymentContextPreparedStackProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type DeploymentContextPreparedStackProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: DeploymentContextPreparedStackProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: DeploymentContextPreparedStackProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type DeploymentContextPreparedStackProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<DeploymentContextPreparedStackProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<DeploymentContextPreparedStackProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<DeploymentContextPreparedStackProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type DeploymentContextPreparedStackProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: DeploymentContextPreparedStackProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type DeploymentContextPreparedStackProfileUnion = DeploymentContextPreparedStackProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type DeploymentContextPreparedStackPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: DeploymentContextPreparedStackManagement1 | DeploymentContextPreparedStackManagement2 | DeploymentContextPreparedStackManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<DeploymentContextPreparedStackProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type DeploymentContextPreparedStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type DeploymentContextPreparedStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const DeploymentContextPreparedStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type DeploymentContextPreparedStackLifecycle = ClosedEnum<typeof DeploymentContextPreparedStackLifecycle>;
export type DeploymentContextPreparedStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: DeploymentContextPreparedStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<DeploymentContextPreparedStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: DeploymentContextPreparedStackLifecycle;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type DeploymentContextPreparedStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: DeploymentContextPreparedStackPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: DeploymentContextPreparedStackResources;
    };
};
/**
 * Runtime metadata for deployment
 *
 * @remarks
 *
 * Stores deployment state that needs to persist across step calls.
 */
export type DeploymentContextRuntimeMetadata = {
    /**
     * Hash of the environment variables snapshot that was last synced to the vault
     *
     * @remarks
     * Used to avoid redundant sync operations during incremental deployment
     */
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const DeploymentContextStackStatePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type DeploymentContextStackStatePlatform = ClosedEnum<typeof DeploymentContextStackStatePlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type DeploymentContextStackStateConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type DeploymentContextStackStateDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type DeploymentContextError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable?: boolean | undefined;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const DeploymentContextStackStateLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type DeploymentContextStackStateLifecycle = ClosedEnum<typeof DeploymentContextStackStateLifecycle>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type DeploymentContextOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type DeploymentContextPreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const DeploymentContextStackStateStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type DeploymentContextStackStateStatus = ClosedEnum<typeof DeploymentContextStackStateStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type DeploymentContextStackStateResources = {
    internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: DeploymentContextStackStateConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<DeploymentContextStackStateDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: DeploymentContextStackStateStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * Represents the target cloud platform.
 */
export declare const DeploymentContextKubernetesInfrastructurePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type DeploymentContextKubernetesInfrastructurePlatform = ClosedEnum<typeof DeploymentContextKubernetesInfrastructurePlatform>;
export declare const DeploymentContextStackStatePlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type DeploymentContextStackStatePlatformKubernetes = ClosedEnum<typeof DeploymentContextStackStatePlatformKubernetes>;
export type DeploymentContextManagementKubernetes = {
    platform: DeploymentContextStackStatePlatformKubernetes;
};
/**
 * Image pull credentials for container registries
 */
export type DeploymentContextImagePullCredentialsCurrent = {
    /**
     * Password for the container registry
     */
    password: string;
    /**
     * Username for the container registry
     */
    username: string;
};
export declare const DeploymentContextStackStatePlatformAzure: {
    readonly Azure: "azure";
};
export type DeploymentContextStackStatePlatformAzure = ClosedEnum<typeof DeploymentContextStackStatePlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type DeploymentContextManagementAzure = {
    imagePullCredentials?: any | null | undefined;
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: DeploymentContextStackStatePlatformAzure;
};
export declare const DeploymentContextStackStatePlatformGcp: {
    readonly Gcp: "gcp";
};
export type DeploymentContextStackStatePlatformGcp = ClosedEnum<typeof DeploymentContextStackStatePlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type DeploymentContextManagementGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: DeploymentContextStackStatePlatformGcp;
};
export declare const DeploymentContextStackStatePlatformAws: {
    readonly Aws: "aws";
};
export type DeploymentContextStackStatePlatformAws = ClosedEnum<typeof DeploymentContextStackStatePlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type DeploymentContextManagementAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: DeploymentContextStackStatePlatformAws;
};
/**
 * Remote capabilities configuration for agents
 */
export type DeploymentContextCurrentRemoteCapabilities = {
    /**
     * Whether the agent supports automatic updates
     */
    autoUpdates: boolean;
    /**
     * Whether the agent supports heartbeat functionality
     */
    heartbeat: boolean;
    /**
     * Whether the agent supports monitoring
     */
    monitoring: boolean;
};
/**
 * Stack-level settings that customize deployment behavior
 */
export type DeploymentContextSettings = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    /**
     * Remote capabilities configuration for agents
     */
    remoteCapabilities: DeploymentContextCurrentRemoteCapabilities;
};
/**
 * Represents the collective state of all resources in a stack, including platform and pending actions.
 */
export type DeploymentContextStackState = {
    /**
     * Represents the target cloud platform.
     */
    platform: DeploymentContextStackStatePlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: DeploymentContextStackStateResources;
    };
    /**
     * Stack-level settings that customize deployment behavior
     */
    settings: DeploymentContextSettings;
};
/**
 * Deployment status in the deployment lifecycle
 */
export declare const DeploymentContextStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type DeploymentContextStatus = ClosedEnum<typeof DeploymentContextStatus>;
/**
 * Current deployment state
 */
export type DeploymentContextCurrent = {
    currentStack?: any | null | undefined;
    environmentInfo?: any | null | undefined;
    /**
     * Represents the target cloud platform.
     */
    platform: DeploymentContextCurrentPlatform;
    /**
     * Whether a retry has been requested for a failed deployment
     *
     * @remarks
     * When true and status is a failed state, the deployment system will retry failed resources
     */
    retryRequested?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    /**
     * Deployment status in the deployment lifecycle
     */
    status: DeploymentContextStatus;
};
export declare const ManagementTargetStackEnum: {
    readonly Auto: "auto";
};
export type ManagementTargetStackEnum = ClosedEnum<typeof ManagementTargetStackEnum>;
/**
 * AWS-specific binding specification
 */
export type OverrideTargetStackAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type OverrideTargetStackAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type OverrideTargetStackAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: OverrideTargetStackAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: OverrideTargetStackAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type OverrideTargetStackAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type OverrideTargetStackAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: OverrideTargetStackAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: OverrideTargetStackAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type OverrideTargetStackAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type OverrideTargetStackAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type OverrideTargetStackAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: OverrideTargetStackAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: OverrideTargetStackAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type OverrideTargetStackAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type OverrideTargetStackAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: OverrideTargetStackAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: OverrideTargetStackAzureGrant;
};
/**
 * GCP IAM condition
 */
export type OverrideConditionTargetStackResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type OverrideTargetStackGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type OverrideConditionTargetStackStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type OverrideTargetStackGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type OverrideTargetStackGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: OverrideTargetStackGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: OverrideTargetStackGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type OverrideTargetStackGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type OverrideTargetStackGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: OverrideTargetStackGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: OverrideTargetStackGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type OverrideTargetStackPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<OverrideTargetStackAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<OverrideTargetStackAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<OverrideTargetStackGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type OverrideTargetStack = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: OverrideTargetStackPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type TargetStackOverrideUnion = OverrideTargetStack | string;
export type ManagementTargetStack2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<OverrideTargetStack | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type ExtendTargetStackAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ExtendTargetStackAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ExtendTargetStackAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ExtendTargetStackAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ExtendTargetStackAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ExtendTargetStackAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ExtendTargetStackAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ExtendTargetStackAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ExtendTargetStackAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ExtendTargetStackAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ExtendTargetStackAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ExtendTargetStackAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ExtendTargetStackAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ExtendTargetStackAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ExtendTargetStackAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ExtendTargetStackAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ExtendTargetStackAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ExtendTargetStackAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ExtendConditionTargetStackResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ExtendTargetStackGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ExtendConditionTargetStackStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ExtendTargetStackGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ExtendTargetStackGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ExtendTargetStackGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ExtendTargetStackGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ExtendTargetStackGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ExtendTargetStackGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ExtendTargetStackGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ExtendTargetStackGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ExtendTargetStackPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ExtendTargetStackAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ExtendTargetStackAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ExtendTargetStackGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ExtendTargetStack = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ExtendTargetStackPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type TargetStackExtendUnion = ExtendTargetStack | string;
export type ManagementTargetStack1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<ExtendTargetStack | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type TargetStackManagementUnion = ManagementTargetStack1 | ManagementTargetStack2 | ManagementTargetStackEnum;
/**
 * AWS-specific binding specification
 */
export type ProfileTargetStackAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ProfileTargetStackAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ProfileTargetStackAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ProfileTargetStackAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ProfileTargetStackAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ProfileTargetStackAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ProfileTargetStackAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ProfileTargetStackAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ProfileTargetStackAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ProfileTargetStackAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ProfileTargetStackAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ProfileTargetStackAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ProfileTargetStackAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ProfileTargetStackAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ProfileTargetStackAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ProfileTargetStackAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ProfileTargetStackAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ProfileTargetStackAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ProfileConditionTargetStackResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ProfileTargetStackGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ProfileConditionTargetStackStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ProfileTargetStackGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ProfileTargetStackGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ProfileTargetStackGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ProfileTargetStackGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ProfileTargetStackGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ProfileTargetStackGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ProfileTargetStackGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ProfileTargetStackGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ProfileTargetStackPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ProfileTargetStackAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ProfileTargetStackAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ProfileTargetStackGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ProfileTargetStack = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ProfileTargetStackPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type TargetStackProfileUnion = ProfileTargetStack | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type TargetStackPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: ManagementTargetStack1 | ManagementTargetStack2 | ManagementTargetStackEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<ProfileTargetStack | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type TargetStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type TargetStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const TargetStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type TargetStackLifecycle = ClosedEnum<typeof TargetStackLifecycle>;
export type TargetStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: TargetStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<TargetStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: TargetStackLifecycle;
};
/**
 * Target stack to deploy
 */
export type TargetStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: TargetStackPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: TargetStackResources;
    };
};
/**
 * Artifact registry configuration for pulling container images.
 *
 * @remarks
 *
 * Used when the agent needs to pull images from an agent manager's artifact registry.
 * This is required for Local platform and can optionally be used by cloud platforms
 * instead of native registry mechanisms (ECR/GCR/ACR).
 */
export type ArtifactRegistry = {
    /**
     * Agent manager base URL for fetching credentials and accessing the registry
     */
    agentManagerUrl: string;
    /**
     * Optional authentication token (JWT) for agent manager API access
     *
     * @remarks
     * When present, must be included in Authorization header as "Bearer {token}"
     */
    authToken?: string | null | undefined;
};
/**
 * Type of environment variable
 */
export declare const DeploymentContextType: {
    readonly Plain: "plain";
    readonly Secret: "secret";
};
/**
 * Type of environment variable
 */
export type DeploymentContextType = ClosedEnum<typeof DeploymentContextType>;
/**
 * Environment variable for deployment
 */
export type DeploymentContextVariable = {
    /**
     * Variable name
     */
    name: string;
    /**
     * Target function patterns (null = all functions, Some = wildcard patterns)
     */
    targetFunctions?: Array<string> | null | undefined;
    /**
     * Type of environment variable
     */
    type: DeploymentContextType;
    /**
     * Variable value (decrypted - deployment has access to decryption keys)
     */
    value: string;
};
/**
 * Snapshot of environment variables at a point in time
 */
export type EnvironmentVariables = {
    /**
     * ISO 8601 timestamp when snapshot was created
     */
    createdAt: string;
    /**
     * Deterministic hash of all variables (for change detection)
     */
    hash: string;
    /**
     * Environment variables in the snapshot
     */
    variables: Array<DeploymentContextVariable>;
};
export declare const ManagementConfigPlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type ManagementConfigPlatformKubernetes = ClosedEnum<typeof ManagementConfigPlatformKubernetes>;
export type ManagementConfigKubernetes = {
    platform: ManagementConfigPlatformKubernetes;
};
/**
 * Image pull credentials for container registries
 */
export type ManagementConfigImagePullCredentials = {
    /**
     * Password for the container registry
     */
    password: string;
    /**
     * Username for the container registry
     */
    username: string;
};
export declare const ManagementConfigPlatformAzure: {
    readonly Azure: "azure";
};
export type ManagementConfigPlatformAzure = ClosedEnum<typeof ManagementConfigPlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type ManagementConfigAzure = {
    imagePullCredentials?: any | null | undefined;
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: ManagementConfigPlatformAzure;
};
export declare const ManagementConfigPlatformGcp: {
    readonly Gcp: "gcp";
};
export type ManagementConfigPlatformGcp = ClosedEnum<typeof ManagementConfigPlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type ManagementConfigGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: ManagementConfigPlatformGcp;
};
export declare const ManagementConfigPlatformAws: {
    readonly Aws: "aws";
};
export type ManagementConfigPlatformAws = ClosedEnum<typeof ManagementConfigPlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type ManagementConfigAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: ManagementConfigPlatformAws;
};
/**
 * Remote capabilities configuration for agents
 */
export type ConfigRemoteCapabilities = {
    /**
     * Whether the agent supports automatic updates
     */
    autoUpdates: boolean;
    /**
     * Whether the agent supports heartbeat functionality
     */
    heartbeat: boolean;
    /**
     * Whether the agent supports monitoring
     */
    monitoring: boolean;
};
/**
 * Deployment configuration
 */
export type DeploymentContextConfig = {
    /**
     * Allow frozen resource changes during updates
     *
     * @remarks
     * When true, skips the frozen resources compatibility check.
     * This requires running with elevated cloud credentials.
     */
    allowFrozenChanges?: boolean | undefined;
    artifactRegistry?: any | null | undefined;
    /**
     * Snapshot of environment variables at a point in time
     */
    environmentVariables: EnvironmentVariables;
    managementConfig?: any | null | undefined;
    /**
     * Remote capabilities configuration for agents
     */
    remoteCapabilities: ConfigRemoteCapabilities;
};
/**
 * Deployment context
 */
export type DeploymentContext = {
    /**
     * Current deployment state
     */
    current: DeploymentContextCurrent;
    /**
     * Target stack to deploy
     */
    targetStack: TargetStack;
    /**
     * Deployment configuration
     */
    config: DeploymentContextConfig;
    /**
     * Session that holds the lock
     */
    session: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackManagementEnum$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentStackManagementEnum>;
/** @internal */
export declare const DeploymentContextCurrentStackManagementEnum$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentStackManagementEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackManagementEnum$ {
    /** @deprecated use `DeploymentContextCurrentStackManagementEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `DeploymentContextCurrentStackManagementEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAwResource$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwResource>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAwResource$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAwResourceToJSON(deploymentContextCurrentStackOverrideAwResource: DeploymentContextCurrentStackOverrideAwResource): string;
export declare function deploymentContextCurrentStackOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAwStack$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwStack>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAwStack$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAwStackToJSON(deploymentContextCurrentStackOverrideAwStack: DeploymentContextCurrentStackOverrideAwStack): string;
export declare function deploymentContextCurrentStackOverrideAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAwBinding$Outbound = {
    resource?: DeploymentContextCurrentStackOverrideAwResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackOverrideAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAwBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwBinding>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAwBinding$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAwBindingToJSON(deploymentContextCurrentStackOverrideAwBinding: DeploymentContextCurrentStackOverrideAwBinding): string;
export declare function deploymentContextCurrentStackOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAwGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAwGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAwGrant>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAwGrant$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAwGrantToJSON(deploymentContextCurrentStackOverrideAwGrant: DeploymentContextCurrentStackOverrideAwGrant): string;
export declare function deploymentContextCurrentStackOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAw$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAw$Outbound = {
    binding: DeploymentContextCurrentStackOverrideAwBinding$Outbound;
    grant: DeploymentContextCurrentStackOverrideAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAw$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAw$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAw>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAw$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAw$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAwToJSON(deploymentContextCurrentStackOverrideAw: DeploymentContextCurrentStackOverrideAw): string;
export declare function deploymentContextCurrentStackOverrideAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAzureResource$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureResource>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAzureResource$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAzureResourceToJSON(deploymentContextCurrentStackOverrideAzureResource: DeploymentContextCurrentStackOverrideAzureResource): string;
export declare function deploymentContextCurrentStackOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAzureStack$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureStack>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAzureStack$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAzureStackToJSON(deploymentContextCurrentStackOverrideAzureStack: DeploymentContextCurrentStackOverrideAzureStack): string;
export declare function deploymentContextCurrentStackOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAzureBinding$Outbound = {
    resource?: DeploymentContextCurrentStackOverrideAzureResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackOverrideAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAzureBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureBinding>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAzureBinding$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAzureBindingToJSON(deploymentContextCurrentStackOverrideAzureBinding: DeploymentContextCurrentStackOverrideAzureBinding): string;
export declare function deploymentContextCurrentStackOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzureGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAzureGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzureGrant>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAzureGrant$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAzureGrantToJSON(deploymentContextCurrentStackOverrideAzureGrant: DeploymentContextCurrentStackOverrideAzureGrant): string;
export declare function deploymentContextCurrentStackOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzure$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideAzure$Outbound = {
    binding: DeploymentContextCurrentStackOverrideAzureBinding$Outbound;
    grant: DeploymentContextCurrentStackOverrideAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideAzure$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideAzure$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideAzure>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideAzure$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideAzure$Outbound;
}
export declare function deploymentContextCurrentStackOverrideAzureToJSON(deploymentContextCurrentStackOverrideAzure: DeploymentContextCurrentStackOverrideAzure): string;
export declare function deploymentContextCurrentStackOverrideAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideConditionResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideConditionResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideConditionResource$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideConditionResource>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideConditionResource$Outbound;
}
export declare function deploymentContextCurrentStackOverrideConditionResourceToJSON(deploymentContextCurrentStackOverrideConditionResource: DeploymentContextCurrentStackOverrideConditionResource): string;
export declare function deploymentContextCurrentStackOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideGcpResource$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpResource>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideGcpResource$Outbound;
}
export declare function deploymentContextCurrentStackOverrideGcpResourceToJSON(deploymentContextCurrentStackOverrideGcpResource: DeploymentContextCurrentStackOverrideGcpResource): string;
export declare function deploymentContextCurrentStackOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideConditionStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideConditionStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideConditionStack$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideConditionStack>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideConditionStack$Outbound;
}
export declare function deploymentContextCurrentStackOverrideConditionStackToJSON(deploymentContextCurrentStackOverrideConditionStack: DeploymentContextCurrentStackOverrideConditionStack): string;
export declare function deploymentContextCurrentStackOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideGcpStack$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpStack>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideGcpStack$Outbound;
}
export declare function deploymentContextCurrentStackOverrideGcpStackToJSON(deploymentContextCurrentStackOverrideGcpStack: DeploymentContextCurrentStackOverrideGcpStack): string;
export declare function deploymentContextCurrentStackOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideGcpBinding$Outbound = {
    resource?: DeploymentContextCurrentStackOverrideGcpResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackOverrideGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideGcpBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpBinding>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideGcpBinding$Outbound;
}
export declare function deploymentContextCurrentStackOverrideGcpBindingToJSON(deploymentContextCurrentStackOverrideGcpBinding: DeploymentContextCurrentStackOverrideGcpBinding): string;
export declare function deploymentContextCurrentStackOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcpGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideGcpGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcpGrant>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideGcpGrant$Outbound;
}
export declare function deploymentContextCurrentStackOverrideGcpGrantToJSON(deploymentContextCurrentStackOverrideGcpGrant: DeploymentContextCurrentStackOverrideGcpGrant): string;
export declare function deploymentContextCurrentStackOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcp$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideGcp$Outbound = {
    binding: DeploymentContextCurrentStackOverrideGcpBinding$Outbound;
    grant: DeploymentContextCurrentStackOverrideGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverrideGcp$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideGcp$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideGcp>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideGcp$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideGcp$Outbound;
}
export declare function deploymentContextCurrentStackOverrideGcpToJSON(deploymentContextCurrentStackOverrideGcp: DeploymentContextCurrentStackOverrideGcp): string;
export declare function deploymentContextCurrentStackOverrideGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverridePlatforms$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverridePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverridePlatforms$Outbound = {
    aws?: Array<DeploymentContextCurrentStackOverrideAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextCurrentStackOverrideAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextCurrentStackOverrideGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverridePlatforms$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverridePlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverridePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverridePlatforms$ {
    /** @deprecated use `DeploymentContextCurrentStackOverridePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverridePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverridePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverridePlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverridePlatforms>;
    /** @deprecated use `DeploymentContextCurrentStackOverridePlatforms$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverridePlatforms$Outbound;
}
export declare function deploymentContextCurrentStackOverridePlatformsToJSON(deploymentContextCurrentStackOverridePlatforms: DeploymentContextCurrentStackOverridePlatforms): string;
export declare function deploymentContextCurrentStackOverridePlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverride$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverride, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverride$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextCurrentStackOverridePlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackOverride$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverride$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverride>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverride$ {
    /** @deprecated use `DeploymentContextCurrentStackOverride$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverride, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverride$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverride$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverride>;
    /** @deprecated use `DeploymentContextCurrentStackOverride$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverride$Outbound;
}
export declare function deploymentContextCurrentStackOverrideToJSON(deploymentContextCurrentStackOverride: DeploymentContextCurrentStackOverride): string;
export declare function deploymentContextCurrentStackOverrideFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverride, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideUnion$inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackOverrideUnion$Outbound = DeploymentContextCurrentStackOverride$Outbound | string;
/** @internal */
export declare const DeploymentContextCurrentStackOverrideUnion$outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackOverrideUnion$ {
    /** @deprecated use `DeploymentContextCurrentStackOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackOverrideUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackOverrideUnion>;
    /** @deprecated use `DeploymentContextCurrentStackOverrideUnion$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackOverrideUnion$Outbound;
}
export declare function deploymentContextCurrentStackOverrideUnionToJSON(deploymentContextCurrentStackOverrideUnion: DeploymentContextCurrentStackOverrideUnion): string;
export declare function deploymentContextCurrentStackOverrideUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackOverrideUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackManagement2$inboundSchema: z.ZodType<DeploymentContextCurrentStackManagement2, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackManagement2$Outbound = {
    override: {
        [k: string]: Array<DeploymentContextCurrentStackOverride$Outbound | string>;
    };
};
/** @internal */
export declare const DeploymentContextCurrentStackManagement2$outboundSchema: z.ZodType<DeploymentContextCurrentStackManagement2$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagement2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackManagement2$ {
    /** @deprecated use `DeploymentContextCurrentStackManagement2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackManagement2, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackManagement2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackManagement2$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagement2>;
    /** @deprecated use `DeploymentContextCurrentStackManagement2$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackManagement2$Outbound;
}
export declare function deploymentContextCurrentStackManagement2ToJSON(deploymentContextCurrentStackManagement2: DeploymentContextCurrentStackManagement2): string;
export declare function deploymentContextCurrentStackManagement2FromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackManagement2, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAwResource$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwResource>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAwResource$Outbound;
}
export declare function deploymentContextCurrentStackExtendAwResourceToJSON(deploymentContextCurrentStackExtendAwResource: DeploymentContextCurrentStackExtendAwResource): string;
export declare function deploymentContextCurrentStackExtendAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAwStack$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwStack>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAwStack$Outbound;
}
export declare function deploymentContextCurrentStackExtendAwStackToJSON(deploymentContextCurrentStackExtendAwStack: DeploymentContextCurrentStackExtendAwStack): string;
export declare function deploymentContextCurrentStackExtendAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAwBinding$Outbound = {
    resource?: DeploymentContextCurrentStackExtendAwResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackExtendAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAwBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwBinding>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAwBinding$Outbound;
}
export declare function deploymentContextCurrentStackExtendAwBindingToJSON(deploymentContextCurrentStackExtendAwBinding: DeploymentContextCurrentStackExtendAwBinding): string;
export declare function deploymentContextCurrentStackExtendAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAwGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAwGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAwGrant>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAwGrant$Outbound;
}
export declare function deploymentContextCurrentStackExtendAwGrantToJSON(deploymentContextCurrentStackExtendAwGrant: DeploymentContextCurrentStackExtendAwGrant): string;
export declare function deploymentContextCurrentStackExtendAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAw$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAw$Outbound = {
    binding: DeploymentContextCurrentStackExtendAwBinding$Outbound;
    grant: DeploymentContextCurrentStackExtendAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAw$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAw$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAw>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAw$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAw$Outbound;
}
export declare function deploymentContextCurrentStackExtendAwToJSON(deploymentContextCurrentStackExtendAw: DeploymentContextCurrentStackExtendAw): string;
export declare function deploymentContextCurrentStackExtendAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAzureResource$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureResource>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAzureResource$Outbound;
}
export declare function deploymentContextCurrentStackExtendAzureResourceToJSON(deploymentContextCurrentStackExtendAzureResource: DeploymentContextCurrentStackExtendAzureResource): string;
export declare function deploymentContextCurrentStackExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAzureStack$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureStack>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAzureStack$Outbound;
}
export declare function deploymentContextCurrentStackExtendAzureStackToJSON(deploymentContextCurrentStackExtendAzureStack: DeploymentContextCurrentStackExtendAzureStack): string;
export declare function deploymentContextCurrentStackExtendAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAzureBinding$Outbound = {
    resource?: DeploymentContextCurrentStackExtendAzureResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackExtendAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAzureBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureBinding>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAzureBinding$Outbound;
}
export declare function deploymentContextCurrentStackExtendAzureBindingToJSON(deploymentContextCurrentStackExtendAzureBinding: DeploymentContextCurrentStackExtendAzureBinding): string;
export declare function deploymentContextCurrentStackExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzureGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAzureGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzureGrant>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAzureGrant$Outbound;
}
export declare function deploymentContextCurrentStackExtendAzureGrantToJSON(deploymentContextCurrentStackExtendAzureGrant: DeploymentContextCurrentStackExtendAzureGrant): string;
export declare function deploymentContextCurrentStackExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzure$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendAzure$Outbound = {
    binding: DeploymentContextCurrentStackExtendAzureBinding$Outbound;
    grant: DeploymentContextCurrentStackExtendAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendAzure$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendAzure$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendAzure>;
    /** @deprecated use `DeploymentContextCurrentStackExtendAzure$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendAzure$Outbound;
}
export declare function deploymentContextCurrentStackExtendAzureToJSON(deploymentContextCurrentStackExtendAzure: DeploymentContextCurrentStackExtendAzure): string;
export declare function deploymentContextCurrentStackExtendAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendConditionResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendConditionResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendConditionResource$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendConditionResource>;
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendConditionResource$Outbound;
}
export declare function deploymentContextCurrentStackExtendConditionResourceToJSON(deploymentContextCurrentStackExtendConditionResource: DeploymentContextCurrentStackExtendConditionResource): string;
export declare function deploymentContextCurrentStackExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendGcpResource$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpResource>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendGcpResource$Outbound;
}
export declare function deploymentContextCurrentStackExtendGcpResourceToJSON(deploymentContextCurrentStackExtendGcpResource: DeploymentContextCurrentStackExtendGcpResource): string;
export declare function deploymentContextCurrentStackExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendConditionStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendConditionStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendConditionStack$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendConditionStack>;
    /** @deprecated use `DeploymentContextCurrentStackExtendConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendConditionStack$Outbound;
}
export declare function deploymentContextCurrentStackExtendConditionStackToJSON(deploymentContextCurrentStackExtendConditionStack: DeploymentContextCurrentStackExtendConditionStack): string;
export declare function deploymentContextCurrentStackExtendConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendGcpStack$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpStack>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendGcpStack$Outbound;
}
export declare function deploymentContextCurrentStackExtendGcpStackToJSON(deploymentContextCurrentStackExtendGcpStack: DeploymentContextCurrentStackExtendGcpStack): string;
export declare function deploymentContextCurrentStackExtendGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendGcpBinding$Outbound = {
    resource?: DeploymentContextCurrentStackExtendGcpResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackExtendGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendGcpBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpBinding>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendGcpBinding$Outbound;
}
export declare function deploymentContextCurrentStackExtendGcpBindingToJSON(deploymentContextCurrentStackExtendGcpBinding: DeploymentContextCurrentStackExtendGcpBinding): string;
export declare function deploymentContextCurrentStackExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcpGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendGcpGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcpGrant>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendGcpGrant$Outbound;
}
export declare function deploymentContextCurrentStackExtendGcpGrantToJSON(deploymentContextCurrentStackExtendGcpGrant: DeploymentContextCurrentStackExtendGcpGrant): string;
export declare function deploymentContextCurrentStackExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcp$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendGcp$Outbound = {
    binding: DeploymentContextCurrentStackExtendGcpBinding$Outbound;
    grant: DeploymentContextCurrentStackExtendGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendGcp$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendGcp$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendGcp>;
    /** @deprecated use `DeploymentContextCurrentStackExtendGcp$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendGcp$Outbound;
}
export declare function deploymentContextCurrentStackExtendGcpToJSON(deploymentContextCurrentStackExtendGcp: DeploymentContextCurrentStackExtendGcp): string;
export declare function deploymentContextCurrentStackExtendGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendPlatforms$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendPlatforms$Outbound = {
    aws?: Array<DeploymentContextCurrentStackExtendAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextCurrentStackExtendAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextCurrentStackExtendGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtendPlatforms$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendPlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendPlatforms$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendPlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendPlatforms>;
    /** @deprecated use `DeploymentContextCurrentStackExtendPlatforms$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendPlatforms$Outbound;
}
export declare function deploymentContextCurrentStackExtendPlatformsToJSON(deploymentContextCurrentStackExtendPlatforms: DeploymentContextCurrentStackExtendPlatforms): string;
export declare function deploymentContextCurrentStackExtendPlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtend$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtend, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtend$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextCurrentStackExtendPlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackExtend$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtend$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtend>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtend$ {
    /** @deprecated use `DeploymentContextCurrentStackExtend$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtend, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtend$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtend$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtend>;
    /** @deprecated use `DeploymentContextCurrentStackExtend$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtend$Outbound;
}
export declare function deploymentContextCurrentStackExtendToJSON(deploymentContextCurrentStackExtend: DeploymentContextCurrentStackExtend): string;
export declare function deploymentContextCurrentStackExtendFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtend, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackExtendUnion$inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackExtendUnion$Outbound = DeploymentContextCurrentStackExtend$Outbound | string;
/** @internal */
export declare const DeploymentContextCurrentStackExtendUnion$outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackExtendUnion$ {
    /** @deprecated use `DeploymentContextCurrentStackExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackExtendUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackExtendUnion>;
    /** @deprecated use `DeploymentContextCurrentStackExtendUnion$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackExtendUnion$Outbound;
}
export declare function deploymentContextCurrentStackExtendUnionToJSON(deploymentContextCurrentStackExtendUnion: DeploymentContextCurrentStackExtendUnion): string;
export declare function deploymentContextCurrentStackExtendUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackExtendUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackManagement1$inboundSchema: z.ZodType<DeploymentContextCurrentStackManagement1, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackManagement1$Outbound = {
    extend: {
        [k: string]: Array<DeploymentContextCurrentStackExtend$Outbound | string>;
    };
};
/** @internal */
export declare const DeploymentContextCurrentStackManagement1$outboundSchema: z.ZodType<DeploymentContextCurrentStackManagement1$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagement1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackManagement1$ {
    /** @deprecated use `DeploymentContextCurrentStackManagement1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackManagement1, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackManagement1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackManagement1$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagement1>;
    /** @deprecated use `DeploymentContextCurrentStackManagement1$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackManagement1$Outbound;
}
export declare function deploymentContextCurrentStackManagement1ToJSON(deploymentContextCurrentStackManagement1: DeploymentContextCurrentStackManagement1): string;
export declare function deploymentContextCurrentStackManagement1FromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackManagement1, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackManagementUnion$inboundSchema: z.ZodType<DeploymentContextCurrentStackManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackManagementUnion$Outbound = DeploymentContextCurrentStackManagement1$Outbound | DeploymentContextCurrentStackManagement2$Outbound | string;
/** @internal */
export declare const DeploymentContextCurrentStackManagementUnion$outboundSchema: z.ZodType<DeploymentContextCurrentStackManagementUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackManagementUnion$ {
    /** @deprecated use `DeploymentContextCurrentStackManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackManagementUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackManagementUnion>;
    /** @deprecated use `DeploymentContextCurrentStackManagementUnion$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackManagementUnion$Outbound;
}
export declare function deploymentContextCurrentStackManagementUnionToJSON(deploymentContextCurrentStackManagementUnion: DeploymentContextCurrentStackManagementUnion): string;
export declare function deploymentContextCurrentStackManagementUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackManagementUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAwResource$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwResource>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAwResource$Outbound;
}
export declare function deploymentContextCurrentStackProfileAwResourceToJSON(deploymentContextCurrentStackProfileAwResource: DeploymentContextCurrentStackProfileAwResource): string;
export declare function deploymentContextCurrentStackProfileAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAwStack$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwStack>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAwStack$Outbound;
}
export declare function deploymentContextCurrentStackProfileAwStackToJSON(deploymentContextCurrentStackProfileAwStack: DeploymentContextCurrentStackProfileAwStack): string;
export declare function deploymentContextCurrentStackProfileAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAwBinding$Outbound = {
    resource?: DeploymentContextCurrentStackProfileAwResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackProfileAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAwBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwBinding>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAwBinding$Outbound;
}
export declare function deploymentContextCurrentStackProfileAwBindingToJSON(deploymentContextCurrentStackProfileAwBinding: DeploymentContextCurrentStackProfileAwBinding): string;
export declare function deploymentContextCurrentStackProfileAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAwGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAwGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAwGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAwGrant>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAwGrant$Outbound;
}
export declare function deploymentContextCurrentStackProfileAwGrantToJSON(deploymentContextCurrentStackProfileAwGrant: DeploymentContextCurrentStackProfileAwGrant): string;
export declare function deploymentContextCurrentStackProfileAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAw$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAw$Outbound = {
    binding: DeploymentContextCurrentStackProfileAwBinding$Outbound;
    grant: DeploymentContextCurrentStackProfileAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAw$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAw$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAw$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAw>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAw$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAw$Outbound;
}
export declare function deploymentContextCurrentStackProfileAwToJSON(deploymentContextCurrentStackProfileAw: DeploymentContextCurrentStackProfileAw): string;
export declare function deploymentContextCurrentStackProfileAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAzureResource$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureResource>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAzureResource$Outbound;
}
export declare function deploymentContextCurrentStackProfileAzureResourceToJSON(deploymentContextCurrentStackProfileAzureResource: DeploymentContextCurrentStackProfileAzureResource): string;
export declare function deploymentContextCurrentStackProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAzureStack$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureStack>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAzureStack$Outbound;
}
export declare function deploymentContextCurrentStackProfileAzureStackToJSON(deploymentContextCurrentStackProfileAzureStack: DeploymentContextCurrentStackProfileAzureStack): string;
export declare function deploymentContextCurrentStackProfileAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAzureBinding$Outbound = {
    resource?: DeploymentContextCurrentStackProfileAzureResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackProfileAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAzureBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureBinding>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAzureBinding$Outbound;
}
export declare function deploymentContextCurrentStackProfileAzureBindingToJSON(deploymentContextCurrentStackProfileAzureBinding: DeploymentContextCurrentStackProfileAzureBinding): string;
export declare function deploymentContextCurrentStackProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzureGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAzureGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzureGrant>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAzureGrant$Outbound;
}
export declare function deploymentContextCurrentStackProfileAzureGrantToJSON(deploymentContextCurrentStackProfileAzureGrant: DeploymentContextCurrentStackProfileAzureGrant): string;
export declare function deploymentContextCurrentStackProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzure$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileAzure$Outbound = {
    binding: DeploymentContextCurrentStackProfileAzureBinding$Outbound;
    grant: DeploymentContextCurrentStackProfileAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileAzure$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileAzure$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileAzure$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileAzure>;
    /** @deprecated use `DeploymentContextCurrentStackProfileAzure$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileAzure$Outbound;
}
export declare function deploymentContextCurrentStackProfileAzureToJSON(deploymentContextCurrentStackProfileAzure: DeploymentContextCurrentStackProfileAzure): string;
export declare function deploymentContextCurrentStackProfileAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileConditionResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileConditionResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileConditionResource$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileConditionResource>;
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileConditionResource$Outbound;
}
export declare function deploymentContextCurrentStackProfileConditionResourceToJSON(deploymentContextCurrentStackProfileConditionResource: DeploymentContextCurrentStackProfileConditionResource): string;
export declare function deploymentContextCurrentStackProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpResource$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpResource$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileGcpResource$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpResource$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpResource>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileGcpResource$Outbound;
}
export declare function deploymentContextCurrentStackProfileGcpResourceToJSON(deploymentContextCurrentStackProfileGcpResource: DeploymentContextCurrentStackProfileGcpResource): string;
export declare function deploymentContextCurrentStackProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileConditionStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileConditionStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileConditionStack$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileConditionStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileConditionStack>;
    /** @deprecated use `DeploymentContextCurrentStackProfileConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileConditionStack$Outbound;
}
export declare function deploymentContextCurrentStackProfileConditionStackToJSON(deploymentContextCurrentStackProfileConditionStack: DeploymentContextCurrentStackProfileConditionStack): string;
export declare function deploymentContextCurrentStackProfileConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpStack$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpStack$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileGcpStack$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpStack>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileGcpStack$Outbound;
}
export declare function deploymentContextCurrentStackProfileGcpStackToJSON(deploymentContextCurrentStackProfileGcpStack: DeploymentContextCurrentStackProfileGcpStack): string;
export declare function deploymentContextCurrentStackProfileGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpBinding$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileGcpBinding$Outbound = {
    resource?: DeploymentContextCurrentStackProfileGcpResource$Outbound | undefined;
    stack?: DeploymentContextCurrentStackProfileGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpBinding$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileGcpBinding$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpBinding>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileGcpBinding$Outbound;
}
export declare function deploymentContextCurrentStackProfileGcpBindingToJSON(deploymentContextCurrentStackProfileGcpBinding: DeploymentContextCurrentStackProfileGcpBinding): string;
export declare function deploymentContextCurrentStackProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpGrant$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcpGrant$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileGcpGrant$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcpGrant>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileGcpGrant$Outbound;
}
export declare function deploymentContextCurrentStackProfileGcpGrantToJSON(deploymentContextCurrentStackProfileGcpGrant: DeploymentContextCurrentStackProfileGcpGrant): string;
export declare function deploymentContextCurrentStackProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcp$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileGcp$Outbound = {
    binding: DeploymentContextCurrentStackProfileGcpBinding$Outbound;
    grant: DeploymentContextCurrentStackProfileGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfileGcp$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileGcp$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileGcp$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileGcp>;
    /** @deprecated use `DeploymentContextCurrentStackProfileGcp$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileGcp$Outbound;
}
export declare function deploymentContextCurrentStackProfileGcpToJSON(deploymentContextCurrentStackProfileGcp: DeploymentContextCurrentStackProfileGcp): string;
export declare function deploymentContextCurrentStackProfileGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfilePlatforms$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfilePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfilePlatforms$Outbound = {
    aws?: Array<DeploymentContextCurrentStackProfileAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextCurrentStackProfileAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextCurrentStackProfileGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfilePlatforms$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfilePlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfilePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfilePlatforms$ {
    /** @deprecated use `DeploymentContextCurrentStackProfilePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfilePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfilePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfilePlatforms$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfilePlatforms>;
    /** @deprecated use `DeploymentContextCurrentStackProfilePlatforms$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfilePlatforms$Outbound;
}
export declare function deploymentContextCurrentStackProfilePlatformsToJSON(deploymentContextCurrentStackProfilePlatforms: DeploymentContextCurrentStackProfilePlatforms): string;
export declare function deploymentContextCurrentStackProfilePlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfile$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfile, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfile$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextCurrentStackProfilePlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextCurrentStackProfile$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfile$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfile>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfile$ {
    /** @deprecated use `DeploymentContextCurrentStackProfile$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfile, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfile$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfile$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfile>;
    /** @deprecated use `DeploymentContextCurrentStackProfile$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfile$Outbound;
}
export declare function deploymentContextCurrentStackProfileToJSON(deploymentContextCurrentStackProfile: DeploymentContextCurrentStackProfile): string;
export declare function deploymentContextCurrentStackProfileFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfile, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackProfileUnion$inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackProfileUnion$Outbound = DeploymentContextCurrentStackProfile$Outbound | string;
/** @internal */
export declare const DeploymentContextCurrentStackProfileUnion$outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackProfileUnion$ {
    /** @deprecated use `DeploymentContextCurrentStackProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackProfileUnion$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackProfileUnion>;
    /** @deprecated use `DeploymentContextCurrentStackProfileUnion$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackProfileUnion$Outbound;
}
export declare function deploymentContextCurrentStackProfileUnionToJSON(deploymentContextCurrentStackProfileUnion: DeploymentContextCurrentStackProfileUnion): string;
export declare function deploymentContextCurrentStackProfileUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackProfileUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackPermissions$inboundSchema: z.ZodType<DeploymentContextCurrentStackPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackPermissions$Outbound = {
    management?: DeploymentContextCurrentStackManagement1$Outbound | DeploymentContextCurrentStackManagement2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<DeploymentContextCurrentStackProfile$Outbound | string>;
        };
    };
};
/** @internal */
export declare const DeploymentContextCurrentStackPermissions$outboundSchema: z.ZodType<DeploymentContextCurrentStackPermissions$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackPermissions$ {
    /** @deprecated use `DeploymentContextCurrentStackPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackPermissions$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackPermissions>;
    /** @deprecated use `DeploymentContextCurrentStackPermissions$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackPermissions$Outbound;
}
export declare function deploymentContextCurrentStackPermissionsToJSON(deploymentContextCurrentStackPermissions: DeploymentContextCurrentStackPermissions): string;
export declare function deploymentContextCurrentStackPermissionsFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackPermissions, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackConfig$inboundSchema: z.ZodType<DeploymentContextCurrentStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const DeploymentContextCurrentStackConfig$outboundSchema: z.ZodType<DeploymentContextCurrentStackConfig$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackConfig$ {
    /** @deprecated use `DeploymentContextCurrentStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackConfig$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackConfig>;
    /** @deprecated use `DeploymentContextCurrentStackConfig$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackConfig$Outbound;
}
export declare function deploymentContextCurrentStackConfigToJSON(deploymentContextCurrentStackConfig: DeploymentContextCurrentStackConfig): string;
export declare function deploymentContextCurrentStackConfigFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackConfig, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackDependency$inboundSchema: z.ZodType<DeploymentContextCurrentStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackDependency$outboundSchema: z.ZodType<DeploymentContextCurrentStackDependency$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackDependency$ {
    /** @deprecated use `DeploymentContextCurrentStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackDependency$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackDependency>;
    /** @deprecated use `DeploymentContextCurrentStackDependency$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackDependency$Outbound;
}
export declare function deploymentContextCurrentStackDependencyToJSON(deploymentContextCurrentStackDependency: DeploymentContextCurrentStackDependency): string;
export declare function deploymentContextCurrentStackDependencyFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackDependency, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentStackLifecycle>;
/** @internal */
export declare const DeploymentContextCurrentStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackLifecycle$ {
    /** @deprecated use `DeploymentContextCurrentStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `DeploymentContextCurrentStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const DeploymentContextCurrentStackResources$inboundSchema: z.ZodType<DeploymentContextCurrentStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStackResources$Outbound = {
    config: DeploymentContextCurrentStackConfig$Outbound;
    dependencies: Array<DeploymentContextCurrentStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const DeploymentContextCurrentStackResources$outboundSchema: z.ZodType<DeploymentContextCurrentStackResources$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStackResources$ {
    /** @deprecated use `DeploymentContextCurrentStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStackResources$Outbound, z.ZodTypeDef, DeploymentContextCurrentStackResources>;
    /** @deprecated use `DeploymentContextCurrentStackResources$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStackResources$Outbound;
}
export declare function deploymentContextCurrentStackResourcesToJSON(deploymentContextCurrentStackResources: DeploymentContextCurrentStackResources): string;
export declare function deploymentContextCurrentStackResourcesFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStackResources, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentStack$inboundSchema: z.ZodType<DeploymentContextCurrentStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentStack$Outbound = {
    id: string;
    permissions?: DeploymentContextCurrentStackPermissions$Outbound | undefined;
    resources: {
        [k: string]: DeploymentContextCurrentStackResources$Outbound;
    };
};
/** @internal */
export declare const DeploymentContextCurrentStack$outboundSchema: z.ZodType<DeploymentContextCurrentStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentStack$ {
    /** @deprecated use `DeploymentContextCurrentStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentStack$Outbound, z.ZodTypeDef, DeploymentContextCurrentStack>;
    /** @deprecated use `DeploymentContextCurrentStack$Outbound` instead. */
    type Outbound = DeploymentContextCurrentStack$Outbound;
}
export declare function deploymentContextCurrentStackToJSON(deploymentContextCurrentStack: DeploymentContextCurrentStack): string;
export declare function deploymentContextCurrentStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPlatformLocal$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextPlatformLocal>;
/** @internal */
export declare const DeploymentContextPlatformLocal$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextPlatformLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPlatformLocal$ {
    /** @deprecated use `DeploymentContextPlatformLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
    /** @deprecated use `DeploymentContextPlatformLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const DeploymentContextEnvironmentInfoLocal$inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextEnvironmentInfoLocal$Outbound = {
    arch: string;
    hostname: string;
    os: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextEnvironmentInfoLocal$outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoLocal$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoLocal$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextEnvironmentInfoLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoLocal$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoLocal>;
    /** @deprecated use `DeploymentContextEnvironmentInfoLocal$Outbound` instead. */
    type Outbound = DeploymentContextEnvironmentInfoLocal$Outbound;
}
export declare function deploymentContextEnvironmentInfoLocalToJSON(deploymentContextEnvironmentInfoLocal: DeploymentContextEnvironmentInfoLocal): string;
export declare function deploymentContextEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<DeploymentContextEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformAzure$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformAzure>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformAzure$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoPlatformAzure$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const DeploymentContextEnvironmentInfoAzure$inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextEnvironmentInfoAzure$Outbound = {
    location: string;
    subscriptionId: string;
    tenantId: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextEnvironmentInfoAzure$outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAzure$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoAzure$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextEnvironmentInfoAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAzure$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoAzure>;
    /** @deprecated use `DeploymentContextEnvironmentInfoAzure$Outbound` instead. */
    type Outbound = DeploymentContextEnvironmentInfoAzure$Outbound;
}
export declare function deploymentContextEnvironmentInfoAzureToJSON(deploymentContextEnvironmentInfoAzure: DeploymentContextEnvironmentInfoAzure): string;
export declare function deploymentContextEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformGcp$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformGcp>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformGcp$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoPlatformGcp$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const DeploymentContextEnvironmentInfoGcp$inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextEnvironmentInfoGcp$Outbound = {
    projectId: string;
    projectNumber: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextEnvironmentInfoGcp$outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoGcp$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoGcp$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextEnvironmentInfoGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoGcp$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoGcp>;
    /** @deprecated use `DeploymentContextEnvironmentInfoGcp$Outbound` instead. */
    type Outbound = DeploymentContextEnvironmentInfoGcp$Outbound;
}
export declare function deploymentContextEnvironmentInfoGcpToJSON(deploymentContextEnvironmentInfoGcp: DeploymentContextEnvironmentInfoGcp): string;
export declare function deploymentContextEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformAws$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformAws>;
/** @internal */
export declare const DeploymentContextEnvironmentInfoPlatformAws$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextEnvironmentInfoPlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoPlatformAws$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `DeploymentContextEnvironmentInfoPlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const DeploymentContextEnvironmentInfoAws$inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAws, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextEnvironmentInfoAws$Outbound = {
    accountId: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextEnvironmentInfoAws$outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAws$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextEnvironmentInfoAws$ {
    /** @deprecated use `DeploymentContextEnvironmentInfoAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextEnvironmentInfoAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextEnvironmentInfoAws$Outbound, z.ZodTypeDef, DeploymentContextEnvironmentInfoAws>;
    /** @deprecated use `DeploymentContextEnvironmentInfoAws$Outbound` instead. */
    type Outbound = DeploymentContextEnvironmentInfoAws$Outbound;
}
export declare function deploymentContextEnvironmentInfoAwsToJSON(deploymentContextEnvironmentInfoAws: DeploymentContextEnvironmentInfoAws): string;
export declare function deploymentContextEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<DeploymentContextEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentPlatform$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentPlatform>;
/** @internal */
export declare const DeploymentContextCurrentPlatform$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextCurrentPlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentPlatform$ {
    /** @deprecated use `DeploymentContextCurrentPlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `DeploymentContextCurrentPlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const DeploymentContextPreparedStackManagementEnum$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextPreparedStackManagementEnum>;
/** @internal */
export declare const DeploymentContextPreparedStackManagementEnum$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextPreparedStackManagementEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackManagementEnum$ {
    /** @deprecated use `DeploymentContextPreparedStackManagementEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `DeploymentContextPreparedStackManagementEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAwResource$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwResource>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAwResource$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAwResourceToJSON(deploymentContextPreparedStackOverrideAwResource: DeploymentContextPreparedStackOverrideAwResource): string;
export declare function deploymentContextPreparedStackOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAwStack$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwStack>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAwStack$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAwStackToJSON(deploymentContextPreparedStackOverrideAwStack: DeploymentContextPreparedStackOverrideAwStack): string;
export declare function deploymentContextPreparedStackOverrideAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAwBinding$Outbound = {
    resource?: DeploymentContextPreparedStackOverrideAwResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackOverrideAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAwBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwBinding>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAwBinding$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAwBindingToJSON(deploymentContextPreparedStackOverrideAwBinding: DeploymentContextPreparedStackOverrideAwBinding): string;
export declare function deploymentContextPreparedStackOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAwGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAwGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAwGrant>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAwGrant$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAwGrantToJSON(deploymentContextPreparedStackOverrideAwGrant: DeploymentContextPreparedStackOverrideAwGrant): string;
export declare function deploymentContextPreparedStackOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAw$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAw$Outbound = {
    binding: DeploymentContextPreparedStackOverrideAwBinding$Outbound;
    grant: DeploymentContextPreparedStackOverrideAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAw$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAw$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAw>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAw$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAw$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAwToJSON(deploymentContextPreparedStackOverrideAw: DeploymentContextPreparedStackOverrideAw): string;
export declare function deploymentContextPreparedStackOverrideAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAzureResource$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureResource>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAzureResource$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAzureResourceToJSON(deploymentContextPreparedStackOverrideAzureResource: DeploymentContextPreparedStackOverrideAzureResource): string;
export declare function deploymentContextPreparedStackOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAzureStack$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureStack>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAzureStack$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAzureStackToJSON(deploymentContextPreparedStackOverrideAzureStack: DeploymentContextPreparedStackOverrideAzureStack): string;
export declare function deploymentContextPreparedStackOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAzureBinding$Outbound = {
    resource?: DeploymentContextPreparedStackOverrideAzureResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackOverrideAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAzureBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureBinding>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAzureBinding$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAzureBindingToJSON(deploymentContextPreparedStackOverrideAzureBinding: DeploymentContextPreparedStackOverrideAzureBinding): string;
export declare function deploymentContextPreparedStackOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzureGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAzureGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzureGrant>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAzureGrant$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAzureGrantToJSON(deploymentContextPreparedStackOverrideAzureGrant: DeploymentContextPreparedStackOverrideAzureGrant): string;
export declare function deploymentContextPreparedStackOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzure$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideAzure$Outbound = {
    binding: DeploymentContextPreparedStackOverrideAzureBinding$Outbound;
    grant: DeploymentContextPreparedStackOverrideAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideAzure$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideAzure$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideAzure>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideAzure$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideAzure$Outbound;
}
export declare function deploymentContextPreparedStackOverrideAzureToJSON(deploymentContextPreparedStackOverrideAzure: DeploymentContextPreparedStackOverrideAzure): string;
export declare function deploymentContextPreparedStackOverrideAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideConditionResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideConditionResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideConditionResource$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideConditionResource>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideConditionResource$Outbound;
}
export declare function deploymentContextPreparedStackOverrideConditionResourceToJSON(deploymentContextPreparedStackOverrideConditionResource: DeploymentContextPreparedStackOverrideConditionResource): string;
export declare function deploymentContextPreparedStackOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideGcpResource$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpResource>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideGcpResource$Outbound;
}
export declare function deploymentContextPreparedStackOverrideGcpResourceToJSON(deploymentContextPreparedStackOverrideGcpResource: DeploymentContextPreparedStackOverrideGcpResource): string;
export declare function deploymentContextPreparedStackOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideConditionStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideConditionStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideConditionStack$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideConditionStack>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideConditionStack$Outbound;
}
export declare function deploymentContextPreparedStackOverrideConditionStackToJSON(deploymentContextPreparedStackOverrideConditionStack: DeploymentContextPreparedStackOverrideConditionStack): string;
export declare function deploymentContextPreparedStackOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideGcpStack$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpStack>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideGcpStack$Outbound;
}
export declare function deploymentContextPreparedStackOverrideGcpStackToJSON(deploymentContextPreparedStackOverrideGcpStack: DeploymentContextPreparedStackOverrideGcpStack): string;
export declare function deploymentContextPreparedStackOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideGcpBinding$Outbound = {
    resource?: DeploymentContextPreparedStackOverrideGcpResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackOverrideGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideGcpBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpBinding>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideGcpBinding$Outbound;
}
export declare function deploymentContextPreparedStackOverrideGcpBindingToJSON(deploymentContextPreparedStackOverrideGcpBinding: DeploymentContextPreparedStackOverrideGcpBinding): string;
export declare function deploymentContextPreparedStackOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcpGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideGcpGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcpGrant>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideGcpGrant$Outbound;
}
export declare function deploymentContextPreparedStackOverrideGcpGrantToJSON(deploymentContextPreparedStackOverrideGcpGrant: DeploymentContextPreparedStackOverrideGcpGrant): string;
export declare function deploymentContextPreparedStackOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcp$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideGcp$Outbound = {
    binding: DeploymentContextPreparedStackOverrideGcpBinding$Outbound;
    grant: DeploymentContextPreparedStackOverrideGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverrideGcp$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideGcp$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideGcp>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideGcp$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideGcp$Outbound;
}
export declare function deploymentContextPreparedStackOverrideGcpToJSON(deploymentContextPreparedStackOverrideGcp: DeploymentContextPreparedStackOverrideGcp): string;
export declare function deploymentContextPreparedStackOverrideGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverridePlatforms$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverridePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverridePlatforms$Outbound = {
    aws?: Array<DeploymentContextPreparedStackOverrideAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextPreparedStackOverrideAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextPreparedStackOverrideGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverridePlatforms$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverridePlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverridePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverridePlatforms$ {
    /** @deprecated use `DeploymentContextPreparedStackOverridePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverridePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverridePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverridePlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverridePlatforms>;
    /** @deprecated use `DeploymentContextPreparedStackOverridePlatforms$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverridePlatforms$Outbound;
}
export declare function deploymentContextPreparedStackOverridePlatformsToJSON(deploymentContextPreparedStackOverridePlatforms: DeploymentContextPreparedStackOverridePlatforms): string;
export declare function deploymentContextPreparedStackOverridePlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverride$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverride, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverride$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextPreparedStackOverridePlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackOverride$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverride$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverride>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverride$ {
    /** @deprecated use `DeploymentContextPreparedStackOverride$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverride, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverride$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverride$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverride>;
    /** @deprecated use `DeploymentContextPreparedStackOverride$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverride$Outbound;
}
export declare function deploymentContextPreparedStackOverrideToJSON(deploymentContextPreparedStackOverride: DeploymentContextPreparedStackOverride): string;
export declare function deploymentContextPreparedStackOverrideFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverride, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideUnion$inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackOverrideUnion$Outbound = DeploymentContextPreparedStackOverride$Outbound | string;
/** @internal */
export declare const DeploymentContextPreparedStackOverrideUnion$outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackOverrideUnion$ {
    /** @deprecated use `DeploymentContextPreparedStackOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackOverrideUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackOverrideUnion>;
    /** @deprecated use `DeploymentContextPreparedStackOverrideUnion$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackOverrideUnion$Outbound;
}
export declare function deploymentContextPreparedStackOverrideUnionToJSON(deploymentContextPreparedStackOverrideUnion: DeploymentContextPreparedStackOverrideUnion): string;
export declare function deploymentContextPreparedStackOverrideUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackOverrideUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackManagement2$inboundSchema: z.ZodType<DeploymentContextPreparedStackManagement2, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackManagement2$Outbound = {
    override: {
        [k: string]: Array<DeploymentContextPreparedStackOverride$Outbound | string>;
    };
};
/** @internal */
export declare const DeploymentContextPreparedStackManagement2$outboundSchema: z.ZodType<DeploymentContextPreparedStackManagement2$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagement2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackManagement2$ {
    /** @deprecated use `DeploymentContextPreparedStackManagement2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackManagement2, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackManagement2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackManagement2$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagement2>;
    /** @deprecated use `DeploymentContextPreparedStackManagement2$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackManagement2$Outbound;
}
export declare function deploymentContextPreparedStackManagement2ToJSON(deploymentContextPreparedStackManagement2: DeploymentContextPreparedStackManagement2): string;
export declare function deploymentContextPreparedStackManagement2FromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackManagement2, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAwResource$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwResource>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAwResource$Outbound;
}
export declare function deploymentContextPreparedStackExtendAwResourceToJSON(deploymentContextPreparedStackExtendAwResource: DeploymentContextPreparedStackExtendAwResource): string;
export declare function deploymentContextPreparedStackExtendAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAwStack$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwStack>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAwStack$Outbound;
}
export declare function deploymentContextPreparedStackExtendAwStackToJSON(deploymentContextPreparedStackExtendAwStack: DeploymentContextPreparedStackExtendAwStack): string;
export declare function deploymentContextPreparedStackExtendAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAwBinding$Outbound = {
    resource?: DeploymentContextPreparedStackExtendAwResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackExtendAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAwBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwBinding>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAwBinding$Outbound;
}
export declare function deploymentContextPreparedStackExtendAwBindingToJSON(deploymentContextPreparedStackExtendAwBinding: DeploymentContextPreparedStackExtendAwBinding): string;
export declare function deploymentContextPreparedStackExtendAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAwGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAwGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAwGrant>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAwGrant$Outbound;
}
export declare function deploymentContextPreparedStackExtendAwGrantToJSON(deploymentContextPreparedStackExtendAwGrant: DeploymentContextPreparedStackExtendAwGrant): string;
export declare function deploymentContextPreparedStackExtendAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAw$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAw$Outbound = {
    binding: DeploymentContextPreparedStackExtendAwBinding$Outbound;
    grant: DeploymentContextPreparedStackExtendAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAw$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAw$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAw>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAw$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAw$Outbound;
}
export declare function deploymentContextPreparedStackExtendAwToJSON(deploymentContextPreparedStackExtendAw: DeploymentContextPreparedStackExtendAw): string;
export declare function deploymentContextPreparedStackExtendAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAzureResource$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureResource>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAzureResource$Outbound;
}
export declare function deploymentContextPreparedStackExtendAzureResourceToJSON(deploymentContextPreparedStackExtendAzureResource: DeploymentContextPreparedStackExtendAzureResource): string;
export declare function deploymentContextPreparedStackExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAzureStack$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureStack>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAzureStack$Outbound;
}
export declare function deploymentContextPreparedStackExtendAzureStackToJSON(deploymentContextPreparedStackExtendAzureStack: DeploymentContextPreparedStackExtendAzureStack): string;
export declare function deploymentContextPreparedStackExtendAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAzureBinding$Outbound = {
    resource?: DeploymentContextPreparedStackExtendAzureResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackExtendAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAzureBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureBinding>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAzureBinding$Outbound;
}
export declare function deploymentContextPreparedStackExtendAzureBindingToJSON(deploymentContextPreparedStackExtendAzureBinding: DeploymentContextPreparedStackExtendAzureBinding): string;
export declare function deploymentContextPreparedStackExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzureGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAzureGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzureGrant>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAzureGrant$Outbound;
}
export declare function deploymentContextPreparedStackExtendAzureGrantToJSON(deploymentContextPreparedStackExtendAzureGrant: DeploymentContextPreparedStackExtendAzureGrant): string;
export declare function deploymentContextPreparedStackExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzure$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendAzure$Outbound = {
    binding: DeploymentContextPreparedStackExtendAzureBinding$Outbound;
    grant: DeploymentContextPreparedStackExtendAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendAzure$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendAzure$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendAzure>;
    /** @deprecated use `DeploymentContextPreparedStackExtendAzure$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendAzure$Outbound;
}
export declare function deploymentContextPreparedStackExtendAzureToJSON(deploymentContextPreparedStackExtendAzure: DeploymentContextPreparedStackExtendAzure): string;
export declare function deploymentContextPreparedStackExtendAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendConditionResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendConditionResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendConditionResource$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendConditionResource>;
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendConditionResource$Outbound;
}
export declare function deploymentContextPreparedStackExtendConditionResourceToJSON(deploymentContextPreparedStackExtendConditionResource: DeploymentContextPreparedStackExtendConditionResource): string;
export declare function deploymentContextPreparedStackExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendGcpResource$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpResource>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendGcpResource$Outbound;
}
export declare function deploymentContextPreparedStackExtendGcpResourceToJSON(deploymentContextPreparedStackExtendGcpResource: DeploymentContextPreparedStackExtendGcpResource): string;
export declare function deploymentContextPreparedStackExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendConditionStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendConditionStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendConditionStack$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendConditionStack>;
    /** @deprecated use `DeploymentContextPreparedStackExtendConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendConditionStack$Outbound;
}
export declare function deploymentContextPreparedStackExtendConditionStackToJSON(deploymentContextPreparedStackExtendConditionStack: DeploymentContextPreparedStackExtendConditionStack): string;
export declare function deploymentContextPreparedStackExtendConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendGcpStack$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpStack>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendGcpStack$Outbound;
}
export declare function deploymentContextPreparedStackExtendGcpStackToJSON(deploymentContextPreparedStackExtendGcpStack: DeploymentContextPreparedStackExtendGcpStack): string;
export declare function deploymentContextPreparedStackExtendGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendGcpBinding$Outbound = {
    resource?: DeploymentContextPreparedStackExtendGcpResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackExtendGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendGcpBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpBinding>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendGcpBinding$Outbound;
}
export declare function deploymentContextPreparedStackExtendGcpBindingToJSON(deploymentContextPreparedStackExtendGcpBinding: DeploymentContextPreparedStackExtendGcpBinding): string;
export declare function deploymentContextPreparedStackExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcpGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendGcpGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcpGrant>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendGcpGrant$Outbound;
}
export declare function deploymentContextPreparedStackExtendGcpGrantToJSON(deploymentContextPreparedStackExtendGcpGrant: DeploymentContextPreparedStackExtendGcpGrant): string;
export declare function deploymentContextPreparedStackExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcp$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendGcp$Outbound = {
    binding: DeploymentContextPreparedStackExtendGcpBinding$Outbound;
    grant: DeploymentContextPreparedStackExtendGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendGcp$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendGcp$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendGcp>;
    /** @deprecated use `DeploymentContextPreparedStackExtendGcp$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendGcp$Outbound;
}
export declare function deploymentContextPreparedStackExtendGcpToJSON(deploymentContextPreparedStackExtendGcp: DeploymentContextPreparedStackExtendGcp): string;
export declare function deploymentContextPreparedStackExtendGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendPlatforms$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendPlatforms$Outbound = {
    aws?: Array<DeploymentContextPreparedStackExtendAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextPreparedStackExtendAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextPreparedStackExtendGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtendPlatforms$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendPlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendPlatforms$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendPlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendPlatforms>;
    /** @deprecated use `DeploymentContextPreparedStackExtendPlatforms$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendPlatforms$Outbound;
}
export declare function deploymentContextPreparedStackExtendPlatformsToJSON(deploymentContextPreparedStackExtendPlatforms: DeploymentContextPreparedStackExtendPlatforms): string;
export declare function deploymentContextPreparedStackExtendPlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtend$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtend, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtend$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextPreparedStackExtendPlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackExtend$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtend$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtend>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtend$ {
    /** @deprecated use `DeploymentContextPreparedStackExtend$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtend, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtend$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtend$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtend>;
    /** @deprecated use `DeploymentContextPreparedStackExtend$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtend$Outbound;
}
export declare function deploymentContextPreparedStackExtendToJSON(deploymentContextPreparedStackExtend: DeploymentContextPreparedStackExtend): string;
export declare function deploymentContextPreparedStackExtendFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtend, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackExtendUnion$inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackExtendUnion$Outbound = DeploymentContextPreparedStackExtend$Outbound | string;
/** @internal */
export declare const DeploymentContextPreparedStackExtendUnion$outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackExtendUnion$ {
    /** @deprecated use `DeploymentContextPreparedStackExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackExtendUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackExtendUnion>;
    /** @deprecated use `DeploymentContextPreparedStackExtendUnion$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackExtendUnion$Outbound;
}
export declare function deploymentContextPreparedStackExtendUnionToJSON(deploymentContextPreparedStackExtendUnion: DeploymentContextPreparedStackExtendUnion): string;
export declare function deploymentContextPreparedStackExtendUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackExtendUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackManagement1$inboundSchema: z.ZodType<DeploymentContextPreparedStackManagement1, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackManagement1$Outbound = {
    extend: {
        [k: string]: Array<DeploymentContextPreparedStackExtend$Outbound | string>;
    };
};
/** @internal */
export declare const DeploymentContextPreparedStackManagement1$outboundSchema: z.ZodType<DeploymentContextPreparedStackManagement1$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagement1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackManagement1$ {
    /** @deprecated use `DeploymentContextPreparedStackManagement1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackManagement1, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackManagement1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackManagement1$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagement1>;
    /** @deprecated use `DeploymentContextPreparedStackManagement1$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackManagement1$Outbound;
}
export declare function deploymentContextPreparedStackManagement1ToJSON(deploymentContextPreparedStackManagement1: DeploymentContextPreparedStackManagement1): string;
export declare function deploymentContextPreparedStackManagement1FromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackManagement1, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackManagementUnion$inboundSchema: z.ZodType<DeploymentContextPreparedStackManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackManagementUnion$Outbound = DeploymentContextPreparedStackManagement1$Outbound | DeploymentContextPreparedStackManagement2$Outbound | string;
/** @internal */
export declare const DeploymentContextPreparedStackManagementUnion$outboundSchema: z.ZodType<DeploymentContextPreparedStackManagementUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackManagementUnion$ {
    /** @deprecated use `DeploymentContextPreparedStackManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackManagementUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackManagementUnion>;
    /** @deprecated use `DeploymentContextPreparedStackManagementUnion$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackManagementUnion$Outbound;
}
export declare function deploymentContextPreparedStackManagementUnionToJSON(deploymentContextPreparedStackManagementUnion: DeploymentContextPreparedStackManagementUnion): string;
export declare function deploymentContextPreparedStackManagementUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackManagementUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAwResource$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwResource>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAwResource$Outbound;
}
export declare function deploymentContextPreparedStackProfileAwResourceToJSON(deploymentContextPreparedStackProfileAwResource: DeploymentContextPreparedStackProfileAwResource): string;
export declare function deploymentContextPreparedStackProfileAwResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAwResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAwStack$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwStack>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAwStack$Outbound;
}
export declare function deploymentContextPreparedStackProfileAwStackToJSON(deploymentContextPreparedStackProfileAwStack: DeploymentContextPreparedStackProfileAwStack): string;
export declare function deploymentContextPreparedStackProfileAwStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAwStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAwBinding$Outbound = {
    resource?: DeploymentContextPreparedStackProfileAwResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackProfileAwStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAwBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwBinding>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAwBinding$Outbound;
}
export declare function deploymentContextPreparedStackProfileAwBindingToJSON(deploymentContextPreparedStackProfileAwBinding: DeploymentContextPreparedStackProfileAwBinding): string;
export declare function deploymentContextPreparedStackProfileAwBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAwGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAwGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAwGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAwGrant>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAwGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAwGrant$Outbound;
}
export declare function deploymentContextPreparedStackProfileAwGrantToJSON(deploymentContextPreparedStackProfileAwGrant: DeploymentContextPreparedStackProfileAwGrant): string;
export declare function deploymentContextPreparedStackProfileAwGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAw$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAw, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAw$Outbound = {
    binding: DeploymentContextPreparedStackProfileAwBinding$Outbound;
    grant: DeploymentContextPreparedStackProfileAwGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAw$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAw$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAw$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAw>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAw$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAw$Outbound;
}
export declare function deploymentContextPreparedStackProfileAwToJSON(deploymentContextPreparedStackProfileAw: DeploymentContextPreparedStackProfileAw): string;
export declare function deploymentContextPreparedStackProfileAwFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAw, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAzureResource$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureResource>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAzureResource$Outbound;
}
export declare function deploymentContextPreparedStackProfileAzureResourceToJSON(deploymentContextPreparedStackProfileAzureResource: DeploymentContextPreparedStackProfileAzureResource): string;
export declare function deploymentContextPreparedStackProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAzureStack$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureStack>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAzureStack$Outbound;
}
export declare function deploymentContextPreparedStackProfileAzureStackToJSON(deploymentContextPreparedStackProfileAzureStack: DeploymentContextPreparedStackProfileAzureStack): string;
export declare function deploymentContextPreparedStackProfileAzureStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAzureBinding$Outbound = {
    resource?: DeploymentContextPreparedStackProfileAzureResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackProfileAzureStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAzureBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureBinding>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAzureBinding$Outbound;
}
export declare function deploymentContextPreparedStackProfileAzureBindingToJSON(deploymentContextPreparedStackProfileAzureBinding: DeploymentContextPreparedStackProfileAzureBinding): string;
export declare function deploymentContextPreparedStackProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzureGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAzureGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzureGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzureGrant>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzureGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAzureGrant$Outbound;
}
export declare function deploymentContextPreparedStackProfileAzureGrantToJSON(deploymentContextPreparedStackProfileAzureGrant: DeploymentContextPreparedStackProfileAzureGrant): string;
export declare function deploymentContextPreparedStackProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzure$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileAzure$Outbound = {
    binding: DeploymentContextPreparedStackProfileAzureBinding$Outbound;
    grant: DeploymentContextPreparedStackProfileAzureGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileAzure$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileAzure$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileAzure$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileAzure>;
    /** @deprecated use `DeploymentContextPreparedStackProfileAzure$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileAzure$Outbound;
}
export declare function deploymentContextPreparedStackProfileAzureToJSON(deploymentContextPreparedStackProfileAzure: DeploymentContextPreparedStackProfileAzure): string;
export declare function deploymentContextPreparedStackProfileAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileConditionResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileConditionResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileConditionResource$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileConditionResource>;
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileConditionResource$Outbound;
}
export declare function deploymentContextPreparedStackProfileConditionResourceToJSON(deploymentContextPreparedStackProfileConditionResource: DeploymentContextPreparedStackProfileConditionResource): string;
export declare function deploymentContextPreparedStackProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpResource$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpResource$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileGcpResource$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpResource$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpResource>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpResource$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileGcpResource$Outbound;
}
export declare function deploymentContextPreparedStackProfileGcpResourceToJSON(deploymentContextPreparedStackProfileGcpResource: DeploymentContextPreparedStackProfileGcpResource): string;
export declare function deploymentContextPreparedStackProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileConditionStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileConditionStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileConditionStack$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileConditionStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileConditionStack>;
    /** @deprecated use `DeploymentContextPreparedStackProfileConditionStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileConditionStack$Outbound;
}
export declare function deploymentContextPreparedStackProfileConditionStackToJSON(deploymentContextPreparedStackProfileConditionStack: DeploymentContextPreparedStackProfileConditionStack): string;
export declare function deploymentContextPreparedStackProfileConditionStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpStack$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpStack$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileGcpStack$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpStack>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileGcpStack$Outbound;
}
export declare function deploymentContextPreparedStackProfileGcpStackToJSON(deploymentContextPreparedStackProfileGcpStack: DeploymentContextPreparedStackProfileGcpStack): string;
export declare function deploymentContextPreparedStackProfileGcpStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpBinding$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileGcpBinding$Outbound = {
    resource?: DeploymentContextPreparedStackProfileGcpResource$Outbound | undefined;
    stack?: DeploymentContextPreparedStackProfileGcpStack$Outbound | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpBinding$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileGcpBinding$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpBinding$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpBinding>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpBinding$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileGcpBinding$Outbound;
}
export declare function deploymentContextPreparedStackProfileGcpBindingToJSON(deploymentContextPreparedStackProfileGcpBinding: DeploymentContextPreparedStackProfileGcpBinding): string;
export declare function deploymentContextPreparedStackProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpGrant$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcpGrant$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileGcpGrant$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcpGrant$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcpGrant>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcpGrant$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileGcpGrant$Outbound;
}
export declare function deploymentContextPreparedStackProfileGcpGrantToJSON(deploymentContextPreparedStackProfileGcpGrant: DeploymentContextPreparedStackProfileGcpGrant): string;
export declare function deploymentContextPreparedStackProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcp$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileGcp$Outbound = {
    binding: DeploymentContextPreparedStackProfileGcpBinding$Outbound;
    grant: DeploymentContextPreparedStackProfileGcpGrant$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfileGcp$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileGcp$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileGcp$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileGcp>;
    /** @deprecated use `DeploymentContextPreparedStackProfileGcp$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileGcp$Outbound;
}
export declare function deploymentContextPreparedStackProfileGcpToJSON(deploymentContextPreparedStackProfileGcp: DeploymentContextPreparedStackProfileGcp): string;
export declare function deploymentContextPreparedStackProfileGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfilePlatforms$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfilePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfilePlatforms$Outbound = {
    aws?: Array<DeploymentContextPreparedStackProfileAw$Outbound> | null | undefined;
    azure?: Array<DeploymentContextPreparedStackProfileAzure$Outbound> | null | undefined;
    gcp?: Array<DeploymentContextPreparedStackProfileGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfilePlatforms$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfilePlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfilePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfilePlatforms$ {
    /** @deprecated use `DeploymentContextPreparedStackProfilePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfilePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfilePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfilePlatforms$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfilePlatforms>;
    /** @deprecated use `DeploymentContextPreparedStackProfilePlatforms$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfilePlatforms$Outbound;
}
export declare function deploymentContextPreparedStackProfilePlatformsToJSON(deploymentContextPreparedStackProfilePlatforms: DeploymentContextPreparedStackProfilePlatforms): string;
export declare function deploymentContextPreparedStackProfilePlatformsFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfile$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfile, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfile$Outbound = {
    description: string;
    id: string;
    platforms: DeploymentContextPreparedStackProfilePlatforms$Outbound;
};
/** @internal */
export declare const DeploymentContextPreparedStackProfile$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfile$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfile>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfile$ {
    /** @deprecated use `DeploymentContextPreparedStackProfile$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfile, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfile$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfile$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfile>;
    /** @deprecated use `DeploymentContextPreparedStackProfile$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfile$Outbound;
}
export declare function deploymentContextPreparedStackProfileToJSON(deploymentContextPreparedStackProfile: DeploymentContextPreparedStackProfile): string;
export declare function deploymentContextPreparedStackProfileFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfile, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackProfileUnion$inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackProfileUnion$Outbound = DeploymentContextPreparedStackProfile$Outbound | string;
/** @internal */
export declare const DeploymentContextPreparedStackProfileUnion$outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackProfileUnion$ {
    /** @deprecated use `DeploymentContextPreparedStackProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackProfileUnion$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackProfileUnion>;
    /** @deprecated use `DeploymentContextPreparedStackProfileUnion$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackProfileUnion$Outbound;
}
export declare function deploymentContextPreparedStackProfileUnionToJSON(deploymentContextPreparedStackProfileUnion: DeploymentContextPreparedStackProfileUnion): string;
export declare function deploymentContextPreparedStackProfileUnionFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackProfileUnion, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackPermissions$inboundSchema: z.ZodType<DeploymentContextPreparedStackPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackPermissions$Outbound = {
    management?: DeploymentContextPreparedStackManagement1$Outbound | DeploymentContextPreparedStackManagement2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<DeploymentContextPreparedStackProfile$Outbound | string>;
        };
    };
};
/** @internal */
export declare const DeploymentContextPreparedStackPermissions$outboundSchema: z.ZodType<DeploymentContextPreparedStackPermissions$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackPermissions$ {
    /** @deprecated use `DeploymentContextPreparedStackPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackPermissions$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackPermissions>;
    /** @deprecated use `DeploymentContextPreparedStackPermissions$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackPermissions$Outbound;
}
export declare function deploymentContextPreparedStackPermissionsToJSON(deploymentContextPreparedStackPermissions: DeploymentContextPreparedStackPermissions): string;
export declare function deploymentContextPreparedStackPermissionsFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackPermissions, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackConfig$inboundSchema: z.ZodType<DeploymentContextPreparedStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const DeploymentContextPreparedStackConfig$outboundSchema: z.ZodType<DeploymentContextPreparedStackConfig$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackConfig$ {
    /** @deprecated use `DeploymentContextPreparedStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackConfig$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackConfig>;
    /** @deprecated use `DeploymentContextPreparedStackConfig$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackConfig$Outbound;
}
export declare function deploymentContextPreparedStackConfigToJSON(deploymentContextPreparedStackConfig: DeploymentContextPreparedStackConfig): string;
export declare function deploymentContextPreparedStackConfigFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackConfig, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackDependency$inboundSchema: z.ZodType<DeploymentContextPreparedStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackDependency$outboundSchema: z.ZodType<DeploymentContextPreparedStackDependency$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackDependency$ {
    /** @deprecated use `DeploymentContextPreparedStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackDependency$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackDependency>;
    /** @deprecated use `DeploymentContextPreparedStackDependency$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackDependency$Outbound;
}
export declare function deploymentContextPreparedStackDependencyToJSON(deploymentContextPreparedStackDependency: DeploymentContextPreparedStackDependency): string;
export declare function deploymentContextPreparedStackDependencyFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackDependency, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextPreparedStackLifecycle>;
/** @internal */
export declare const DeploymentContextPreparedStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextPreparedStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackLifecycle$ {
    /** @deprecated use `DeploymentContextPreparedStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `DeploymentContextPreparedStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const DeploymentContextPreparedStackResources$inboundSchema: z.ZodType<DeploymentContextPreparedStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStackResources$Outbound = {
    config: DeploymentContextPreparedStackConfig$Outbound;
    dependencies: Array<DeploymentContextPreparedStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const DeploymentContextPreparedStackResources$outboundSchema: z.ZodType<DeploymentContextPreparedStackResources$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStackResources$ {
    /** @deprecated use `DeploymentContextPreparedStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStackResources$Outbound, z.ZodTypeDef, DeploymentContextPreparedStackResources>;
    /** @deprecated use `DeploymentContextPreparedStackResources$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStackResources$Outbound;
}
export declare function deploymentContextPreparedStackResourcesToJSON(deploymentContextPreparedStackResources: DeploymentContextPreparedStackResources): string;
export declare function deploymentContextPreparedStackResourcesFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStackResources, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreparedStack$inboundSchema: z.ZodType<DeploymentContextPreparedStack, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreparedStack$Outbound = {
    id: string;
    permissions?: DeploymentContextPreparedStackPermissions$Outbound | undefined;
    resources: {
        [k: string]: DeploymentContextPreparedStackResources$Outbound;
    };
};
/** @internal */
export declare const DeploymentContextPreparedStack$outboundSchema: z.ZodType<DeploymentContextPreparedStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreparedStack$ {
    /** @deprecated use `DeploymentContextPreparedStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreparedStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreparedStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreparedStack$Outbound, z.ZodTypeDef, DeploymentContextPreparedStack>;
    /** @deprecated use `DeploymentContextPreparedStack$Outbound` instead. */
    type Outbound = DeploymentContextPreparedStack$Outbound;
}
export declare function deploymentContextPreparedStackToJSON(deploymentContextPreparedStack: DeploymentContextPreparedStack): string;
export declare function deploymentContextPreparedStackFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreparedStack, SDKValidationError>;
/** @internal */
export declare const DeploymentContextRuntimeMetadata$inboundSchema: z.ZodType<DeploymentContextRuntimeMetadata, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextRuntimeMetadata$Outbound = {
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/** @internal */
export declare const DeploymentContextRuntimeMetadata$outboundSchema: z.ZodType<DeploymentContextRuntimeMetadata$Outbound, z.ZodTypeDef, DeploymentContextRuntimeMetadata>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextRuntimeMetadata$ {
    /** @deprecated use `DeploymentContextRuntimeMetadata$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextRuntimeMetadata, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextRuntimeMetadata$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextRuntimeMetadata$Outbound, z.ZodTypeDef, DeploymentContextRuntimeMetadata>;
    /** @deprecated use `DeploymentContextRuntimeMetadata$Outbound` instead. */
    type Outbound = DeploymentContextRuntimeMetadata$Outbound;
}
export declare function deploymentContextRuntimeMetadataToJSON(deploymentContextRuntimeMetadata: DeploymentContextRuntimeMetadata): string;
export declare function deploymentContextRuntimeMetadataFromJSON(jsonString: string): SafeParseResult<DeploymentContextRuntimeMetadata, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStatePlatform$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatform>;
/** @internal */
export declare const DeploymentContextStackStatePlatform$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStatePlatform$ {
    /** @deprecated use `DeploymentContextStackStatePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `DeploymentContextStackStatePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const DeploymentContextStackStateConfig$inboundSchema: z.ZodType<DeploymentContextStackStateConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextStackStateConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const DeploymentContextStackStateConfig$outboundSchema: z.ZodType<DeploymentContextStackStateConfig$Outbound, z.ZodTypeDef, DeploymentContextStackStateConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStateConfig$ {
    /** @deprecated use `DeploymentContextStackStateConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextStackStateConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextStackStateConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextStackStateConfig$Outbound, z.ZodTypeDef, DeploymentContextStackStateConfig>;
    /** @deprecated use `DeploymentContextStackStateConfig$Outbound` instead. */
    type Outbound = DeploymentContextStackStateConfig$Outbound;
}
export declare function deploymentContextStackStateConfigToJSON(deploymentContextStackStateConfig: DeploymentContextStackStateConfig): string;
export declare function deploymentContextStackStateConfigFromJSON(jsonString: string): SafeParseResult<DeploymentContextStackStateConfig, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStateDependency$inboundSchema: z.ZodType<DeploymentContextStackStateDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextStackStateDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const DeploymentContextStackStateDependency$outboundSchema: z.ZodType<DeploymentContextStackStateDependency$Outbound, z.ZodTypeDef, DeploymentContextStackStateDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStateDependency$ {
    /** @deprecated use `DeploymentContextStackStateDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextStackStateDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextStackStateDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextStackStateDependency$Outbound, z.ZodTypeDef, DeploymentContextStackStateDependency>;
    /** @deprecated use `DeploymentContextStackStateDependency$Outbound` instead. */
    type Outbound = DeploymentContextStackStateDependency$Outbound;
}
export declare function deploymentContextStackStateDependencyToJSON(deploymentContextStackStateDependency: DeploymentContextStackStateDependency): string;
export declare function deploymentContextStackStateDependencyFromJSON(jsonString: string): SafeParseResult<DeploymentContextStackStateDependency, SDKValidationError>;
/** @internal */
export declare const DeploymentContextError$inboundSchema: z.ZodType<DeploymentContextError, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextError$Outbound = {
    code: string;
    context?: any | null | undefined;
    httpStatusCode?: number | null | undefined;
    internal: boolean;
    message: string;
    retryable: boolean;
    source?: any | null | undefined;
};
/** @internal */
export declare const DeploymentContextError$outboundSchema: z.ZodType<DeploymentContextError$Outbound, z.ZodTypeDef, DeploymentContextError>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextError$ {
    /** @deprecated use `DeploymentContextError$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextError, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextError$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextError$Outbound, z.ZodTypeDef, DeploymentContextError>;
    /** @deprecated use `DeploymentContextError$Outbound` instead. */
    type Outbound = DeploymentContextError$Outbound;
}
export declare function deploymentContextErrorToJSON(deploymentContextError: DeploymentContextError): string;
export declare function deploymentContextErrorFromJSON(jsonString: string): SafeParseResult<DeploymentContextError, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStateLifecycle$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStateLifecycle>;
/** @internal */
export declare const DeploymentContextStackStateLifecycle$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStateLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStateLifecycle$ {
    /** @deprecated use `DeploymentContextStackStateLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `DeploymentContextStackStateLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const DeploymentContextOutputs$inboundSchema: z.ZodType<DeploymentContextOutputs, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextOutputs$Outbound = {
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const DeploymentContextOutputs$outboundSchema: z.ZodType<DeploymentContextOutputs$Outbound, z.ZodTypeDef, DeploymentContextOutputs>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextOutputs$ {
    /** @deprecated use `DeploymentContextOutputs$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextOutputs, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextOutputs$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextOutputs$Outbound, z.ZodTypeDef, DeploymentContextOutputs>;
    /** @deprecated use `DeploymentContextOutputs$Outbound` instead. */
    type Outbound = DeploymentContextOutputs$Outbound;
}
export declare function deploymentContextOutputsToJSON(deploymentContextOutputs: DeploymentContextOutputs): string;
export declare function deploymentContextOutputsFromJSON(jsonString: string): SafeParseResult<DeploymentContextOutputs, SDKValidationError>;
/** @internal */
export declare const DeploymentContextPreviousConfig$inboundSchema: z.ZodType<DeploymentContextPreviousConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextPreviousConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const DeploymentContextPreviousConfig$outboundSchema: z.ZodType<DeploymentContextPreviousConfig$Outbound, z.ZodTypeDef, DeploymentContextPreviousConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextPreviousConfig$ {
    /** @deprecated use `DeploymentContextPreviousConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextPreviousConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextPreviousConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextPreviousConfig$Outbound, z.ZodTypeDef, DeploymentContextPreviousConfig>;
    /** @deprecated use `DeploymentContextPreviousConfig$Outbound` instead. */
    type Outbound = DeploymentContextPreviousConfig$Outbound;
}
export declare function deploymentContextPreviousConfigToJSON(deploymentContextPreviousConfig: DeploymentContextPreviousConfig): string;
export declare function deploymentContextPreviousConfigFromJSON(jsonString: string): SafeParseResult<DeploymentContextPreviousConfig, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStateStatus$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStateStatus>;
/** @internal */
export declare const DeploymentContextStackStateStatus$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStateStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStateStatus$ {
    /** @deprecated use `DeploymentContextStackStateStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
    /** @deprecated use `DeploymentContextStackStateStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
}
/** @internal */
export declare const DeploymentContextStackStateResources$inboundSchema: z.ZodType<DeploymentContextStackStateResources, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextStackStateResources$Outbound = {
    _internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    config: DeploymentContextStackStateConfig$Outbound;
    dependencies?: Array<DeploymentContextStackStateDependency$Outbound> | undefined;
    error?: any | null | undefined;
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    retryAttempt?: number | undefined;
    status: string;
    type: string;
};
/** @internal */
export declare const DeploymentContextStackStateResources$outboundSchema: z.ZodType<DeploymentContextStackStateResources$Outbound, z.ZodTypeDef, DeploymentContextStackStateResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStateResources$ {
    /** @deprecated use `DeploymentContextStackStateResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextStackStateResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextStackStateResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextStackStateResources$Outbound, z.ZodTypeDef, DeploymentContextStackStateResources>;
    /** @deprecated use `DeploymentContextStackStateResources$Outbound` instead. */
    type Outbound = DeploymentContextStackStateResources$Outbound;
}
export declare function deploymentContextStackStateResourcesToJSON(deploymentContextStackStateResources: DeploymentContextStackStateResources): string;
export declare function deploymentContextStackStateResourcesFromJSON(jsonString: string): SafeParseResult<DeploymentContextStackStateResources, SDKValidationError>;
/** @internal */
export declare const DeploymentContextKubernetesInfrastructurePlatform$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextKubernetesInfrastructurePlatform>;
/** @internal */
export declare const DeploymentContextKubernetesInfrastructurePlatform$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextKubernetesInfrastructurePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextKubernetesInfrastructurePlatform$ {
    /** @deprecated use `DeploymentContextKubernetesInfrastructurePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `DeploymentContextKubernetesInfrastructurePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const DeploymentContextStackStatePlatformKubernetes$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformKubernetes>;
/** @internal */
export declare const DeploymentContextStackStatePlatformKubernetes$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStatePlatformKubernetes$ {
    /** @deprecated use `DeploymentContextStackStatePlatformKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
    /** @deprecated use `DeploymentContextStackStatePlatformKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
}
/** @internal */
export declare const DeploymentContextManagementKubernetes$inboundSchema: z.ZodType<DeploymentContextManagementKubernetes, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextManagementKubernetes$Outbound = {
    platform: string;
};
/** @internal */
export declare const DeploymentContextManagementKubernetes$outboundSchema: z.ZodType<DeploymentContextManagementKubernetes$Outbound, z.ZodTypeDef, DeploymentContextManagementKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextManagementKubernetes$ {
    /** @deprecated use `DeploymentContextManagementKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextManagementKubernetes, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextManagementKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextManagementKubernetes$Outbound, z.ZodTypeDef, DeploymentContextManagementKubernetes>;
    /** @deprecated use `DeploymentContextManagementKubernetes$Outbound` instead. */
    type Outbound = DeploymentContextManagementKubernetes$Outbound;
}
export declare function deploymentContextManagementKubernetesToJSON(deploymentContextManagementKubernetes: DeploymentContextManagementKubernetes): string;
export declare function deploymentContextManagementKubernetesFromJSON(jsonString: string): SafeParseResult<DeploymentContextManagementKubernetes, SDKValidationError>;
/** @internal */
export declare const DeploymentContextImagePullCredentialsCurrent$inboundSchema: z.ZodType<DeploymentContextImagePullCredentialsCurrent, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextImagePullCredentialsCurrent$Outbound = {
    password: string;
    username: string;
};
/** @internal */
export declare const DeploymentContextImagePullCredentialsCurrent$outboundSchema: z.ZodType<DeploymentContextImagePullCredentialsCurrent$Outbound, z.ZodTypeDef, DeploymentContextImagePullCredentialsCurrent>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextImagePullCredentialsCurrent$ {
    /** @deprecated use `DeploymentContextImagePullCredentialsCurrent$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextImagePullCredentialsCurrent, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextImagePullCredentialsCurrent$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextImagePullCredentialsCurrent$Outbound, z.ZodTypeDef, DeploymentContextImagePullCredentialsCurrent>;
    /** @deprecated use `DeploymentContextImagePullCredentialsCurrent$Outbound` instead. */
    type Outbound = DeploymentContextImagePullCredentialsCurrent$Outbound;
}
export declare function deploymentContextImagePullCredentialsCurrentToJSON(deploymentContextImagePullCredentialsCurrent: DeploymentContextImagePullCredentialsCurrent): string;
export declare function deploymentContextImagePullCredentialsCurrentFromJSON(jsonString: string): SafeParseResult<DeploymentContextImagePullCredentialsCurrent, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStatePlatformAzure$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformAzure>;
/** @internal */
export declare const DeploymentContextStackStatePlatformAzure$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStatePlatformAzure$ {
    /** @deprecated use `DeploymentContextStackStatePlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `DeploymentContextStackStatePlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const DeploymentContextManagementAzure$inboundSchema: z.ZodType<DeploymentContextManagementAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextManagementAzure$Outbound = {
    imagePullCredentials?: any | null | undefined;
    managementPrincipalId: string;
    managingTenantId: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextManagementAzure$outboundSchema: z.ZodType<DeploymentContextManagementAzure$Outbound, z.ZodTypeDef, DeploymentContextManagementAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextManagementAzure$ {
    /** @deprecated use `DeploymentContextManagementAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextManagementAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextManagementAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextManagementAzure$Outbound, z.ZodTypeDef, DeploymentContextManagementAzure>;
    /** @deprecated use `DeploymentContextManagementAzure$Outbound` instead. */
    type Outbound = DeploymentContextManagementAzure$Outbound;
}
export declare function deploymentContextManagementAzureToJSON(deploymentContextManagementAzure: DeploymentContextManagementAzure): string;
export declare function deploymentContextManagementAzureFromJSON(jsonString: string): SafeParseResult<DeploymentContextManagementAzure, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStatePlatformGcp$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformGcp>;
/** @internal */
export declare const DeploymentContextStackStatePlatformGcp$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStatePlatformGcp$ {
    /** @deprecated use `DeploymentContextStackStatePlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `DeploymentContextStackStatePlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const DeploymentContextManagementGcp$inboundSchema: z.ZodType<DeploymentContextManagementGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextManagementGcp$Outbound = {
    serviceAccountEmail: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextManagementGcp$outboundSchema: z.ZodType<DeploymentContextManagementGcp$Outbound, z.ZodTypeDef, DeploymentContextManagementGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextManagementGcp$ {
    /** @deprecated use `DeploymentContextManagementGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextManagementGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextManagementGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextManagementGcp$Outbound, z.ZodTypeDef, DeploymentContextManagementGcp>;
    /** @deprecated use `DeploymentContextManagementGcp$Outbound` instead. */
    type Outbound = DeploymentContextManagementGcp$Outbound;
}
export declare function deploymentContextManagementGcpToJSON(deploymentContextManagementGcp: DeploymentContextManagementGcp): string;
export declare function deploymentContextManagementGcpFromJSON(jsonString: string): SafeParseResult<DeploymentContextManagementGcp, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackStatePlatformAws$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformAws>;
/** @internal */
export declare const DeploymentContextStackStatePlatformAws$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStackStatePlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackStatePlatformAws$ {
    /** @deprecated use `DeploymentContextStackStatePlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `DeploymentContextStackStatePlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const DeploymentContextManagementAws$inboundSchema: z.ZodType<DeploymentContextManagementAws, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextManagementAws$Outbound = {
    managingRoleArn: string;
    platform: string;
};
/** @internal */
export declare const DeploymentContextManagementAws$outboundSchema: z.ZodType<DeploymentContextManagementAws$Outbound, z.ZodTypeDef, DeploymentContextManagementAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextManagementAws$ {
    /** @deprecated use `DeploymentContextManagementAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextManagementAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextManagementAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextManagementAws$Outbound, z.ZodTypeDef, DeploymentContextManagementAws>;
    /** @deprecated use `DeploymentContextManagementAws$Outbound` instead. */
    type Outbound = DeploymentContextManagementAws$Outbound;
}
export declare function deploymentContextManagementAwsToJSON(deploymentContextManagementAws: DeploymentContextManagementAws): string;
export declare function deploymentContextManagementAwsFromJSON(jsonString: string): SafeParseResult<DeploymentContextManagementAws, SDKValidationError>;
/** @internal */
export declare const DeploymentContextCurrentRemoteCapabilities$inboundSchema: z.ZodType<DeploymentContextCurrentRemoteCapabilities, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrentRemoteCapabilities$Outbound = {
    autoUpdates: boolean;
    heartbeat: boolean;
    monitoring: boolean;
};
/** @internal */
export declare const DeploymentContextCurrentRemoteCapabilities$outboundSchema: z.ZodType<DeploymentContextCurrentRemoteCapabilities$Outbound, z.ZodTypeDef, DeploymentContextCurrentRemoteCapabilities>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrentRemoteCapabilities$ {
    /** @deprecated use `DeploymentContextCurrentRemoteCapabilities$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrentRemoteCapabilities, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrentRemoteCapabilities$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrentRemoteCapabilities$Outbound, z.ZodTypeDef, DeploymentContextCurrentRemoteCapabilities>;
    /** @deprecated use `DeploymentContextCurrentRemoteCapabilities$Outbound` instead. */
    type Outbound = DeploymentContextCurrentRemoteCapabilities$Outbound;
}
export declare function deploymentContextCurrentRemoteCapabilitiesToJSON(deploymentContextCurrentRemoteCapabilities: DeploymentContextCurrentRemoteCapabilities): string;
export declare function deploymentContextCurrentRemoteCapabilitiesFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrentRemoteCapabilities, SDKValidationError>;
/** @internal */
export declare const DeploymentContextSettings$inboundSchema: z.ZodType<DeploymentContextSettings, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextSettings$Outbound = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    remoteCapabilities: DeploymentContextCurrentRemoteCapabilities$Outbound;
};
/** @internal */
export declare const DeploymentContextSettings$outboundSchema: z.ZodType<DeploymentContextSettings$Outbound, z.ZodTypeDef, DeploymentContextSettings>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextSettings$ {
    /** @deprecated use `DeploymentContextSettings$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextSettings, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextSettings$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextSettings$Outbound, z.ZodTypeDef, DeploymentContextSettings>;
    /** @deprecated use `DeploymentContextSettings$Outbound` instead. */
    type Outbound = DeploymentContextSettings$Outbound;
}
export declare function deploymentContextSettingsToJSON(deploymentContextSettings: DeploymentContextSettings): string;
export declare function deploymentContextSettingsFromJSON(jsonString: string): SafeParseResult<DeploymentContextSettings, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStackState$inboundSchema: z.ZodType<DeploymentContextStackState, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextStackState$Outbound = {
    platform: string;
    resourcePrefix: string;
    resources: {
        [k: string]: DeploymentContextStackStateResources$Outbound;
    };
    settings: DeploymentContextSettings$Outbound;
};
/** @internal */
export declare const DeploymentContextStackState$outboundSchema: z.ZodType<DeploymentContextStackState$Outbound, z.ZodTypeDef, DeploymentContextStackState>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStackState$ {
    /** @deprecated use `DeploymentContextStackState$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextStackState, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextStackState$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextStackState$Outbound, z.ZodTypeDef, DeploymentContextStackState>;
    /** @deprecated use `DeploymentContextStackState$Outbound` instead. */
    type Outbound = DeploymentContextStackState$Outbound;
}
export declare function deploymentContextStackStateToJSON(deploymentContextStackState: DeploymentContextStackState): string;
export declare function deploymentContextStackStateFromJSON(jsonString: string): SafeParseResult<DeploymentContextStackState, SDKValidationError>;
/** @internal */
export declare const DeploymentContextStatus$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextStatus>;
/** @internal */
export declare const DeploymentContextStatus$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextStatus$ {
    /** @deprecated use `DeploymentContextStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
    /** @deprecated use `DeploymentContextStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
}
/** @internal */
export declare const DeploymentContextCurrent$inboundSchema: z.ZodType<DeploymentContextCurrent, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextCurrent$Outbound = {
    currentStack?: any | null | undefined;
    environmentInfo?: any | null | undefined;
    platform: string;
    retryRequested?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    status: string;
};
/** @internal */
export declare const DeploymentContextCurrent$outboundSchema: z.ZodType<DeploymentContextCurrent$Outbound, z.ZodTypeDef, DeploymentContextCurrent>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextCurrent$ {
    /** @deprecated use `DeploymentContextCurrent$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextCurrent, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextCurrent$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextCurrent$Outbound, z.ZodTypeDef, DeploymentContextCurrent>;
    /** @deprecated use `DeploymentContextCurrent$Outbound` instead. */
    type Outbound = DeploymentContextCurrent$Outbound;
}
export declare function deploymentContextCurrentToJSON(deploymentContextCurrent: DeploymentContextCurrent): string;
export declare function deploymentContextCurrentFromJSON(jsonString: string): SafeParseResult<DeploymentContextCurrent, SDKValidationError>;
/** @internal */
export declare const ManagementTargetStackEnum$inboundSchema: z.ZodNativeEnum<typeof ManagementTargetStackEnum>;
/** @internal */
export declare const ManagementTargetStackEnum$outboundSchema: z.ZodNativeEnum<typeof ManagementTargetStackEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementTargetStackEnum$ {
    /** @deprecated use `ManagementTargetStackEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `ManagementTargetStackEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const OverrideTargetStackAwResource$inboundSchema: z.ZodType<OverrideTargetStackAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const OverrideTargetStackAwResource$outboundSchema: z.ZodType<OverrideTargetStackAwResource$Outbound, z.ZodTypeDef, OverrideTargetStackAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAwResource$ {
    /** @deprecated use `OverrideTargetStackAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAwResource$Outbound, z.ZodTypeDef, OverrideTargetStackAwResource>;
    /** @deprecated use `OverrideTargetStackAwResource$Outbound` instead. */
    type Outbound = OverrideTargetStackAwResource$Outbound;
}
export declare function overrideTargetStackAwResourceToJSON(overrideTargetStackAwResource: OverrideTargetStackAwResource): string;
export declare function overrideTargetStackAwResourceFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAwResource, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAwStack$inboundSchema: z.ZodType<OverrideTargetStackAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const OverrideTargetStackAwStack$outboundSchema: z.ZodType<OverrideTargetStackAwStack$Outbound, z.ZodTypeDef, OverrideTargetStackAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAwStack$ {
    /** @deprecated use `OverrideTargetStackAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAwStack$Outbound, z.ZodTypeDef, OverrideTargetStackAwStack>;
    /** @deprecated use `OverrideTargetStackAwStack$Outbound` instead. */
    type Outbound = OverrideTargetStackAwStack$Outbound;
}
export declare function overrideTargetStackAwStackToJSON(overrideTargetStackAwStack: OverrideTargetStackAwStack): string;
export declare function overrideTargetStackAwStackFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAwStack, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAwBinding$inboundSchema: z.ZodType<OverrideTargetStackAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAwBinding$Outbound = {
    resource?: OverrideTargetStackAwResource$Outbound | undefined;
    stack?: OverrideTargetStackAwStack$Outbound | undefined;
};
/** @internal */
export declare const OverrideTargetStackAwBinding$outboundSchema: z.ZodType<OverrideTargetStackAwBinding$Outbound, z.ZodTypeDef, OverrideTargetStackAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAwBinding$ {
    /** @deprecated use `OverrideTargetStackAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAwBinding$Outbound, z.ZodTypeDef, OverrideTargetStackAwBinding>;
    /** @deprecated use `OverrideTargetStackAwBinding$Outbound` instead. */
    type Outbound = OverrideTargetStackAwBinding$Outbound;
}
export declare function overrideTargetStackAwBindingToJSON(overrideTargetStackAwBinding: OverrideTargetStackAwBinding): string;
export declare function overrideTargetStackAwBindingFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAwBinding, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAwGrant$inboundSchema: z.ZodType<OverrideTargetStackAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const OverrideTargetStackAwGrant$outboundSchema: z.ZodType<OverrideTargetStackAwGrant$Outbound, z.ZodTypeDef, OverrideTargetStackAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAwGrant$ {
    /** @deprecated use `OverrideTargetStackAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAwGrant$Outbound, z.ZodTypeDef, OverrideTargetStackAwGrant>;
    /** @deprecated use `OverrideTargetStackAwGrant$Outbound` instead. */
    type Outbound = OverrideTargetStackAwGrant$Outbound;
}
export declare function overrideTargetStackAwGrantToJSON(overrideTargetStackAwGrant: OverrideTargetStackAwGrant): string;
export declare function overrideTargetStackAwGrantFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAwGrant, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAw$inboundSchema: z.ZodType<OverrideTargetStackAw, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAw$Outbound = {
    binding: OverrideTargetStackAwBinding$Outbound;
    grant: OverrideTargetStackAwGrant$Outbound;
};
/** @internal */
export declare const OverrideTargetStackAw$outboundSchema: z.ZodType<OverrideTargetStackAw$Outbound, z.ZodTypeDef, OverrideTargetStackAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAw$ {
    /** @deprecated use `OverrideTargetStackAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAw$Outbound, z.ZodTypeDef, OverrideTargetStackAw>;
    /** @deprecated use `OverrideTargetStackAw$Outbound` instead. */
    type Outbound = OverrideTargetStackAw$Outbound;
}
export declare function overrideTargetStackAwToJSON(overrideTargetStackAw: OverrideTargetStackAw): string;
export declare function overrideTargetStackAwFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAw, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAzureResource$inboundSchema: z.ZodType<OverrideTargetStackAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const OverrideTargetStackAzureResource$outboundSchema: z.ZodType<OverrideTargetStackAzureResource$Outbound, z.ZodTypeDef, OverrideTargetStackAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAzureResource$ {
    /** @deprecated use `OverrideTargetStackAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAzureResource$Outbound, z.ZodTypeDef, OverrideTargetStackAzureResource>;
    /** @deprecated use `OverrideTargetStackAzureResource$Outbound` instead. */
    type Outbound = OverrideTargetStackAzureResource$Outbound;
}
export declare function overrideTargetStackAzureResourceToJSON(overrideTargetStackAzureResource: OverrideTargetStackAzureResource): string;
export declare function overrideTargetStackAzureResourceFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAzureResource, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAzureStack$inboundSchema: z.ZodType<OverrideTargetStackAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const OverrideTargetStackAzureStack$outboundSchema: z.ZodType<OverrideTargetStackAzureStack$Outbound, z.ZodTypeDef, OverrideTargetStackAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAzureStack$ {
    /** @deprecated use `OverrideTargetStackAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAzureStack$Outbound, z.ZodTypeDef, OverrideTargetStackAzureStack>;
    /** @deprecated use `OverrideTargetStackAzureStack$Outbound` instead. */
    type Outbound = OverrideTargetStackAzureStack$Outbound;
}
export declare function overrideTargetStackAzureStackToJSON(overrideTargetStackAzureStack: OverrideTargetStackAzureStack): string;
export declare function overrideTargetStackAzureStackFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAzureStack, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAzureBinding$inboundSchema: z.ZodType<OverrideTargetStackAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAzureBinding$Outbound = {
    resource?: OverrideTargetStackAzureResource$Outbound | undefined;
    stack?: OverrideTargetStackAzureStack$Outbound | undefined;
};
/** @internal */
export declare const OverrideTargetStackAzureBinding$outboundSchema: z.ZodType<OverrideTargetStackAzureBinding$Outbound, z.ZodTypeDef, OverrideTargetStackAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAzureBinding$ {
    /** @deprecated use `OverrideTargetStackAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAzureBinding$Outbound, z.ZodTypeDef, OverrideTargetStackAzureBinding>;
    /** @deprecated use `OverrideTargetStackAzureBinding$Outbound` instead. */
    type Outbound = OverrideTargetStackAzureBinding$Outbound;
}
export declare function overrideTargetStackAzureBindingToJSON(overrideTargetStackAzureBinding: OverrideTargetStackAzureBinding): string;
export declare function overrideTargetStackAzureBindingFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAzureBinding, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAzureGrant$inboundSchema: z.ZodType<OverrideTargetStackAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const OverrideTargetStackAzureGrant$outboundSchema: z.ZodType<OverrideTargetStackAzureGrant$Outbound, z.ZodTypeDef, OverrideTargetStackAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAzureGrant$ {
    /** @deprecated use `OverrideTargetStackAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAzureGrant$Outbound, z.ZodTypeDef, OverrideTargetStackAzureGrant>;
    /** @deprecated use `OverrideTargetStackAzureGrant$Outbound` instead. */
    type Outbound = OverrideTargetStackAzureGrant$Outbound;
}
export declare function overrideTargetStackAzureGrantToJSON(overrideTargetStackAzureGrant: OverrideTargetStackAzureGrant): string;
export declare function overrideTargetStackAzureGrantFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAzureGrant, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackAzure$inboundSchema: z.ZodType<OverrideTargetStackAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackAzure$Outbound = {
    binding: OverrideTargetStackAzureBinding$Outbound;
    grant: OverrideTargetStackAzureGrant$Outbound;
};
/** @internal */
export declare const OverrideTargetStackAzure$outboundSchema: z.ZodType<OverrideTargetStackAzure$Outbound, z.ZodTypeDef, OverrideTargetStackAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackAzure$ {
    /** @deprecated use `OverrideTargetStackAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackAzure$Outbound, z.ZodTypeDef, OverrideTargetStackAzure>;
    /** @deprecated use `OverrideTargetStackAzure$Outbound` instead. */
    type Outbound = OverrideTargetStackAzure$Outbound;
}
export declare function overrideTargetStackAzureToJSON(overrideTargetStackAzure: OverrideTargetStackAzure): string;
export declare function overrideTargetStackAzureFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackAzure, SDKValidationError>;
/** @internal */
export declare const OverrideConditionTargetStackResource$inboundSchema: z.ZodType<OverrideConditionTargetStackResource, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideConditionTargetStackResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const OverrideConditionTargetStackResource$outboundSchema: z.ZodType<OverrideConditionTargetStackResource$Outbound, z.ZodTypeDef, OverrideConditionTargetStackResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideConditionTargetStackResource$ {
    /** @deprecated use `OverrideConditionTargetStackResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideConditionTargetStackResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideConditionTargetStackResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideConditionTargetStackResource$Outbound, z.ZodTypeDef, OverrideConditionTargetStackResource>;
    /** @deprecated use `OverrideConditionTargetStackResource$Outbound` instead. */
    type Outbound = OverrideConditionTargetStackResource$Outbound;
}
export declare function overrideConditionTargetStackResourceToJSON(overrideConditionTargetStackResource: OverrideConditionTargetStackResource): string;
export declare function overrideConditionTargetStackResourceFromJSON(jsonString: string): SafeParseResult<OverrideConditionTargetStackResource, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackGcpResource$inboundSchema: z.ZodType<OverrideTargetStackGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const OverrideTargetStackGcpResource$outboundSchema: z.ZodType<OverrideTargetStackGcpResource$Outbound, z.ZodTypeDef, OverrideTargetStackGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackGcpResource$ {
    /** @deprecated use `OverrideTargetStackGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackGcpResource$Outbound, z.ZodTypeDef, OverrideTargetStackGcpResource>;
    /** @deprecated use `OverrideTargetStackGcpResource$Outbound` instead. */
    type Outbound = OverrideTargetStackGcpResource$Outbound;
}
export declare function overrideTargetStackGcpResourceToJSON(overrideTargetStackGcpResource: OverrideTargetStackGcpResource): string;
export declare function overrideTargetStackGcpResourceFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackGcpResource, SDKValidationError>;
/** @internal */
export declare const OverrideConditionTargetStackStack$inboundSchema: z.ZodType<OverrideConditionTargetStackStack, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideConditionTargetStackStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const OverrideConditionTargetStackStack$outboundSchema: z.ZodType<OverrideConditionTargetStackStack$Outbound, z.ZodTypeDef, OverrideConditionTargetStackStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideConditionTargetStackStack$ {
    /** @deprecated use `OverrideConditionTargetStackStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideConditionTargetStackStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideConditionTargetStackStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideConditionTargetStackStack$Outbound, z.ZodTypeDef, OverrideConditionTargetStackStack>;
    /** @deprecated use `OverrideConditionTargetStackStack$Outbound` instead. */
    type Outbound = OverrideConditionTargetStackStack$Outbound;
}
export declare function overrideConditionTargetStackStackToJSON(overrideConditionTargetStackStack: OverrideConditionTargetStackStack): string;
export declare function overrideConditionTargetStackStackFromJSON(jsonString: string): SafeParseResult<OverrideConditionTargetStackStack, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackGcpStack$inboundSchema: z.ZodType<OverrideTargetStackGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const OverrideTargetStackGcpStack$outboundSchema: z.ZodType<OverrideTargetStackGcpStack$Outbound, z.ZodTypeDef, OverrideTargetStackGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackGcpStack$ {
    /** @deprecated use `OverrideTargetStackGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackGcpStack$Outbound, z.ZodTypeDef, OverrideTargetStackGcpStack>;
    /** @deprecated use `OverrideTargetStackGcpStack$Outbound` instead. */
    type Outbound = OverrideTargetStackGcpStack$Outbound;
}
export declare function overrideTargetStackGcpStackToJSON(overrideTargetStackGcpStack: OverrideTargetStackGcpStack): string;
export declare function overrideTargetStackGcpStackFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackGcpStack, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackGcpBinding$inboundSchema: z.ZodType<OverrideTargetStackGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackGcpBinding$Outbound = {
    resource?: OverrideTargetStackGcpResource$Outbound | undefined;
    stack?: OverrideTargetStackGcpStack$Outbound | undefined;
};
/** @internal */
export declare const OverrideTargetStackGcpBinding$outboundSchema: z.ZodType<OverrideTargetStackGcpBinding$Outbound, z.ZodTypeDef, OverrideTargetStackGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackGcpBinding$ {
    /** @deprecated use `OverrideTargetStackGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackGcpBinding$Outbound, z.ZodTypeDef, OverrideTargetStackGcpBinding>;
    /** @deprecated use `OverrideTargetStackGcpBinding$Outbound` instead. */
    type Outbound = OverrideTargetStackGcpBinding$Outbound;
}
export declare function overrideTargetStackGcpBindingToJSON(overrideTargetStackGcpBinding: OverrideTargetStackGcpBinding): string;
export declare function overrideTargetStackGcpBindingFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackGcpBinding, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackGcpGrant$inboundSchema: z.ZodType<OverrideTargetStackGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const OverrideTargetStackGcpGrant$outboundSchema: z.ZodType<OverrideTargetStackGcpGrant$Outbound, z.ZodTypeDef, OverrideTargetStackGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackGcpGrant$ {
    /** @deprecated use `OverrideTargetStackGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackGcpGrant$Outbound, z.ZodTypeDef, OverrideTargetStackGcpGrant>;
    /** @deprecated use `OverrideTargetStackGcpGrant$Outbound` instead. */
    type Outbound = OverrideTargetStackGcpGrant$Outbound;
}
export declare function overrideTargetStackGcpGrantToJSON(overrideTargetStackGcpGrant: OverrideTargetStackGcpGrant): string;
export declare function overrideTargetStackGcpGrantFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackGcpGrant, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackGcp$inboundSchema: z.ZodType<OverrideTargetStackGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackGcp$Outbound = {
    binding: OverrideTargetStackGcpBinding$Outbound;
    grant: OverrideTargetStackGcpGrant$Outbound;
};
/** @internal */
export declare const OverrideTargetStackGcp$outboundSchema: z.ZodType<OverrideTargetStackGcp$Outbound, z.ZodTypeDef, OverrideTargetStackGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackGcp$ {
    /** @deprecated use `OverrideTargetStackGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackGcp$Outbound, z.ZodTypeDef, OverrideTargetStackGcp>;
    /** @deprecated use `OverrideTargetStackGcp$Outbound` instead. */
    type Outbound = OverrideTargetStackGcp$Outbound;
}
export declare function overrideTargetStackGcpToJSON(overrideTargetStackGcp: OverrideTargetStackGcp): string;
export declare function overrideTargetStackGcpFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackGcp, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStackPlatforms$inboundSchema: z.ZodType<OverrideTargetStackPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStackPlatforms$Outbound = {
    aws?: Array<OverrideTargetStackAw$Outbound> | null | undefined;
    azure?: Array<OverrideTargetStackAzure$Outbound> | null | undefined;
    gcp?: Array<OverrideTargetStackGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const OverrideTargetStackPlatforms$outboundSchema: z.ZodType<OverrideTargetStackPlatforms$Outbound, z.ZodTypeDef, OverrideTargetStackPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStackPlatforms$ {
    /** @deprecated use `OverrideTargetStackPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStackPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStackPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStackPlatforms$Outbound, z.ZodTypeDef, OverrideTargetStackPlatforms>;
    /** @deprecated use `OverrideTargetStackPlatforms$Outbound` instead. */
    type Outbound = OverrideTargetStackPlatforms$Outbound;
}
export declare function overrideTargetStackPlatformsToJSON(overrideTargetStackPlatforms: OverrideTargetStackPlatforms): string;
export declare function overrideTargetStackPlatformsFromJSON(jsonString: string): SafeParseResult<OverrideTargetStackPlatforms, SDKValidationError>;
/** @internal */
export declare const OverrideTargetStack$inboundSchema: z.ZodType<OverrideTargetStack, z.ZodTypeDef, unknown>;
/** @internal */
export type OverrideTargetStack$Outbound = {
    description: string;
    id: string;
    platforms: OverrideTargetStackPlatforms$Outbound;
};
/** @internal */
export declare const OverrideTargetStack$outboundSchema: z.ZodType<OverrideTargetStack$Outbound, z.ZodTypeDef, OverrideTargetStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace OverrideTargetStack$ {
    /** @deprecated use `OverrideTargetStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<OverrideTargetStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `OverrideTargetStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<OverrideTargetStack$Outbound, z.ZodTypeDef, OverrideTargetStack>;
    /** @deprecated use `OverrideTargetStack$Outbound` instead. */
    type Outbound = OverrideTargetStack$Outbound;
}
export declare function overrideTargetStackToJSON(overrideTargetStack: OverrideTargetStack): string;
export declare function overrideTargetStackFromJSON(jsonString: string): SafeParseResult<OverrideTargetStack, SDKValidationError>;
/** @internal */
export declare const TargetStackOverrideUnion$inboundSchema: z.ZodType<TargetStackOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackOverrideUnion$Outbound = OverrideTargetStack$Outbound | string;
/** @internal */
export declare const TargetStackOverrideUnion$outboundSchema: z.ZodType<TargetStackOverrideUnion$Outbound, z.ZodTypeDef, TargetStackOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackOverrideUnion$ {
    /** @deprecated use `TargetStackOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackOverrideUnion$Outbound, z.ZodTypeDef, TargetStackOverrideUnion>;
    /** @deprecated use `TargetStackOverrideUnion$Outbound` instead. */
    type Outbound = TargetStackOverrideUnion$Outbound;
}
export declare function targetStackOverrideUnionToJSON(targetStackOverrideUnion: TargetStackOverrideUnion): string;
export declare function targetStackOverrideUnionFromJSON(jsonString: string): SafeParseResult<TargetStackOverrideUnion, SDKValidationError>;
/** @internal */
export declare const ManagementTargetStack2$inboundSchema: z.ZodType<ManagementTargetStack2, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementTargetStack2$Outbound = {
    override: {
        [k: string]: Array<OverrideTargetStack$Outbound | string>;
    };
};
/** @internal */
export declare const ManagementTargetStack2$outboundSchema: z.ZodType<ManagementTargetStack2$Outbound, z.ZodTypeDef, ManagementTargetStack2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementTargetStack2$ {
    /** @deprecated use `ManagementTargetStack2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementTargetStack2, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementTargetStack2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementTargetStack2$Outbound, z.ZodTypeDef, ManagementTargetStack2>;
    /** @deprecated use `ManagementTargetStack2$Outbound` instead. */
    type Outbound = ManagementTargetStack2$Outbound;
}
export declare function managementTargetStack2ToJSON(managementTargetStack2: ManagementTargetStack2): string;
export declare function managementTargetStack2FromJSON(jsonString: string): SafeParseResult<ManagementTargetStack2, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAwResource$inboundSchema: z.ZodType<ExtendTargetStackAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ExtendTargetStackAwResource$outboundSchema: z.ZodType<ExtendTargetStackAwResource$Outbound, z.ZodTypeDef, ExtendTargetStackAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAwResource$ {
    /** @deprecated use `ExtendTargetStackAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAwResource$Outbound, z.ZodTypeDef, ExtendTargetStackAwResource>;
    /** @deprecated use `ExtendTargetStackAwResource$Outbound` instead. */
    type Outbound = ExtendTargetStackAwResource$Outbound;
}
export declare function extendTargetStackAwResourceToJSON(extendTargetStackAwResource: ExtendTargetStackAwResource): string;
export declare function extendTargetStackAwResourceFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAwResource, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAwStack$inboundSchema: z.ZodType<ExtendTargetStackAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ExtendTargetStackAwStack$outboundSchema: z.ZodType<ExtendTargetStackAwStack$Outbound, z.ZodTypeDef, ExtendTargetStackAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAwStack$ {
    /** @deprecated use `ExtendTargetStackAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAwStack$Outbound, z.ZodTypeDef, ExtendTargetStackAwStack>;
    /** @deprecated use `ExtendTargetStackAwStack$Outbound` instead. */
    type Outbound = ExtendTargetStackAwStack$Outbound;
}
export declare function extendTargetStackAwStackToJSON(extendTargetStackAwStack: ExtendTargetStackAwStack): string;
export declare function extendTargetStackAwStackFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAwStack, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAwBinding$inboundSchema: z.ZodType<ExtendTargetStackAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAwBinding$Outbound = {
    resource?: ExtendTargetStackAwResource$Outbound | undefined;
    stack?: ExtendTargetStackAwStack$Outbound | undefined;
};
/** @internal */
export declare const ExtendTargetStackAwBinding$outboundSchema: z.ZodType<ExtendTargetStackAwBinding$Outbound, z.ZodTypeDef, ExtendTargetStackAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAwBinding$ {
    /** @deprecated use `ExtendTargetStackAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAwBinding$Outbound, z.ZodTypeDef, ExtendTargetStackAwBinding>;
    /** @deprecated use `ExtendTargetStackAwBinding$Outbound` instead. */
    type Outbound = ExtendTargetStackAwBinding$Outbound;
}
export declare function extendTargetStackAwBindingToJSON(extendTargetStackAwBinding: ExtendTargetStackAwBinding): string;
export declare function extendTargetStackAwBindingFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAwBinding, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAwGrant$inboundSchema: z.ZodType<ExtendTargetStackAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ExtendTargetStackAwGrant$outboundSchema: z.ZodType<ExtendTargetStackAwGrant$Outbound, z.ZodTypeDef, ExtendTargetStackAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAwGrant$ {
    /** @deprecated use `ExtendTargetStackAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAwGrant$Outbound, z.ZodTypeDef, ExtendTargetStackAwGrant>;
    /** @deprecated use `ExtendTargetStackAwGrant$Outbound` instead. */
    type Outbound = ExtendTargetStackAwGrant$Outbound;
}
export declare function extendTargetStackAwGrantToJSON(extendTargetStackAwGrant: ExtendTargetStackAwGrant): string;
export declare function extendTargetStackAwGrantFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAwGrant, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAw$inboundSchema: z.ZodType<ExtendTargetStackAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAw$Outbound = {
    binding: ExtendTargetStackAwBinding$Outbound;
    grant: ExtendTargetStackAwGrant$Outbound;
};
/** @internal */
export declare const ExtendTargetStackAw$outboundSchema: z.ZodType<ExtendTargetStackAw$Outbound, z.ZodTypeDef, ExtendTargetStackAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAw$ {
    /** @deprecated use `ExtendTargetStackAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAw$Outbound, z.ZodTypeDef, ExtendTargetStackAw>;
    /** @deprecated use `ExtendTargetStackAw$Outbound` instead. */
    type Outbound = ExtendTargetStackAw$Outbound;
}
export declare function extendTargetStackAwToJSON(extendTargetStackAw: ExtendTargetStackAw): string;
export declare function extendTargetStackAwFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAw, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAzureResource$inboundSchema: z.ZodType<ExtendTargetStackAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ExtendTargetStackAzureResource$outboundSchema: z.ZodType<ExtendTargetStackAzureResource$Outbound, z.ZodTypeDef, ExtendTargetStackAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAzureResource$ {
    /** @deprecated use `ExtendTargetStackAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAzureResource$Outbound, z.ZodTypeDef, ExtendTargetStackAzureResource>;
    /** @deprecated use `ExtendTargetStackAzureResource$Outbound` instead. */
    type Outbound = ExtendTargetStackAzureResource$Outbound;
}
export declare function extendTargetStackAzureResourceToJSON(extendTargetStackAzureResource: ExtendTargetStackAzureResource): string;
export declare function extendTargetStackAzureResourceFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAzureResource, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAzureStack$inboundSchema: z.ZodType<ExtendTargetStackAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ExtendTargetStackAzureStack$outboundSchema: z.ZodType<ExtendTargetStackAzureStack$Outbound, z.ZodTypeDef, ExtendTargetStackAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAzureStack$ {
    /** @deprecated use `ExtendTargetStackAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAzureStack$Outbound, z.ZodTypeDef, ExtendTargetStackAzureStack>;
    /** @deprecated use `ExtendTargetStackAzureStack$Outbound` instead. */
    type Outbound = ExtendTargetStackAzureStack$Outbound;
}
export declare function extendTargetStackAzureStackToJSON(extendTargetStackAzureStack: ExtendTargetStackAzureStack): string;
export declare function extendTargetStackAzureStackFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAzureStack, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAzureBinding$inboundSchema: z.ZodType<ExtendTargetStackAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAzureBinding$Outbound = {
    resource?: ExtendTargetStackAzureResource$Outbound | undefined;
    stack?: ExtendTargetStackAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ExtendTargetStackAzureBinding$outboundSchema: z.ZodType<ExtendTargetStackAzureBinding$Outbound, z.ZodTypeDef, ExtendTargetStackAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAzureBinding$ {
    /** @deprecated use `ExtendTargetStackAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAzureBinding$Outbound, z.ZodTypeDef, ExtendTargetStackAzureBinding>;
    /** @deprecated use `ExtendTargetStackAzureBinding$Outbound` instead. */
    type Outbound = ExtendTargetStackAzureBinding$Outbound;
}
export declare function extendTargetStackAzureBindingToJSON(extendTargetStackAzureBinding: ExtendTargetStackAzureBinding): string;
export declare function extendTargetStackAzureBindingFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAzureBinding, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAzureGrant$inboundSchema: z.ZodType<ExtendTargetStackAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ExtendTargetStackAzureGrant$outboundSchema: z.ZodType<ExtendTargetStackAzureGrant$Outbound, z.ZodTypeDef, ExtendTargetStackAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAzureGrant$ {
    /** @deprecated use `ExtendTargetStackAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAzureGrant$Outbound, z.ZodTypeDef, ExtendTargetStackAzureGrant>;
    /** @deprecated use `ExtendTargetStackAzureGrant$Outbound` instead. */
    type Outbound = ExtendTargetStackAzureGrant$Outbound;
}
export declare function extendTargetStackAzureGrantToJSON(extendTargetStackAzureGrant: ExtendTargetStackAzureGrant): string;
export declare function extendTargetStackAzureGrantFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAzureGrant, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackAzure$inboundSchema: z.ZodType<ExtendTargetStackAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackAzure$Outbound = {
    binding: ExtendTargetStackAzureBinding$Outbound;
    grant: ExtendTargetStackAzureGrant$Outbound;
};
/** @internal */
export declare const ExtendTargetStackAzure$outboundSchema: z.ZodType<ExtendTargetStackAzure$Outbound, z.ZodTypeDef, ExtendTargetStackAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackAzure$ {
    /** @deprecated use `ExtendTargetStackAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackAzure$Outbound, z.ZodTypeDef, ExtendTargetStackAzure>;
    /** @deprecated use `ExtendTargetStackAzure$Outbound` instead. */
    type Outbound = ExtendTargetStackAzure$Outbound;
}
export declare function extendTargetStackAzureToJSON(extendTargetStackAzure: ExtendTargetStackAzure): string;
export declare function extendTargetStackAzureFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackAzure, SDKValidationError>;
/** @internal */
export declare const ExtendConditionTargetStackResource$inboundSchema: z.ZodType<ExtendConditionTargetStackResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendConditionTargetStackResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ExtendConditionTargetStackResource$outboundSchema: z.ZodType<ExtendConditionTargetStackResource$Outbound, z.ZodTypeDef, ExtendConditionTargetStackResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendConditionTargetStackResource$ {
    /** @deprecated use `ExtendConditionTargetStackResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendConditionTargetStackResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendConditionTargetStackResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendConditionTargetStackResource$Outbound, z.ZodTypeDef, ExtendConditionTargetStackResource>;
    /** @deprecated use `ExtendConditionTargetStackResource$Outbound` instead. */
    type Outbound = ExtendConditionTargetStackResource$Outbound;
}
export declare function extendConditionTargetStackResourceToJSON(extendConditionTargetStackResource: ExtendConditionTargetStackResource): string;
export declare function extendConditionTargetStackResourceFromJSON(jsonString: string): SafeParseResult<ExtendConditionTargetStackResource, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackGcpResource$inboundSchema: z.ZodType<ExtendTargetStackGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ExtendTargetStackGcpResource$outboundSchema: z.ZodType<ExtendTargetStackGcpResource$Outbound, z.ZodTypeDef, ExtendTargetStackGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackGcpResource$ {
    /** @deprecated use `ExtendTargetStackGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackGcpResource$Outbound, z.ZodTypeDef, ExtendTargetStackGcpResource>;
    /** @deprecated use `ExtendTargetStackGcpResource$Outbound` instead. */
    type Outbound = ExtendTargetStackGcpResource$Outbound;
}
export declare function extendTargetStackGcpResourceToJSON(extendTargetStackGcpResource: ExtendTargetStackGcpResource): string;
export declare function extendTargetStackGcpResourceFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackGcpResource, SDKValidationError>;
/** @internal */
export declare const ExtendConditionTargetStackStack$inboundSchema: z.ZodType<ExtendConditionTargetStackStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendConditionTargetStackStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ExtendConditionTargetStackStack$outboundSchema: z.ZodType<ExtendConditionTargetStackStack$Outbound, z.ZodTypeDef, ExtendConditionTargetStackStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendConditionTargetStackStack$ {
    /** @deprecated use `ExtendConditionTargetStackStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendConditionTargetStackStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendConditionTargetStackStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendConditionTargetStackStack$Outbound, z.ZodTypeDef, ExtendConditionTargetStackStack>;
    /** @deprecated use `ExtendConditionTargetStackStack$Outbound` instead. */
    type Outbound = ExtendConditionTargetStackStack$Outbound;
}
export declare function extendConditionTargetStackStackToJSON(extendConditionTargetStackStack: ExtendConditionTargetStackStack): string;
export declare function extendConditionTargetStackStackFromJSON(jsonString: string): SafeParseResult<ExtendConditionTargetStackStack, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackGcpStack$inboundSchema: z.ZodType<ExtendTargetStackGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ExtendTargetStackGcpStack$outboundSchema: z.ZodType<ExtendTargetStackGcpStack$Outbound, z.ZodTypeDef, ExtendTargetStackGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackGcpStack$ {
    /** @deprecated use `ExtendTargetStackGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackGcpStack$Outbound, z.ZodTypeDef, ExtendTargetStackGcpStack>;
    /** @deprecated use `ExtendTargetStackGcpStack$Outbound` instead. */
    type Outbound = ExtendTargetStackGcpStack$Outbound;
}
export declare function extendTargetStackGcpStackToJSON(extendTargetStackGcpStack: ExtendTargetStackGcpStack): string;
export declare function extendTargetStackGcpStackFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackGcpStack, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackGcpBinding$inboundSchema: z.ZodType<ExtendTargetStackGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackGcpBinding$Outbound = {
    resource?: ExtendTargetStackGcpResource$Outbound | undefined;
    stack?: ExtendTargetStackGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ExtendTargetStackGcpBinding$outboundSchema: z.ZodType<ExtendTargetStackGcpBinding$Outbound, z.ZodTypeDef, ExtendTargetStackGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackGcpBinding$ {
    /** @deprecated use `ExtendTargetStackGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackGcpBinding$Outbound, z.ZodTypeDef, ExtendTargetStackGcpBinding>;
    /** @deprecated use `ExtendTargetStackGcpBinding$Outbound` instead. */
    type Outbound = ExtendTargetStackGcpBinding$Outbound;
}
export declare function extendTargetStackGcpBindingToJSON(extendTargetStackGcpBinding: ExtendTargetStackGcpBinding): string;
export declare function extendTargetStackGcpBindingFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackGcpBinding, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackGcpGrant$inboundSchema: z.ZodType<ExtendTargetStackGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ExtendTargetStackGcpGrant$outboundSchema: z.ZodType<ExtendTargetStackGcpGrant$Outbound, z.ZodTypeDef, ExtendTargetStackGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackGcpGrant$ {
    /** @deprecated use `ExtendTargetStackGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackGcpGrant$Outbound, z.ZodTypeDef, ExtendTargetStackGcpGrant>;
    /** @deprecated use `ExtendTargetStackGcpGrant$Outbound` instead. */
    type Outbound = ExtendTargetStackGcpGrant$Outbound;
}
export declare function extendTargetStackGcpGrantToJSON(extendTargetStackGcpGrant: ExtendTargetStackGcpGrant): string;
export declare function extendTargetStackGcpGrantFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackGcpGrant, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackGcp$inboundSchema: z.ZodType<ExtendTargetStackGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackGcp$Outbound = {
    binding: ExtendTargetStackGcpBinding$Outbound;
    grant: ExtendTargetStackGcpGrant$Outbound;
};
/** @internal */
export declare const ExtendTargetStackGcp$outboundSchema: z.ZodType<ExtendTargetStackGcp$Outbound, z.ZodTypeDef, ExtendTargetStackGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackGcp$ {
    /** @deprecated use `ExtendTargetStackGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackGcp$Outbound, z.ZodTypeDef, ExtendTargetStackGcp>;
    /** @deprecated use `ExtendTargetStackGcp$Outbound` instead. */
    type Outbound = ExtendTargetStackGcp$Outbound;
}
export declare function extendTargetStackGcpToJSON(extendTargetStackGcp: ExtendTargetStackGcp): string;
export declare function extendTargetStackGcpFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackGcp, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStackPlatforms$inboundSchema: z.ZodType<ExtendTargetStackPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStackPlatforms$Outbound = {
    aws?: Array<ExtendTargetStackAw$Outbound> | null | undefined;
    azure?: Array<ExtendTargetStackAzure$Outbound> | null | undefined;
    gcp?: Array<ExtendTargetStackGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ExtendTargetStackPlatforms$outboundSchema: z.ZodType<ExtendTargetStackPlatforms$Outbound, z.ZodTypeDef, ExtendTargetStackPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStackPlatforms$ {
    /** @deprecated use `ExtendTargetStackPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStackPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStackPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStackPlatforms$Outbound, z.ZodTypeDef, ExtendTargetStackPlatforms>;
    /** @deprecated use `ExtendTargetStackPlatforms$Outbound` instead. */
    type Outbound = ExtendTargetStackPlatforms$Outbound;
}
export declare function extendTargetStackPlatformsToJSON(extendTargetStackPlatforms: ExtendTargetStackPlatforms): string;
export declare function extendTargetStackPlatformsFromJSON(jsonString: string): SafeParseResult<ExtendTargetStackPlatforms, SDKValidationError>;
/** @internal */
export declare const ExtendTargetStack$inboundSchema: z.ZodType<ExtendTargetStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ExtendTargetStack$Outbound = {
    description: string;
    id: string;
    platforms: ExtendTargetStackPlatforms$Outbound;
};
/** @internal */
export declare const ExtendTargetStack$outboundSchema: z.ZodType<ExtendTargetStack$Outbound, z.ZodTypeDef, ExtendTargetStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExtendTargetStack$ {
    /** @deprecated use `ExtendTargetStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExtendTargetStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExtendTargetStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExtendTargetStack$Outbound, z.ZodTypeDef, ExtendTargetStack>;
    /** @deprecated use `ExtendTargetStack$Outbound` instead. */
    type Outbound = ExtendTargetStack$Outbound;
}
export declare function extendTargetStackToJSON(extendTargetStack: ExtendTargetStack): string;
export declare function extendTargetStackFromJSON(jsonString: string): SafeParseResult<ExtendTargetStack, SDKValidationError>;
/** @internal */
export declare const TargetStackExtendUnion$inboundSchema: z.ZodType<TargetStackExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackExtendUnion$Outbound = ExtendTargetStack$Outbound | string;
/** @internal */
export declare const TargetStackExtendUnion$outboundSchema: z.ZodType<TargetStackExtendUnion$Outbound, z.ZodTypeDef, TargetStackExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackExtendUnion$ {
    /** @deprecated use `TargetStackExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackExtendUnion$Outbound, z.ZodTypeDef, TargetStackExtendUnion>;
    /** @deprecated use `TargetStackExtendUnion$Outbound` instead. */
    type Outbound = TargetStackExtendUnion$Outbound;
}
export declare function targetStackExtendUnionToJSON(targetStackExtendUnion: TargetStackExtendUnion): string;
export declare function targetStackExtendUnionFromJSON(jsonString: string): SafeParseResult<TargetStackExtendUnion, SDKValidationError>;
/** @internal */
export declare const ManagementTargetStack1$inboundSchema: z.ZodType<ManagementTargetStack1, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementTargetStack1$Outbound = {
    extend: {
        [k: string]: Array<ExtendTargetStack$Outbound | string>;
    };
};
/** @internal */
export declare const ManagementTargetStack1$outboundSchema: z.ZodType<ManagementTargetStack1$Outbound, z.ZodTypeDef, ManagementTargetStack1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementTargetStack1$ {
    /** @deprecated use `ManagementTargetStack1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementTargetStack1, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementTargetStack1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementTargetStack1$Outbound, z.ZodTypeDef, ManagementTargetStack1>;
    /** @deprecated use `ManagementTargetStack1$Outbound` instead. */
    type Outbound = ManagementTargetStack1$Outbound;
}
export declare function managementTargetStack1ToJSON(managementTargetStack1: ManagementTargetStack1): string;
export declare function managementTargetStack1FromJSON(jsonString: string): SafeParseResult<ManagementTargetStack1, SDKValidationError>;
/** @internal */
export declare const TargetStackManagementUnion$inboundSchema: z.ZodType<TargetStackManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackManagementUnion$Outbound = ManagementTargetStack1$Outbound | ManagementTargetStack2$Outbound | string;
/** @internal */
export declare const TargetStackManagementUnion$outboundSchema: z.ZodType<TargetStackManagementUnion$Outbound, z.ZodTypeDef, TargetStackManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackManagementUnion$ {
    /** @deprecated use `TargetStackManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackManagementUnion$Outbound, z.ZodTypeDef, TargetStackManagementUnion>;
    /** @deprecated use `TargetStackManagementUnion$Outbound` instead. */
    type Outbound = TargetStackManagementUnion$Outbound;
}
export declare function targetStackManagementUnionToJSON(targetStackManagementUnion: TargetStackManagementUnion): string;
export declare function targetStackManagementUnionFromJSON(jsonString: string): SafeParseResult<TargetStackManagementUnion, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAwResource$inboundSchema: z.ZodType<ProfileTargetStackAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ProfileTargetStackAwResource$outboundSchema: z.ZodType<ProfileTargetStackAwResource$Outbound, z.ZodTypeDef, ProfileTargetStackAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAwResource$ {
    /** @deprecated use `ProfileTargetStackAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAwResource$Outbound, z.ZodTypeDef, ProfileTargetStackAwResource>;
    /** @deprecated use `ProfileTargetStackAwResource$Outbound` instead. */
    type Outbound = ProfileTargetStackAwResource$Outbound;
}
export declare function profileTargetStackAwResourceToJSON(profileTargetStackAwResource: ProfileTargetStackAwResource): string;
export declare function profileTargetStackAwResourceFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAwResource, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAwStack$inboundSchema: z.ZodType<ProfileTargetStackAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ProfileTargetStackAwStack$outboundSchema: z.ZodType<ProfileTargetStackAwStack$Outbound, z.ZodTypeDef, ProfileTargetStackAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAwStack$ {
    /** @deprecated use `ProfileTargetStackAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAwStack$Outbound, z.ZodTypeDef, ProfileTargetStackAwStack>;
    /** @deprecated use `ProfileTargetStackAwStack$Outbound` instead. */
    type Outbound = ProfileTargetStackAwStack$Outbound;
}
export declare function profileTargetStackAwStackToJSON(profileTargetStackAwStack: ProfileTargetStackAwStack): string;
export declare function profileTargetStackAwStackFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAwStack, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAwBinding$inboundSchema: z.ZodType<ProfileTargetStackAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAwBinding$Outbound = {
    resource?: ProfileTargetStackAwResource$Outbound | undefined;
    stack?: ProfileTargetStackAwStack$Outbound | undefined;
};
/** @internal */
export declare const ProfileTargetStackAwBinding$outboundSchema: z.ZodType<ProfileTargetStackAwBinding$Outbound, z.ZodTypeDef, ProfileTargetStackAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAwBinding$ {
    /** @deprecated use `ProfileTargetStackAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAwBinding$Outbound, z.ZodTypeDef, ProfileTargetStackAwBinding>;
    /** @deprecated use `ProfileTargetStackAwBinding$Outbound` instead. */
    type Outbound = ProfileTargetStackAwBinding$Outbound;
}
export declare function profileTargetStackAwBindingToJSON(profileTargetStackAwBinding: ProfileTargetStackAwBinding): string;
export declare function profileTargetStackAwBindingFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAwBinding, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAwGrant$inboundSchema: z.ZodType<ProfileTargetStackAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ProfileTargetStackAwGrant$outboundSchema: z.ZodType<ProfileTargetStackAwGrant$Outbound, z.ZodTypeDef, ProfileTargetStackAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAwGrant$ {
    /** @deprecated use `ProfileTargetStackAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAwGrant$Outbound, z.ZodTypeDef, ProfileTargetStackAwGrant>;
    /** @deprecated use `ProfileTargetStackAwGrant$Outbound` instead. */
    type Outbound = ProfileTargetStackAwGrant$Outbound;
}
export declare function profileTargetStackAwGrantToJSON(profileTargetStackAwGrant: ProfileTargetStackAwGrant): string;
export declare function profileTargetStackAwGrantFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAwGrant, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAw$inboundSchema: z.ZodType<ProfileTargetStackAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAw$Outbound = {
    binding: ProfileTargetStackAwBinding$Outbound;
    grant: ProfileTargetStackAwGrant$Outbound;
};
/** @internal */
export declare const ProfileTargetStackAw$outboundSchema: z.ZodType<ProfileTargetStackAw$Outbound, z.ZodTypeDef, ProfileTargetStackAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAw$ {
    /** @deprecated use `ProfileTargetStackAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAw$Outbound, z.ZodTypeDef, ProfileTargetStackAw>;
    /** @deprecated use `ProfileTargetStackAw$Outbound` instead. */
    type Outbound = ProfileTargetStackAw$Outbound;
}
export declare function profileTargetStackAwToJSON(profileTargetStackAw: ProfileTargetStackAw): string;
export declare function profileTargetStackAwFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAw, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAzureResource$inboundSchema: z.ZodType<ProfileTargetStackAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ProfileTargetStackAzureResource$outboundSchema: z.ZodType<ProfileTargetStackAzureResource$Outbound, z.ZodTypeDef, ProfileTargetStackAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAzureResource$ {
    /** @deprecated use `ProfileTargetStackAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAzureResource$Outbound, z.ZodTypeDef, ProfileTargetStackAzureResource>;
    /** @deprecated use `ProfileTargetStackAzureResource$Outbound` instead. */
    type Outbound = ProfileTargetStackAzureResource$Outbound;
}
export declare function profileTargetStackAzureResourceToJSON(profileTargetStackAzureResource: ProfileTargetStackAzureResource): string;
export declare function profileTargetStackAzureResourceFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAzureResource, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAzureStack$inboundSchema: z.ZodType<ProfileTargetStackAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ProfileTargetStackAzureStack$outboundSchema: z.ZodType<ProfileTargetStackAzureStack$Outbound, z.ZodTypeDef, ProfileTargetStackAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAzureStack$ {
    /** @deprecated use `ProfileTargetStackAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAzureStack$Outbound, z.ZodTypeDef, ProfileTargetStackAzureStack>;
    /** @deprecated use `ProfileTargetStackAzureStack$Outbound` instead. */
    type Outbound = ProfileTargetStackAzureStack$Outbound;
}
export declare function profileTargetStackAzureStackToJSON(profileTargetStackAzureStack: ProfileTargetStackAzureStack): string;
export declare function profileTargetStackAzureStackFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAzureStack, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAzureBinding$inboundSchema: z.ZodType<ProfileTargetStackAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAzureBinding$Outbound = {
    resource?: ProfileTargetStackAzureResource$Outbound | undefined;
    stack?: ProfileTargetStackAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ProfileTargetStackAzureBinding$outboundSchema: z.ZodType<ProfileTargetStackAzureBinding$Outbound, z.ZodTypeDef, ProfileTargetStackAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAzureBinding$ {
    /** @deprecated use `ProfileTargetStackAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAzureBinding$Outbound, z.ZodTypeDef, ProfileTargetStackAzureBinding>;
    /** @deprecated use `ProfileTargetStackAzureBinding$Outbound` instead. */
    type Outbound = ProfileTargetStackAzureBinding$Outbound;
}
export declare function profileTargetStackAzureBindingToJSON(profileTargetStackAzureBinding: ProfileTargetStackAzureBinding): string;
export declare function profileTargetStackAzureBindingFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAzureBinding, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAzureGrant$inboundSchema: z.ZodType<ProfileTargetStackAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ProfileTargetStackAzureGrant$outboundSchema: z.ZodType<ProfileTargetStackAzureGrant$Outbound, z.ZodTypeDef, ProfileTargetStackAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAzureGrant$ {
    /** @deprecated use `ProfileTargetStackAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAzureGrant$Outbound, z.ZodTypeDef, ProfileTargetStackAzureGrant>;
    /** @deprecated use `ProfileTargetStackAzureGrant$Outbound` instead. */
    type Outbound = ProfileTargetStackAzureGrant$Outbound;
}
export declare function profileTargetStackAzureGrantToJSON(profileTargetStackAzureGrant: ProfileTargetStackAzureGrant): string;
export declare function profileTargetStackAzureGrantFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAzureGrant, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackAzure$inboundSchema: z.ZodType<ProfileTargetStackAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackAzure$Outbound = {
    binding: ProfileTargetStackAzureBinding$Outbound;
    grant: ProfileTargetStackAzureGrant$Outbound;
};
/** @internal */
export declare const ProfileTargetStackAzure$outboundSchema: z.ZodType<ProfileTargetStackAzure$Outbound, z.ZodTypeDef, ProfileTargetStackAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackAzure$ {
    /** @deprecated use `ProfileTargetStackAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackAzure$Outbound, z.ZodTypeDef, ProfileTargetStackAzure>;
    /** @deprecated use `ProfileTargetStackAzure$Outbound` instead. */
    type Outbound = ProfileTargetStackAzure$Outbound;
}
export declare function profileTargetStackAzureToJSON(profileTargetStackAzure: ProfileTargetStackAzure): string;
export declare function profileTargetStackAzureFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackAzure, SDKValidationError>;
/** @internal */
export declare const ProfileConditionTargetStackResource$inboundSchema: z.ZodType<ProfileConditionTargetStackResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileConditionTargetStackResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ProfileConditionTargetStackResource$outboundSchema: z.ZodType<ProfileConditionTargetStackResource$Outbound, z.ZodTypeDef, ProfileConditionTargetStackResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileConditionTargetStackResource$ {
    /** @deprecated use `ProfileConditionTargetStackResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileConditionTargetStackResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileConditionTargetStackResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileConditionTargetStackResource$Outbound, z.ZodTypeDef, ProfileConditionTargetStackResource>;
    /** @deprecated use `ProfileConditionTargetStackResource$Outbound` instead. */
    type Outbound = ProfileConditionTargetStackResource$Outbound;
}
export declare function profileConditionTargetStackResourceToJSON(profileConditionTargetStackResource: ProfileConditionTargetStackResource): string;
export declare function profileConditionTargetStackResourceFromJSON(jsonString: string): SafeParseResult<ProfileConditionTargetStackResource, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackGcpResource$inboundSchema: z.ZodType<ProfileTargetStackGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ProfileTargetStackGcpResource$outboundSchema: z.ZodType<ProfileTargetStackGcpResource$Outbound, z.ZodTypeDef, ProfileTargetStackGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackGcpResource$ {
    /** @deprecated use `ProfileTargetStackGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackGcpResource$Outbound, z.ZodTypeDef, ProfileTargetStackGcpResource>;
    /** @deprecated use `ProfileTargetStackGcpResource$Outbound` instead. */
    type Outbound = ProfileTargetStackGcpResource$Outbound;
}
export declare function profileTargetStackGcpResourceToJSON(profileTargetStackGcpResource: ProfileTargetStackGcpResource): string;
export declare function profileTargetStackGcpResourceFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackGcpResource, SDKValidationError>;
/** @internal */
export declare const ProfileConditionTargetStackStack$inboundSchema: z.ZodType<ProfileConditionTargetStackStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileConditionTargetStackStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ProfileConditionTargetStackStack$outboundSchema: z.ZodType<ProfileConditionTargetStackStack$Outbound, z.ZodTypeDef, ProfileConditionTargetStackStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileConditionTargetStackStack$ {
    /** @deprecated use `ProfileConditionTargetStackStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileConditionTargetStackStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileConditionTargetStackStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileConditionTargetStackStack$Outbound, z.ZodTypeDef, ProfileConditionTargetStackStack>;
    /** @deprecated use `ProfileConditionTargetStackStack$Outbound` instead. */
    type Outbound = ProfileConditionTargetStackStack$Outbound;
}
export declare function profileConditionTargetStackStackToJSON(profileConditionTargetStackStack: ProfileConditionTargetStackStack): string;
export declare function profileConditionTargetStackStackFromJSON(jsonString: string): SafeParseResult<ProfileConditionTargetStackStack, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackGcpStack$inboundSchema: z.ZodType<ProfileTargetStackGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ProfileTargetStackGcpStack$outboundSchema: z.ZodType<ProfileTargetStackGcpStack$Outbound, z.ZodTypeDef, ProfileTargetStackGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackGcpStack$ {
    /** @deprecated use `ProfileTargetStackGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackGcpStack$Outbound, z.ZodTypeDef, ProfileTargetStackGcpStack>;
    /** @deprecated use `ProfileTargetStackGcpStack$Outbound` instead. */
    type Outbound = ProfileTargetStackGcpStack$Outbound;
}
export declare function profileTargetStackGcpStackToJSON(profileTargetStackGcpStack: ProfileTargetStackGcpStack): string;
export declare function profileTargetStackGcpStackFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackGcpStack, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackGcpBinding$inboundSchema: z.ZodType<ProfileTargetStackGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackGcpBinding$Outbound = {
    resource?: ProfileTargetStackGcpResource$Outbound | undefined;
    stack?: ProfileTargetStackGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ProfileTargetStackGcpBinding$outboundSchema: z.ZodType<ProfileTargetStackGcpBinding$Outbound, z.ZodTypeDef, ProfileTargetStackGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackGcpBinding$ {
    /** @deprecated use `ProfileTargetStackGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackGcpBinding$Outbound, z.ZodTypeDef, ProfileTargetStackGcpBinding>;
    /** @deprecated use `ProfileTargetStackGcpBinding$Outbound` instead. */
    type Outbound = ProfileTargetStackGcpBinding$Outbound;
}
export declare function profileTargetStackGcpBindingToJSON(profileTargetStackGcpBinding: ProfileTargetStackGcpBinding): string;
export declare function profileTargetStackGcpBindingFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackGcpBinding, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackGcpGrant$inboundSchema: z.ZodType<ProfileTargetStackGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ProfileTargetStackGcpGrant$outboundSchema: z.ZodType<ProfileTargetStackGcpGrant$Outbound, z.ZodTypeDef, ProfileTargetStackGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackGcpGrant$ {
    /** @deprecated use `ProfileTargetStackGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackGcpGrant$Outbound, z.ZodTypeDef, ProfileTargetStackGcpGrant>;
    /** @deprecated use `ProfileTargetStackGcpGrant$Outbound` instead. */
    type Outbound = ProfileTargetStackGcpGrant$Outbound;
}
export declare function profileTargetStackGcpGrantToJSON(profileTargetStackGcpGrant: ProfileTargetStackGcpGrant): string;
export declare function profileTargetStackGcpGrantFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackGcpGrant, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackGcp$inboundSchema: z.ZodType<ProfileTargetStackGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackGcp$Outbound = {
    binding: ProfileTargetStackGcpBinding$Outbound;
    grant: ProfileTargetStackGcpGrant$Outbound;
};
/** @internal */
export declare const ProfileTargetStackGcp$outboundSchema: z.ZodType<ProfileTargetStackGcp$Outbound, z.ZodTypeDef, ProfileTargetStackGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackGcp$ {
    /** @deprecated use `ProfileTargetStackGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackGcp$Outbound, z.ZodTypeDef, ProfileTargetStackGcp>;
    /** @deprecated use `ProfileTargetStackGcp$Outbound` instead. */
    type Outbound = ProfileTargetStackGcp$Outbound;
}
export declare function profileTargetStackGcpToJSON(profileTargetStackGcp: ProfileTargetStackGcp): string;
export declare function profileTargetStackGcpFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackGcp, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStackPlatforms$inboundSchema: z.ZodType<ProfileTargetStackPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStackPlatforms$Outbound = {
    aws?: Array<ProfileTargetStackAw$Outbound> | null | undefined;
    azure?: Array<ProfileTargetStackAzure$Outbound> | null | undefined;
    gcp?: Array<ProfileTargetStackGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ProfileTargetStackPlatforms$outboundSchema: z.ZodType<ProfileTargetStackPlatforms$Outbound, z.ZodTypeDef, ProfileTargetStackPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStackPlatforms$ {
    /** @deprecated use `ProfileTargetStackPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStackPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStackPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStackPlatforms$Outbound, z.ZodTypeDef, ProfileTargetStackPlatforms>;
    /** @deprecated use `ProfileTargetStackPlatforms$Outbound` instead. */
    type Outbound = ProfileTargetStackPlatforms$Outbound;
}
export declare function profileTargetStackPlatformsToJSON(profileTargetStackPlatforms: ProfileTargetStackPlatforms): string;
export declare function profileTargetStackPlatformsFromJSON(jsonString: string): SafeParseResult<ProfileTargetStackPlatforms, SDKValidationError>;
/** @internal */
export declare const ProfileTargetStack$inboundSchema: z.ZodType<ProfileTargetStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ProfileTargetStack$Outbound = {
    description: string;
    id: string;
    platforms: ProfileTargetStackPlatforms$Outbound;
};
/** @internal */
export declare const ProfileTargetStack$outboundSchema: z.ZodType<ProfileTargetStack$Outbound, z.ZodTypeDef, ProfileTargetStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProfileTargetStack$ {
    /** @deprecated use `ProfileTargetStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProfileTargetStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProfileTargetStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProfileTargetStack$Outbound, z.ZodTypeDef, ProfileTargetStack>;
    /** @deprecated use `ProfileTargetStack$Outbound` instead. */
    type Outbound = ProfileTargetStack$Outbound;
}
export declare function profileTargetStackToJSON(profileTargetStack: ProfileTargetStack): string;
export declare function profileTargetStackFromJSON(jsonString: string): SafeParseResult<ProfileTargetStack, SDKValidationError>;
/** @internal */
export declare const TargetStackProfileUnion$inboundSchema: z.ZodType<TargetStackProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackProfileUnion$Outbound = ProfileTargetStack$Outbound | string;
/** @internal */
export declare const TargetStackProfileUnion$outboundSchema: z.ZodType<TargetStackProfileUnion$Outbound, z.ZodTypeDef, TargetStackProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackProfileUnion$ {
    /** @deprecated use `TargetStackProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackProfileUnion$Outbound, z.ZodTypeDef, TargetStackProfileUnion>;
    /** @deprecated use `TargetStackProfileUnion$Outbound` instead. */
    type Outbound = TargetStackProfileUnion$Outbound;
}
export declare function targetStackProfileUnionToJSON(targetStackProfileUnion: TargetStackProfileUnion): string;
export declare function targetStackProfileUnionFromJSON(jsonString: string): SafeParseResult<TargetStackProfileUnion, SDKValidationError>;
/** @internal */
export declare const TargetStackPermissions$inboundSchema: z.ZodType<TargetStackPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackPermissions$Outbound = {
    management?: ManagementTargetStack1$Outbound | ManagementTargetStack2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<ProfileTargetStack$Outbound | string>;
        };
    };
};
/** @internal */
export declare const TargetStackPermissions$outboundSchema: z.ZodType<TargetStackPermissions$Outbound, z.ZodTypeDef, TargetStackPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackPermissions$ {
    /** @deprecated use `TargetStackPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackPermissions$Outbound, z.ZodTypeDef, TargetStackPermissions>;
    /** @deprecated use `TargetStackPermissions$Outbound` instead. */
    type Outbound = TargetStackPermissions$Outbound;
}
export declare function targetStackPermissionsToJSON(targetStackPermissions: TargetStackPermissions): string;
export declare function targetStackPermissionsFromJSON(jsonString: string): SafeParseResult<TargetStackPermissions, SDKValidationError>;
/** @internal */
export declare const TargetStackConfig$inboundSchema: z.ZodType<TargetStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const TargetStackConfig$outboundSchema: z.ZodType<TargetStackConfig$Outbound, z.ZodTypeDef, TargetStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackConfig$ {
    /** @deprecated use `TargetStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackConfig$Outbound, z.ZodTypeDef, TargetStackConfig>;
    /** @deprecated use `TargetStackConfig$Outbound` instead. */
    type Outbound = TargetStackConfig$Outbound;
}
export declare function targetStackConfigToJSON(targetStackConfig: TargetStackConfig): string;
export declare function targetStackConfigFromJSON(jsonString: string): SafeParseResult<TargetStackConfig, SDKValidationError>;
/** @internal */
export declare const TargetStackDependency$inboundSchema: z.ZodType<TargetStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const TargetStackDependency$outboundSchema: z.ZodType<TargetStackDependency$Outbound, z.ZodTypeDef, TargetStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackDependency$ {
    /** @deprecated use `TargetStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackDependency$Outbound, z.ZodTypeDef, TargetStackDependency>;
    /** @deprecated use `TargetStackDependency$Outbound` instead. */
    type Outbound = TargetStackDependency$Outbound;
}
export declare function targetStackDependencyToJSON(targetStackDependency: TargetStackDependency): string;
export declare function targetStackDependencyFromJSON(jsonString: string): SafeParseResult<TargetStackDependency, SDKValidationError>;
/** @internal */
export declare const TargetStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof TargetStackLifecycle>;
/** @internal */
export declare const TargetStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof TargetStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackLifecycle$ {
    /** @deprecated use `TargetStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `TargetStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const TargetStackResources$inboundSchema: z.ZodType<TargetStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStackResources$Outbound = {
    config: TargetStackConfig$Outbound;
    dependencies: Array<TargetStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const TargetStackResources$outboundSchema: z.ZodType<TargetStackResources$Outbound, z.ZodTypeDef, TargetStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStackResources$ {
    /** @deprecated use `TargetStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStackResources$Outbound, z.ZodTypeDef, TargetStackResources>;
    /** @deprecated use `TargetStackResources$Outbound` instead. */
    type Outbound = TargetStackResources$Outbound;
}
export declare function targetStackResourcesToJSON(targetStackResources: TargetStackResources): string;
export declare function targetStackResourcesFromJSON(jsonString: string): SafeParseResult<TargetStackResources, SDKValidationError>;
/** @internal */
export declare const TargetStack$inboundSchema: z.ZodType<TargetStack, z.ZodTypeDef, unknown>;
/** @internal */
export type TargetStack$Outbound = {
    id: string;
    permissions?: TargetStackPermissions$Outbound | undefined;
    resources: {
        [k: string]: TargetStackResources$Outbound;
    };
};
/** @internal */
export declare const TargetStack$outboundSchema: z.ZodType<TargetStack$Outbound, z.ZodTypeDef, TargetStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TargetStack$ {
    /** @deprecated use `TargetStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<TargetStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `TargetStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<TargetStack$Outbound, z.ZodTypeDef, TargetStack>;
    /** @deprecated use `TargetStack$Outbound` instead. */
    type Outbound = TargetStack$Outbound;
}
export declare function targetStackToJSON(targetStack: TargetStack): string;
export declare function targetStackFromJSON(jsonString: string): SafeParseResult<TargetStack, SDKValidationError>;
/** @internal */
export declare const ArtifactRegistry$inboundSchema: z.ZodType<ArtifactRegistry, z.ZodTypeDef, unknown>;
/** @internal */
export type ArtifactRegistry$Outbound = {
    agentManagerUrl: string;
    authToken?: string | null | undefined;
};
/** @internal */
export declare const ArtifactRegistry$outboundSchema: z.ZodType<ArtifactRegistry$Outbound, z.ZodTypeDef, ArtifactRegistry>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ArtifactRegistry$ {
    /** @deprecated use `ArtifactRegistry$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ArtifactRegistry, z.ZodTypeDef, unknown>;
    /** @deprecated use `ArtifactRegistry$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ArtifactRegistry$Outbound, z.ZodTypeDef, ArtifactRegistry>;
    /** @deprecated use `ArtifactRegistry$Outbound` instead. */
    type Outbound = ArtifactRegistry$Outbound;
}
export declare function artifactRegistryToJSON(artifactRegistry: ArtifactRegistry): string;
export declare function artifactRegistryFromJSON(jsonString: string): SafeParseResult<ArtifactRegistry, SDKValidationError>;
/** @internal */
export declare const DeploymentContextType$inboundSchema: z.ZodNativeEnum<typeof DeploymentContextType>;
/** @internal */
export declare const DeploymentContextType$outboundSchema: z.ZodNativeEnum<typeof DeploymentContextType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextType$ {
    /** @deprecated use `DeploymentContextType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Plain: "plain";
        readonly Secret: "secret";
    }>;
    /** @deprecated use `DeploymentContextType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Plain: "plain";
        readonly Secret: "secret";
    }>;
}
/** @internal */
export declare const DeploymentContextVariable$inboundSchema: z.ZodType<DeploymentContextVariable, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextVariable$Outbound = {
    name: string;
    targetFunctions?: Array<string> | null | undefined;
    type: string;
    value: string;
};
/** @internal */
export declare const DeploymentContextVariable$outboundSchema: z.ZodType<DeploymentContextVariable$Outbound, z.ZodTypeDef, DeploymentContextVariable>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextVariable$ {
    /** @deprecated use `DeploymentContextVariable$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextVariable, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextVariable$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextVariable$Outbound, z.ZodTypeDef, DeploymentContextVariable>;
    /** @deprecated use `DeploymentContextVariable$Outbound` instead. */
    type Outbound = DeploymentContextVariable$Outbound;
}
export declare function deploymentContextVariableToJSON(deploymentContextVariable: DeploymentContextVariable): string;
export declare function deploymentContextVariableFromJSON(jsonString: string): SafeParseResult<DeploymentContextVariable, SDKValidationError>;
/** @internal */
export declare const EnvironmentVariables$inboundSchema: z.ZodType<EnvironmentVariables, z.ZodTypeDef, unknown>;
/** @internal */
export type EnvironmentVariables$Outbound = {
    createdAt: string;
    hash: string;
    variables: Array<DeploymentContextVariable$Outbound>;
};
/** @internal */
export declare const EnvironmentVariables$outboundSchema: z.ZodType<EnvironmentVariables$Outbound, z.ZodTypeDef, EnvironmentVariables>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnvironmentVariables$ {
    /** @deprecated use `EnvironmentVariables$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnvironmentVariables, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnvironmentVariables$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnvironmentVariables$Outbound, z.ZodTypeDef, EnvironmentVariables>;
    /** @deprecated use `EnvironmentVariables$Outbound` instead. */
    type Outbound = EnvironmentVariables$Outbound;
}
export declare function environmentVariablesToJSON(environmentVariables: EnvironmentVariables): string;
export declare function environmentVariablesFromJSON(jsonString: string): SafeParseResult<EnvironmentVariables, SDKValidationError>;
/** @internal */
export declare const ManagementConfigPlatformKubernetes$inboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformKubernetes>;
/** @internal */
export declare const ManagementConfigPlatformKubernetes$outboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigPlatformKubernetes$ {
    /** @deprecated use `ManagementConfigPlatformKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
    /** @deprecated use `ManagementConfigPlatformKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
}
/** @internal */
export declare const ManagementConfigKubernetes$inboundSchema: z.ZodType<ManagementConfigKubernetes, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementConfigKubernetes$Outbound = {
    platform: string;
};
/** @internal */
export declare const ManagementConfigKubernetes$outboundSchema: z.ZodType<ManagementConfigKubernetes$Outbound, z.ZodTypeDef, ManagementConfigKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigKubernetes$ {
    /** @deprecated use `ManagementConfigKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementConfigKubernetes, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementConfigKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementConfigKubernetes$Outbound, z.ZodTypeDef, ManagementConfigKubernetes>;
    /** @deprecated use `ManagementConfigKubernetes$Outbound` instead. */
    type Outbound = ManagementConfigKubernetes$Outbound;
}
export declare function managementConfigKubernetesToJSON(managementConfigKubernetes: ManagementConfigKubernetes): string;
export declare function managementConfigKubernetesFromJSON(jsonString: string): SafeParseResult<ManagementConfigKubernetes, SDKValidationError>;
/** @internal */
export declare const ManagementConfigImagePullCredentials$inboundSchema: z.ZodType<ManagementConfigImagePullCredentials, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementConfigImagePullCredentials$Outbound = {
    password: string;
    username: string;
};
/** @internal */
export declare const ManagementConfigImagePullCredentials$outboundSchema: z.ZodType<ManagementConfigImagePullCredentials$Outbound, z.ZodTypeDef, ManagementConfigImagePullCredentials>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigImagePullCredentials$ {
    /** @deprecated use `ManagementConfigImagePullCredentials$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementConfigImagePullCredentials, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementConfigImagePullCredentials$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementConfigImagePullCredentials$Outbound, z.ZodTypeDef, ManagementConfigImagePullCredentials>;
    /** @deprecated use `ManagementConfigImagePullCredentials$Outbound` instead. */
    type Outbound = ManagementConfigImagePullCredentials$Outbound;
}
export declare function managementConfigImagePullCredentialsToJSON(managementConfigImagePullCredentials: ManagementConfigImagePullCredentials): string;
export declare function managementConfigImagePullCredentialsFromJSON(jsonString: string): SafeParseResult<ManagementConfigImagePullCredentials, SDKValidationError>;
/** @internal */
export declare const ManagementConfigPlatformAzure$inboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformAzure>;
/** @internal */
export declare const ManagementConfigPlatformAzure$outboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigPlatformAzure$ {
    /** @deprecated use `ManagementConfigPlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `ManagementConfigPlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const ManagementConfigAzure$inboundSchema: z.ZodType<ManagementConfigAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementConfigAzure$Outbound = {
    imagePullCredentials?: any | null | undefined;
    managementPrincipalId: string;
    managingTenantId: string;
    platform: string;
};
/** @internal */
export declare const ManagementConfigAzure$outboundSchema: z.ZodType<ManagementConfigAzure$Outbound, z.ZodTypeDef, ManagementConfigAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigAzure$ {
    /** @deprecated use `ManagementConfigAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementConfigAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementConfigAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementConfigAzure$Outbound, z.ZodTypeDef, ManagementConfigAzure>;
    /** @deprecated use `ManagementConfigAzure$Outbound` instead. */
    type Outbound = ManagementConfigAzure$Outbound;
}
export declare function managementConfigAzureToJSON(managementConfigAzure: ManagementConfigAzure): string;
export declare function managementConfigAzureFromJSON(jsonString: string): SafeParseResult<ManagementConfigAzure, SDKValidationError>;
/** @internal */
export declare const ManagementConfigPlatformGcp$inboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformGcp>;
/** @internal */
export declare const ManagementConfigPlatformGcp$outboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigPlatformGcp$ {
    /** @deprecated use `ManagementConfigPlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `ManagementConfigPlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const ManagementConfigGcp$inboundSchema: z.ZodType<ManagementConfigGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementConfigGcp$Outbound = {
    serviceAccountEmail: string;
    platform: string;
};
/** @internal */
export declare const ManagementConfigGcp$outboundSchema: z.ZodType<ManagementConfigGcp$Outbound, z.ZodTypeDef, ManagementConfigGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigGcp$ {
    /** @deprecated use `ManagementConfigGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementConfigGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementConfigGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementConfigGcp$Outbound, z.ZodTypeDef, ManagementConfigGcp>;
    /** @deprecated use `ManagementConfigGcp$Outbound` instead. */
    type Outbound = ManagementConfigGcp$Outbound;
}
export declare function managementConfigGcpToJSON(managementConfigGcp: ManagementConfigGcp): string;
export declare function managementConfigGcpFromJSON(jsonString: string): SafeParseResult<ManagementConfigGcp, SDKValidationError>;
/** @internal */
export declare const ManagementConfigPlatformAws$inboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformAws>;
/** @internal */
export declare const ManagementConfigPlatformAws$outboundSchema: z.ZodNativeEnum<typeof ManagementConfigPlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigPlatformAws$ {
    /** @deprecated use `ManagementConfigPlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `ManagementConfigPlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const ManagementConfigAws$inboundSchema: z.ZodType<ManagementConfigAws, z.ZodTypeDef, unknown>;
/** @internal */
export type ManagementConfigAws$Outbound = {
    managingRoleArn: string;
    platform: string;
};
/** @internal */
export declare const ManagementConfigAws$outboundSchema: z.ZodType<ManagementConfigAws$Outbound, z.ZodTypeDef, ManagementConfigAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ManagementConfigAws$ {
    /** @deprecated use `ManagementConfigAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ManagementConfigAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `ManagementConfigAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ManagementConfigAws$Outbound, z.ZodTypeDef, ManagementConfigAws>;
    /** @deprecated use `ManagementConfigAws$Outbound` instead. */
    type Outbound = ManagementConfigAws$Outbound;
}
export declare function managementConfigAwsToJSON(managementConfigAws: ManagementConfigAws): string;
export declare function managementConfigAwsFromJSON(jsonString: string): SafeParseResult<ManagementConfigAws, SDKValidationError>;
/** @internal */
export declare const ConfigRemoteCapabilities$inboundSchema: z.ZodType<ConfigRemoteCapabilities, z.ZodTypeDef, unknown>;
/** @internal */
export type ConfigRemoteCapabilities$Outbound = {
    autoUpdates: boolean;
    heartbeat: boolean;
    monitoring: boolean;
};
/** @internal */
export declare const ConfigRemoteCapabilities$outboundSchema: z.ZodType<ConfigRemoteCapabilities$Outbound, z.ZodTypeDef, ConfigRemoteCapabilities>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ConfigRemoteCapabilities$ {
    /** @deprecated use `ConfigRemoteCapabilities$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ConfigRemoteCapabilities, z.ZodTypeDef, unknown>;
    /** @deprecated use `ConfigRemoteCapabilities$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ConfigRemoteCapabilities$Outbound, z.ZodTypeDef, ConfigRemoteCapabilities>;
    /** @deprecated use `ConfigRemoteCapabilities$Outbound` instead. */
    type Outbound = ConfigRemoteCapabilities$Outbound;
}
export declare function configRemoteCapabilitiesToJSON(configRemoteCapabilities: ConfigRemoteCapabilities): string;
export declare function configRemoteCapabilitiesFromJSON(jsonString: string): SafeParseResult<ConfigRemoteCapabilities, SDKValidationError>;
/** @internal */
export declare const DeploymentContextConfig$inboundSchema: z.ZodType<DeploymentContextConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContextConfig$Outbound = {
    allowFrozenChanges?: boolean | undefined;
    artifactRegistry?: any | null | undefined;
    environmentVariables: EnvironmentVariables$Outbound;
    managementConfig?: any | null | undefined;
    remoteCapabilities: ConfigRemoteCapabilities$Outbound;
};
/** @internal */
export declare const DeploymentContextConfig$outboundSchema: z.ZodType<DeploymentContextConfig$Outbound, z.ZodTypeDef, DeploymentContextConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContextConfig$ {
    /** @deprecated use `DeploymentContextConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContextConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContextConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContextConfig$Outbound, z.ZodTypeDef, DeploymentContextConfig>;
    /** @deprecated use `DeploymentContextConfig$Outbound` instead. */
    type Outbound = DeploymentContextConfig$Outbound;
}
export declare function deploymentContextConfigToJSON(deploymentContextConfig: DeploymentContextConfig): string;
export declare function deploymentContextConfigFromJSON(jsonString: string): SafeParseResult<DeploymentContextConfig, SDKValidationError>;
/** @internal */
export declare const DeploymentContext$inboundSchema: z.ZodType<DeploymentContext, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentContext$Outbound = {
    current: DeploymentContextCurrent$Outbound;
    targetStack: TargetStack$Outbound;
    config: DeploymentContextConfig$Outbound;
    session: string;
};
/** @internal */
export declare const DeploymentContext$outboundSchema: z.ZodType<DeploymentContext$Outbound, z.ZodTypeDef, DeploymentContext>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentContext$ {
    /** @deprecated use `DeploymentContext$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentContext, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentContext$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentContext$Outbound, z.ZodTypeDef, DeploymentContext>;
    /** @deprecated use `DeploymentContext$Outbound` instead. */
    type Outbound = DeploymentContext$Outbound;
}
export declare function deploymentContextToJSON(deploymentContext: DeploymentContext): string;
export declare function deploymentContextFromJSON(jsonString: string): SafeParseResult<DeploymentContext, SDKValidationError>;
//# sourceMappingURL=deploymentcontext.d.ts.map