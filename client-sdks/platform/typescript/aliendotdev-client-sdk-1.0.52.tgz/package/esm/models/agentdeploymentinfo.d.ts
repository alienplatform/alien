import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { Agent, Agent$Outbound } from "./agent.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Project information
 */
export type AgentDeploymentInfoProject = {
    /**
     * Project ID
     */
    id: string;
    /**
     * Project name (used as CLI name)
     */
    name: string;
};
/**
 * Terraform deployment information
 */
export type Terraform = {
    /**
     * Terraform provider name
     */
    providerName: string;
    /**
     * URL to download example Terraform configuration
     */
    exampleDownloadUrl: string;
    /**
     * URL to Terraform provider documentation
     */
    docsUrl: string;
};
/**
 * Deployment URLs and resources
 */
export type DeploymentUrls = {
    /**
     * CloudFormation template URL (AWS only)
     */
    cloudFormation: string | null;
    /**
     * Terraform deployment information
     */
    terraform: Terraform | null;
};
export type AgentDeploymentInfo = {
    agent: Agent;
    /**
     * Project information
     */
    project: AgentDeploymentInfoProject;
    /**
     * Deployment URLs and resources
     */
    deploymentUrls: DeploymentUrls;
};
/** @internal */
export declare const AgentDeploymentInfoProject$inboundSchema: z.ZodType<AgentDeploymentInfoProject, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentDeploymentInfoProject$Outbound = {
    id: string;
    name: string;
};
/** @internal */
export declare const AgentDeploymentInfoProject$outboundSchema: z.ZodType<AgentDeploymentInfoProject$Outbound, z.ZodTypeDef, AgentDeploymentInfoProject>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentDeploymentInfoProject$ {
    /** @deprecated use `AgentDeploymentInfoProject$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AgentDeploymentInfoProject, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentDeploymentInfoProject$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AgentDeploymentInfoProject$Outbound, z.ZodTypeDef, AgentDeploymentInfoProject>;
    /** @deprecated use `AgentDeploymentInfoProject$Outbound` instead. */
    type Outbound = AgentDeploymentInfoProject$Outbound;
}
export declare function agentDeploymentInfoProjectToJSON(agentDeploymentInfoProject: AgentDeploymentInfoProject): string;
export declare function agentDeploymentInfoProjectFromJSON(jsonString: string): SafeParseResult<AgentDeploymentInfoProject, SDKValidationError>;
/** @internal */
export declare const Terraform$inboundSchema: z.ZodType<Terraform, z.ZodTypeDef, unknown>;
/** @internal */
export type Terraform$Outbound = {
    providerName: string;
    exampleDownloadUrl: string;
    docsUrl: string;
};
/** @internal */
export declare const Terraform$outboundSchema: z.ZodType<Terraform$Outbound, z.ZodTypeDef, Terraform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace Terraform$ {
    /** @deprecated use `Terraform$inboundSchema` instead. */
    const inboundSchema: z.ZodType<Terraform, z.ZodTypeDef, unknown>;
    /** @deprecated use `Terraform$outboundSchema` instead. */
    const outboundSchema: z.ZodType<Terraform$Outbound, z.ZodTypeDef, Terraform>;
    /** @deprecated use `Terraform$Outbound` instead. */
    type Outbound = Terraform$Outbound;
}
export declare function terraformToJSON(terraform: Terraform): string;
export declare function terraformFromJSON(jsonString: string): SafeParseResult<Terraform, SDKValidationError>;
/** @internal */
export declare const DeploymentUrls$inboundSchema: z.ZodType<DeploymentUrls, z.ZodTypeDef, unknown>;
/** @internal */
export type DeploymentUrls$Outbound = {
    cloudFormation: string | null;
    terraform: Terraform$Outbound | null;
};
/** @internal */
export declare const DeploymentUrls$outboundSchema: z.ZodType<DeploymentUrls$Outbound, z.ZodTypeDef, DeploymentUrls>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeploymentUrls$ {
    /** @deprecated use `DeploymentUrls$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeploymentUrls, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeploymentUrls$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeploymentUrls$Outbound, z.ZodTypeDef, DeploymentUrls>;
    /** @deprecated use `DeploymentUrls$Outbound` instead. */
    type Outbound = DeploymentUrls$Outbound;
}
export declare function deploymentUrlsToJSON(deploymentUrls: DeploymentUrls): string;
export declare function deploymentUrlsFromJSON(jsonString: string): SafeParseResult<DeploymentUrls, SDKValidationError>;
/** @internal */
export declare const AgentDeploymentInfo$inboundSchema: z.ZodType<AgentDeploymentInfo, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentDeploymentInfo$Outbound = {
    agent: Agent$Outbound;
    project: AgentDeploymentInfoProject$Outbound;
    deploymentUrls: DeploymentUrls$Outbound;
};
/** @internal */
export declare const AgentDeploymentInfo$outboundSchema: z.ZodType<AgentDeploymentInfo$Outbound, z.ZodTypeDef, AgentDeploymentInfo>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentDeploymentInfo$ {
    /** @deprecated use `AgentDeploymentInfo$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AgentDeploymentInfo, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentDeploymentInfo$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AgentDeploymentInfo$Outbound, z.ZodTypeDef, AgentDeploymentInfo>;
    /** @deprecated use `AgentDeploymentInfo$Outbound` instead. */
    type Outbound = AgentDeploymentInfo$Outbound;
}
export declare function agentDeploymentInfoToJSON(agentDeploymentInfo: AgentDeploymentInfo): string;
export declare function agentDeploymentInfoFromJSON(jsonString: string): SafeParseResult<AgentDeploymentInfo, SDKValidationError>;
//# sourceMappingURL=agentdeploymentinfo.d.ts.map