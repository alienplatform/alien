import * as z from "zod/v4";
export type CreateDeploymentGroupRequest = {
    /**
     * Name of the deployment group
     */
    name: string;
    /**
     * Project ID or name this deployment group belongs to
     */
    project: string;
    /**
     * Maximum number of agents in this deployment group
     */
    maxAgents?: number | undefined;
};
/** @internal */
export type CreateDeploymentGroupRequest$Outbound = {
    name: string;
    project: string;
    maxAgents: number;
};
/** @internal */
export declare const CreateDeploymentGroupRequest$outboundSchema: z.ZodType<CreateDeploymentGroupRequest$Outbound, CreateDeploymentGroupRequest>;
export declare function createDeploymentGroupRequestToJSON(createDeploymentGroupRequest: CreateDeploymentGroupRequest): string;
//# sourceMappingURL=createdeploymentgrouprequest.d.ts.map