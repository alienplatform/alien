import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { CommandDeploymentGroupInfo } from "./commanddeploymentgroupinfo.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Represents the target cloud platform.
 */
export declare const CommandAgentInfoPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type CommandAgentInfoPlatform = ClosedEnum<typeof CommandAgentInfoPlatform>;
export declare const CommandAgentInfoPlatformTest: {
    readonly Test: "test";
};
export type CommandAgentInfoPlatformTest = ClosedEnum<typeof CommandAgentInfoPlatformTest>;
/**
 * Test platform environment information (mock)
 */
export type CommandAgentInfoEnvironmentInfoTest = {
    /**
     * Test identifier for this environment
     */
    testId: string;
    platform: CommandAgentInfoPlatformTest;
};
export declare const CommandAgentInfoPlatformLocal: {
    readonly Local: "local";
};
export type CommandAgentInfoPlatformLocal = ClosedEnum<typeof CommandAgentInfoPlatformLocal>;
/**
 * Local platform environment information
 */
export type CommandAgentInfoEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: CommandAgentInfoPlatformLocal;
};
export declare const CommandAgentInfoPlatformAzure: {
    readonly Azure: "azure";
};
export type CommandAgentInfoPlatformAzure = ClosedEnum<typeof CommandAgentInfoPlatformAzure>;
/**
 * Azure-specific environment information
 */
export type CommandAgentInfoEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: CommandAgentInfoPlatformAzure;
};
export declare const CommandAgentInfoPlatformGcp: {
    readonly Gcp: "gcp";
};
export type CommandAgentInfoPlatformGcp = ClosedEnum<typeof CommandAgentInfoPlatformGcp>;
/**
 * GCP-specific environment information
 */
export type CommandAgentInfoEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: CommandAgentInfoPlatformGcp;
};
export declare const CommandAgentInfoPlatformAws: {
    readonly Aws: "aws";
};
export type CommandAgentInfoPlatformAws = ClosedEnum<typeof CommandAgentInfoPlatformAws>;
/**
 * AWS-specific environment information
 */
export type CommandAgentInfoEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: CommandAgentInfoPlatformAws;
};
/**
 * Platform-specific environment information
 */
export type CommandAgentInfoEnvironmentInfoUnion = CommandAgentInfoEnvironmentInfoGcp | CommandAgentInfoEnvironmentInfoAzure | CommandAgentInfoEnvironmentInfoLocal | CommandAgentInfoEnvironmentInfoAws | CommandAgentInfoEnvironmentInfoTest | any;
export type CommandAgentInfo = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    name: string;
    deploymentGroup?: CommandDeploymentGroupInfo | undefined;
    /**
     * Represents the target cloud platform.
     */
    platform?: CommandAgentInfoPlatform | undefined;
    /**
     * Platform-specific environment information
     */
    environmentInfo?: CommandAgentInfoEnvironmentInfoGcp | CommandAgentInfoEnvironmentInfoAzure | CommandAgentInfoEnvironmentInfoLocal | CommandAgentInfoEnvironmentInfoAws | CommandAgentInfoEnvironmentInfoTest | any | null | undefined;
    /**
     * URL of the agent manager for direct payload access
     */
    agentManagerUrl?: string | null | undefined;
    /**
     * Human-readable name of the agent manager
     */
    agentManagerName?: string | null | undefined;
    /**
     * Whether the agent manager is Alien-hosted (system)
     */
    agentManagerIsSystem?: boolean | null | undefined;
};
/** @internal */
export declare const CommandAgentInfoPlatform$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatform>;
/** @internal */
export declare const CommandAgentInfoPlatformTest$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatformTest>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoTest$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoTest, unknown>;
export declare function commandAgentInfoEnvironmentInfoTestFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoTest, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfoPlatformLocal$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatformLocal>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoLocal$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoLocal, unknown>;
export declare function commandAgentInfoEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfoPlatformAzure$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatformAzure>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoAzure$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoAzure, unknown>;
export declare function commandAgentInfoEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfoPlatformGcp$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatformGcp>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoGcp$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoGcp, unknown>;
export declare function commandAgentInfoEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfoPlatformAws$inboundSchema: z.ZodEnum<typeof CommandAgentInfoPlatformAws>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoAws$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoAws, unknown>;
export declare function commandAgentInfoEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfoEnvironmentInfoUnion$inboundSchema: z.ZodType<CommandAgentInfoEnvironmentInfoUnion, unknown>;
export declare function commandAgentInfoEnvironmentInfoUnionFromJSON(jsonString: string): SafeParseResult<CommandAgentInfoEnvironmentInfoUnion, SDKValidationError>;
/** @internal */
export declare const CommandAgentInfo$inboundSchema: z.ZodType<CommandAgentInfo, unknown>;
export declare function commandAgentInfoFromJSON(jsonString: string): SafeParseResult<CommandAgentInfo, SDKValidationError>;
//# sourceMappingURL=commandagentinfo.d.ts.map