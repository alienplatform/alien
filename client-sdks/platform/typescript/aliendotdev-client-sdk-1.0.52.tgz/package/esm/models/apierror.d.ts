import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Error that occurred during context building
 */
export type APIError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    source?: any | null | undefined;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
};
/** @internal */
export declare const APIError$inboundSchema: z.ZodType<APIError, unknown>;
export declare function apiErrorFromJSON(jsonString: string): SafeParseResult<APIError, SDKValidationError>;
//# sourceMappingURL=apierror.d.ts.map