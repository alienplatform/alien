import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const GitHubProviderType: {
    readonly Github: "github";
};
export type GitHubProviderType = ClosedEnum<typeof GitHubProviderType>;
export type GitHubProvider = {
    type: GitHubProviderType;
    /**
     * Repository owner (user or organization)
     */
    org: string;
    /**
     * Repository name
     */
    repo: string;
};
/** @internal */
export declare const GitHubProviderType$inboundSchema: z.ZodEnum<typeof GitHubProviderType>;
/** @internal */
export declare const GitHubProviderType$outboundSchema: z.ZodEnum<typeof GitHubProviderType>;
/** @internal */
export declare const GitHubProvider$inboundSchema: z.ZodType<GitHubProvider, unknown>;
/** @internal */
export type GitHubProvider$Outbound = {
    type: string;
    org: string;
    repo: string;
};
/** @internal */
export declare const GitHubProvider$outboundSchema: z.ZodType<GitHubProvider$Outbound, GitHubProvider>;
export declare function gitHubProviderToJSON(gitHubProvider: GitHubProvider): string;
export declare function gitHubProviderFromJSON(jsonString: string): SafeParseResult<GitHubProvider, SDKValidationError>;
//# sourceMappingURL=githubprovider.d.ts.map