import * as z from "zod/v4";
import { DeploymentGroupRole } from "./deploymentgrouprole.js";
/**
 * Deployment group-scoped configuration
 */
export type DeploymentGroupScope = {
    type: "deployment-group";
    /**
     * ID of the deployment group this is scoped to
     */
    deploymentGroupId: string;
    /**
     * ID of the project this deployment group belongs to
     */
    projectId: string;
    /**
     * Role for deployment group-scoped service accounts
     */
    role: DeploymentGroupRole;
};
/** @internal */
export type DeploymentGroupScope$Outbound = {
    type: "deployment-group";
    deploymentGroupId: string;
    projectId: string;
    role: string;
};
/** @internal */
export declare const DeploymentGroupScope$outboundSchema: z.ZodType<DeploymentGroupScope$Outbound, DeploymentGroupScope>;
export declare function deploymentGroupScopeToJSON(deploymentGroupScope: DeploymentGroupScope): string;
//# sourceMappingURL=deploymentgroupscope.d.ts.map