import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CreateDeploymentTokenResponse = {
    /**
     * The generated deployment token (only shown once)
     */
    token: string;
    /**
     * The agent ID that this token is scoped to
     */
    agentId: string;
};
/** @internal */
export declare const CreateDeploymentTokenResponse$inboundSchema: z.ZodType<CreateDeploymentTokenResponse, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateDeploymentTokenResponse$Outbound = {
    token: string;
    agentId: string;
};
/** @internal */
export declare const CreateDeploymentTokenResponse$outboundSchema: z.ZodType<CreateDeploymentTokenResponse$Outbound, z.ZodTypeDef, CreateDeploymentTokenResponse>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CreateDeploymentTokenResponse$ {
    /** @deprecated use `CreateDeploymentTokenResponse$inboundSchema` instead. */
    const inboundSchema: z.ZodType<CreateDeploymentTokenResponse, z.ZodTypeDef, unknown>;
    /** @deprecated use `CreateDeploymentTokenResponse$outboundSchema` instead. */
    const outboundSchema: z.ZodType<CreateDeploymentTokenResponse$Outbound, z.ZodTypeDef, CreateDeploymentTokenResponse>;
    /** @deprecated use `CreateDeploymentTokenResponse$Outbound` instead. */
    type Outbound = CreateDeploymentTokenResponse$Outbound;
}
export declare function createDeploymentTokenResponseToJSON(createDeploymentTokenResponse: CreateDeploymentTokenResponse): string;
export declare function createDeploymentTokenResponseFromJSON(jsonString: string): SafeParseResult<CreateDeploymentTokenResponse, SDKValidationError>;
//# sourceMappingURL=createdeploymenttokenresponse.d.ts.map