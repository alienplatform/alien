import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Type of deepstore agent to get token for
 */
export declare const AgentType: {
    readonly Query: "query";
    readonly Write: "write";
    readonly Index: "index";
};
/**
 * Type of deepstore agent to get token for
 */
export type AgentType = ClosedEnum<typeof AgentType>;
export type DeepstoreTokenRequest = {
    /**
     * Type of deepstore agent to get token for
     */
    agentType: AgentType;
};
/** @internal */
export declare const AgentType$inboundSchema: z.ZodNativeEnum<typeof AgentType>;
/** @internal */
export declare const AgentType$outboundSchema: z.ZodNativeEnum<typeof AgentType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentType$ {
    /** @deprecated use `AgentType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Query: "query";
        readonly Write: "write";
        readonly Index: "index";
    }>;
    /** @deprecated use `AgentType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Query: "query";
        readonly Write: "write";
        readonly Index: "index";
    }>;
}
/** @internal */
export declare const DeepstoreTokenRequest$inboundSchema: z.ZodType<DeepstoreTokenRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type DeepstoreTokenRequest$Outbound = {
    agentType: string;
};
/** @internal */
export declare const DeepstoreTokenRequest$outboundSchema: z.ZodType<DeepstoreTokenRequest$Outbound, z.ZodTypeDef, DeepstoreTokenRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeepstoreTokenRequest$ {
    /** @deprecated use `DeepstoreTokenRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeepstoreTokenRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeepstoreTokenRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeepstoreTokenRequest$Outbound, z.ZodTypeDef, DeepstoreTokenRequest>;
    /** @deprecated use `DeepstoreTokenRequest$Outbound` instead. */
    type Outbound = DeepstoreTokenRequest$Outbound;
}
export declare function deepstoreTokenRequestToJSON(deepstoreTokenRequest: DeepstoreTokenRequest): string;
export declare function deepstoreTokenRequestFromJSON(jsonString: string): SafeParseResult<DeepstoreTokenRequest, SDKValidationError>;
//# sourceMappingURL=deepstoretokenrequest.d.ts.map