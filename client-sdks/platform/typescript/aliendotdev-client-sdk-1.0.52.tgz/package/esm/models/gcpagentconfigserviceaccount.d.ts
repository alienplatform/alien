import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Automatically create a new service account. This option is only valid when creating a new agent.
 */
export declare const NewServiceAccount: {
    readonly Auto: "auto";
};
/**
 * Automatically create a new service account. This option is only valid when creating a new agent.
 */
export type NewServiceAccount = ClosedEnum<typeof NewServiceAccount>;
export type GCPAgentConfigServiceAccount = string | NewServiceAccount;
/** @internal */
export declare const NewServiceAccount$inboundSchema: z.ZodNativeEnum<typeof NewServiceAccount>;
/** @internal */
export declare const NewServiceAccount$outboundSchema: z.ZodNativeEnum<typeof NewServiceAccount>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace NewServiceAccount$ {
    /** @deprecated use `NewServiceAccount$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `NewServiceAccount$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const GCPAgentConfigServiceAccount$inboundSchema: z.ZodType<GCPAgentConfigServiceAccount, z.ZodTypeDef, unknown>;
/** @internal */
export type GCPAgentConfigServiceAccount$Outbound = string | string;
/** @internal */
export declare const GCPAgentConfigServiceAccount$outboundSchema: z.ZodType<GCPAgentConfigServiceAccount$Outbound, z.ZodTypeDef, GCPAgentConfigServiceAccount>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GCPAgentConfigServiceAccount$ {
    /** @deprecated use `GCPAgentConfigServiceAccount$inboundSchema` instead. */
    const inboundSchema: z.ZodType<string, z.ZodTypeDef, unknown>;
    /** @deprecated use `GCPAgentConfigServiceAccount$outboundSchema` instead. */
    const outboundSchema: z.ZodType<string, z.ZodTypeDef, string>;
    /** @deprecated use `GCPAgentConfigServiceAccount$Outbound` instead. */
    type Outbound = GCPAgentConfigServiceAccount$Outbound;
}
export declare function gcpAgentConfigServiceAccountToJSON(gcpAgentConfigServiceAccount: GCPAgentConfigServiceAccount): string;
export declare function gcpAgentConfigServiceAccountFromJSON(jsonString: string): SafeParseResult<GCPAgentConfigServiceAccount, SDKValidationError>;
//# sourceMappingURL=gcpagentconfigserviceaccount.d.ts.map