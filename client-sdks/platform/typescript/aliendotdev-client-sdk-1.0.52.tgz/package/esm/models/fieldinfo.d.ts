import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type FieldInfo = {
    name: string;
    type: string;
    description?: string | undefined;
};
/** @internal */
export declare const FieldInfo$inboundSchema: z.ZodType<FieldInfo, unknown>;
export declare function fieldInfoFromJSON(jsonString: string): SafeParseResult<FieldInfo, SDKValidationError>;
//# sourceMappingURL=fieldinfo.d.ts.map