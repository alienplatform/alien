import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * AWS region.
 */
export declare const AWSRegion: {
    readonly UsEast1: "us-east-1";
    readonly UsEast2: "us-east-2";
    readonly UsWest1: "us-west-1";
    readonly UsWest2: "us-west-2";
    readonly ApSouth1: "ap-south-1";
    readonly ApNortheast3: "ap-northeast-3";
    readonly ApNortheast2: "ap-northeast-2";
    readonly ApSoutheast1: "ap-southeast-1";
    readonly ApSoutheast2: "ap-southeast-2";
    readonly ApNortheast1: "ap-northeast-1";
    readonly CaCentral1: "ca-central-1";
    readonly EuCentral1: "eu-central-1";
    readonly EuWest1: "eu-west-1";
    readonly EuWest2: "eu-west-2";
    readonly EuWest3: "eu-west-3";
    readonly EuNorth1: "eu-north-1";
    readonly SaEast1: "sa-east-1";
};
/**
 * AWS region.
 */
export type AWSRegion = ClosedEnum<typeof AWSRegion>;
/** @internal */
export declare const AWSRegion$inboundSchema: z.ZodNativeEnum<typeof AWSRegion>;
/** @internal */
export declare const AWSRegion$outboundSchema: z.ZodNativeEnum<typeof AWSRegion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AWSRegion$ {
    /** @deprecated use `AWSRegion$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly UsEast1: "us-east-1";
        readonly UsEast2: "us-east-2";
        readonly UsWest1: "us-west-1";
        readonly UsWest2: "us-west-2";
        readonly ApSouth1: "ap-south-1";
        readonly ApNortheast3: "ap-northeast-3";
        readonly ApNortheast2: "ap-northeast-2";
        readonly ApSoutheast1: "ap-southeast-1";
        readonly ApSoutheast2: "ap-southeast-2";
        readonly ApNortheast1: "ap-northeast-1";
        readonly CaCentral1: "ca-central-1";
        readonly EuCentral1: "eu-central-1";
        readonly EuWest1: "eu-west-1";
        readonly EuWest2: "eu-west-2";
        readonly EuWest3: "eu-west-3";
        readonly EuNorth1: "eu-north-1";
        readonly SaEast1: "sa-east-1";
    }>;
    /** @deprecated use `AWSRegion$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly UsEast1: "us-east-1";
        readonly UsEast2: "us-east-2";
        readonly UsWest1: "us-west-1";
        readonly UsWest2: "us-west-2";
        readonly ApSouth1: "ap-south-1";
        readonly ApNortheast3: "ap-northeast-3";
        readonly ApNortheast2: "ap-northeast-2";
        readonly ApSoutheast1: "ap-southeast-1";
        readonly ApSoutheast2: "ap-southeast-2";
        readonly ApNortheast1: "ap-northeast-1";
        readonly CaCentral1: "ca-central-1";
        readonly EuCentral1: "eu-central-1";
        readonly EuWest1: "eu-west-1";
        readonly EuWest2: "eu-west-2";
        readonly EuWest3: "eu-west-3";
        readonly EuNorth1: "eu-north-1";
        readonly SaEast1: "sa-east-1";
    }>;
}
//# sourceMappingURL=awsregion.d.ts.map