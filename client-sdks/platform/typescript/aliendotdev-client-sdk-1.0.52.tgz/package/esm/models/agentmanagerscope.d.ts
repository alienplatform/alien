import * as z from "zod/v4";
import { AgentManagerRole } from "./agentmanagerrole.js";
/**
 * Agent manager-scoped configuration
 */
export type AgentManagerScope = {
    type: "agent-manager";
    /**
     * ID of the agent manager this is scoped to
     */
    agentManagerId: string;
    /**
     * Role for agent manager-scoped service accounts
     */
    role: AgentManagerRole;
};
/** @internal */
export type AgentManagerScope$Outbound = {
    type: "agent-manager";
    agentManagerId: string;
    role: string;
};
/** @internal */
export declare const AgentManagerScope$outboundSchema: z.ZodType<AgentManagerScope$Outbound, AgentManagerScope>;
export declare function agentManagerScopeToJSON(agentManagerScope: AgentManagerScope): string;
//# sourceMappingURL=agentmanagerscope.d.ts.map