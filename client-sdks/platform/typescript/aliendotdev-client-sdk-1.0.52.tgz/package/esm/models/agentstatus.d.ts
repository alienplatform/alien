import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * The status of the agent.
 */
export declare const AgentStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly Provisioning: "provisioning";
    readonly Running: "running";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly Deleted: "deleted";
    readonly ProvisionFailed: "provision-failed";
    readonly UpdateFailed: "update-failed";
    readonly DeleteFailed: "delete-failed";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * The status of the agent.
 */
export type AgentStatus = ClosedEnum<typeof AgentStatus>;
/** @internal */
export declare const AgentStatus$inboundSchema: z.ZodNativeEnum<typeof AgentStatus>;
/** @internal */
export declare const AgentStatus$outboundSchema: z.ZodNativeEnum<typeof AgentStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentStatus$ {
    /** @deprecated use `AgentStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly Provisioning: "provisioning";
        readonly Running: "running";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly Deleted: "deleted";
        readonly ProvisionFailed: "provision-failed";
        readonly UpdateFailed: "update-failed";
        readonly DeleteFailed: "delete-failed";
        readonly RefreshFailed: "refresh-failed";
    }>;
    /** @deprecated use `AgentStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly Provisioning: "provisioning";
        readonly Running: "running";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly Deleted: "deleted";
        readonly ProvisionFailed: "provision-failed";
        readonly UpdateFailed: "update-failed";
        readonly DeleteFailed: "delete-failed";
        readonly RefreshFailed: "refresh-failed";
    }>;
}
//# sourceMappingURL=agentstatus.d.ts.map