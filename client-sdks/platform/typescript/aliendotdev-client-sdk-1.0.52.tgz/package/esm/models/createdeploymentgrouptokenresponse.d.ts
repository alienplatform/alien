import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CreateDeploymentGroupTokenResponse = {
    /**
     * The API key token
     */
    token: string;
    /**
     * Formatted deployment link
     */
    deploymentLink: string;
};
/** @internal */
export declare const CreateDeploymentGroupTokenResponse$inboundSchema: z.ZodType<CreateDeploymentGroupTokenResponse, unknown>;
export declare function createDeploymentGroupTokenResponseFromJSON(jsonString: string): SafeParseResult<CreateDeploymentGroupTokenResponse, SDKValidationError>;
//# sourceMappingURL=createdeploymentgrouptokenresponse.d.ts.map