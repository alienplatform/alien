import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const CloudFormationTemplateTypeType: {
    readonly Cloudformation: "cloudformation";
};
export type CloudFormationTemplateTypeType = ClosedEnum<typeof CloudFormationTemplateTypeType>;
export type CloudFormationTemplateType = {
    type: CloudFormationTemplateTypeType;
};
/** @internal */
export declare const CloudFormationTemplateTypeType$inboundSchema: z.ZodNativeEnum<typeof CloudFormationTemplateTypeType>;
/** @internal */
export declare const CloudFormationTemplateTypeType$outboundSchema: z.ZodNativeEnum<typeof CloudFormationTemplateTypeType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CloudFormationTemplateTypeType$ {
    /** @deprecated use `CloudFormationTemplateTypeType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Cloudformation: "cloudformation";
    }>;
    /** @deprecated use `CloudFormationTemplateTypeType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Cloudformation: "cloudformation";
    }>;
}
/** @internal */
export declare const CloudFormationTemplateType$inboundSchema: z.ZodType<CloudFormationTemplateType, z.ZodTypeDef, unknown>;
/** @internal */
export type CloudFormationTemplateType$Outbound = {
    type: string;
};
/** @internal */
export declare const CloudFormationTemplateType$outboundSchema: z.ZodType<CloudFormationTemplateType$Outbound, z.ZodTypeDef, CloudFormationTemplateType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CloudFormationTemplateType$ {
    /** @deprecated use `CloudFormationTemplateType$inboundSchema` instead. */
    const inboundSchema: z.ZodType<CloudFormationTemplateType, z.ZodTypeDef, unknown>;
    /** @deprecated use `CloudFormationTemplateType$outboundSchema` instead. */
    const outboundSchema: z.ZodType<CloudFormationTemplateType$Outbound, z.ZodTypeDef, CloudFormationTemplateType>;
    /** @deprecated use `CloudFormationTemplateType$Outbound` instead. */
    type Outbound = CloudFormationTemplateType$Outbound;
}
export declare function cloudFormationTemplateTypeToJSON(cloudFormationTemplateType: CloudFormationTemplateType): string;
export declare function cloudFormationTemplateTypeFromJSON(jsonString: string): SafeParseResult<CloudFormationTemplateType, SDKValidationError>;
//# sourceMappingURL=cloudformationtemplatetype.d.ts.map