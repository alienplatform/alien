import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const AlienTemplateTypeType: {
    readonly Alien: "alien";
};
export type AlienTemplateTypeType = ClosedEnum<typeof AlienTemplateTypeType>;
/**
 * Platform to export for alien template
 */
export declare const AlienTemplateTypePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Platform to export for alien template
 */
export type AlienTemplateTypePlatform = ClosedEnum<typeof AlienTemplateTypePlatform>;
export type AlienTemplateType = {
    type: AlienTemplateTypeType;
    /**
     * Platform to export for alien template
     */
    platform: AlienTemplateTypePlatform;
};
/** @internal */
export declare const AlienTemplateTypeType$inboundSchema: z.ZodNativeEnum<typeof AlienTemplateTypeType>;
/** @internal */
export declare const AlienTemplateTypeType$outboundSchema: z.ZodNativeEnum<typeof AlienTemplateTypeType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AlienTemplateTypeType$ {
    /** @deprecated use `AlienTemplateTypeType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Alien: "alien";
    }>;
    /** @deprecated use `AlienTemplateTypeType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Alien: "alien";
    }>;
}
/** @internal */
export declare const AlienTemplateTypePlatform$inboundSchema: z.ZodNativeEnum<typeof AlienTemplateTypePlatform>;
/** @internal */
export declare const AlienTemplateTypePlatform$outboundSchema: z.ZodNativeEnum<typeof AlienTemplateTypePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AlienTemplateTypePlatform$ {
    /** @deprecated use `AlienTemplateTypePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `AlienTemplateTypePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const AlienTemplateType$inboundSchema: z.ZodType<AlienTemplateType, z.ZodTypeDef, unknown>;
/** @internal */
export type AlienTemplateType$Outbound = {
    type: string;
    platform: string;
};
/** @internal */
export declare const AlienTemplateType$outboundSchema: z.ZodType<AlienTemplateType$Outbound, z.ZodTypeDef, AlienTemplateType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AlienTemplateType$ {
    /** @deprecated use `AlienTemplateType$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AlienTemplateType, z.ZodTypeDef, unknown>;
    /** @deprecated use `AlienTemplateType$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AlienTemplateType$Outbound, z.ZodTypeDef, AlienTemplateType>;
    /** @deprecated use `AlienTemplateType$Outbound` instead. */
    type Outbound = AlienTemplateType$Outbound;
}
export declare function alienTemplateTypeToJSON(alienTemplateType: AlienTemplateType): string;
export declare function alienTemplateTypeFromJSON(jsonString: string): SafeParseResult<AlienTemplateType, SDKValidationError>;
//# sourceMappingURL=alientemplatetype.d.ts.map