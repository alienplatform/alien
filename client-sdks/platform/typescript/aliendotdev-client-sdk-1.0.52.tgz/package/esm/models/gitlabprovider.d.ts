import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const GitLabProviderType: {
    readonly Gitlab: "gitlab";
};
export type GitLabProviderType = ClosedEnum<typeof GitLabProviderType>;
export type GitLabProvider = {
    type: GitLabProviderType;
    /**
     * Group/project namespace
     */
    namespace: string;
    /**
     * Project name
     */
    project: string;
};
/** @internal */
export declare const GitLabProviderType$inboundSchema: z.ZodEnum<typeof GitLabProviderType>;
/** @internal */
export declare const GitLabProviderType$outboundSchema: z.ZodEnum<typeof GitLabProviderType>;
/** @internal */
export declare const GitLabProvider$inboundSchema: z.ZodType<GitLabProvider, unknown>;
/** @internal */
export type GitLabProvider$Outbound = {
    type: string;
    namespace: string;
    project: string;
};
/** @internal */
export declare const GitLabProvider$outboundSchema: z.ZodType<GitLabProvider$Outbound, GitLabProvider>;
export declare function gitLabProviderToJSON(gitLabProvider: GitLabProvider): string;
export declare function gitLabProviderFromJSON(jsonString: string): SafeParseResult<GitLabProvider, SDKValidationError>;
//# sourceMappingURL=gitlabprovider.d.ts.map