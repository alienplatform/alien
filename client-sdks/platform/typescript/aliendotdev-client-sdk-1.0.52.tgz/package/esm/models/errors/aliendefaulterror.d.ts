import { AlienError } from "./alienerror.js";
/** The fallback error class if no more specific error class is matched */
export declare class AlienDefaultError extends AlienError {
    constructor(message: string, httpMeta: {
        response: Response;
        request: Request;
        body: string;
    });
}
//# sourceMappingURL=aliendefaulterror.d.ts.map