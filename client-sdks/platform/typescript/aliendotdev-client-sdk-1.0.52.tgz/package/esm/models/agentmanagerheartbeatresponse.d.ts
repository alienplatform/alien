import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type AgentManagerHeartbeatResponse = {
    acknowledged: boolean;
    timestamp: string;
};
/** @internal */
export declare const AgentManagerHeartbeatResponse$inboundSchema: z.ZodType<AgentManagerHeartbeatResponse, unknown>;
export declare function agentManagerHeartbeatResponseFromJSON(jsonString: string): SafeParseResult<AgentManagerHeartbeatResponse, SDKValidationError>;
//# sourceMappingURL=agentmanagerheartbeatresponse.d.ts.map