import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Current health status
 */
export declare const AgentManagerHeartbeatRequestStatus: {
    readonly Healthy: "healthy";
    readonly Degraded: "degraded";
    readonly Unhealthy: "unhealthy";
};
/**
 * Current health status
 */
export type AgentManagerHeartbeatRequestStatus = ClosedEnum<typeof AgentManagerHeartbeatRequestStatus>;
export declare const AgentManagerHeartbeatRequestPlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type AgentManagerHeartbeatRequestPlatformKubernetes = ClosedEnum<typeof AgentManagerHeartbeatRequestPlatformKubernetes>;
export type AgentManagerHeartbeatRequestManagementConfigKubernetes = {
    platform: AgentManagerHeartbeatRequestPlatformKubernetes;
};
export declare const AgentManagerHeartbeatRequestPlatformAzure: {
    readonly Azure: "azure";
};
export type AgentManagerHeartbeatRequestPlatformAzure = ClosedEnum<typeof AgentManagerHeartbeatRequestPlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type AgentManagerHeartbeatRequestManagementConfigAzure = {
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: AgentManagerHeartbeatRequestPlatformAzure;
};
export declare const AgentManagerHeartbeatRequestPlatformGcp: {
    readonly Gcp: "gcp";
};
export type AgentManagerHeartbeatRequestPlatformGcp = ClosedEnum<typeof AgentManagerHeartbeatRequestPlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type AgentManagerHeartbeatRequestManagementConfigGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: AgentManagerHeartbeatRequestPlatformGcp;
};
export declare const AgentManagerHeartbeatRequestPlatformAws: {
    readonly Aws: "aws";
};
export type AgentManagerHeartbeatRequestPlatformAws = ClosedEnum<typeof AgentManagerHeartbeatRequestPlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type AgentManagerHeartbeatRequestManagementConfigAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: AgentManagerHeartbeatRequestPlatformAws;
};
/**
 * Management configuration for cross-account access (from ServiceAccount binding)
 */
export type AgentManagerHeartbeatRequestManagementConfigUnion = AgentManagerHeartbeatRequestManagementConfigAzure | AgentManagerHeartbeatRequestManagementConfigAws | AgentManagerHeartbeatRequestManagementConfigGcp | AgentManagerHeartbeatRequestManagementConfigKubernetes | any;
/**
 * Optional runtime metrics
 */
export type Metrics = {
    activeAgents?: number | undefined;
    pendingDeployments?: number | undefined;
    memoryUsageMb?: number | undefined;
    cpuUsagePercent?: number | undefined;
};
export type AgentManagerHeartbeatRequest = {
    /**
     * Current health status
     */
    status: AgentManagerHeartbeatRequestStatus;
    /**
     * Agent Manager version
     */
    version?: string | undefined;
    /**
     * Agent Manager public URL (for accessing DeepStore endpoints)
     */
    url: string;
    /**
     * Management configuration for cross-account access (from ServiceAccount binding)
     */
    managementConfig?: AgentManagerHeartbeatRequestManagementConfigAzure | AgentManagerHeartbeatRequestManagementConfigAws | AgentManagerHeartbeatRequestManagementConfigGcp | AgentManagerHeartbeatRequestManagementConfigKubernetes | any | null | undefined;
    /**
     * Optional runtime metrics
     */
    metrics?: Metrics | undefined;
};
/** @internal */
export declare const AgentManagerHeartbeatRequestStatus$outboundSchema: z.ZodEnum<typeof AgentManagerHeartbeatRequestStatus>;
/** @internal */
export declare const AgentManagerHeartbeatRequestPlatformKubernetes$outboundSchema: z.ZodEnum<typeof AgentManagerHeartbeatRequestPlatformKubernetes>;
/** @internal */
export type AgentManagerHeartbeatRequestManagementConfigKubernetes$Outbound = {
    platform: string;
};
/** @internal */
export declare const AgentManagerHeartbeatRequestManagementConfigKubernetes$outboundSchema: z.ZodType<AgentManagerHeartbeatRequestManagementConfigKubernetes$Outbound, AgentManagerHeartbeatRequestManagementConfigKubernetes>;
export declare function agentManagerHeartbeatRequestManagementConfigKubernetesToJSON(agentManagerHeartbeatRequestManagementConfigKubernetes: AgentManagerHeartbeatRequestManagementConfigKubernetes): string;
/** @internal */
export declare const AgentManagerHeartbeatRequestPlatformAzure$outboundSchema: z.ZodEnum<typeof AgentManagerHeartbeatRequestPlatformAzure>;
/** @internal */
export type AgentManagerHeartbeatRequestManagementConfigAzure$Outbound = {
    managementPrincipalId: string;
    managingTenantId: string;
    platform: string;
};
/** @internal */
export declare const AgentManagerHeartbeatRequestManagementConfigAzure$outboundSchema: z.ZodType<AgentManagerHeartbeatRequestManagementConfigAzure$Outbound, AgentManagerHeartbeatRequestManagementConfigAzure>;
export declare function agentManagerHeartbeatRequestManagementConfigAzureToJSON(agentManagerHeartbeatRequestManagementConfigAzure: AgentManagerHeartbeatRequestManagementConfigAzure): string;
/** @internal */
export declare const AgentManagerHeartbeatRequestPlatformGcp$outboundSchema: z.ZodEnum<typeof AgentManagerHeartbeatRequestPlatformGcp>;
/** @internal */
export type AgentManagerHeartbeatRequestManagementConfigGcp$Outbound = {
    serviceAccountEmail: string;
    platform: string;
};
/** @internal */
export declare const AgentManagerHeartbeatRequestManagementConfigGcp$outboundSchema: z.ZodType<AgentManagerHeartbeatRequestManagementConfigGcp$Outbound, AgentManagerHeartbeatRequestManagementConfigGcp>;
export declare function agentManagerHeartbeatRequestManagementConfigGcpToJSON(agentManagerHeartbeatRequestManagementConfigGcp: AgentManagerHeartbeatRequestManagementConfigGcp): string;
/** @internal */
export declare const AgentManagerHeartbeatRequestPlatformAws$outboundSchema: z.ZodEnum<typeof AgentManagerHeartbeatRequestPlatformAws>;
/** @internal */
export type AgentManagerHeartbeatRequestManagementConfigAws$Outbound = {
    managingRoleArn: string;
    platform: string;
};
/** @internal */
export declare const AgentManagerHeartbeatRequestManagementConfigAws$outboundSchema: z.ZodType<AgentManagerHeartbeatRequestManagementConfigAws$Outbound, AgentManagerHeartbeatRequestManagementConfigAws>;
export declare function agentManagerHeartbeatRequestManagementConfigAwsToJSON(agentManagerHeartbeatRequestManagementConfigAws: AgentManagerHeartbeatRequestManagementConfigAws): string;
/** @internal */
export type AgentManagerHeartbeatRequestManagementConfigUnion$Outbound = AgentManagerHeartbeatRequestManagementConfigAzure$Outbound | AgentManagerHeartbeatRequestManagementConfigAws$Outbound | AgentManagerHeartbeatRequestManagementConfigGcp$Outbound | AgentManagerHeartbeatRequestManagementConfigKubernetes$Outbound | any;
/** @internal */
export declare const AgentManagerHeartbeatRequestManagementConfigUnion$outboundSchema: z.ZodType<AgentManagerHeartbeatRequestManagementConfigUnion$Outbound, AgentManagerHeartbeatRequestManagementConfigUnion>;
export declare function agentManagerHeartbeatRequestManagementConfigUnionToJSON(agentManagerHeartbeatRequestManagementConfigUnion: AgentManagerHeartbeatRequestManagementConfigUnion): string;
/** @internal */
export type Metrics$Outbound = {
    activeAgents?: number | undefined;
    pendingDeployments?: number | undefined;
    memoryUsageMb?: number | undefined;
    cpuUsagePercent?: number | undefined;
};
/** @internal */
export declare const Metrics$outboundSchema: z.ZodType<Metrics$Outbound, Metrics>;
export declare function metricsToJSON(metrics: Metrics): string;
/** @internal */
export type AgentManagerHeartbeatRequest$Outbound = {
    status: string;
    version?: string | undefined;
    url: string;
    managementConfig?: AgentManagerHeartbeatRequestManagementConfigAzure$Outbound | AgentManagerHeartbeatRequestManagementConfigAws$Outbound | AgentManagerHeartbeatRequestManagementConfigGcp$Outbound | AgentManagerHeartbeatRequestManagementConfigKubernetes$Outbound | any | null | undefined;
    metrics?: Metrics$Outbound | undefined;
};
/** @internal */
export declare const AgentManagerHeartbeatRequest$outboundSchema: z.ZodType<AgentManagerHeartbeatRequest$Outbound, AgentManagerHeartbeatRequest>;
export declare function agentManagerHeartbeatRequestToJSON(agentManagerHeartbeatRequest: AgentManagerHeartbeatRequest): string;
//# sourceMappingURL=agentmanagerheartbeatrequest.d.ts.map