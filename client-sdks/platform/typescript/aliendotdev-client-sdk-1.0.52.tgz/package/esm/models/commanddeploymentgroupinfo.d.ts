import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CommandDeploymentGroupInfo = {
    id: string;
    name: string;
};
/** @internal */
export declare const CommandDeploymentGroupInfo$inboundSchema: z.ZodType<CommandDeploymentGroupInfo, unknown>;
export declare function commandDeploymentGroupInfoFromJSON(jsonString: string): SafeParseResult<CommandDeploymentGroupInfo, SDKValidationError>;
//# sourceMappingURL=commanddeploymentgroupinfo.d.ts.map