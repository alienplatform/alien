import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const ApplyDeploymentRequestPlatformLocal: {
    readonly Local: "local";
};
export type ApplyDeploymentRequestPlatformLocal = ClosedEnum<typeof ApplyDeploymentRequestPlatformLocal>;
/**
 * Local platform environment information
 */
export type ApplyDeploymentRequestEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: ApplyDeploymentRequestPlatformLocal;
};
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAzure: {
    readonly Azure: "azure";
};
export type ApplyDeploymentRequestEnvironmentInfoPlatformAzure = ClosedEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAzure>;
/**
 * Azure-specific environment information
 */
export type ApplyDeploymentRequestEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: ApplyDeploymentRequestEnvironmentInfoPlatformAzure;
};
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformGcp: {
    readonly Gcp: "gcp";
};
export type ApplyDeploymentRequestEnvironmentInfoPlatformGcp = ClosedEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformGcp>;
/**
 * GCP-specific environment information
 */
export type ApplyDeploymentRequestEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: ApplyDeploymentRequestEnvironmentInfoPlatformGcp;
};
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAws: {
    readonly Aws: "aws";
};
export type ApplyDeploymentRequestEnvironmentInfoPlatformAws = ClosedEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAws>;
/**
 * AWS-specific environment information
 */
export type ApplyDeploymentRequestEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: ApplyDeploymentRequestEnvironmentInfoPlatformAws;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type ApplyDeploymentRequestError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable?: boolean | undefined;
    source?: any | null | undefined;
};
export declare const ApplyDeploymentRequestManagementEnum: {
    readonly Auto: "auto";
};
export type ApplyDeploymentRequestManagementEnum = ClosedEnum<typeof ApplyDeploymentRequestManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentRequestOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentRequestOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentRequestOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentRequestOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentRequestOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentRequestOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentRequestOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentRequestOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentRequestOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentRequestOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentRequestOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentRequestOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentRequestOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentRequestOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentRequestOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentRequestOverrideUnion = ApplyDeploymentRequestOverride | string;
export type ApplyDeploymentRequestPreparedStackManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<ApplyDeploymentRequestOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentRequestExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentRequestExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentRequestExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentRequestExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentRequestExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentRequestExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentRequestExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentRequestExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentRequestExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentRequestExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentRequestExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentRequestExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentRequestExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentRequestExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentRequestExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentRequestExtendUnion = ApplyDeploymentRequestExtend | string;
export type ApplyDeploymentRequestPreparedStackManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<ApplyDeploymentRequestExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type ApplyDeploymentRequestManagementUnion = ApplyDeploymentRequestPreparedStackManagement1 | ApplyDeploymentRequestPreparedStackManagement2 | ApplyDeploymentRequestManagementEnum;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentRequestProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentRequestProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentRequestProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentRequestProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentRequestProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentRequestProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentRequestProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentRequestProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentRequestProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentRequestProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentRequestProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentRequestProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentRequestProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentRequestProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentRequestProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentRequestProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentRequestProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentRequestProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentRequestProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentRequestProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentRequestProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentRequestProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentRequestProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentRequestProfileUnion = ApplyDeploymentRequestProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type ApplyDeploymentRequestPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: ApplyDeploymentRequestPreparedStackManagement1 | ApplyDeploymentRequestPreparedStackManagement2 | ApplyDeploymentRequestManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentRequestProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentRequestPreparedStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type ApplyDeploymentRequestPreparedStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const ApplyDeploymentRequestPreparedStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type ApplyDeploymentRequestPreparedStackLifecycle = ClosedEnum<typeof ApplyDeploymentRequestPreparedStackLifecycle>;
export type ApplyDeploymentRequestPreparedStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: ApplyDeploymentRequestPreparedStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<ApplyDeploymentRequestPreparedStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: ApplyDeploymentRequestPreparedStackLifecycle;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type ApplyDeploymentRequestPreparedStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: ApplyDeploymentRequestPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: ApplyDeploymentRequestPreparedStackResources;
    };
};
/**
 * Runtime metadata for deployment
 *
 * @remarks
 *
 * Stores deployment state that needs to persist across step calls.
 */
export type ApplyDeploymentRequestRuntimeMetadata = {
    /**
     * Hash of the environment variables snapshot that was last synced to the vault
     *
     * @remarks
     * Used to avoid redundant sync operations during incremental deployment
     */
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const ApplyDeploymentRequestStackStatePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type ApplyDeploymentRequestStackStatePlatform = ClosedEnum<typeof ApplyDeploymentRequestStackStatePlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentRequestStackStateConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type ApplyDeploymentRequestStackStateDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type ApplyDeploymentRequestStackStateError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable?: boolean | undefined;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const ApplyDeploymentRequestStackStateLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type ApplyDeploymentRequestStackStateLifecycle = ClosedEnum<typeof ApplyDeploymentRequestStackStateLifecycle>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type ApplyDeploymentRequestOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentRequestPreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const ApplyDeploymentRequestStackStateStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type ApplyDeploymentRequestStackStateStatus = ClosedEnum<typeof ApplyDeploymentRequestStackStateStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type ApplyDeploymentRequestStackStateResources = {
    internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: ApplyDeploymentRequestStackStateConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<ApplyDeploymentRequestStackStateDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: ApplyDeploymentRequestStackStateStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * Represents the target cloud platform.
 */
export declare const ApplyDeploymentRequestKubernetesInfrastructurePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type ApplyDeploymentRequestKubernetesInfrastructurePlatform = ClosedEnum<typeof ApplyDeploymentRequestKubernetesInfrastructurePlatform>;
export declare const ApplyDeploymentRequestPlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type ApplyDeploymentRequestPlatformKubernetes = ClosedEnum<typeof ApplyDeploymentRequestPlatformKubernetes>;
export type ApplyDeploymentRequestManagementKubernetes = {
    platform: ApplyDeploymentRequestPlatformKubernetes;
};
/**
 * Image pull credentials for container registries
 */
export type ApplyDeploymentRequestImagePullCredentials = {
    /**
     * Password for the container registry
     */
    password: string;
    /**
     * Username for the container registry
     */
    username: string;
};
export declare const ApplyDeploymentRequestStackStatePlatformAzure: {
    readonly Azure: "azure";
};
export type ApplyDeploymentRequestStackStatePlatformAzure = ClosedEnum<typeof ApplyDeploymentRequestStackStatePlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type ApplyDeploymentRequestManagementAzure = {
    imagePullCredentials?: any | null | undefined;
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: ApplyDeploymentRequestStackStatePlatformAzure;
};
export declare const ApplyDeploymentRequestStackStatePlatformGcp: {
    readonly Gcp: "gcp";
};
export type ApplyDeploymentRequestStackStatePlatformGcp = ClosedEnum<typeof ApplyDeploymentRequestStackStatePlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type ApplyDeploymentRequestManagementGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: ApplyDeploymentRequestStackStatePlatformGcp;
};
export declare const ApplyDeploymentRequestStackStatePlatformAws: {
    readonly Aws: "aws";
};
export type ApplyDeploymentRequestStackStatePlatformAws = ClosedEnum<typeof ApplyDeploymentRequestStackStatePlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type ApplyDeploymentRequestManagementAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: ApplyDeploymentRequestStackStatePlatformAws;
};
/**
 * Remote capabilities configuration for agents
 */
export type ApplyDeploymentRequestRemoteCapabilities = {
    /**
     * Whether the agent supports automatic updates
     */
    autoUpdates: boolean;
    /**
     * Whether the agent supports heartbeat functionality
     */
    heartbeat: boolean;
    /**
     * Whether the agent supports monitoring
     */
    monitoring: boolean;
};
/**
 * Stack-level settings that customize deployment behavior
 */
export type ApplyDeploymentRequestSettings = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    /**
     * Remote capabilities configuration for agents
     */
    remoteCapabilities: ApplyDeploymentRequestRemoteCapabilities;
};
/**
 * Represents the collective state of all resources in a stack, including platform and pending actions.
 */
export type ApplyDeploymentRequestStackState = {
    /**
     * Represents the target cloud platform.
     */
    platform: ApplyDeploymentRequestStackStatePlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: ApplyDeploymentRequestStackStateResources;
    };
    /**
     * Stack-level settings that customize deployment behavior
     */
    settings: ApplyDeploymentRequestSettings;
};
/**
 * Deployment status in the deployment lifecycle
 */
export declare const ApplyDeploymentRequestStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type ApplyDeploymentRequestStatus = ClosedEnum<typeof ApplyDeploymentRequestStatus>;
/**
 * Deployment state update from step()
 */
export type Update = {
    /**
     * Whether to clear the retry_requested flag
     *
     * @remarks
     * - `false`: No action
     * - `true`: Clear the retry_requested flag (set when transitioning from failed to active status)
     */
    clearRetryRequested?: boolean | undefined;
    environmentInfo?: any | null | undefined;
    error?: any | null | undefined;
    /**
     * Whether to promote target to current (deployment/update complete)
     *
     * @remarks
     * - `false`: No action
     * - `true`: Promote target_release_id → current_release_id (and clear target)
     */
    promoteTargetToCurrent?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    status?: any | null | undefined;
    /**
     * Suggested delay in milliseconds before next step
     *
     * @remarks
     * - `None`: No suggested delay
     * - `Some(ms)`: Wait this many milliseconds before calling step() again
     */
    suggestedDelayMs?: number | null | undefined;
    /**
     * Whether to update the heartbeat timestamp
     *
     * @remarks
     * - `false`: No action
     * - `true`: Update lastHeartbeatAt timestamp (used when status is Running)
     */
    updateHeartbeat?: boolean | undefined;
};
/**
 * Request to apply deployment update
 */
export type ApplyDeploymentRequest = {
    /**
     * Session identifier that holds the lock
     */
    session: string;
    /**
     * Deployment state update from step()
     */
    update: Update;
    /**
     * Release lock after applying (default: false)
     */
    release?: boolean | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestPlatformLocal$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPlatformLocal>;
/** @internal */
export declare const ApplyDeploymentRequestPlatformLocal$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPlatformLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPlatformLocal$ {
    /** @deprecated use `ApplyDeploymentRequestPlatformLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentRequestPlatformLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoLocal$inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestEnvironmentInfoLocal$Outbound = {
    arch: string;
    hostname: string;
    os: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoLocal$outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoLocal$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoLocal$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoLocal$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoLocal>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoLocal$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestEnvironmentInfoLocal$Outbound;
}
export declare function applyDeploymentRequestEnvironmentInfoLocalToJSON(applyDeploymentRequestEnvironmentInfoLocal: ApplyDeploymentRequestEnvironmentInfoLocal): string;
export declare function applyDeploymentRequestEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAzure$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAzure>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAzure$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoPlatformAzure$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoAzure$inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestEnvironmentInfoAzure$Outbound = {
    location: string;
    subscriptionId: string;
    tenantId: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoAzure$outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoAzure$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoAzure>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestEnvironmentInfoAzure$Outbound;
}
export declare function applyDeploymentRequestEnvironmentInfoAzureToJSON(applyDeploymentRequestEnvironmentInfoAzure: ApplyDeploymentRequestEnvironmentInfoAzure): string;
export declare function applyDeploymentRequestEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformGcp$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformGcp>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformGcp$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoPlatformGcp$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoGcp$inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestEnvironmentInfoGcp$Outbound = {
    projectId: string;
    projectNumber: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoGcp$outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoGcp$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoGcp>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestEnvironmentInfoGcp$Outbound;
}
export declare function applyDeploymentRequestEnvironmentInfoGcpToJSON(applyDeploymentRequestEnvironmentInfoGcp: ApplyDeploymentRequestEnvironmentInfoGcp): string;
export declare function applyDeploymentRequestEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAws$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAws>;
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoPlatformAws$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestEnvironmentInfoPlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoPlatformAws$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoPlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoAws$inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAws, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestEnvironmentInfoAws$Outbound = {
    accountId: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestEnvironmentInfoAws$outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAws$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestEnvironmentInfoAws$ {
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestEnvironmentInfoAws$Outbound, z.ZodTypeDef, ApplyDeploymentRequestEnvironmentInfoAws>;
    /** @deprecated use `ApplyDeploymentRequestEnvironmentInfoAws$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestEnvironmentInfoAws$Outbound;
}
export declare function applyDeploymentRequestEnvironmentInfoAwsToJSON(applyDeploymentRequestEnvironmentInfoAws: ApplyDeploymentRequestEnvironmentInfoAws): string;
export declare function applyDeploymentRequestEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestError$inboundSchema: z.ZodType<ApplyDeploymentRequestError, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestError$Outbound = {
    code: string;
    context?: any | null | undefined;
    httpStatusCode?: number | null | undefined;
    internal: boolean;
    message: string;
    retryable: boolean;
    source?: any | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestError$outboundSchema: z.ZodType<ApplyDeploymentRequestError$Outbound, z.ZodTypeDef, ApplyDeploymentRequestError>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestError$ {
    /** @deprecated use `ApplyDeploymentRequestError$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestError, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestError$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestError$Outbound, z.ZodTypeDef, ApplyDeploymentRequestError>;
    /** @deprecated use `ApplyDeploymentRequestError$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestError$Outbound;
}
export declare function applyDeploymentRequestErrorToJSON(applyDeploymentRequestError: ApplyDeploymentRequestError): string;
export declare function applyDeploymentRequestErrorFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestError, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestManagementEnum$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestManagementEnum>;
/** @internal */
export declare const ApplyDeploymentRequestManagementEnum$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestManagementEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementEnum$ {
    /** @deprecated use `ApplyDeploymentRequestManagementEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `ApplyDeploymentRequestManagementEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwResource$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwResource$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAwResource$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwResource>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAwResource$Outbound;
}
export declare function applyDeploymentRequestOverrideAwResourceToJSON(applyDeploymentRequestOverrideAwResource: ApplyDeploymentRequestOverrideAwResource): string;
export declare function applyDeploymentRequestOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwStack$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwStack$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAwStack$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwStack>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAwStack$Outbound;
}
export declare function applyDeploymentRequestOverrideAwStackToJSON(applyDeploymentRequestOverrideAwStack: ApplyDeploymentRequestOverrideAwStack): string;
export declare function applyDeploymentRequestOverrideAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAwBinding$Outbound = {
    resource?: ApplyDeploymentRequestOverrideAwResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestOverrideAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAwBinding$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwBinding>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAwBinding$Outbound;
}
export declare function applyDeploymentRequestOverrideAwBindingToJSON(applyDeploymentRequestOverrideAwBinding: ApplyDeploymentRequestOverrideAwBinding): string;
export declare function applyDeploymentRequestOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAwGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAwGrant$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAwGrant>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAwGrant$Outbound;
}
export declare function applyDeploymentRequestOverrideAwGrantToJSON(applyDeploymentRequestOverrideAwGrant: ApplyDeploymentRequestOverrideAwGrant): string;
export declare function applyDeploymentRequestOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAw$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAw$Outbound = {
    binding: ApplyDeploymentRequestOverrideAwBinding$Outbound;
    grant: ApplyDeploymentRequestOverrideAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAw$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAw$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAw>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAw$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAw$Outbound;
}
export declare function applyDeploymentRequestOverrideAwToJSON(applyDeploymentRequestOverrideAw: ApplyDeploymentRequestOverrideAw): string;
export declare function applyDeploymentRequestOverrideAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureResource$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureResource$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAzureResource$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureResource>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAzureResource$Outbound;
}
export declare function applyDeploymentRequestOverrideAzureResourceToJSON(applyDeploymentRequestOverrideAzureResource: ApplyDeploymentRequestOverrideAzureResource): string;
export declare function applyDeploymentRequestOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureStack$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureStack$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAzureStack$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureStack>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAzureStack$Outbound;
}
export declare function applyDeploymentRequestOverrideAzureStackToJSON(applyDeploymentRequestOverrideAzureStack: ApplyDeploymentRequestOverrideAzureStack): string;
export declare function applyDeploymentRequestOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAzureBinding$Outbound = {
    resource?: ApplyDeploymentRequestOverrideAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestOverrideAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAzureBinding$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureBinding>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAzureBinding$Outbound;
}
export declare function applyDeploymentRequestOverrideAzureBindingToJSON(applyDeploymentRequestOverrideAzureBinding: ApplyDeploymentRequestOverrideAzureBinding): string;
export declare function applyDeploymentRequestOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAzureGrant$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzureGrant>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAzureGrant$Outbound;
}
export declare function applyDeploymentRequestOverrideAzureGrantToJSON(applyDeploymentRequestOverrideAzureGrant: ApplyDeploymentRequestOverrideAzureGrant): string;
export declare function applyDeploymentRequestOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzure$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideAzure$Outbound = {
    binding: ApplyDeploymentRequestOverrideAzureBinding$Outbound;
    grant: ApplyDeploymentRequestOverrideAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideAzure$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideAzure$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideAzure>;
    /** @deprecated use `ApplyDeploymentRequestOverrideAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideAzure$Outbound;
}
export declare function applyDeploymentRequestOverrideAzureToJSON(applyDeploymentRequestOverrideAzure: ApplyDeploymentRequestOverrideAzure): string;
export declare function applyDeploymentRequestOverrideAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideConditionResource$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideConditionResource$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideConditionResource$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideConditionResource>;
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideConditionResource$Outbound;
}
export declare function applyDeploymentRequestOverrideConditionResourceToJSON(applyDeploymentRequestOverrideConditionResource: ApplyDeploymentRequestOverrideConditionResource): string;
export declare function applyDeploymentRequestOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpResource$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpResource$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideGcpResource$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpResource>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideGcpResource$Outbound;
}
export declare function applyDeploymentRequestOverrideGcpResourceToJSON(applyDeploymentRequestOverrideGcpResource: ApplyDeploymentRequestOverrideGcpResource): string;
export declare function applyDeploymentRequestOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideConditionStack$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideConditionStack$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideConditionStack$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideConditionStack>;
    /** @deprecated use `ApplyDeploymentRequestOverrideConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideConditionStack$Outbound;
}
export declare function applyDeploymentRequestOverrideConditionStackToJSON(applyDeploymentRequestOverrideConditionStack: ApplyDeploymentRequestOverrideConditionStack): string;
export declare function applyDeploymentRequestOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpStack$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpStack$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideGcpStack$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpStack>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideGcpStack$Outbound;
}
export declare function applyDeploymentRequestOverrideGcpStackToJSON(applyDeploymentRequestOverrideGcpStack: ApplyDeploymentRequestOverrideGcpStack): string;
export declare function applyDeploymentRequestOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideGcpBinding$Outbound = {
    resource?: ApplyDeploymentRequestOverrideGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestOverrideGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideGcpBinding$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpBinding>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideGcpBinding$Outbound;
}
export declare function applyDeploymentRequestOverrideGcpBindingToJSON(applyDeploymentRequestOverrideGcpBinding: ApplyDeploymentRequestOverrideGcpBinding): string;
export declare function applyDeploymentRequestOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideGcpGrant$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcpGrant>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideGcpGrant$Outbound;
}
export declare function applyDeploymentRequestOverrideGcpGrantToJSON(applyDeploymentRequestOverrideGcpGrant: ApplyDeploymentRequestOverrideGcpGrant): string;
export declare function applyDeploymentRequestOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcp$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideGcp$Outbound = {
    binding: ApplyDeploymentRequestOverrideGcpBinding$Outbound;
    grant: ApplyDeploymentRequestOverrideGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestOverrideGcp$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideGcp$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideGcp>;
    /** @deprecated use `ApplyDeploymentRequestOverrideGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideGcp$Outbound;
}
export declare function applyDeploymentRequestOverrideGcpToJSON(applyDeploymentRequestOverrideGcp: ApplyDeploymentRequestOverrideGcp): string;
export declare function applyDeploymentRequestOverrideGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverridePlatforms$inboundSchema: z.ZodType<ApplyDeploymentRequestOverridePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverridePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentRequestOverrideAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentRequestOverrideAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentRequestOverrideGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestOverridePlatforms$outboundSchema: z.ZodType<ApplyDeploymentRequestOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverridePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverridePlatforms$ {
    /** @deprecated use `ApplyDeploymentRequestOverridePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverridePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverridePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverridePlatforms>;
    /** @deprecated use `ApplyDeploymentRequestOverridePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverridePlatforms$Outbound;
}
export declare function applyDeploymentRequestOverridePlatformsToJSON(applyDeploymentRequestOverridePlatforms: ApplyDeploymentRequestOverridePlatforms): string;
export declare function applyDeploymentRequestOverridePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverride$inboundSchema: z.ZodType<ApplyDeploymentRequestOverride, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverride$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentRequestOverridePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestOverride$outboundSchema: z.ZodType<ApplyDeploymentRequestOverride$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverride>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverride$ {
    /** @deprecated use `ApplyDeploymentRequestOverride$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverride, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverride$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverride$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverride>;
    /** @deprecated use `ApplyDeploymentRequestOverride$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverride$Outbound;
}
export declare function applyDeploymentRequestOverrideToJSON(applyDeploymentRequestOverride: ApplyDeploymentRequestOverride): string;
export declare function applyDeploymentRequestOverrideFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverride, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestOverrideUnion$inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOverrideUnion$Outbound = ApplyDeploymentRequestOverride$Outbound | string;
/** @internal */
export declare const ApplyDeploymentRequestOverrideUnion$outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOverrideUnion$ {
    /** @deprecated use `ApplyDeploymentRequestOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOverrideUnion>;
    /** @deprecated use `ApplyDeploymentRequestOverrideUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOverrideUnion$Outbound;
}
export declare function applyDeploymentRequestOverrideUnionToJSON(applyDeploymentRequestOverrideUnion: ApplyDeploymentRequestOverrideUnion): string;
export declare function applyDeploymentRequestOverrideUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOverrideUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackManagement2$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement2, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStackManagement2$Outbound = {
    override: {
        [k: string]: Array<ApplyDeploymentRequestOverride$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackManagement2$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackManagement2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackManagement2$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement2, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackManagement2>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement2$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStackManagement2$Outbound;
}
export declare function applyDeploymentRequestPreparedStackManagement2ToJSON(applyDeploymentRequestPreparedStackManagement2: ApplyDeploymentRequestPreparedStackManagement2): string;
export declare function applyDeploymentRequestPreparedStackManagement2FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStackManagement2, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAwResource$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAwResource$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAwResource$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwResource>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAwResource$Outbound;
}
export declare function applyDeploymentRequestExtendAwResourceToJSON(applyDeploymentRequestExtendAwResource: ApplyDeploymentRequestExtendAwResource): string;
export declare function applyDeploymentRequestExtendAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAwStack$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAwStack$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAwStack$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwStack>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAwStack$Outbound;
}
export declare function applyDeploymentRequestExtendAwStackToJSON(applyDeploymentRequestExtendAwStack: ApplyDeploymentRequestExtendAwStack): string;
export declare function applyDeploymentRequestExtendAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAwBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAwBinding$Outbound = {
    resource?: ApplyDeploymentRequestExtendAwResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestExtendAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAwBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAwBinding$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwBinding>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAwBinding$Outbound;
}
export declare function applyDeploymentRequestExtendAwBindingToJSON(applyDeploymentRequestExtendAwBinding: ApplyDeploymentRequestExtendAwBinding): string;
export declare function applyDeploymentRequestExtendAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAwGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAwGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAwGrant$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAwGrant>;
    /** @deprecated use `ApplyDeploymentRequestExtendAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAwGrant$Outbound;
}
export declare function applyDeploymentRequestExtendAwGrantToJSON(applyDeploymentRequestExtendAwGrant: ApplyDeploymentRequestExtendAwGrant): string;
export declare function applyDeploymentRequestExtendAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAw$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAw$Outbound = {
    binding: ApplyDeploymentRequestExtendAwBinding$Outbound;
    grant: ApplyDeploymentRequestExtendAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAw$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAw$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAw>;
    /** @deprecated use `ApplyDeploymentRequestExtendAw$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAw$Outbound;
}
export declare function applyDeploymentRequestExtendAwToJSON(applyDeploymentRequestExtendAw: ApplyDeploymentRequestExtendAw): string;
export declare function applyDeploymentRequestExtendAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureResource$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureResource$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAzureResource$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureResource>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAzureResource$Outbound;
}
export declare function applyDeploymentRequestExtendAzureResourceToJSON(applyDeploymentRequestExtendAzureResource: ApplyDeploymentRequestExtendAzureResource): string;
export declare function applyDeploymentRequestExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureStack$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureStack$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAzureStack$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureStack>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAzureStack$Outbound;
}
export declare function applyDeploymentRequestExtendAzureStackToJSON(applyDeploymentRequestExtendAzureStack: ApplyDeploymentRequestExtendAzureStack): string;
export declare function applyDeploymentRequestExtendAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAzureBinding$Outbound = {
    resource?: ApplyDeploymentRequestExtendAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestExtendAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAzureBinding$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureBinding>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAzureBinding$Outbound;
}
export declare function applyDeploymentRequestExtendAzureBindingToJSON(applyDeploymentRequestExtendAzureBinding: ApplyDeploymentRequestExtendAzureBinding): string;
export declare function applyDeploymentRequestExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAzureGrant$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzureGrant>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAzureGrant$Outbound;
}
export declare function applyDeploymentRequestExtendAzureGrantToJSON(applyDeploymentRequestExtendAzureGrant: ApplyDeploymentRequestExtendAzureGrant): string;
export declare function applyDeploymentRequestExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendAzure$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendAzure$Outbound = {
    binding: ApplyDeploymentRequestExtendAzureBinding$Outbound;
    grant: ApplyDeploymentRequestExtendAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendAzure$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendAzure$ {
    /** @deprecated use `ApplyDeploymentRequestExtendAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendAzure>;
    /** @deprecated use `ApplyDeploymentRequestExtendAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendAzure$Outbound;
}
export declare function applyDeploymentRequestExtendAzureToJSON(applyDeploymentRequestExtendAzure: ApplyDeploymentRequestExtendAzure): string;
export declare function applyDeploymentRequestExtendAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendConditionResource$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendConditionResource$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendConditionResource$ {
    /** @deprecated use `ApplyDeploymentRequestExtendConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendConditionResource>;
    /** @deprecated use `ApplyDeploymentRequestExtendConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendConditionResource$Outbound;
}
export declare function applyDeploymentRequestExtendConditionResourceToJSON(applyDeploymentRequestExtendConditionResource: ApplyDeploymentRequestExtendConditionResource): string;
export declare function applyDeploymentRequestExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpResource$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpResource$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendGcpResource$ {
    /** @deprecated use `ApplyDeploymentRequestExtendGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpResource>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendGcpResource$Outbound;
}
export declare function applyDeploymentRequestExtendGcpResourceToJSON(applyDeploymentRequestExtendGcpResource: ApplyDeploymentRequestExtendGcpResource): string;
export declare function applyDeploymentRequestExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendConditionStack$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendConditionStack$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendConditionStack$ {
    /** @deprecated use `ApplyDeploymentRequestExtendConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendConditionStack>;
    /** @deprecated use `ApplyDeploymentRequestExtendConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendConditionStack$Outbound;
}
export declare function applyDeploymentRequestExtendConditionStackToJSON(applyDeploymentRequestExtendConditionStack: ApplyDeploymentRequestExtendConditionStack): string;
export declare function applyDeploymentRequestExtendConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpStack$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpStack$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendGcpStack$ {
    /** @deprecated use `ApplyDeploymentRequestExtendGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpStack>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendGcpStack$Outbound;
}
export declare function applyDeploymentRequestExtendGcpStackToJSON(applyDeploymentRequestExtendGcpStack: ApplyDeploymentRequestExtendGcpStack): string;
export declare function applyDeploymentRequestExtendGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendGcpBinding$Outbound = {
    resource?: ApplyDeploymentRequestExtendGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestExtendGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendGcpBinding$ {
    /** @deprecated use `ApplyDeploymentRequestExtendGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpBinding>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendGcpBinding$Outbound;
}
export declare function applyDeploymentRequestExtendGcpBindingToJSON(applyDeploymentRequestExtendGcpBinding: ApplyDeploymentRequestExtendGcpBinding): string;
export declare function applyDeploymentRequestExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendGcpGrant$ {
    /** @deprecated use `ApplyDeploymentRequestExtendGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcpGrant>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendGcpGrant$Outbound;
}
export declare function applyDeploymentRequestExtendGcpGrantToJSON(applyDeploymentRequestExtendGcpGrant: ApplyDeploymentRequestExtendGcpGrant): string;
export declare function applyDeploymentRequestExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendGcp$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendGcp$Outbound = {
    binding: ApplyDeploymentRequestExtendGcpBinding$Outbound;
    grant: ApplyDeploymentRequestExtendGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendGcp$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendGcp$ {
    /** @deprecated use `ApplyDeploymentRequestExtendGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendGcp>;
    /** @deprecated use `ApplyDeploymentRequestExtendGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendGcp$Outbound;
}
export declare function applyDeploymentRequestExtendGcpToJSON(applyDeploymentRequestExtendGcp: ApplyDeploymentRequestExtendGcp): string;
export declare function applyDeploymentRequestExtendGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendPlatforms$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendPlatforms$Outbound = {
    aws?: Array<ApplyDeploymentRequestExtendAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentRequestExtendAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentRequestExtendGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestExtendPlatforms$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendPlatforms$ {
    /** @deprecated use `ApplyDeploymentRequestExtendPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendPlatforms>;
    /** @deprecated use `ApplyDeploymentRequestExtendPlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendPlatforms$Outbound;
}
export declare function applyDeploymentRequestExtendPlatformsToJSON(applyDeploymentRequestExtendPlatforms: ApplyDeploymentRequestExtendPlatforms): string;
export declare function applyDeploymentRequestExtendPlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtend$inboundSchema: z.ZodType<ApplyDeploymentRequestExtend, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtend$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentRequestExtendPlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestExtend$outboundSchema: z.ZodType<ApplyDeploymentRequestExtend$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtend>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtend$ {
    /** @deprecated use `ApplyDeploymentRequestExtend$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtend, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtend$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtend$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtend>;
    /** @deprecated use `ApplyDeploymentRequestExtend$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtend$Outbound;
}
export declare function applyDeploymentRequestExtendToJSON(applyDeploymentRequestExtend: ApplyDeploymentRequestExtend): string;
export declare function applyDeploymentRequestExtendFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtend, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestExtendUnion$inboundSchema: z.ZodType<ApplyDeploymentRequestExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestExtendUnion$Outbound = ApplyDeploymentRequestExtend$Outbound | string;
/** @internal */
export declare const ApplyDeploymentRequestExtendUnion$outboundSchema: z.ZodType<ApplyDeploymentRequestExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestExtendUnion$ {
    /** @deprecated use `ApplyDeploymentRequestExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestExtendUnion>;
    /** @deprecated use `ApplyDeploymentRequestExtendUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestExtendUnion$Outbound;
}
export declare function applyDeploymentRequestExtendUnionToJSON(applyDeploymentRequestExtendUnion: ApplyDeploymentRequestExtendUnion): string;
export declare function applyDeploymentRequestExtendUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestExtendUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackManagement1$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement1, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStackManagement1$Outbound = {
    extend: {
        [k: string]: Array<ApplyDeploymentRequestExtend$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackManagement1$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackManagement1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackManagement1$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement1, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackManagement1>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackManagement1$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStackManagement1$Outbound;
}
export declare function applyDeploymentRequestPreparedStackManagement1ToJSON(applyDeploymentRequestPreparedStackManagement1: ApplyDeploymentRequestPreparedStackManagement1): string;
export declare function applyDeploymentRequestPreparedStackManagement1FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStackManagement1, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestManagementUnion$inboundSchema: z.ZodType<ApplyDeploymentRequestManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestManagementUnion$Outbound = ApplyDeploymentRequestPreparedStackManagement1$Outbound | ApplyDeploymentRequestPreparedStackManagement2$Outbound | string;
/** @internal */
export declare const ApplyDeploymentRequestManagementUnion$outboundSchema: z.ZodType<ApplyDeploymentRequestManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementUnion$ {
    /** @deprecated use `ApplyDeploymentRequestManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementUnion>;
    /** @deprecated use `ApplyDeploymentRequestManagementUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestManagementUnion$Outbound;
}
export declare function applyDeploymentRequestManagementUnionToJSON(applyDeploymentRequestManagementUnion: ApplyDeploymentRequestManagementUnion): string;
export declare function applyDeploymentRequestManagementUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestManagementUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAwResource$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAwResource$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAwResource$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwResource>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAwResource$Outbound;
}
export declare function applyDeploymentRequestProfileAwResourceToJSON(applyDeploymentRequestProfileAwResource: ApplyDeploymentRequestProfileAwResource): string;
export declare function applyDeploymentRequestProfileAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAwStack$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAwStack$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAwStack$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwStack>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAwStack$Outbound;
}
export declare function applyDeploymentRequestProfileAwStackToJSON(applyDeploymentRequestProfileAwStack: ApplyDeploymentRequestProfileAwStack): string;
export declare function applyDeploymentRequestProfileAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAwBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAwBinding$Outbound = {
    resource?: ApplyDeploymentRequestProfileAwResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestProfileAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAwBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAwBinding$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwBinding>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAwBinding$Outbound;
}
export declare function applyDeploymentRequestProfileAwBindingToJSON(applyDeploymentRequestProfileAwBinding: ApplyDeploymentRequestProfileAwBinding): string;
export declare function applyDeploymentRequestProfileAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAwGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAwGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAwGrant$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAwGrant>;
    /** @deprecated use `ApplyDeploymentRequestProfileAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAwGrant$Outbound;
}
export declare function applyDeploymentRequestProfileAwGrantToJSON(applyDeploymentRequestProfileAwGrant: ApplyDeploymentRequestProfileAwGrant): string;
export declare function applyDeploymentRequestProfileAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAw$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAw$Outbound = {
    binding: ApplyDeploymentRequestProfileAwBinding$Outbound;
    grant: ApplyDeploymentRequestProfileAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAw$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAw$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAw>;
    /** @deprecated use `ApplyDeploymentRequestProfileAw$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAw$Outbound;
}
export declare function applyDeploymentRequestProfileAwToJSON(applyDeploymentRequestProfileAw: ApplyDeploymentRequestProfileAw): string;
export declare function applyDeploymentRequestProfileAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureResource$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureResource$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAzureResource$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureResource>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAzureResource$Outbound;
}
export declare function applyDeploymentRequestProfileAzureResourceToJSON(applyDeploymentRequestProfileAzureResource: ApplyDeploymentRequestProfileAzureResource): string;
export declare function applyDeploymentRequestProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureStack$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureStack$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAzureStack$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureStack>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAzureStack$Outbound;
}
export declare function applyDeploymentRequestProfileAzureStackToJSON(applyDeploymentRequestProfileAzureStack: ApplyDeploymentRequestProfileAzureStack): string;
export declare function applyDeploymentRequestProfileAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAzureBinding$Outbound = {
    resource?: ApplyDeploymentRequestProfileAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestProfileAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAzureBinding$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureBinding>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAzureBinding$Outbound;
}
export declare function applyDeploymentRequestProfileAzureBindingToJSON(applyDeploymentRequestProfileAzureBinding: ApplyDeploymentRequestProfileAzureBinding): string;
export declare function applyDeploymentRequestProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAzureGrant$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzureGrant>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAzureGrant$Outbound;
}
export declare function applyDeploymentRequestProfileAzureGrantToJSON(applyDeploymentRequestProfileAzureGrant: ApplyDeploymentRequestProfileAzureGrant): string;
export declare function applyDeploymentRequestProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileAzure$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileAzure$Outbound = {
    binding: ApplyDeploymentRequestProfileAzureBinding$Outbound;
    grant: ApplyDeploymentRequestProfileAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileAzure$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileAzure$ {
    /** @deprecated use `ApplyDeploymentRequestProfileAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileAzure>;
    /** @deprecated use `ApplyDeploymentRequestProfileAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileAzure$Outbound;
}
export declare function applyDeploymentRequestProfileAzureToJSON(applyDeploymentRequestProfileAzure: ApplyDeploymentRequestProfileAzure): string;
export declare function applyDeploymentRequestProfileAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileConditionResource$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileConditionResource$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileConditionResource$ {
    /** @deprecated use `ApplyDeploymentRequestProfileConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileConditionResource>;
    /** @deprecated use `ApplyDeploymentRequestProfileConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileConditionResource$Outbound;
}
export declare function applyDeploymentRequestProfileConditionResourceToJSON(applyDeploymentRequestProfileConditionResource: ApplyDeploymentRequestProfileConditionResource): string;
export declare function applyDeploymentRequestProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpResource$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpResource$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileGcpResource$ {
    /** @deprecated use `ApplyDeploymentRequestProfileGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpResource>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileGcpResource$Outbound;
}
export declare function applyDeploymentRequestProfileGcpResourceToJSON(applyDeploymentRequestProfileGcpResource: ApplyDeploymentRequestProfileGcpResource): string;
export declare function applyDeploymentRequestProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileConditionStack$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileConditionStack$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileConditionStack$ {
    /** @deprecated use `ApplyDeploymentRequestProfileConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileConditionStack>;
    /** @deprecated use `ApplyDeploymentRequestProfileConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileConditionStack$Outbound;
}
export declare function applyDeploymentRequestProfileConditionStackToJSON(applyDeploymentRequestProfileConditionStack: ApplyDeploymentRequestProfileConditionStack): string;
export declare function applyDeploymentRequestProfileConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpStack$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpStack$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileGcpStack$ {
    /** @deprecated use `ApplyDeploymentRequestProfileGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpStack>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileGcpStack$Outbound;
}
export declare function applyDeploymentRequestProfileGcpStackToJSON(applyDeploymentRequestProfileGcpStack: ApplyDeploymentRequestProfileGcpStack): string;
export declare function applyDeploymentRequestProfileGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileGcpBinding$Outbound = {
    resource?: ApplyDeploymentRequestProfileGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentRequestProfileGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileGcpBinding$ {
    /** @deprecated use `ApplyDeploymentRequestProfileGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpBinding>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileGcpBinding$Outbound;
}
export declare function applyDeploymentRequestProfileGcpBindingToJSON(applyDeploymentRequestProfileGcpBinding: ApplyDeploymentRequestProfileGcpBinding): string;
export declare function applyDeploymentRequestProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileGcpGrant$ {
    /** @deprecated use `ApplyDeploymentRequestProfileGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcpGrant>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileGcpGrant$Outbound;
}
export declare function applyDeploymentRequestProfileGcpGrantToJSON(applyDeploymentRequestProfileGcpGrant: ApplyDeploymentRequestProfileGcpGrant): string;
export declare function applyDeploymentRequestProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileGcp$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileGcp$Outbound = {
    binding: ApplyDeploymentRequestProfileGcpBinding$Outbound;
    grant: ApplyDeploymentRequestProfileGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestProfileGcp$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileGcp$ {
    /** @deprecated use `ApplyDeploymentRequestProfileGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileGcp>;
    /** @deprecated use `ApplyDeploymentRequestProfileGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileGcp$Outbound;
}
export declare function applyDeploymentRequestProfileGcpToJSON(applyDeploymentRequestProfileGcp: ApplyDeploymentRequestProfileGcp): string;
export declare function applyDeploymentRequestProfileGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfilePlatforms$inboundSchema: z.ZodType<ApplyDeploymentRequestProfilePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfilePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentRequestProfileAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentRequestProfileAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentRequestProfileGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestProfilePlatforms$outboundSchema: z.ZodType<ApplyDeploymentRequestProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfilePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfilePlatforms$ {
    /** @deprecated use `ApplyDeploymentRequestProfilePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfilePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfilePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfilePlatforms>;
    /** @deprecated use `ApplyDeploymentRequestProfilePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfilePlatforms$Outbound;
}
export declare function applyDeploymentRequestProfilePlatformsToJSON(applyDeploymentRequestProfilePlatforms: ApplyDeploymentRequestProfilePlatforms): string;
export declare function applyDeploymentRequestProfilePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfile$inboundSchema: z.ZodType<ApplyDeploymentRequestProfile, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfile$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentRequestProfilePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestProfile$outboundSchema: z.ZodType<ApplyDeploymentRequestProfile$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfile>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfile$ {
    /** @deprecated use `ApplyDeploymentRequestProfile$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfile, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfile$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfile$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfile>;
    /** @deprecated use `ApplyDeploymentRequestProfile$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfile$Outbound;
}
export declare function applyDeploymentRequestProfileToJSON(applyDeploymentRequestProfile: ApplyDeploymentRequestProfile): string;
export declare function applyDeploymentRequestProfileFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfile, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestProfileUnion$inboundSchema: z.ZodType<ApplyDeploymentRequestProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestProfileUnion$Outbound = ApplyDeploymentRequestProfile$Outbound | string;
/** @internal */
export declare const ApplyDeploymentRequestProfileUnion$outboundSchema: z.ZodType<ApplyDeploymentRequestProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestProfileUnion$ {
    /** @deprecated use `ApplyDeploymentRequestProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentRequestProfileUnion>;
    /** @deprecated use `ApplyDeploymentRequestProfileUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestProfileUnion$Outbound;
}
export declare function applyDeploymentRequestProfileUnionToJSON(applyDeploymentRequestProfileUnion: ApplyDeploymentRequestProfileUnion): string;
export declare function applyDeploymentRequestProfileUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestProfileUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPermissions$inboundSchema: z.ZodType<ApplyDeploymentRequestPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPermissions$Outbound = {
    management?: ApplyDeploymentRequestPreparedStackManagement1$Outbound | ApplyDeploymentRequestPreparedStackManagement2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentRequestProfile$Outbound | string>;
        };
    };
};
/** @internal */
export declare const ApplyDeploymentRequestPermissions$outboundSchema: z.ZodType<ApplyDeploymentRequestPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPermissions$ {
    /** @deprecated use `ApplyDeploymentRequestPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPermissions>;
    /** @deprecated use `ApplyDeploymentRequestPermissions$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPermissions$Outbound;
}
export declare function applyDeploymentRequestPermissionsToJSON(applyDeploymentRequestPermissions: ApplyDeploymentRequestPermissions): string;
export declare function applyDeploymentRequestPermissionsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPermissions, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackConfig$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackConfig$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackConfig$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackConfig>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStackConfig$Outbound;
}
export declare function applyDeploymentRequestPreparedStackConfigToJSON(applyDeploymentRequestPreparedStackConfig: ApplyDeploymentRequestPreparedStackConfig): string;
export declare function applyDeploymentRequestPreparedStackConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStackConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackDependency$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackDependency$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackDependency$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackDependency>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackDependency$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStackDependency$Outbound;
}
export declare function applyDeploymentRequestPreparedStackDependencyToJSON(applyDeploymentRequestPreparedStackDependency: ApplyDeploymentRequestPreparedStackDependency): string;
export declare function applyDeploymentRequestPreparedStackDependencyFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStackDependency, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPreparedStackLifecycle>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPreparedStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackLifecycle$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackResources$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStackResources$Outbound = {
    config: ApplyDeploymentRequestPreparedStackConfig$Outbound;
    dependencies: Array<ApplyDeploymentRequestPreparedStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStackResources$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStackResources$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStackResources>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStackResources$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStackResources$Outbound;
}
export declare function applyDeploymentRequestPreparedStackResourcesToJSON(applyDeploymentRequestPreparedStackResources: ApplyDeploymentRequestPreparedStackResources): string;
export declare function applyDeploymentRequestPreparedStackResourcesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStackResources, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreparedStack$inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreparedStack$Outbound = {
    id: string;
    permissions?: ApplyDeploymentRequestPermissions$Outbound | undefined;
    resources: {
        [k: string]: ApplyDeploymentRequestPreparedStackResources$Outbound;
    };
};
/** @internal */
export declare const ApplyDeploymentRequestPreparedStack$outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreparedStack$ {
    /** @deprecated use `ApplyDeploymentRequestPreparedStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreparedStack$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreparedStack>;
    /** @deprecated use `ApplyDeploymentRequestPreparedStack$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreparedStack$Outbound;
}
export declare function applyDeploymentRequestPreparedStackToJSON(applyDeploymentRequestPreparedStack: ApplyDeploymentRequestPreparedStack): string;
export declare function applyDeploymentRequestPreparedStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreparedStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestRuntimeMetadata$inboundSchema: z.ZodType<ApplyDeploymentRequestRuntimeMetadata, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestRuntimeMetadata$Outbound = {
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestRuntimeMetadata$outboundSchema: z.ZodType<ApplyDeploymentRequestRuntimeMetadata$Outbound, z.ZodTypeDef, ApplyDeploymentRequestRuntimeMetadata>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestRuntimeMetadata$ {
    /** @deprecated use `ApplyDeploymentRequestRuntimeMetadata$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestRuntimeMetadata, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestRuntimeMetadata$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestRuntimeMetadata$Outbound, z.ZodTypeDef, ApplyDeploymentRequestRuntimeMetadata>;
    /** @deprecated use `ApplyDeploymentRequestRuntimeMetadata$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestRuntimeMetadata$Outbound;
}
export declare function applyDeploymentRequestRuntimeMetadataToJSON(applyDeploymentRequestRuntimeMetadata: ApplyDeploymentRequestRuntimeMetadata): string;
export declare function applyDeploymentRequestRuntimeMetadataFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestRuntimeMetadata, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatform$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatform>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatform$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStatePlatform$ {
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestStackStateConfig$inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestStackStateConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentRequestStackStateConfig$outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateConfig$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestStackStateConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateConfig>;
    /** @deprecated use `ApplyDeploymentRequestStackStateConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestStackStateConfig$Outbound;
}
export declare function applyDeploymentRequestStackStateConfigToJSON(applyDeploymentRequestStackStateConfig: ApplyDeploymentRequestStackStateConfig): string;
export declare function applyDeploymentRequestStackStateConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestStackStateConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateDependency$inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestStackStateDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentRequestStackStateDependency$outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateDependency$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateDependency$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestStackStateDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateDependency$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateDependency>;
    /** @deprecated use `ApplyDeploymentRequestStackStateDependency$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestStackStateDependency$Outbound;
}
export declare function applyDeploymentRequestStackStateDependencyToJSON(applyDeploymentRequestStackStateDependency: ApplyDeploymentRequestStackStateDependency): string;
export declare function applyDeploymentRequestStackStateDependencyFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestStackStateDependency, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateError$inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateError, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestStackStateError$Outbound = {
    code: string;
    context?: any | null | undefined;
    httpStatusCode?: number | null | undefined;
    internal: boolean;
    message: string;
    retryable: boolean;
    source?: any | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequestStackStateError$outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateError$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateError>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateError$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateError$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateError, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestStackStateError$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateError$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateError>;
    /** @deprecated use `ApplyDeploymentRequestStackStateError$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestStackStateError$Outbound;
}
export declare function applyDeploymentRequestStackStateErrorToJSON(applyDeploymentRequestStackStateError: ApplyDeploymentRequestStackStateError): string;
export declare function applyDeploymentRequestStackStateErrorFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestStackStateError, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateLifecycle$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStateLifecycle>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateLifecycle$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStateLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateLifecycle$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStateLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestOutputs$inboundSchema: z.ZodType<ApplyDeploymentRequestOutputs, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestOutputs$Outbound = {
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentRequestOutputs$outboundSchema: z.ZodType<ApplyDeploymentRequestOutputs$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOutputs>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestOutputs$ {
    /** @deprecated use `ApplyDeploymentRequestOutputs$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestOutputs, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestOutputs$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestOutputs$Outbound, z.ZodTypeDef, ApplyDeploymentRequestOutputs>;
    /** @deprecated use `ApplyDeploymentRequestOutputs$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestOutputs$Outbound;
}
export declare function applyDeploymentRequestOutputsToJSON(applyDeploymentRequestOutputs: ApplyDeploymentRequestOutputs): string;
export declare function applyDeploymentRequestOutputsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestOutputs, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestPreviousConfig$inboundSchema: z.ZodType<ApplyDeploymentRequestPreviousConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestPreviousConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentRequestPreviousConfig$outboundSchema: z.ZodType<ApplyDeploymentRequestPreviousConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreviousConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPreviousConfig$ {
    /** @deprecated use `ApplyDeploymentRequestPreviousConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestPreviousConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestPreviousConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestPreviousConfig$Outbound, z.ZodTypeDef, ApplyDeploymentRequestPreviousConfig>;
    /** @deprecated use `ApplyDeploymentRequestPreviousConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestPreviousConfig$Outbound;
}
export declare function applyDeploymentRequestPreviousConfigToJSON(applyDeploymentRequestPreviousConfig: ApplyDeploymentRequestPreviousConfig): string;
export declare function applyDeploymentRequestPreviousConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestPreviousConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateStatus$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStateStatus>;
/** @internal */
export declare const ApplyDeploymentRequestStackStateStatus$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStateStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateStatus$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStateStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestStackStateResources$inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateResources, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestStackStateResources$Outbound = {
    _internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    config: ApplyDeploymentRequestStackStateConfig$Outbound;
    dependencies?: Array<ApplyDeploymentRequestStackStateDependency$Outbound> | undefined;
    error?: any | null | undefined;
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    retryAttempt?: number | undefined;
    status: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentRequestStackStateResources$outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateResources$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStateResources$ {
    /** @deprecated use `ApplyDeploymentRequestStackStateResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestStackStateResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestStackStateResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestStackStateResources$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackStateResources>;
    /** @deprecated use `ApplyDeploymentRequestStackStateResources$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestStackStateResources$Outbound;
}
export declare function applyDeploymentRequestStackStateResourcesToJSON(applyDeploymentRequestStackStateResources: ApplyDeploymentRequestStackStateResources): string;
export declare function applyDeploymentRequestStackStateResourcesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestStackStateResources, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestKubernetesInfrastructurePlatform$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestKubernetesInfrastructurePlatform>;
/** @internal */
export declare const ApplyDeploymentRequestKubernetesInfrastructurePlatform$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestKubernetesInfrastructurePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestKubernetesInfrastructurePlatform$ {
    /** @deprecated use `ApplyDeploymentRequestKubernetesInfrastructurePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentRequestKubernetesInfrastructurePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestPlatformKubernetes$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPlatformKubernetes>;
/** @internal */
export declare const ApplyDeploymentRequestPlatformKubernetes$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestPlatformKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestPlatformKubernetes$ {
    /** @deprecated use `ApplyDeploymentRequestPlatformKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
    /** @deprecated use `ApplyDeploymentRequestPlatformKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestManagementKubernetes$inboundSchema: z.ZodType<ApplyDeploymentRequestManagementKubernetes, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestManagementKubernetes$Outbound = {
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestManagementKubernetes$outboundSchema: z.ZodType<ApplyDeploymentRequestManagementKubernetes$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementKubernetes$ {
    /** @deprecated use `ApplyDeploymentRequestManagementKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestManagementKubernetes, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestManagementKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestManagementKubernetes$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementKubernetes>;
    /** @deprecated use `ApplyDeploymentRequestManagementKubernetes$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestManagementKubernetes$Outbound;
}
export declare function applyDeploymentRequestManagementKubernetesToJSON(applyDeploymentRequestManagementKubernetes: ApplyDeploymentRequestManagementKubernetes): string;
export declare function applyDeploymentRequestManagementKubernetesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestManagementKubernetes, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestImagePullCredentials$inboundSchema: z.ZodType<ApplyDeploymentRequestImagePullCredentials, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestImagePullCredentials$Outbound = {
    password: string;
    username: string;
};
/** @internal */
export declare const ApplyDeploymentRequestImagePullCredentials$outboundSchema: z.ZodType<ApplyDeploymentRequestImagePullCredentials$Outbound, z.ZodTypeDef, ApplyDeploymentRequestImagePullCredentials>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestImagePullCredentials$ {
    /** @deprecated use `ApplyDeploymentRequestImagePullCredentials$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestImagePullCredentials, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestImagePullCredentials$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestImagePullCredentials$Outbound, z.ZodTypeDef, ApplyDeploymentRequestImagePullCredentials>;
    /** @deprecated use `ApplyDeploymentRequestImagePullCredentials$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestImagePullCredentials$Outbound;
}
export declare function applyDeploymentRequestImagePullCredentialsToJSON(applyDeploymentRequestImagePullCredentials: ApplyDeploymentRequestImagePullCredentials): string;
export declare function applyDeploymentRequestImagePullCredentialsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestImagePullCredentials, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformAzure$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformAzure>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformAzure$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStatePlatformAzure$ {
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestManagementAzure$inboundSchema: z.ZodType<ApplyDeploymentRequestManagementAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestManagementAzure$Outbound = {
    imagePullCredentials?: any | null | undefined;
    managementPrincipalId: string;
    managingTenantId: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestManagementAzure$outboundSchema: z.ZodType<ApplyDeploymentRequestManagementAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementAzure$ {
    /** @deprecated use `ApplyDeploymentRequestManagementAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestManagementAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestManagementAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestManagementAzure$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementAzure>;
    /** @deprecated use `ApplyDeploymentRequestManagementAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestManagementAzure$Outbound;
}
export declare function applyDeploymentRequestManagementAzureToJSON(applyDeploymentRequestManagementAzure: ApplyDeploymentRequestManagementAzure): string;
export declare function applyDeploymentRequestManagementAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestManagementAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformGcp$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformGcp>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformGcp$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStatePlatformGcp$ {
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestManagementGcp$inboundSchema: z.ZodType<ApplyDeploymentRequestManagementGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestManagementGcp$Outbound = {
    serviceAccountEmail: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestManagementGcp$outboundSchema: z.ZodType<ApplyDeploymentRequestManagementGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementGcp$ {
    /** @deprecated use `ApplyDeploymentRequestManagementGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestManagementGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestManagementGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestManagementGcp$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementGcp>;
    /** @deprecated use `ApplyDeploymentRequestManagementGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestManagementGcp$Outbound;
}
export declare function applyDeploymentRequestManagementGcpToJSON(applyDeploymentRequestManagementGcp: ApplyDeploymentRequestManagementGcp): string;
export declare function applyDeploymentRequestManagementGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestManagementGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformAws$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformAws>;
/** @internal */
export declare const ApplyDeploymentRequestStackStatePlatformAws$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStackStatePlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackStatePlatformAws$ {
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStackStatePlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const ApplyDeploymentRequestManagementAws$inboundSchema: z.ZodType<ApplyDeploymentRequestManagementAws, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestManagementAws$Outbound = {
    managingRoleArn: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentRequestManagementAws$outboundSchema: z.ZodType<ApplyDeploymentRequestManagementAws$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestManagementAws$ {
    /** @deprecated use `ApplyDeploymentRequestManagementAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestManagementAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestManagementAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestManagementAws$Outbound, z.ZodTypeDef, ApplyDeploymentRequestManagementAws>;
    /** @deprecated use `ApplyDeploymentRequestManagementAws$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestManagementAws$Outbound;
}
export declare function applyDeploymentRequestManagementAwsToJSON(applyDeploymentRequestManagementAws: ApplyDeploymentRequestManagementAws): string;
export declare function applyDeploymentRequestManagementAwsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestManagementAws, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestRemoteCapabilities$inboundSchema: z.ZodType<ApplyDeploymentRequestRemoteCapabilities, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestRemoteCapabilities$Outbound = {
    autoUpdates: boolean;
    heartbeat: boolean;
    monitoring: boolean;
};
/** @internal */
export declare const ApplyDeploymentRequestRemoteCapabilities$outboundSchema: z.ZodType<ApplyDeploymentRequestRemoteCapabilities$Outbound, z.ZodTypeDef, ApplyDeploymentRequestRemoteCapabilities>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestRemoteCapabilities$ {
    /** @deprecated use `ApplyDeploymentRequestRemoteCapabilities$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestRemoteCapabilities, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestRemoteCapabilities$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestRemoteCapabilities$Outbound, z.ZodTypeDef, ApplyDeploymentRequestRemoteCapabilities>;
    /** @deprecated use `ApplyDeploymentRequestRemoteCapabilities$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestRemoteCapabilities$Outbound;
}
export declare function applyDeploymentRequestRemoteCapabilitiesToJSON(applyDeploymentRequestRemoteCapabilities: ApplyDeploymentRequestRemoteCapabilities): string;
export declare function applyDeploymentRequestRemoteCapabilitiesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestRemoteCapabilities, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestSettings$inboundSchema: z.ZodType<ApplyDeploymentRequestSettings, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestSettings$Outbound = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    remoteCapabilities: ApplyDeploymentRequestRemoteCapabilities$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestSettings$outboundSchema: z.ZodType<ApplyDeploymentRequestSettings$Outbound, z.ZodTypeDef, ApplyDeploymentRequestSettings>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestSettings$ {
    /** @deprecated use `ApplyDeploymentRequestSettings$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestSettings, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestSettings$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestSettings$Outbound, z.ZodTypeDef, ApplyDeploymentRequestSettings>;
    /** @deprecated use `ApplyDeploymentRequestSettings$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestSettings$Outbound;
}
export declare function applyDeploymentRequestSettingsToJSON(applyDeploymentRequestSettings: ApplyDeploymentRequestSettings): string;
export declare function applyDeploymentRequestSettingsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestSettings, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStackState$inboundSchema: z.ZodType<ApplyDeploymentRequestStackState, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequestStackState$Outbound = {
    platform: string;
    resourcePrefix: string;
    resources: {
        [k: string]: ApplyDeploymentRequestStackStateResources$Outbound;
    };
    settings: ApplyDeploymentRequestSettings$Outbound;
};
/** @internal */
export declare const ApplyDeploymentRequestStackState$outboundSchema: z.ZodType<ApplyDeploymentRequestStackState$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackState>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStackState$ {
    /** @deprecated use `ApplyDeploymentRequestStackState$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequestStackState, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequestStackState$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequestStackState$Outbound, z.ZodTypeDef, ApplyDeploymentRequestStackState>;
    /** @deprecated use `ApplyDeploymentRequestStackState$Outbound` instead. */
    type Outbound = ApplyDeploymentRequestStackState$Outbound;
}
export declare function applyDeploymentRequestStackStateToJSON(applyDeploymentRequestStackState: ApplyDeploymentRequestStackState): string;
export declare function applyDeploymentRequestStackStateFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequestStackState, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequestStatus$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStatus>;
/** @internal */
export declare const ApplyDeploymentRequestStatus$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentRequestStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequestStatus$ {
    /** @deprecated use `ApplyDeploymentRequestStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
    /** @deprecated use `ApplyDeploymentRequestStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
}
/** @internal */
export declare const Update$inboundSchema: z.ZodType<Update, z.ZodTypeDef, unknown>;
/** @internal */
export type Update$Outbound = {
    clearRetryRequested?: boolean | undefined;
    environmentInfo?: any | null | undefined;
    error?: any | null | undefined;
    promoteTargetToCurrent?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    status?: any | null | undefined;
    suggestedDelayMs?: number | null | undefined;
    updateHeartbeat?: boolean | undefined;
};
/** @internal */
export declare const Update$outboundSchema: z.ZodType<Update$Outbound, z.ZodTypeDef, Update>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace Update$ {
    /** @deprecated use `Update$inboundSchema` instead. */
    const inboundSchema: z.ZodType<Update, z.ZodTypeDef, unknown>;
    /** @deprecated use `Update$outboundSchema` instead. */
    const outboundSchema: z.ZodType<Update$Outbound, z.ZodTypeDef, Update>;
    /** @deprecated use `Update$Outbound` instead. */
    type Outbound = Update$Outbound;
}
export declare function updateToJSON(update: Update): string;
export declare function updateFromJSON(jsonString: string): SafeParseResult<Update, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentRequest$inboundSchema: z.ZodType<ApplyDeploymentRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequest$Outbound = {
    session: string;
    update: Update$Outbound;
    release?: boolean | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequest$outboundSchema: z.ZodType<ApplyDeploymentRequest$Outbound, z.ZodTypeDef, ApplyDeploymentRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequest$ {
    /** @deprecated use `ApplyDeploymentRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequest$Outbound, z.ZodTypeDef, ApplyDeploymentRequest>;
    /** @deprecated use `ApplyDeploymentRequest$Outbound` instead. */
    type Outbound = ApplyDeploymentRequest$Outbound;
}
export declare function applyDeploymentRequestToJSON(applyDeploymentRequest: ApplyDeploymentRequest): string;
export declare function applyDeploymentRequestFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequest, SDKValidationError>;
//# sourceMappingURL=applydeploymentrequest.d.ts.map