import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
import { GitHubProvider, GitHubProvider$Outbound } from "./githubprovider.js";
import { GitLabProvider, GitLabProvider$Outbound } from "./gitlabprovider.js";
/**
 * Provider-specific repository information, resolved server-side from remoteUrl
 */
export type GitProvider = GitHubProvider | GitLabProvider | any;
/** @internal */
export declare const GitProvider$inboundSchema: z.ZodType<GitProvider, unknown>;
/** @internal */
export type GitProvider$Outbound = GitHubProvider$Outbound | GitLabProvider$Outbound | any;
/** @internal */
export declare const GitProvider$outboundSchema: z.ZodType<GitProvider$Outbound, GitProvider>;
export declare function gitProviderToJSON(gitProvider: GitProvider): string;
export declare function gitProviderFromJSON(jsonString: string): SafeParseResult<GitProvider, SDKValidationError>;
//# sourceMappingURL=gitprovider.d.ts.map