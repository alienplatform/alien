import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { Agent } from "./agent.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CreateAgentResponse = {
    agent: Agent;
    /**
     * Agent token (only returned when using deployment group token)
     */
    token?: string | undefined;
};
/** @internal */
export declare const CreateAgentResponse$inboundSchema: z.ZodType<CreateAgentResponse, unknown>;
export declare function createAgentResponseFromJSON(jsonString: string): SafeParseResult<CreateAgentResponse, SDKValidationError>;
//# sourceMappingURL=createagentresponse.d.ts.map