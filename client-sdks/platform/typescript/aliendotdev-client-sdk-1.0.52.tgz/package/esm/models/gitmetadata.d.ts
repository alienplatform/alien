import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
import { GitProvider, GitProvider$Outbound } from "./gitprovider.js";
export type GitMetadata = {
    /**
     * The hash of the commit
     */
    commitSha?: string | null | undefined;
    /**
     * The commit message
     */
    commitMessage?: string | null | undefined;
    /**
     * The branch or tag on which the commit was made
     */
    commitRef?: string | null | undefined;
    /**
     * The date and time when the commit was created
     */
    commitDate?: Date | null | undefined;
    /**
     * Whether or not there have been modifications to the working tree since the latest commit
     */
    dirty?: boolean | null | undefined;
    /**
     * The git repository's remote origin url
     */
    remoteUrl?: string | null | undefined;
    /**
     * The name of the author of the commit (from git config)
     */
    commitAuthorName?: string | null | undefined;
    /**
     * The email of the author of the commit (from git config)
     */
    commitAuthorEmail?: string | null | undefined;
    /**
     * The provider username of the commit author (e.g., GitHub login), resolved server-side from the commit email
     */
    commitAuthorLogin?: string | null | undefined;
    /**
     * The avatar URL of the commit author, resolved server-side from the provider login
     */
    commitAuthorAvatarUrl?: string | null | undefined;
    /**
     * Provider-specific repository information, resolved server-side from remoteUrl
     */
    provider?: GitProvider | null | undefined;
};
/** @internal */
export declare const GitMetadata$inboundSchema: z.ZodType<GitMetadata, unknown>;
/** @internal */
export type GitMetadata$Outbound = {
    commitSha?: string | null | undefined;
    commitMessage?: string | null | undefined;
    commitRef?: string | null | undefined;
    commitDate?: string | null | undefined;
    dirty?: boolean | null | undefined;
    remoteUrl?: string | null | undefined;
    commitAuthorName?: string | null | undefined;
    commitAuthorEmail?: string | null | undefined;
    commitAuthorLogin?: string | null | undefined;
    commitAuthorAvatarUrl?: string | null | undefined;
    provider?: GitProvider$Outbound | null | undefined;
};
/** @internal */
export declare const GitMetadata$outboundSchema: z.ZodType<GitMetadata$Outbound, GitMetadata>;
export declare function gitMetadataToJSON(gitMetadata: GitMetadata): string;
export declare function gitMetadataFromJSON(jsonString: string): SafeParseResult<GitMetadata, SDKValidationError>;
//# sourceMappingURL=gitmetadata.d.ts.map