import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { AgentDeploymentGroupInfo } from "./agentdeploymentgroupinfo.js";
import { AgentProjectInfo } from "./agentprojectinfo.js";
import { AgentReleaseInfo } from "./agentreleaseinfo.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Deployment status in the deployment lifecycle
 */
export declare const AgentListItemResponseStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type AgentListItemResponseStatus = ClosedEnum<typeof AgentListItemResponseStatus>;
/**
 * Target platform for the agent
 */
export declare const AgentListItemResponsePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Target platform for the agent
 */
export type AgentListItemResponsePlatform = ClosedEnum<typeof AgentListItemResponsePlatform>;
export declare const AgentListItemResponsePlatformTest: {
    readonly Test: "test";
};
export type AgentListItemResponsePlatformTest = ClosedEnum<typeof AgentListItemResponsePlatformTest>;
/**
 * Test platform environment information (mock)
 */
export type AgentListItemResponseEnvironmentInfoTest = {
    /**
     * Test identifier for this environment
     */
    testId: string;
    platform: AgentListItemResponsePlatformTest;
};
export declare const AgentListItemResponsePlatformLocal: {
    readonly Local: "local";
};
export type AgentListItemResponsePlatformLocal = ClosedEnum<typeof AgentListItemResponsePlatformLocal>;
/**
 * Local platform environment information
 */
export type AgentListItemResponseEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: AgentListItemResponsePlatformLocal;
};
export declare const AgentListItemResponsePlatformAzure: {
    readonly Azure: "azure";
};
export type AgentListItemResponsePlatformAzure = ClosedEnum<typeof AgentListItemResponsePlatformAzure>;
/**
 * Azure-specific environment information
 */
export type AgentListItemResponseEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: AgentListItemResponsePlatformAzure;
};
export declare const AgentListItemResponsePlatformGcp: {
    readonly Gcp: "gcp";
};
export type AgentListItemResponsePlatformGcp = ClosedEnum<typeof AgentListItemResponsePlatformGcp>;
/**
 * GCP-specific environment information
 */
export type AgentListItemResponseEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: AgentListItemResponsePlatformGcp;
};
export declare const AgentListItemResponsePlatformAws: {
    readonly Aws: "aws";
};
export type AgentListItemResponsePlatformAws = ClosedEnum<typeof AgentListItemResponsePlatformAws>;
/**
 * AWS-specific environment information
 */
export type AgentListItemResponseEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: AgentListItemResponsePlatformAws;
};
/**
 * Cloud environment information
 */
export type AgentListItemResponseEnvironmentInfoUnion = AgentListItemResponseEnvironmentInfoGcp | AgentListItemResponseEnvironmentInfoAzure | AgentListItemResponseEnvironmentInfoLocal | AgentListItemResponseEnvironmentInfoAws | AgentListItemResponseEnvironmentInfoTest | any;
/**
 * Latest error information if in a failed state
 */
export type AgentListItemResponseError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
export type AgentListItemResponse = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    name: string;
    /**
     * Deployment status in the deployment lifecycle
     */
    status: AgentListItemResponseStatus;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Target platform for the agent
     */
    platform: AgentListItemResponsePlatform;
    /**
     * ID of deployment group this agent belongs to
     */
    deploymentGroupId: string;
    /**
     * Cloud environment information
     */
    environmentInfo?: AgentListItemResponseEnvironmentInfoGcp | AgentListItemResponseEnvironmentInfoAzure | AgentListItemResponseEnvironmentInfoLocal | AgentListItemResponseEnvironmentInfoAws | AgentListItemResponseEnvironmentInfoTest | any | null | undefined;
    /**
     * ID of the currently deployed release
     */
    currentReleaseId?: string | null | undefined;
    /**
     * ID of the desired release
     */
    desiredReleaseId?: string | null | undefined;
    /**
     * ID of the pinned release
     */
    pinnedReleaseId?: string | null | undefined;
    /**
     * Timestamp of the last received heartbeat
     */
    lastHeartbeatAt?: Date | null | undefined;
    /**
     * Latest error information if in a failed state
     */
    error?: AgentListItemResponseError | null | undefined;
    /**
     * Whether a retry has been requested
     */
    retryRequested: boolean;
    createdAt: Date;
    updatedAt: Date;
    /**
     * ID of the agent manager
     */
    agentManagerId?: string | null | undefined;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    release?: AgentReleaseInfo | null | undefined;
    deploymentGroup?: AgentDeploymentGroupInfo | undefined;
    project?: AgentProjectInfo | undefined;
};
/** @internal */
export declare const AgentListItemResponseStatus$inboundSchema: z.ZodEnum<typeof AgentListItemResponseStatus>;
/** @internal */
export declare const AgentListItemResponsePlatform$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatform>;
/** @internal */
export declare const AgentListItemResponsePlatformTest$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatformTest>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoTest$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoTest, unknown>;
export declare function agentListItemResponseEnvironmentInfoTestFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoTest, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponsePlatformLocal$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatformLocal>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoLocal$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoLocal, unknown>;
export declare function agentListItemResponseEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponsePlatformAzure$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatformAzure>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoAzure$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoAzure, unknown>;
export declare function agentListItemResponseEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponsePlatformGcp$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatformGcp>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoGcp$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoGcp, unknown>;
export declare function agentListItemResponseEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponsePlatformAws$inboundSchema: z.ZodEnum<typeof AgentListItemResponsePlatformAws>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoAws$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoAws, unknown>;
export declare function agentListItemResponseEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponseEnvironmentInfoUnion$inboundSchema: z.ZodType<AgentListItemResponseEnvironmentInfoUnion, unknown>;
export declare function agentListItemResponseEnvironmentInfoUnionFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseEnvironmentInfoUnion, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponseError$inboundSchema: z.ZodType<AgentListItemResponseError, unknown>;
export declare function agentListItemResponseErrorFromJSON(jsonString: string): SafeParseResult<AgentListItemResponseError, SDKValidationError>;
/** @internal */
export declare const AgentListItemResponse$inboundSchema: z.ZodType<AgentListItemResponse, unknown>;
export declare function agentListItemResponseFromJSON(jsonString: string): SafeParseResult<AgentListItemResponse, SDKValidationError>;
//# sourceMappingURL=agentlistitemresponse.d.ts.map