import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Role for deployment group-scoped service accounts
 */
export declare const DeploymentGroupRole: {
    readonly DeploymentGroupDeployer: "deployment-group.deployer";
};
/**
 * Role for deployment group-scoped service accounts
 */
export type DeploymentGroupRole = ClosedEnum<typeof DeploymentGroupRole>;
/** @internal */
export declare const DeploymentGroupRole$inboundSchema: z.ZodEnum<typeof DeploymentGroupRole>;
/** @internal */
export declare const DeploymentGroupRole$outboundSchema: z.ZodEnum<typeof DeploymentGroupRole>;
//# sourceMappingURL=deploymentgrouprole.d.ts.map