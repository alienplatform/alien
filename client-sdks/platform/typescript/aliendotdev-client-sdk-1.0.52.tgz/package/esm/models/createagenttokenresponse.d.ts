import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CreateAgentTokenResponse = {
    /**
     * The generated agent token (only shown once)
     */
    token: string;
    /**
     * The agent ID that this token is scoped to
     */
    agentId: string;
};
/** @internal */
export declare const CreateAgentTokenResponse$inboundSchema: z.ZodType<CreateAgentTokenResponse, unknown>;
export declare function createAgentTokenResponseFromJSON(jsonString: string): SafeParseResult<CreateAgentTokenResponse, SDKValidationError>;
//# sourceMappingURL=createagenttokenresponse.d.ts.map