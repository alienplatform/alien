import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { EnvironmentVariableType } from "./environmentvariabletype.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type EnvironmentVariableConfig = {
    /**
     * Variable name
     */
    name: string;
    /**
     * Variable value (encrypted in database)
     */
    value: string;
    /**
     * Variable type (plain or secret)
     */
    type: EnvironmentVariableType;
    /**
     * Target resource patterns (null = all resources, array = wildcard patterns)
     */
    targetResources: Array<string> | null;
};
/** @internal */
export declare const EnvironmentVariableConfig$inboundSchema: z.ZodType<EnvironmentVariableConfig, unknown>;
/** @internal */
export type EnvironmentVariableConfig$Outbound = {
    name: string;
    value: string;
    type: string;
    targetResources: Array<string> | null;
};
/** @internal */
export declare const EnvironmentVariableConfig$outboundSchema: z.ZodType<EnvironmentVariableConfig$Outbound, EnvironmentVariableConfig>;
export declare function environmentVariableConfigToJSON(environmentVariableConfig: EnvironmentVariableConfig): string;
export declare function environmentVariableConfigFromJSON(jsonString: string): SafeParseResult<EnvironmentVariableConfig, SDKValidationError>;
//# sourceMappingURL=environmentvariableconfig.d.ts.map