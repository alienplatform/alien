import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Role for agent-scoped service accounts
 */
export declare const AgentRole: {
    readonly AgentViewer: "agent.viewer";
    readonly AgentManager: "agent.manager";
};
/**
 * Role for agent-scoped service accounts
 */
export type AgentRole = ClosedEnum<typeof AgentRole>;
/** @internal */
export declare const AgentRole$inboundSchema: z.ZodEnum<typeof AgentRole>;
/** @internal */
export declare const AgentRole$outboundSchema: z.ZodEnum<typeof AgentRole>;
//# sourceMappingURL=agentrole.d.ts.map