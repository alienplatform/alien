import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CreateDeploymentTokenRequest = {
    /**
     * Optional description for the deployment token
     */
    description: string | null;
    /**
     * Optional expiration date for the deployment token
     */
    expiresAt?: Date | null | undefined;
    /**
     * Optional agent ID to create token for. If not provided, a new agent ID will be generated.
     */
    agentId?: string | undefined;
};
/** @internal */
export declare const CreateDeploymentTokenRequest$inboundSchema: z.ZodType<CreateDeploymentTokenRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateDeploymentTokenRequest$Outbound = {
    description: string | null;
    expiresAt?: string | null | undefined;
    agentId?: string | undefined;
};
/** @internal */
export declare const CreateDeploymentTokenRequest$outboundSchema: z.ZodType<CreateDeploymentTokenRequest$Outbound, z.ZodTypeDef, CreateDeploymentTokenRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CreateDeploymentTokenRequest$ {
    /** @deprecated use `CreateDeploymentTokenRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<CreateDeploymentTokenRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `CreateDeploymentTokenRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<CreateDeploymentTokenRequest$Outbound, z.ZodTypeDef, CreateDeploymentTokenRequest>;
    /** @deprecated use `CreateDeploymentTokenRequest$Outbound` instead. */
    type Outbound = CreateDeploymentTokenRequest$Outbound;
}
export declare function createDeploymentTokenRequestToJSON(createDeploymentTokenRequest: CreateDeploymentTokenRequest): string;
export declare function createDeploymentTokenRequestFromJSON(jsonString: string): SafeParseResult<CreateDeploymentTokenRequest, SDKValidationError>;
//# sourceMappingURL=createdeploymenttokenrequest.d.ts.map