import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Current health status
 */
export declare const AgentManagerStatus: {
    readonly Healthy: "healthy";
    readonly Degraded: "degraded";
    readonly Unhealthy: "unhealthy";
    readonly Unknown: "unknown";
};
/**
 * Current health status
 */
export type AgentManagerStatus = ClosedEnum<typeof AgentManagerStatus>;
/** @internal */
export declare const AgentManagerStatus$inboundSchema: z.ZodEnum<typeof AgentManagerStatus>;
//# sourceMappingURL=agentmanagerstatus.d.ts.map