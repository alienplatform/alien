import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Total counts per severity level
 */
export type LevelCounts = {
    trace: number;
    debug: number;
    info: number;
    warn: number;
    error: number;
    fatal: number;
};
/** @internal */
export declare const LevelCounts$inboundSchema: z.ZodType<LevelCounts, unknown>;
export declare function levelCountsFromJSON(jsonString: string): SafeParseResult<LevelCounts, SDKValidationError>;
//# sourceMappingURL=levelcounts.d.ts.map