import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type GitRepository = {
    name: string;
    private: boolean;
    defaultBranch: string;
    pushedAt?: Date | undefined;
};
/** @internal */
export declare const GitRepository$inboundSchema: z.ZodType<GitRepository, unknown>;
export declare function gitRepositoryFromJSON(jsonString: string): SafeParseResult<GitRepository, SDKValidationError>;
//# sourceMappingURL=gitrepository.d.ts.map