import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const AzureAgentConfigType: {
    readonly Azure: "azure";
};
export type AzureAgentConfigType = ClosedEnum<typeof AzureAgentConfigType>;
/**
 * Configuration for Azure agent.
 */
export type AzureAgentConfig = {
    type: AzureAgentConfigType;
    /**
     * Azure region.
     */
    region: string;
};
/** @internal */
export declare const AzureAgentConfigType$inboundSchema: z.ZodNativeEnum<typeof AzureAgentConfigType>;
/** @internal */
export declare const AzureAgentConfigType$outboundSchema: z.ZodNativeEnum<typeof AzureAgentConfigType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AzureAgentConfigType$ {
    /** @deprecated use `AzureAgentConfigType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `AzureAgentConfigType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const AzureAgentConfig$inboundSchema: z.ZodType<AzureAgentConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type AzureAgentConfig$Outbound = {
    type: string;
    region: string;
};
/** @internal */
export declare const AzureAgentConfig$outboundSchema: z.ZodType<AzureAgentConfig$Outbound, z.ZodTypeDef, AzureAgentConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AzureAgentConfig$ {
    /** @deprecated use `AzureAgentConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AzureAgentConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `AzureAgentConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AzureAgentConfig$Outbound, z.ZodTypeDef, AzureAgentConfig>;
    /** @deprecated use `AzureAgentConfig$Outbound` instead. */
    type Outbound = AzureAgentConfig$Outbound;
}
export declare function azureAgentConfigToJSON(azureAgentConfig: AzureAgentConfig): string;
export declare function azureAgentConfigFromJSON(jsonString: string): SafeParseResult<AzureAgentConfig, SDKValidationError>;
//# sourceMappingURL=azureagentconfig.d.ts.map