import * as z from "zod";
import { Result as SafeParseResult } from "../types/fp.js";
import { EnvironmentVariableType } from "./environmentvariabletype.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type EnvironmentVariable = {
    /**
     * Unique identifier for the environment variable.
     */
    id: string;
    /**
     * Environment variable key/name
     */
    key: string;
    /**
     * Environment variable value (may be masked for secrets)
     */
    value: string;
    /**
     * Variable type (plain or secret)
     */
    type: EnvironmentVariableType;
    /**
     * Function targeting patterns. null = all functions, array = specific patterns like ['api-*', 'worker']
     */
    targetFunctions: Array<string> | null;
    /**
     * Optional comment describing the variable
     */
    comment: string | null;
    /**
     * Agent ID if this is an agent-level override, null for project-level
     */
    agentId: string | null;
    /**
     * Project ID
     */
    projectId: string;
    /**
     * Workspace ID
     */
    workspaceId: string;
    /**
     * Creation timestamp
     */
    createdAt: Date;
};
/** @internal */
export declare const EnvironmentVariable$inboundSchema: z.ZodType<EnvironmentVariable, z.ZodTypeDef, unknown>;
/** @internal */
export type EnvironmentVariable$Outbound = {
    id: string;
    key: string;
    value: string;
    type: string;
    targetFunctions: Array<string> | null;
    comment: string | null;
    agentId: string | null;
    projectId: string;
    workspaceId: string;
    createdAt: string;
};
/** @internal */
export declare const EnvironmentVariable$outboundSchema: z.ZodType<EnvironmentVariable$Outbound, z.ZodTypeDef, EnvironmentVariable>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnvironmentVariable$ {
    /** @deprecated use `EnvironmentVariable$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnvironmentVariable, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnvironmentVariable$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnvironmentVariable$Outbound, z.ZodTypeDef, EnvironmentVariable>;
    /** @deprecated use `EnvironmentVariable$Outbound` instead. */
    type Outbound = EnvironmentVariable$Outbound;
}
export declare function environmentVariableToJSON(environmentVariable: EnvironmentVariable): string;
export declare function environmentVariableFromJSON(jsonString: string): SafeParseResult<EnvironmentVariable, SDKValidationError>;
//# sourceMappingURL=environmentvariable.d.ts.map