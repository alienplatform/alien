import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const CreateAPIKeyResponseType: {
    readonly Workspace: "workspace";
    readonly Project: "project";
    readonly Agent: "agent";
    readonly DeploymentGroup: "deployment-group";
    readonly AgentManager: "agent-manager";
};
export type CreateAPIKeyResponseType = ClosedEnum<typeof CreateAPIKeyResponseType>;
export type KeyInfo = {
    /**
     * Unique identifier for the api key.
     */
    id: string;
    description: string | null;
    keyPrefix: string;
    type: CreateAPIKeyResponseType;
    role: string;
    workspaceId: string;
    projectId: string | null;
    agentId: string | null;
    deploymentGroupId: string | null;
    agentManagerId: string | null;
    enabled: boolean;
    createdAt: Date;
    expiresAt: Date | null;
    lastUsedAt: Date | null;
    revokedAt: Date | null;
};
/**
 * Response containing the new API key and its metadata
 */
export type CreateAPIKeyResponse = {
    /**
     * The generated API key value (only shown once)
     */
    apiKey: string;
    keyInfo: KeyInfo;
};
/** @internal */
export declare const CreateAPIKeyResponseType$inboundSchema: z.ZodEnum<typeof CreateAPIKeyResponseType>;
/** @internal */
export declare const KeyInfo$inboundSchema: z.ZodType<KeyInfo, unknown>;
export declare function keyInfoFromJSON(jsonString: string): SafeParseResult<KeyInfo, SDKValidationError>;
/** @internal */
export declare const CreateAPIKeyResponse$inboundSchema: z.ZodType<CreateAPIKeyResponse, unknown>;
export declare function createAPIKeyResponseFromJSON(jsonString: string): SafeParseResult<CreateAPIKeyResponse, SDKValidationError>;
//# sourceMappingURL=createapikeyresponse.d.ts.map