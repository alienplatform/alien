import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Variable type (plain or secret)
 */
export declare const EnvironmentVariableType: {
    readonly Plain: "plain";
    readonly Secret: "secret";
};
/**
 * Variable type (plain or secret)
 */
export type EnvironmentVariableType = ClosedEnum<typeof EnvironmentVariableType>;
/** @internal */
export declare const EnvironmentVariableType$inboundSchema: z.ZodEnum<typeof EnvironmentVariableType>;
/** @internal */
export declare const EnvironmentVariableType$outboundSchema: z.ZodEnum<typeof EnvironmentVariableType>;
//# sourceMappingURL=environmentvariabletype.d.ts.map