import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const GenerateDeepstoreTokenResponseTokenType: {
    readonly Bearer: "Bearer";
};
export type GenerateDeepstoreTokenResponseTokenType = ClosedEnum<typeof GenerateDeepstoreTokenResponseTokenType>;
export type GenerateDeepstoreTokenResponse = {
    /**
     * JWT token for authenticating with DeepStore
     */
    accessToken: string;
    /**
     * Token lifetime in seconds
     */
    expiresIn: number | null;
    tokenType: GenerateDeepstoreTokenResponseTokenType;
    /**
     * DeepStore database ID for this agent manager
     */
    databaseId: string;
    /**
     * DeepStore control plane URL (for split discovery)
     */
    controlPlaneUrl: string;
    /**
     * Agent manager URL acting as DeepStore auth proxy (for data plane queries)
     */
    authProxyUrl: string;
};
/** @internal */
export declare const GenerateDeepstoreTokenResponseTokenType$inboundSchema: z.ZodEnum<typeof GenerateDeepstoreTokenResponseTokenType>;
/** @internal */
export declare const GenerateDeepstoreTokenResponse$inboundSchema: z.ZodType<GenerateDeepstoreTokenResponse, unknown>;
export declare function generateDeepstoreTokenResponseFromJSON(jsonString: string): SafeParseResult<GenerateDeepstoreTokenResponse, SDKValidationError>;
//# sourceMappingURL=generatedeepstoretokenresponse.d.ts.map