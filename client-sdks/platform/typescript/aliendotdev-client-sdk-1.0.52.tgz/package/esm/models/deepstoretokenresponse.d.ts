import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Token type
 */
export declare const TokenType: {
    readonly Bearer: "Bearer";
};
/**
 * Token type
 */
export type TokenType = ClosedEnum<typeof TokenType>;
export type DeepstoreTokenResponse = {
    /**
     * JWT access token for deepstore
     */
    accessToken: string;
    /**
     * Token expiration time in seconds, or null if token doesn't expire
     */
    expiresIn: number | null;
    /**
     * Token type
     */
    tokenType: TokenType;
};
/** @internal */
export declare const TokenType$inboundSchema: z.ZodNativeEnum<typeof TokenType>;
/** @internal */
export declare const TokenType$outboundSchema: z.ZodNativeEnum<typeof TokenType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace TokenType$ {
    /** @deprecated use `TokenType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Bearer: "Bearer";
    }>;
    /** @deprecated use `TokenType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Bearer: "Bearer";
    }>;
}
/** @internal */
export declare const DeepstoreTokenResponse$inboundSchema: z.ZodType<DeepstoreTokenResponse, z.ZodTypeDef, unknown>;
/** @internal */
export type DeepstoreTokenResponse$Outbound = {
    accessToken: string;
    expiresIn: number | null;
    tokenType: string;
};
/** @internal */
export declare const DeepstoreTokenResponse$outboundSchema: z.ZodType<DeepstoreTokenResponse$Outbound, z.ZodTypeDef, DeepstoreTokenResponse>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeepstoreTokenResponse$ {
    /** @deprecated use `DeepstoreTokenResponse$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeepstoreTokenResponse, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeepstoreTokenResponse$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeepstoreTokenResponse$Outbound, z.ZodTypeDef, DeepstoreTokenResponse>;
    /** @deprecated use `DeepstoreTokenResponse$Outbound` instead. */
    type Outbound = DeepstoreTokenResponse$Outbound;
}
export declare function deepstoreTokenResponseToJSON(deepstoreTokenResponse: DeepstoreTokenResponse): string;
export declare function deepstoreTokenResponseFromJSON(jsonString: string): SafeParseResult<DeepstoreTokenResponse, SDKValidationError>;
//# sourceMappingURL=deepstoretokenresponse.d.ts.map