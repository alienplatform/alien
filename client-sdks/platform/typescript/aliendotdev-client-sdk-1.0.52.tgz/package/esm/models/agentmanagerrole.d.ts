import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Role for agent manager-scoped service accounts
 */
export declare const AgentManagerRole: {
    readonly AgentManagerManager: "agent-manager.manager";
};
/**
 * Role for agent manager-scoped service accounts
 */
export type AgentManagerRole = ClosedEnum<typeof AgentManagerRole>;
/** @internal */
export declare const AgentManagerRole$inboundSchema: z.ZodEnum<typeof AgentManagerRole>;
/** @internal */
export declare const AgentManagerRole$outboundSchema: z.ZodEnum<typeof AgentManagerRole>;
//# sourceMappingURL=agentmanagerrole.d.ts.map