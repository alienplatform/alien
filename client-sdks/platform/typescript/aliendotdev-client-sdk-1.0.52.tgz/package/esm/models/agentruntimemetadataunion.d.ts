import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type AgentRuntimeMetadata3 = {};
/**
 * The current state of the GCP provisioning process.
 */
export declare const ProvisioningState: {
    readonly Pending: "pending";
    readonly ProjectMetadataSaved: "project_metadata_saved";
    readonly FrozenResourcesDeployed: "frozen_resources_deployed";
    readonly Completed: "completed";
};
/**
 * The current state of the GCP provisioning process.
 */
export type ProvisioningState = ClosedEnum<typeof ProvisioningState>;
/**
 * The parent resource of the project (organization or folder).
 */
export type ProjectParent = {
    id?: string | null | undefined;
    type?: string | null | undefined;
};
export type AgentRuntimeMetadata2 = {
    /**
     * The current state of the GCP provisioning process.
     */
    provisioningState?: ProvisioningState | undefined;
    /**
     * The number uniquely identifying the Google Cloud project.
     */
    projectNumber?: string | null | undefined;
    /**
     * The unique, user-assigned ID of the project.
     */
    projectId?: string | null | undefined;
    /**
     * The optional user-assigned display name of the project.
     */
    projectName?: string | null | undefined;
    /**
     * Creation time of the project in RFC 3339 format.
     */
    projectCreateTime?: string | null | undefined;
    /**
     * The labels associated with this project.
     */
    projectLabels?: {
        [k: string]: string;
    } | null | undefined;
    /**
     * The parent resource of the project (organization or folder).
     */
    projectParent?: ProjectParent | null | undefined;
};
export type AgentRuntimeMetadata1 = {};
export type AgentRuntimeMetadataUnion = AgentRuntimeMetadata1 | AgentRuntimeMetadata2 | AgentRuntimeMetadata3 | any;
/** @internal */
export declare const AgentRuntimeMetadata3$inboundSchema: z.ZodType<AgentRuntimeMetadata3, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentRuntimeMetadata3$Outbound = {};
/** @internal */
export declare const AgentRuntimeMetadata3$outboundSchema: z.ZodType<AgentRuntimeMetadata3$Outbound, z.ZodTypeDef, AgentRuntimeMetadata3>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentRuntimeMetadata3$ {
    /** @deprecated use `AgentRuntimeMetadata3$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AgentRuntimeMetadata3, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentRuntimeMetadata3$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AgentRuntimeMetadata3$Outbound, z.ZodTypeDef, AgentRuntimeMetadata3>;
    /** @deprecated use `AgentRuntimeMetadata3$Outbound` instead. */
    type Outbound = AgentRuntimeMetadata3$Outbound;
}
export declare function agentRuntimeMetadata3ToJSON(agentRuntimeMetadata3: AgentRuntimeMetadata3): string;
export declare function agentRuntimeMetadata3FromJSON(jsonString: string): SafeParseResult<AgentRuntimeMetadata3, SDKValidationError>;
/** @internal */
export declare const ProvisioningState$inboundSchema: z.ZodNativeEnum<typeof ProvisioningState>;
/** @internal */
export declare const ProvisioningState$outboundSchema: z.ZodNativeEnum<typeof ProvisioningState>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProvisioningState$ {
    /** @deprecated use `ProvisioningState$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly ProjectMetadataSaved: "project_metadata_saved";
        readonly FrozenResourcesDeployed: "frozen_resources_deployed";
        readonly Completed: "completed";
    }>;
    /** @deprecated use `ProvisioningState$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly ProjectMetadataSaved: "project_metadata_saved";
        readonly FrozenResourcesDeployed: "frozen_resources_deployed";
        readonly Completed: "completed";
    }>;
}
/** @internal */
export declare const ProjectParent$inboundSchema: z.ZodType<ProjectParent, z.ZodTypeDef, unknown>;
/** @internal */
export type ProjectParent$Outbound = {
    id?: string | null | undefined;
    type?: string | null | undefined;
};
/** @internal */
export declare const ProjectParent$outboundSchema: z.ZodType<ProjectParent$Outbound, z.ZodTypeDef, ProjectParent>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ProjectParent$ {
    /** @deprecated use `ProjectParent$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ProjectParent, z.ZodTypeDef, unknown>;
    /** @deprecated use `ProjectParent$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ProjectParent$Outbound, z.ZodTypeDef, ProjectParent>;
    /** @deprecated use `ProjectParent$Outbound` instead. */
    type Outbound = ProjectParent$Outbound;
}
export declare function projectParentToJSON(projectParent: ProjectParent): string;
export declare function projectParentFromJSON(jsonString: string): SafeParseResult<ProjectParent, SDKValidationError>;
/** @internal */
export declare const AgentRuntimeMetadata2$inboundSchema: z.ZodType<AgentRuntimeMetadata2, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentRuntimeMetadata2$Outbound = {
    provisioningState: string;
    projectNumber?: string | null | undefined;
    projectId?: string | null | undefined;
    projectName?: string | null | undefined;
    projectCreateTime?: string | null | undefined;
    projectLabels?: {
        [k: string]: string;
    } | null | undefined;
    projectParent?: ProjectParent$Outbound | null | undefined;
};
/** @internal */
export declare const AgentRuntimeMetadata2$outboundSchema: z.ZodType<AgentRuntimeMetadata2$Outbound, z.ZodTypeDef, AgentRuntimeMetadata2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentRuntimeMetadata2$ {
    /** @deprecated use `AgentRuntimeMetadata2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AgentRuntimeMetadata2, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentRuntimeMetadata2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AgentRuntimeMetadata2$Outbound, z.ZodTypeDef, AgentRuntimeMetadata2>;
    /** @deprecated use `AgentRuntimeMetadata2$Outbound` instead. */
    type Outbound = AgentRuntimeMetadata2$Outbound;
}
export declare function agentRuntimeMetadata2ToJSON(agentRuntimeMetadata2: AgentRuntimeMetadata2): string;
export declare function agentRuntimeMetadata2FromJSON(jsonString: string): SafeParseResult<AgentRuntimeMetadata2, SDKValidationError>;
/** @internal */
export declare const AgentRuntimeMetadata1$inboundSchema: z.ZodType<AgentRuntimeMetadata1, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentRuntimeMetadata1$Outbound = {};
/** @internal */
export declare const AgentRuntimeMetadata1$outboundSchema: z.ZodType<AgentRuntimeMetadata1$Outbound, z.ZodTypeDef, AgentRuntimeMetadata1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentRuntimeMetadata1$ {
    /** @deprecated use `AgentRuntimeMetadata1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AgentRuntimeMetadata1, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentRuntimeMetadata1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AgentRuntimeMetadata1$Outbound, z.ZodTypeDef, AgentRuntimeMetadata1>;
    /** @deprecated use `AgentRuntimeMetadata1$Outbound` instead. */
    type Outbound = AgentRuntimeMetadata1$Outbound;
}
export declare function agentRuntimeMetadata1ToJSON(agentRuntimeMetadata1: AgentRuntimeMetadata1): string;
export declare function agentRuntimeMetadata1FromJSON(jsonString: string): SafeParseResult<AgentRuntimeMetadata1, SDKValidationError>;
/** @internal */
export declare const AgentRuntimeMetadataUnion$inboundSchema: z.ZodType<AgentRuntimeMetadataUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type AgentRuntimeMetadataUnion$Outbound = AgentRuntimeMetadata1$Outbound | AgentRuntimeMetadata2$Outbound | AgentRuntimeMetadata3$Outbound | any;
/** @internal */
export declare const AgentRuntimeMetadataUnion$outboundSchema: z.ZodType<AgentRuntimeMetadataUnion$Outbound, z.ZodTypeDef, AgentRuntimeMetadataUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AgentRuntimeMetadataUnion$ {
    /** @deprecated use `AgentRuntimeMetadataUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<any, z.ZodTypeDef, unknown>;
    /** @deprecated use `AgentRuntimeMetadataUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<any, z.ZodTypeDef, any>;
    /** @deprecated use `AgentRuntimeMetadataUnion$Outbound` instead. */
    type Outbound = AgentRuntimeMetadataUnion$Outbound;
}
export declare function agentRuntimeMetadataUnionToJSON(agentRuntimeMetadataUnion: AgentRuntimeMetadataUnion): string;
export declare function agentRuntimeMetadataUnionFromJSON(jsonString: string): SafeParseResult<AgentRuntimeMetadataUnion, SDKValidationError>;
//# sourceMappingURL=agentruntimemetadataunion.d.ts.map