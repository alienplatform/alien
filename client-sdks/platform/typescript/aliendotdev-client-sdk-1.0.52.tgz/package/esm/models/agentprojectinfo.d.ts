import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type AgentProjectInfo = {
    /**
     * Unique identifier for the project.
     */
    id: string;
    /**
     * Project name.
     */
    name: string;
};
/** @internal */
export declare const AgentProjectInfo$inboundSchema: z.ZodType<AgentProjectInfo, unknown>;
export declare function agentProjectInfoFromJSON(jsonString: string): SafeParseResult<AgentProjectInfo, SDKValidationError>;
//# sourceMappingURL=agentprojectinfo.d.ts.map