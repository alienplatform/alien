import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * How to dispatch the command
 */
export declare const CreateCommandResponseDeploymentModel: {
    readonly Push: "push";
    readonly Pull: "pull";
};
/**
 * How to dispatch the command
 */
export type CreateCommandResponseDeploymentModel = ClosedEnum<typeof CreateCommandResponseDeploymentModel>;
export type CreateCommandResponse = {
    /**
     * Unique identifier for the command.
     */
    id: string;
    /**
     * Project ID (for Agent Manager to use in routing)
     */
    projectId: string;
    /**
     * How to dispatch the command
     */
    deploymentModel: CreateCommandResponseDeploymentModel;
};
/** @internal */
export declare const CreateCommandResponseDeploymentModel$inboundSchema: z.ZodEnum<typeof CreateCommandResponseDeploymentModel>;
/** @internal */
export declare const CreateCommandResponse$inboundSchema: z.ZodType<CreateCommandResponse, unknown>;
export declare function createCommandResponseFromJSON(jsonString: string): SafeParseResult<CreateCommandResponse, SDKValidationError>;
//# sourceMappingURL=createcommandresponse.d.ts.map