import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
import { GCPAgentConfigServiceAccount, GCPAgentConfigServiceAccount$Outbound } from "./gcpagentconfigserviceaccount.js";
import { GCPRegion } from "./gcpregion.js";
export declare const GCPAgentConfigType: {
    readonly Gcp: "gcp";
};
export type GCPAgentConfigType = ClosedEnum<typeof GCPAgentConfigType>;
/**
 * Configuration for Google Cloud agent.
 */
export type GCPAgentConfig = {
    type: GCPAgentConfigType;
    /**
     * Google Cloud Project ID.
     */
    projectId: string;
    serviceAccount: GCPAgentConfigServiceAccount;
    /**
     * Google Cloud region.
     */
    region: GCPRegion;
};
/** @internal */
export declare const GCPAgentConfigType$inboundSchema: z.ZodNativeEnum<typeof GCPAgentConfigType>;
/** @internal */
export declare const GCPAgentConfigType$outboundSchema: z.ZodNativeEnum<typeof GCPAgentConfigType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GCPAgentConfigType$ {
    /** @deprecated use `GCPAgentConfigType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `GCPAgentConfigType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const GCPAgentConfig$inboundSchema: z.ZodType<GCPAgentConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type GCPAgentConfig$Outbound = {
    type: string;
    projectId: string;
    serviceAccount: GCPAgentConfigServiceAccount$Outbound;
    region: string;
};
/** @internal */
export declare const GCPAgentConfig$outboundSchema: z.ZodType<GCPAgentConfig$Outbound, z.ZodTypeDef, GCPAgentConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GCPAgentConfig$ {
    /** @deprecated use `GCPAgentConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<GCPAgentConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `GCPAgentConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<GCPAgentConfig$Outbound, z.ZodTypeDef, GCPAgentConfig>;
    /** @deprecated use `GCPAgentConfig$Outbound` instead. */
    type Outbound = GCPAgentConfig$Outbound;
}
export declare function gcpAgentConfigToJSON(gcpAgentConfig: GCPAgentConfig): string;
export declare function gcpAgentConfigFromJSON(jsonString: string): SafeParseResult<GCPAgentConfig, SDKValidationError>;
//# sourceMappingURL=gcpagentconfig.d.ts.map