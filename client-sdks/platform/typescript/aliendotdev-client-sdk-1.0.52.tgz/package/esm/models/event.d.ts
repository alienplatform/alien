import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type DataEmptyingBuckets = {
    /**
     * Names of the S3 buckets being emptied
     */
    bucketNames: Array<string>;
    type: "EmptyingBuckets";
};
export type DataDeletingCloudFormationStack = {
    /**
     * Name of the CloudFormation stack
     */
    cfnStackName: string;
    /**
     * Current stack status
     */
    currentStatus: string;
    type: "DeletingCloudFormationStack";
};
export type DataImportingStackStateFromCloudFormation = {
    /**
     * Name of the CloudFormation stack
     */
    cfnStackName: string;
    type: "ImportingStackStateFromCloudFormation";
};
export type DataAssumingRole = {
    /**
     * ARN of the role to assume
     */
    roleArn: string;
    type: "AssumingRole";
};
export type DataDeployingCloudFormationStack = {
    /**
     * Name of the CloudFormation stack
     */
    cfnStackName: string;
    /**
     * Current stack status
     */
    currentStatus: string;
    type: "DeployingCloudFormationStack";
};
export type DataEnsuringDockerRepository = {
    /**
     * Name of the docker repository
     */
    repositoryName: string;
    type: "EnsuringDockerRepository";
};
export type DataSettingUpPlatformContext = {
    /**
     * Name of the platform (e.g., "AWS", "GCP")
     */
    platformName: string;
    type: "SettingUpPlatformContext";
};
export type DataCleaningUpEnvironment = {
    /**
     * Name of the stack being cleaned up
     */
    stackName: string;
    /**
     * Name of the deployment strategy being used for cleanup
     */
    strategyName: string;
    type: "CleaningUpEnvironment";
};
export type DataCleaningUpStack = {
    /**
     * Name of the stack being cleaned up
     */
    stackName: string;
    /**
     * Name of the deployment strategy being used for cleanup
     */
    strategyName: string;
    type: "CleaningUpStack";
};
export type DataRunningTestFunction = {
    /**
     * Name of the stack being tested
     */
    stackName: string;
    type: "RunningTestFunction";
};
export type DataDeployingStack = {
    /**
     * Name of the stack being deployed
     */
    stackName: string;
    type: "DeployingStack";
};
export type DataPreparingEnvironment = {
    /**
     * Name of the deployment strategy being used
     */
    strategyName: string;
    type: "PreparingEnvironment";
};
export type DataDebuggingAgent = {
    /**
     * ID of the agent being debugged
     */
    agentId: string;
    /**
     * ID of the debug session
     */
    debugSessionId: string;
    type: "DebuggingAgent";
};
export type DataDeletingAgent = {
    /**
     * ID of the agent being deleted
     */
    agentId: string;
    /**
     * ID of the release that was running on the agent
     */
    releaseId: string;
    type: "DeletingAgent";
};
export type DataUpdatingAgent = {
    /**
     * ID of the agent being updated
     */
    agentId: string;
    /**
     * ID of the new release being deployed to the agent
     */
    releaseId: string;
    type: "UpdatingAgent";
};
export type DataProvisioningAgent = {
    /**
     * ID of the agent being provisioned
     */
    agentId: string;
    /**
     * ID of the release being deployed to the agent
     */
    releaseId: string;
    type: "ProvisioningAgent";
};
export type DataGeneratingTemplate = {
    /**
     * Platform for which the template is being generated
     */
    platform: string;
    type: "GeneratingTemplate";
};
export type DataGeneratingCloudFormationTemplate = {
    type: "GeneratingCloudFormationTemplate";
};
/**
 * Represents the target cloud platform.
 */
export declare const EventPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type EventPlatform = ClosedEnum<typeof EventPlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type EventConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type EventDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type DataError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const EventLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type EventLifecycle = ClosedEnum<typeof EventLifecycle>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type EventOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type EventPreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const EventStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type EventStatus = ClosedEnum<typeof EventStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type EventResources = {
    internal?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: EventConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<EventDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    remoteBindingParams?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: EventStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * Represents the collective state of all resources in a stack, including platform and pending actions.
 */
export type NextState = {
    /**
     * Represents the target cloud platform.
     */
    platform: EventPlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: EventResources;
    };
};
export type DataStackStep = {
    /**
     * Represents the collective state of all resources in a stack, including platform and pending actions.
     */
    nextState: NextState;
    /**
     * An suggested duration to wait before executing the next step.
     */
    suggestedDelayMs?: number | null | undefined;
    type: "StackStep";
};
export type DataCompilingCode = {
    /**
     * Language being compiled (rust, typescript, etc.)
     */
    language: string;
    /**
     * Current progress/status line from the build output
     */
    progress?: string | null | undefined;
    type: "CompilingCode";
};
export type DataCreatingRelease = {
    /**
     * Project name
     */
    project: string;
    type: "CreatingRelease";
};
export type DataPushingResource = {
    /**
     * Name of the resource being pushed
     */
    resourceName: string;
    /**
     * Type of the resource: "function", "container", "worker"
     */
    resourceType: string;
    type: "PushingResource";
};
export type DataPushingStack = {
    /**
     * Target platform
     */
    platform: string;
    /**
     * Name of the stack being pushed
     */
    stack: string;
    type: "PushingStack";
};
/**
 * Progress information for image push operations
 */
export type Progress = {
    /**
     * Bytes uploaded so far
     */
    bytesUploaded: number;
    /**
     * Number of layers uploaded so far
     */
    layersUploaded: number;
    /**
     * Current operation being performed
     */
    operation: string;
    /**
     * Total bytes to upload
     */
    totalBytes: number;
    /**
     * Total number of layers to upload
     */
    totalLayers: number;
};
export type DataPushingImage = {
    /**
     * Name of the image being pushed
     */
    image: string;
    progress?: any | null | undefined;
    type: "PushingImage";
};
export type DataBuildingImage = {
    /**
     * Name of the image being built
     */
    image: string;
    type: "BuildingImage";
};
export type DataBuildingResource = {
    /**
     * All resource names sharing this build (for deduped container groups)
     */
    relatedResources?: Array<string> | undefined;
    /**
     * Name of the resource being built
     */
    resourceName: string;
    /**
     * Type of the resource: "function", "container", "worker"
     */
    resourceType: string;
    type: "BuildingResource";
};
export type DataDownloadingAlienRuntime = {
    /**
     * Target triple for the runtime
     */
    targetTriple: string;
    type: "DownloadingAlienRuntime";
    /**
     * URL being downloaded from
     */
    url: string;
};
export type DataRunningPreflights = {
    /**
     * Platform being targeted
     */
    platform: string;
    /**
     * Name of the stack being checked
     */
    stack: string;
    type: "RunningPreflights";
};
export type DataBuildingStack = {
    /**
     * Name of the stack being built
     */
    stack: string;
    type: "BuildingStack";
};
export type DataFinished = {
    type: "Finished";
};
export type DataLoadingConfiguration = {
    type: "LoadingConfiguration";
};
/**
 * Represents all possible events in the Alien system
 */
export type Data = DataLoadingConfiguration | DataFinished | DataBuildingStack | DataRunningPreflights | DataDownloadingAlienRuntime | DataBuildingResource | DataBuildingImage | DataPushingImage | DataPushingStack | DataPushingResource | DataCreatingRelease | DataCompilingCode | DataStackStep | DataGeneratingCloudFormationTemplate | DataGeneratingTemplate | DataProvisioningAgent | DataUpdatingAgent | DataDeletingAgent | DataDebuggingAgent | DataPreparingEnvironment | DataDeployingStack | DataRunningTestFunction | DataCleaningUpStack | DataCleaningUpEnvironment | DataSettingUpPlatformContext | DataEnsuringDockerRepository | DataDeployingCloudFormationStack | DataAssumingRole | DataImportingStackStateFromCloudFormation | DataDeletingCloudFormationStack | DataEmptyingBuckets;
export declare const StateSuccess: {
    readonly Success: "success";
};
export type StateSuccess = ClosedEnum<typeof StateSuccess>;
export declare const StateStarted: {
    readonly Started: "started";
};
export type StateStarted = ClosedEnum<typeof StateStarted>;
export declare const StateNone: {
    readonly None: "none";
};
export type StateNone = ClosedEnum<typeof StateNone>;
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type ErrorFailed = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Event failed with an error
 */
export type Failed = {
    error?: any | null | undefined;
};
export type EventState = {
    /**
     * Event failed with an error
     */
    failed: Failed;
};
/**
 * Represents the state of an event
 */
export type State = EventState | StateNone | StateStarted | StateSuccess;
export type Event = {
    /**
     * Unique identifier for the event.
     */
    id: string;
    /**
     * Unique identifier for the agent.
     */
    agentId?: string | null | undefined;
    /**
     * Unique identifier for the release.
     */
    releaseId?: string | null | undefined;
    /**
     * Unique identifier for the debug session.
     */
    debugSessionId?: string | null | undefined;
    /**
     * Represents all possible events in the Alien system
     */
    data: DataLoadingConfiguration | DataFinished | DataBuildingStack | DataRunningPreflights | DataDownloadingAlienRuntime | DataBuildingResource | DataBuildingImage | DataPushingImage | DataPushingStack | DataPushingResource | DataCreatingRelease | DataCompilingCode | DataStackStep | DataGeneratingCloudFormationTemplate | DataGeneratingTemplate | DataProvisioningAgent | DataUpdatingAgent | DataDeletingAgent | DataDebuggingAgent | DataPreparingEnvironment | DataDeployingStack | DataRunningTestFunction | DataCleaningUpStack | DataCleaningUpEnvironment | DataSettingUpPlatformContext | DataEnsuringDockerRepository | DataDeployingCloudFormationStack | DataAssumingRole | DataImportingStackStateFromCloudFormation | DataDeletingCloudFormationStack | DataEmptyingBuckets;
    /**
     * Represents the state of an event
     */
    state: EventState | StateNone | StateStarted | StateSuccess;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    createdAt: Date;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
};
/** @internal */
export declare const DataEmptyingBuckets$inboundSchema: z.ZodType<DataEmptyingBuckets, unknown>;
export declare function dataEmptyingBucketsFromJSON(jsonString: string): SafeParseResult<DataEmptyingBuckets, SDKValidationError>;
/** @internal */
export declare const DataDeletingCloudFormationStack$inboundSchema: z.ZodType<DataDeletingCloudFormationStack, unknown>;
export declare function dataDeletingCloudFormationStackFromJSON(jsonString: string): SafeParseResult<DataDeletingCloudFormationStack, SDKValidationError>;
/** @internal */
export declare const DataImportingStackStateFromCloudFormation$inboundSchema: z.ZodType<DataImportingStackStateFromCloudFormation, unknown>;
export declare function dataImportingStackStateFromCloudFormationFromJSON(jsonString: string): SafeParseResult<DataImportingStackStateFromCloudFormation, SDKValidationError>;
/** @internal */
export declare const DataAssumingRole$inboundSchema: z.ZodType<DataAssumingRole, unknown>;
export declare function dataAssumingRoleFromJSON(jsonString: string): SafeParseResult<DataAssumingRole, SDKValidationError>;
/** @internal */
export declare const DataDeployingCloudFormationStack$inboundSchema: z.ZodType<DataDeployingCloudFormationStack, unknown>;
export declare function dataDeployingCloudFormationStackFromJSON(jsonString: string): SafeParseResult<DataDeployingCloudFormationStack, SDKValidationError>;
/** @internal */
export declare const DataEnsuringDockerRepository$inboundSchema: z.ZodType<DataEnsuringDockerRepository, unknown>;
export declare function dataEnsuringDockerRepositoryFromJSON(jsonString: string): SafeParseResult<DataEnsuringDockerRepository, SDKValidationError>;
/** @internal */
export declare const DataSettingUpPlatformContext$inboundSchema: z.ZodType<DataSettingUpPlatformContext, unknown>;
export declare function dataSettingUpPlatformContextFromJSON(jsonString: string): SafeParseResult<DataSettingUpPlatformContext, SDKValidationError>;
/** @internal */
export declare const DataCleaningUpEnvironment$inboundSchema: z.ZodType<DataCleaningUpEnvironment, unknown>;
export declare function dataCleaningUpEnvironmentFromJSON(jsonString: string): SafeParseResult<DataCleaningUpEnvironment, SDKValidationError>;
/** @internal */
export declare const DataCleaningUpStack$inboundSchema: z.ZodType<DataCleaningUpStack, unknown>;
export declare function dataCleaningUpStackFromJSON(jsonString: string): SafeParseResult<DataCleaningUpStack, SDKValidationError>;
/** @internal */
export declare const DataRunningTestFunction$inboundSchema: z.ZodType<DataRunningTestFunction, unknown>;
export declare function dataRunningTestFunctionFromJSON(jsonString: string): SafeParseResult<DataRunningTestFunction, SDKValidationError>;
/** @internal */
export declare const DataDeployingStack$inboundSchema: z.ZodType<DataDeployingStack, unknown>;
export declare function dataDeployingStackFromJSON(jsonString: string): SafeParseResult<DataDeployingStack, SDKValidationError>;
/** @internal */
export declare const DataPreparingEnvironment$inboundSchema: z.ZodType<DataPreparingEnvironment, unknown>;
export declare function dataPreparingEnvironmentFromJSON(jsonString: string): SafeParseResult<DataPreparingEnvironment, SDKValidationError>;
/** @internal */
export declare const DataDebuggingAgent$inboundSchema: z.ZodType<DataDebuggingAgent, unknown>;
export declare function dataDebuggingAgentFromJSON(jsonString: string): SafeParseResult<DataDebuggingAgent, SDKValidationError>;
/** @internal */
export declare const DataDeletingAgent$inboundSchema: z.ZodType<DataDeletingAgent, unknown>;
export declare function dataDeletingAgentFromJSON(jsonString: string): SafeParseResult<DataDeletingAgent, SDKValidationError>;
/** @internal */
export declare const DataUpdatingAgent$inboundSchema: z.ZodType<DataUpdatingAgent, unknown>;
export declare function dataUpdatingAgentFromJSON(jsonString: string): SafeParseResult<DataUpdatingAgent, SDKValidationError>;
/** @internal */
export declare const DataProvisioningAgent$inboundSchema: z.ZodType<DataProvisioningAgent, unknown>;
export declare function dataProvisioningAgentFromJSON(jsonString: string): SafeParseResult<DataProvisioningAgent, SDKValidationError>;
/** @internal */
export declare const DataGeneratingTemplate$inboundSchema: z.ZodType<DataGeneratingTemplate, unknown>;
export declare function dataGeneratingTemplateFromJSON(jsonString: string): SafeParseResult<DataGeneratingTemplate, SDKValidationError>;
/** @internal */
export declare const DataGeneratingCloudFormationTemplate$inboundSchema: z.ZodType<DataGeneratingCloudFormationTemplate, unknown>;
export declare function dataGeneratingCloudFormationTemplateFromJSON(jsonString: string): SafeParseResult<DataGeneratingCloudFormationTemplate, SDKValidationError>;
/** @internal */
export declare const EventPlatform$inboundSchema: z.ZodEnum<typeof EventPlatform>;
/** @internal */
export declare const EventConfig$inboundSchema: z.ZodType<EventConfig, unknown>;
export declare function eventConfigFromJSON(jsonString: string): SafeParseResult<EventConfig, SDKValidationError>;
/** @internal */
export declare const EventDependency$inboundSchema: z.ZodType<EventDependency, unknown>;
export declare function eventDependencyFromJSON(jsonString: string): SafeParseResult<EventDependency, SDKValidationError>;
/** @internal */
export declare const DataError$inboundSchema: z.ZodType<DataError, unknown>;
export declare function dataErrorFromJSON(jsonString: string): SafeParseResult<DataError, SDKValidationError>;
/** @internal */
export declare const EventLifecycle$inboundSchema: z.ZodEnum<typeof EventLifecycle>;
/** @internal */
export declare const EventOutputs$inboundSchema: z.ZodType<EventOutputs, unknown>;
export declare function eventOutputsFromJSON(jsonString: string): SafeParseResult<EventOutputs, SDKValidationError>;
/** @internal */
export declare const EventPreviousConfig$inboundSchema: z.ZodType<EventPreviousConfig, unknown>;
export declare function eventPreviousConfigFromJSON(jsonString: string): SafeParseResult<EventPreviousConfig, SDKValidationError>;
/** @internal */
export declare const EventStatus$inboundSchema: z.ZodEnum<typeof EventStatus>;
/** @internal */
export declare const EventResources$inboundSchema: z.ZodType<EventResources, unknown>;
export declare function eventResourcesFromJSON(jsonString: string): SafeParseResult<EventResources, SDKValidationError>;
/** @internal */
export declare const NextState$inboundSchema: z.ZodType<NextState, unknown>;
export declare function nextStateFromJSON(jsonString: string): SafeParseResult<NextState, SDKValidationError>;
/** @internal */
export declare const DataStackStep$inboundSchema: z.ZodType<DataStackStep, unknown>;
export declare function dataStackStepFromJSON(jsonString: string): SafeParseResult<DataStackStep, SDKValidationError>;
/** @internal */
export declare const DataCompilingCode$inboundSchema: z.ZodType<DataCompilingCode, unknown>;
export declare function dataCompilingCodeFromJSON(jsonString: string): SafeParseResult<DataCompilingCode, SDKValidationError>;
/** @internal */
export declare const DataCreatingRelease$inboundSchema: z.ZodType<DataCreatingRelease, unknown>;
export declare function dataCreatingReleaseFromJSON(jsonString: string): SafeParseResult<DataCreatingRelease, SDKValidationError>;
/** @internal */
export declare const DataPushingResource$inboundSchema: z.ZodType<DataPushingResource, unknown>;
export declare function dataPushingResourceFromJSON(jsonString: string): SafeParseResult<DataPushingResource, SDKValidationError>;
/** @internal */
export declare const DataPushingStack$inboundSchema: z.ZodType<DataPushingStack, unknown>;
export declare function dataPushingStackFromJSON(jsonString: string): SafeParseResult<DataPushingStack, SDKValidationError>;
/** @internal */
export declare const Progress$inboundSchema: z.ZodType<Progress, unknown>;
export declare function progressFromJSON(jsonString: string): SafeParseResult<Progress, SDKValidationError>;
/** @internal */
export declare const DataPushingImage$inboundSchema: z.ZodType<DataPushingImage, unknown>;
export declare function dataPushingImageFromJSON(jsonString: string): SafeParseResult<DataPushingImage, SDKValidationError>;
/** @internal */
export declare const DataBuildingImage$inboundSchema: z.ZodType<DataBuildingImage, unknown>;
export declare function dataBuildingImageFromJSON(jsonString: string): SafeParseResult<DataBuildingImage, SDKValidationError>;
/** @internal */
export declare const DataBuildingResource$inboundSchema: z.ZodType<DataBuildingResource, unknown>;
export declare function dataBuildingResourceFromJSON(jsonString: string): SafeParseResult<DataBuildingResource, SDKValidationError>;
/** @internal */
export declare const DataDownloadingAlienRuntime$inboundSchema: z.ZodType<DataDownloadingAlienRuntime, unknown>;
export declare function dataDownloadingAlienRuntimeFromJSON(jsonString: string): SafeParseResult<DataDownloadingAlienRuntime, SDKValidationError>;
/** @internal */
export declare const DataRunningPreflights$inboundSchema: z.ZodType<DataRunningPreflights, unknown>;
export declare function dataRunningPreflightsFromJSON(jsonString: string): SafeParseResult<DataRunningPreflights, SDKValidationError>;
/** @internal */
export declare const DataBuildingStack$inboundSchema: z.ZodType<DataBuildingStack, unknown>;
export declare function dataBuildingStackFromJSON(jsonString: string): SafeParseResult<DataBuildingStack, SDKValidationError>;
/** @internal */
export declare const DataFinished$inboundSchema: z.ZodType<DataFinished, unknown>;
export declare function dataFinishedFromJSON(jsonString: string): SafeParseResult<DataFinished, SDKValidationError>;
/** @internal */
export declare const DataLoadingConfiguration$inboundSchema: z.ZodType<DataLoadingConfiguration, unknown>;
export declare function dataLoadingConfigurationFromJSON(jsonString: string): SafeParseResult<DataLoadingConfiguration, SDKValidationError>;
/** @internal */
export declare const Data$inboundSchema: z.ZodType<Data, unknown>;
export declare function dataFromJSON(jsonString: string): SafeParseResult<Data, SDKValidationError>;
/** @internal */
export declare const StateSuccess$inboundSchema: z.ZodEnum<typeof StateSuccess>;
/** @internal */
export declare const StateStarted$inboundSchema: z.ZodEnum<typeof StateStarted>;
/** @internal */
export declare const StateNone$inboundSchema: z.ZodEnum<typeof StateNone>;
/** @internal */
export declare const ErrorFailed$inboundSchema: z.ZodType<ErrorFailed, unknown>;
export declare function errorFailedFromJSON(jsonString: string): SafeParseResult<ErrorFailed, SDKValidationError>;
/** @internal */
export declare const Failed$inboundSchema: z.ZodType<Failed, unknown>;
export declare function failedFromJSON(jsonString: string): SafeParseResult<Failed, SDKValidationError>;
/** @internal */
export declare const EventState$inboundSchema: z.ZodType<EventState, unknown>;
export declare function eventStateFromJSON(jsonString: string): SafeParseResult<EventState, SDKValidationError>;
/** @internal */
export declare const State$inboundSchema: z.ZodType<State, unknown>;
export declare function stateFromJSON(jsonString: string): SafeParseResult<State, SDKValidationError>;
/** @internal */
export declare const Event$inboundSchema: z.ZodType<Event, unknown>;
export declare function eventFromJSON(jsonString: string): SafeParseResult<Event, SDKValidationError>;
//# sourceMappingURL=event.d.ts.map