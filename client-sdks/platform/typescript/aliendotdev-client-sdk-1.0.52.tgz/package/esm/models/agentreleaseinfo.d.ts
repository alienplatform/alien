import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
import { GitMetadata } from "./gitmetadata.js";
export type AgentReleaseInfo = {
    /**
     * Unique identifier for the release.
     */
    id: string;
    gitMetadata?: GitMetadata | null | undefined;
    createdAt: Date;
};
/** @internal */
export declare const AgentReleaseInfo$inboundSchema: z.ZodType<AgentReleaseInfo, unknown>;
export declare function agentReleaseInfoFromJSON(jsonString: string): SafeParseResult<AgentReleaseInfo, SDKValidationError>;
//# sourceMappingURL=agentreleaseinfo.d.ts.map