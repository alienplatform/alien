import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CommandProjectInfo = {
    /**
     * Unique identifier for the project.
     */
    id: string;
    name: string;
};
/** @internal */
export declare const CommandProjectInfo$inboundSchema: z.ZodType<CommandProjectInfo, unknown>;
export declare function commandProjectInfoFromJSON(jsonString: string): SafeParseResult<CommandProjectInfo, SDKValidationError>;
//# sourceMappingURL=commandprojectinfo.d.ts.map