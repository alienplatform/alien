import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { AgentDeploymentGroupInfo } from "./agentdeploymentgroupinfo.js";
import { AgentProjectInfo } from "./agentprojectinfo.js";
import { AgentReleaseInfo } from "./agentreleaseinfo.js";
import { EnvironmentVariableConfig } from "./environmentvariableconfig.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Deployment status in the deployment lifecycle
 */
export declare const AgentDetailResponseStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type AgentDetailResponseStatus = ClosedEnum<typeof AgentDetailResponseStatus>;
/**
 * Target platform for the agent
 */
export declare const AgentDetailResponsePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Target platform for the agent
 */
export type AgentDetailResponsePlatform = ClosedEnum<typeof AgentDetailResponsePlatform>;
export declare const AgentDetailResponsePlatformTest: {
    readonly Test: "test";
};
export type AgentDetailResponsePlatformTest = ClosedEnum<typeof AgentDetailResponsePlatformTest>;
/**
 * Test platform environment information (mock)
 */
export type AgentDetailResponseEnvironmentInfoTest = {
    /**
     * Test identifier for this environment
     */
    testId: string;
    platform: AgentDetailResponsePlatformTest;
};
export declare const AgentDetailResponsePlatformLocal: {
    readonly Local: "local";
};
export type AgentDetailResponsePlatformLocal = ClosedEnum<typeof AgentDetailResponsePlatformLocal>;
/**
 * Local platform environment information
 */
export type AgentDetailResponseEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: AgentDetailResponsePlatformLocal;
};
export declare const AgentDetailResponsePlatformAzure: {
    readonly Azure: "azure";
};
export type AgentDetailResponsePlatformAzure = ClosedEnum<typeof AgentDetailResponsePlatformAzure>;
/**
 * Azure-specific environment information
 */
export type AgentDetailResponseEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: AgentDetailResponsePlatformAzure;
};
export declare const AgentDetailResponsePlatformGcp: {
    readonly Gcp: "gcp";
};
export type AgentDetailResponsePlatformGcp = ClosedEnum<typeof AgentDetailResponsePlatformGcp>;
/**
 * GCP-specific environment information
 */
export type AgentDetailResponseEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: AgentDetailResponsePlatformGcp;
};
export declare const AgentDetailResponsePlatformAws: {
    readonly Aws: "aws";
};
export type AgentDetailResponsePlatformAws = ClosedEnum<typeof AgentDetailResponsePlatformAws>;
/**
 * AWS-specific environment information
 */
export type AgentDetailResponseEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: AgentDetailResponsePlatformAws;
};
/**
 * Cloud environment information
 */
export type AgentDetailResponseEnvironmentInfoUnion = AgentDetailResponseEnvironmentInfoGcp | AgentDetailResponseEnvironmentInfoAzure | AgentDetailResponseEnvironmentInfoLocal | AgentDetailResponseEnvironmentInfoAws | AgentDetailResponseEnvironmentInfoTest | any;
/**
 * Deployment model: how updates are delivered to the remote environment.
 */
export declare const AgentDetailResponseDeploymentModel: {
    readonly Push: "push";
    readonly Pull: "pull";
};
/**
 * Deployment model: how updates are delivered to the remote environment.
 */
export type AgentDetailResponseDeploymentModel = ClosedEnum<typeof AgentDetailResponseDeploymentModel>;
export type AgentDetailResponseAws = {
    certificateArn: string;
};
export type AgentDetailResponseDomainsAzure = {
    keyVaultCertificateId: string;
};
export type AgentDetailResponseDomainsGcp = {
    certificateName: string;
};
/**
 * Platform-specific certificate references for custom domains.
 */
export type AgentDetailResponseCertificate = {
    aws?: any | null | undefined;
    azure?: any | null | undefined;
    gcp?: any | null | undefined;
};
/**
 * Custom domain configuration for a single resource.
 */
export type AgentDetailResponseCustomDomains = {
    /**
     * Platform-specific certificate references for custom domains.
     */
    certificate: AgentDetailResponseCertificate;
    /**
     * Fully qualified domain name to use.
     */
    domain: string;
};
/**
 * Domain configuration for the stack.
 *
 * @remarks
 *
 * When `custom_domains` is set, the specified resources use customer-provided
 * domains and certificates. Otherwise, Alien auto-generates domains.
 */
export type AgentDetailResponseDomains = {
    /**
     * Custom domain configuration per resource ID.
     */
    customDomains?: {
        [k: string]: AgentDetailResponseCustomDomains;
    } | null | undefined;
};
/**
 * How heartbeat health checks are handled.
 */
export declare const AgentDetailResponseHeartbeats: {
    readonly Off: "off";
    readonly On: "on";
};
/**
 * How heartbeat health checks are handled.
 */
export type AgentDetailResponseHeartbeats = ClosedEnum<typeof AgentDetailResponseHeartbeats>;
export declare const AgentDetailResponseTypeByoVnetAzure: {
    readonly ByoVnetAzure: "byo-vnet-azure";
};
export type AgentDetailResponseTypeByoVnetAzure = ClosedEnum<typeof AgentDetailResponseTypeByoVnetAzure>;
export type AgentDetailResponseNetworkByoVnetAzure = {
    /**
     * Name of the private subnet within the VNet
     */
    privateSubnetName: string;
    /**
     * Name of the public subnet within the VNet
     */
    publicSubnetName: string;
    type: AgentDetailResponseTypeByoVnetAzure;
    /**
     * The full resource ID of the existing VNet
     */
    vnetResourceId: string;
};
export declare const AgentDetailResponseTypeByoVpcGcp: {
    readonly ByoVpcGcp: "byo-vpc-gcp";
};
export type AgentDetailResponseTypeByoVpcGcp = ClosedEnum<typeof AgentDetailResponseTypeByoVpcGcp>;
export type AgentDetailResponseNetworkByoVpcGcp = {
    /**
     * The name of the existing VPC network
     */
    networkName: string;
    /**
     * The region of the subnet
     */
    region: string;
    /**
     * The name of the subnet to use
     */
    subnetName: string;
    type: AgentDetailResponseTypeByoVpcGcp;
};
export declare const AgentDetailResponseTypeByoVpcAws: {
    readonly ByoVpcAws: "byo-vpc-aws";
};
export type AgentDetailResponseTypeByoVpcAws = ClosedEnum<typeof AgentDetailResponseTypeByoVpcAws>;
export type AgentDetailResponseNetworkByoVpcAws = {
    /**
     * IDs of private subnets
     */
    privateSubnetIds: Array<string>;
    /**
     * IDs of public subnets (required for public ingress)
     */
    publicSubnetIds: Array<string>;
    /**
     * Optional security group IDs to use
     */
    securityGroupIds?: Array<string> | undefined;
    type: AgentDetailResponseTypeByoVpcAws;
    /**
     * The ID of the existing VPC
     */
    vpcId: string;
};
export declare const AgentDetailResponseTypeCreate: {
    readonly Create: "create";
};
export type AgentDetailResponseTypeCreate = ClosedEnum<typeof AgentDetailResponseTypeCreate>;
export type AgentDetailResponseNetworkCreate = {
    /**
     * Number of availability zones (default: 2).
     */
    availabilityZones?: number | undefined;
    /**
     * VPC/VNet CIDR block. If not specified, auto-generated from stack ID
     *
     * @remarks
     * to reduce conflicts (e.g., "10.{hash}.0.0/16").
     */
    cidr?: string | null | undefined;
    type: AgentDetailResponseTypeCreate;
};
export declare const AgentDetailResponseTypeUseDefault: {
    readonly UseDefault: "use-default";
};
export type AgentDetailResponseTypeUseDefault = ClosedEnum<typeof AgentDetailResponseTypeUseDefault>;
export type AgentDetailResponseNetworkUseDefault = {
    type: AgentDetailResponseTypeUseDefault;
};
/**
 * How telemetry (logs, metrics, traces) is handled.
 */
export declare const AgentDetailResponseTelemetry: {
    readonly Off: "off";
    readonly Auto: "auto";
    readonly ApprovalRequired: "approval-required";
};
/**
 * How telemetry (logs, metrics, traces) is handled.
 */
export type AgentDetailResponseTelemetry = ClosedEnum<typeof AgentDetailResponseTelemetry>;
/**
 * How updates are delivered to the agent.
 */
export declare const AgentDetailResponseUpdates: {
    readonly Auto: "auto";
    readonly ApprovalRequired: "approval-required";
};
/**
 * How updates are delivered to the agent.
 */
export type AgentDetailResponseUpdates = ClosedEnum<typeof AgentDetailResponseUpdates>;
/**
 * User-provided configuration (network, deployment model, approvals)
 */
export type AgentDetailResponseStackSettings = {
    /**
     * Deployment model: how updates are delivered to the remote environment.
     */
    deploymentModel?: AgentDetailResponseDeploymentModel | undefined;
    domains?: any | null | undefined;
    /**
     * How heartbeat health checks are handled.
     */
    heartbeats?: AgentDetailResponseHeartbeats | undefined;
    network?: any | null | undefined;
    /**
     * How telemetry (logs, metrics, traces) is handled.
     */
    telemetry?: AgentDetailResponseTelemetry | undefined;
    /**
     * How updates are delivered to the agent.
     */
    updates?: AgentDetailResponseUpdates | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const AgentDetailResponseStackStatePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type AgentDetailResponseStackStatePlatform = ClosedEnum<typeof AgentDetailResponseStackStatePlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentDetailResponseStackStateConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type AgentDetailResponseStackStateDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type AgentDetailResponseErrorStackState = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const AgentDetailResponseLifecycleStackState: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type AgentDetailResponseLifecycleStackState = ClosedEnum<typeof AgentDetailResponseLifecycleStackState>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type AgentDetailResponseOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentDetailResponsePreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const AgentDetailResponseStackStateStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type AgentDetailResponseStackStateStatus = ClosedEnum<typeof AgentDetailResponseStackStateStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type AgentDetailResponseStackStateResources = {
    internal?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: AgentDetailResponseStackStateConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<AgentDetailResponseStackStateDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    remoteBindingParams?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: AgentDetailResponseStackStateStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * State of infrastructure components managed by this agent
 */
export type AgentDetailResponseStackState = {
    /**
     * Represents the target cloud platform.
     */
    platform: AgentDetailResponseStackStatePlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: AgentDetailResponseStackStateResources;
    };
};
export declare const AgentDetailResponseManagementEnum: {
    readonly Auto: "auto";
};
export type AgentDetailResponseManagementEnum = ClosedEnum<typeof AgentDetailResponseManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentDetailResponseOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentDetailResponseOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentDetailResponseOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentDetailResponseOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentDetailResponseOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentDetailResponseOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentDetailResponseOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentDetailResponseOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentDetailResponseOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentDetailResponseOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentDetailResponseOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentDetailResponseOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentDetailResponseOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentDetailResponseOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentDetailResponseOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentDetailResponseOverrideUnion = AgentDetailResponseOverride | string;
export type AgentDetailResponseManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<AgentDetailResponseOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentDetailResponseExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentDetailResponseExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentDetailResponseExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentDetailResponseExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentDetailResponseExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentDetailResponseExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentDetailResponseExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentDetailResponseExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentDetailResponseExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentDetailResponseExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentDetailResponseExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentDetailResponseExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentDetailResponseExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentDetailResponseExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentDetailResponseExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentDetailResponseExtendUnion = AgentDetailResponseExtend | string;
export type AgentDetailResponseManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<AgentDetailResponseExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type AgentDetailResponseManagementUnion = AgentDetailResponseManagement1 | AgentDetailResponseManagement2 | AgentDetailResponseManagementEnum;
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentDetailResponseProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentDetailResponseProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentDetailResponseProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentDetailResponseProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentDetailResponseProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentDetailResponseProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentDetailResponseProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentDetailResponseProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentDetailResponseProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentDetailResponseProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentDetailResponseProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentDetailResponseProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentDetailResponseProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentDetailResponseProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentDetailResponseProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentDetailResponseProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentDetailResponseProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentDetailResponseProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentDetailResponseProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentDetailResponseProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentDetailResponseProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentDetailResponseProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentDetailResponseProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentDetailResponseProfileUnion = AgentDetailResponseProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type AgentDetailResponsePermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: AgentDetailResponseManagement1 | AgentDetailResponseManagement2 | AgentDetailResponseManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<AgentDetailResponseProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentDetailResponsePreparedStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type AgentDetailResponsePreparedStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const AgentDetailResponsePreparedStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type AgentDetailResponsePreparedStackLifecycle = ClosedEnum<typeof AgentDetailResponsePreparedStackLifecycle>;
export type AgentDetailResponsePreparedStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: AgentDetailResponsePreparedStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<AgentDetailResponsePreparedStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: AgentDetailResponsePreparedStackLifecycle;
    /**
     * Enable remote bindings for this resource (BYOB use case).
     *
     * @remarks
     * When true, binding params are synced to StackState's `remote_binding_params`.
     * Default: false (prevents sensitive data in synced state).
     */
    remoteAccess?: boolean | undefined;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type AgentDetailResponsePreparedStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: AgentDetailResponsePermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: AgentDetailResponsePreparedStackResources;
    };
};
/**
 * Runtime metadata for deployment state persistence
 */
export type AgentDetailResponseRuntimeMetadata = {
    /**
     * Hash of the environment variables snapshot that was last synced to the vault
     *
     * @remarks
     * Used to avoid redundant sync operations during incremental deployment
     */
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/**
 * Latest error information if the agent is in a failed state
 */
export type AgentDetailResponseError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Snapshot of target environment variables for the agent
 */
export type AgentDetailResponseTargetEnvironmentVariables = {
    /**
     * Environment variables in the snapshot
     */
    variables: Array<EnvironmentVariableConfig>;
    /**
     * Deterministic hash of all variables for change detection
     */
    hash: string;
    /**
     * ISO 8601 timestamp when snapshot was created
     */
    createdAt: Date;
};
/**
 * Snapshot of current environment variables for the agent
 */
export type AgentDetailResponseCurrentEnvironmentVariables = {
    /**
     * Environment variables in the snapshot
     */
    variables: Array<EnvironmentVariableConfig>;
    /**
     * Deterministic hash of all variables for change detection
     */
    hash: string;
    /**
     * ISO 8601 timestamp when snapshot was created
     */
    createdAt: Date;
};
export type AgentDetailResponse = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Agent name.
     */
    name: string;
    /**
     * Public subdomain for auto-generated domains
     */
    publicSubdomain?: string | null | undefined;
    /**
     * Deployment status in the deployment lifecycle
     */
    status: AgentDetailResponseStatus;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Target platform for the agent
     */
    platform: AgentDetailResponsePlatform;
    /**
     * ID of deployment group this agent belongs to
     */
    deploymentGroupId: string;
    /**
     * Cloud environment information
     */
    environmentInfo?: AgentDetailResponseEnvironmentInfoGcp | AgentDetailResponseEnvironmentInfoAzure | AgentDetailResponseEnvironmentInfoLocal | AgentDetailResponseEnvironmentInfoAws | AgentDetailResponseEnvironmentInfoTest | any | null | undefined;
    /**
     * User-provided configuration (network, deployment model, approvals)
     */
    stackSettings: AgentDetailResponseStackSettings;
    /**
     * State of infrastructure components managed by this agent
     */
    stackState?: AgentDetailResponseStackState | null | undefined;
    /**
     * Runtime metadata for deployment state persistence
     */
    runtimeMetadata?: AgentDetailResponseRuntimeMetadata | null | undefined;
    /**
     * ID of the currently deployed release (actual state)
     */
    currentReleaseId?: string | null | undefined;
    /**
     * ID of the desired release for deployment/update (desired state)
     */
    desiredReleaseId?: string | null | undefined;
    /**
     * ID of the pinned release
     */
    pinnedReleaseId?: string | null | undefined;
    /**
     * Whether a retry has been requested for a failed agent
     */
    retryRequested: boolean;
    /**
     * Timestamp of the last received heartbeat from the agent
     */
    lastHeartbeatAt?: Date | null | undefined;
    /**
     * Latest error information if the agent is in a failed state
     */
    error?: AgentDetailResponseError | null | undefined;
    /**
     * Configuration of environment variables for the agent
     */
    environmentVariables?: Array<EnvironmentVariableConfig> | null | undefined;
    /**
     * Snapshot of target environment variables for the agent
     */
    targetEnvironmentVariables?: AgentDetailResponseTargetEnvironmentVariables | null | undefined;
    /**
     * Snapshot of current environment variables for the agent
     */
    currentEnvironmentVariables?: AgentDetailResponseCurrentEnvironmentVariables | null | undefined;
    createdAt: Date;
    updatedAt: Date;
    /**
     * ID of the agent manager responsible for this agent
     */
    agentManagerId?: string | null | undefined;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    release?: AgentReleaseInfo | null | undefined;
    deploymentGroup?: AgentDeploymentGroupInfo | undefined;
    project?: AgentProjectInfo | undefined;
};
/** @internal */
export declare const AgentDetailResponseStatus$inboundSchema: z.ZodEnum<typeof AgentDetailResponseStatus>;
/** @internal */
export declare const AgentDetailResponsePlatform$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatform>;
/** @internal */
export declare const AgentDetailResponsePlatformTest$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatformTest>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoTest$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoTest, unknown>;
export declare function agentDetailResponseEnvironmentInfoTestFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoTest, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePlatformLocal$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatformLocal>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoLocal$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoLocal, unknown>;
export declare function agentDetailResponseEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePlatformAzure$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatformAzure>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoAzure$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoAzure, unknown>;
export declare function agentDetailResponseEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePlatformGcp$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatformGcp>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoGcp$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoGcp, unknown>;
export declare function agentDetailResponseEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePlatformAws$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePlatformAws>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoAws$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoAws, unknown>;
export declare function agentDetailResponseEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseEnvironmentInfoUnion$inboundSchema: z.ZodType<AgentDetailResponseEnvironmentInfoUnion, unknown>;
export declare function agentDetailResponseEnvironmentInfoUnionFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseEnvironmentInfoUnion, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseDeploymentModel$inboundSchema: z.ZodEnum<typeof AgentDetailResponseDeploymentModel>;
/** @internal */
export declare const AgentDetailResponseAws$inboundSchema: z.ZodType<AgentDetailResponseAws, unknown>;
export declare function agentDetailResponseAwsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseAws, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseDomainsAzure$inboundSchema: z.ZodType<AgentDetailResponseDomainsAzure, unknown>;
export declare function agentDetailResponseDomainsAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseDomainsAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseDomainsGcp$inboundSchema: z.ZodType<AgentDetailResponseDomainsGcp, unknown>;
export declare function agentDetailResponseDomainsGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseDomainsGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseCertificate$inboundSchema: z.ZodType<AgentDetailResponseCertificate, unknown>;
export declare function agentDetailResponseCertificateFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseCertificate, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseCustomDomains$inboundSchema: z.ZodType<AgentDetailResponseCustomDomains, unknown>;
export declare function agentDetailResponseCustomDomainsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseCustomDomains, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseDomains$inboundSchema: z.ZodType<AgentDetailResponseDomains, unknown>;
export declare function agentDetailResponseDomainsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseDomains, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseHeartbeats$inboundSchema: z.ZodEnum<typeof AgentDetailResponseHeartbeats>;
/** @internal */
export declare const AgentDetailResponseTypeByoVnetAzure$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTypeByoVnetAzure>;
/** @internal */
export declare const AgentDetailResponseNetworkByoVnetAzure$inboundSchema: z.ZodType<AgentDetailResponseNetworkByoVnetAzure, unknown>;
export declare function agentDetailResponseNetworkByoVnetAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseNetworkByoVnetAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTypeByoVpcGcp$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTypeByoVpcGcp>;
/** @internal */
export declare const AgentDetailResponseNetworkByoVpcGcp$inboundSchema: z.ZodType<AgentDetailResponseNetworkByoVpcGcp, unknown>;
export declare function agentDetailResponseNetworkByoVpcGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseNetworkByoVpcGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTypeByoVpcAws$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTypeByoVpcAws>;
/** @internal */
export declare const AgentDetailResponseNetworkByoVpcAws$inboundSchema: z.ZodType<AgentDetailResponseNetworkByoVpcAws, unknown>;
export declare function agentDetailResponseNetworkByoVpcAwsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseNetworkByoVpcAws, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTypeCreate$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTypeCreate>;
/** @internal */
export declare const AgentDetailResponseNetworkCreate$inboundSchema: z.ZodType<AgentDetailResponseNetworkCreate, unknown>;
export declare function agentDetailResponseNetworkCreateFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseNetworkCreate, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTypeUseDefault$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTypeUseDefault>;
/** @internal */
export declare const AgentDetailResponseNetworkUseDefault$inboundSchema: z.ZodType<AgentDetailResponseNetworkUseDefault, unknown>;
export declare function agentDetailResponseNetworkUseDefaultFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseNetworkUseDefault, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTelemetry$inboundSchema: z.ZodEnum<typeof AgentDetailResponseTelemetry>;
/** @internal */
export declare const AgentDetailResponseUpdates$inboundSchema: z.ZodEnum<typeof AgentDetailResponseUpdates>;
/** @internal */
export declare const AgentDetailResponseStackSettings$inboundSchema: z.ZodType<AgentDetailResponseStackSettings, unknown>;
export declare function agentDetailResponseStackSettingsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseStackSettings, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseStackStatePlatform$inboundSchema: z.ZodEnum<typeof AgentDetailResponseStackStatePlatform>;
/** @internal */
export declare const AgentDetailResponseStackStateConfig$inboundSchema: z.ZodType<AgentDetailResponseStackStateConfig, unknown>;
export declare function agentDetailResponseStackStateConfigFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseStackStateConfig, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseStackStateDependency$inboundSchema: z.ZodType<AgentDetailResponseStackStateDependency, unknown>;
export declare function agentDetailResponseStackStateDependencyFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseStackStateDependency, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseErrorStackState$inboundSchema: z.ZodType<AgentDetailResponseErrorStackState, unknown>;
export declare function agentDetailResponseErrorStackStateFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseErrorStackState, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseLifecycleStackState$inboundSchema: z.ZodEnum<typeof AgentDetailResponseLifecycleStackState>;
/** @internal */
export declare const AgentDetailResponseOutputs$inboundSchema: z.ZodType<AgentDetailResponseOutputs, unknown>;
export declare function agentDetailResponseOutputsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOutputs, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePreviousConfig$inboundSchema: z.ZodType<AgentDetailResponsePreviousConfig, unknown>;
export declare function agentDetailResponsePreviousConfigFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePreviousConfig, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseStackStateStatus$inboundSchema: z.ZodEnum<typeof AgentDetailResponseStackStateStatus>;
/** @internal */
export declare const AgentDetailResponseStackStateResources$inboundSchema: z.ZodType<AgentDetailResponseStackStateResources, unknown>;
export declare function agentDetailResponseStackStateResourcesFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseStackStateResources, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseStackState$inboundSchema: z.ZodType<AgentDetailResponseStackState, unknown>;
export declare function agentDetailResponseStackStateFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseStackState, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseManagementEnum$inboundSchema: z.ZodEnum<typeof AgentDetailResponseManagementEnum>;
/** @internal */
export declare const AgentDetailResponseOverrideAwResource$inboundSchema: z.ZodType<AgentDetailResponseOverrideAwResource, unknown>;
export declare function agentDetailResponseOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAwStack$inboundSchema: z.ZodType<AgentDetailResponseOverrideAwStack, unknown>;
export declare function agentDetailResponseOverrideAwStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAwBinding$inboundSchema: z.ZodType<AgentDetailResponseOverrideAwBinding, unknown>;
export declare function agentDetailResponseOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAwGrant$inboundSchema: z.ZodType<AgentDetailResponseOverrideAwGrant, unknown>;
export declare function agentDetailResponseOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAw$inboundSchema: z.ZodType<AgentDetailResponseOverrideAw, unknown>;
export declare function agentDetailResponseOverrideAwFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAw, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAzureResource$inboundSchema: z.ZodType<AgentDetailResponseOverrideAzureResource, unknown>;
export declare function agentDetailResponseOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAzureStack$inboundSchema: z.ZodType<AgentDetailResponseOverrideAzureStack, unknown>;
export declare function agentDetailResponseOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAzureBinding$inboundSchema: z.ZodType<AgentDetailResponseOverrideAzureBinding, unknown>;
export declare function agentDetailResponseOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAzureGrant$inboundSchema: z.ZodType<AgentDetailResponseOverrideAzureGrant, unknown>;
export declare function agentDetailResponseOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideAzure$inboundSchema: z.ZodType<AgentDetailResponseOverrideAzure, unknown>;
export declare function agentDetailResponseOverrideAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideConditionResource$inboundSchema: z.ZodType<AgentDetailResponseOverrideConditionResource, unknown>;
export declare function agentDetailResponseOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideGcpResource$inboundSchema: z.ZodType<AgentDetailResponseOverrideGcpResource, unknown>;
export declare function agentDetailResponseOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideConditionStack$inboundSchema: z.ZodType<AgentDetailResponseOverrideConditionStack, unknown>;
export declare function agentDetailResponseOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideGcpStack$inboundSchema: z.ZodType<AgentDetailResponseOverrideGcpStack, unknown>;
export declare function agentDetailResponseOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideGcpBinding$inboundSchema: z.ZodType<AgentDetailResponseOverrideGcpBinding, unknown>;
export declare function agentDetailResponseOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideGcpGrant$inboundSchema: z.ZodType<AgentDetailResponseOverrideGcpGrant, unknown>;
export declare function agentDetailResponseOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideGcp$inboundSchema: z.ZodType<AgentDetailResponseOverrideGcp, unknown>;
export declare function agentDetailResponseOverrideGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverridePlatforms$inboundSchema: z.ZodType<AgentDetailResponseOverridePlatforms, unknown>;
export declare function agentDetailResponseOverridePlatformsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverride$inboundSchema: z.ZodType<AgentDetailResponseOverride, unknown>;
export declare function agentDetailResponseOverrideFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverride, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseOverrideUnion$inboundSchema: z.ZodType<AgentDetailResponseOverrideUnion, unknown>;
export declare function agentDetailResponseOverrideUnionFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseOverrideUnion, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseManagement2$inboundSchema: z.ZodType<AgentDetailResponseManagement2, unknown>;
export declare function agentDetailResponseManagement2FromJSON(jsonString: string): SafeParseResult<AgentDetailResponseManagement2, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAwResource$inboundSchema: z.ZodType<AgentDetailResponseExtendAwResource, unknown>;
export declare function agentDetailResponseExtendAwResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAwResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAwStack$inboundSchema: z.ZodType<AgentDetailResponseExtendAwStack, unknown>;
export declare function agentDetailResponseExtendAwStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAwStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAwBinding$inboundSchema: z.ZodType<AgentDetailResponseExtendAwBinding, unknown>;
export declare function agentDetailResponseExtendAwBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAwGrant$inboundSchema: z.ZodType<AgentDetailResponseExtendAwGrant, unknown>;
export declare function agentDetailResponseExtendAwGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAw$inboundSchema: z.ZodType<AgentDetailResponseExtendAw, unknown>;
export declare function agentDetailResponseExtendAwFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAw, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAzureResource$inboundSchema: z.ZodType<AgentDetailResponseExtendAzureResource, unknown>;
export declare function agentDetailResponseExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAzureStack$inboundSchema: z.ZodType<AgentDetailResponseExtendAzureStack, unknown>;
export declare function agentDetailResponseExtendAzureStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAzureBinding$inboundSchema: z.ZodType<AgentDetailResponseExtendAzureBinding, unknown>;
export declare function agentDetailResponseExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAzureGrant$inboundSchema: z.ZodType<AgentDetailResponseExtendAzureGrant, unknown>;
export declare function agentDetailResponseExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendAzure$inboundSchema: z.ZodType<AgentDetailResponseExtendAzure, unknown>;
export declare function agentDetailResponseExtendAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendConditionResource$inboundSchema: z.ZodType<AgentDetailResponseExtendConditionResource, unknown>;
export declare function agentDetailResponseExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendGcpResource$inboundSchema: z.ZodType<AgentDetailResponseExtendGcpResource, unknown>;
export declare function agentDetailResponseExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendConditionStack$inboundSchema: z.ZodType<AgentDetailResponseExtendConditionStack, unknown>;
export declare function agentDetailResponseExtendConditionStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendGcpStack$inboundSchema: z.ZodType<AgentDetailResponseExtendGcpStack, unknown>;
export declare function agentDetailResponseExtendGcpStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendGcpBinding$inboundSchema: z.ZodType<AgentDetailResponseExtendGcpBinding, unknown>;
export declare function agentDetailResponseExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendGcpGrant$inboundSchema: z.ZodType<AgentDetailResponseExtendGcpGrant, unknown>;
export declare function agentDetailResponseExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendGcp$inboundSchema: z.ZodType<AgentDetailResponseExtendGcp, unknown>;
export declare function agentDetailResponseExtendGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendPlatforms$inboundSchema: z.ZodType<AgentDetailResponseExtendPlatforms, unknown>;
export declare function agentDetailResponseExtendPlatformsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtend$inboundSchema: z.ZodType<AgentDetailResponseExtend, unknown>;
export declare function agentDetailResponseExtendFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtend, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseExtendUnion$inboundSchema: z.ZodType<AgentDetailResponseExtendUnion, unknown>;
export declare function agentDetailResponseExtendUnionFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseExtendUnion, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseManagement1$inboundSchema: z.ZodType<AgentDetailResponseManagement1, unknown>;
export declare function agentDetailResponseManagement1FromJSON(jsonString: string): SafeParseResult<AgentDetailResponseManagement1, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseManagementUnion$inboundSchema: z.ZodType<AgentDetailResponseManagementUnion, unknown>;
export declare function agentDetailResponseManagementUnionFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseManagementUnion, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAwResource$inboundSchema: z.ZodType<AgentDetailResponseProfileAwResource, unknown>;
export declare function agentDetailResponseProfileAwResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAwResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAwStack$inboundSchema: z.ZodType<AgentDetailResponseProfileAwStack, unknown>;
export declare function agentDetailResponseProfileAwStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAwStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAwBinding$inboundSchema: z.ZodType<AgentDetailResponseProfileAwBinding, unknown>;
export declare function agentDetailResponseProfileAwBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAwGrant$inboundSchema: z.ZodType<AgentDetailResponseProfileAwGrant, unknown>;
export declare function agentDetailResponseProfileAwGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAw$inboundSchema: z.ZodType<AgentDetailResponseProfileAw, unknown>;
export declare function agentDetailResponseProfileAwFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAw, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAzureResource$inboundSchema: z.ZodType<AgentDetailResponseProfileAzureResource, unknown>;
export declare function agentDetailResponseProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAzureStack$inboundSchema: z.ZodType<AgentDetailResponseProfileAzureStack, unknown>;
export declare function agentDetailResponseProfileAzureStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAzureBinding$inboundSchema: z.ZodType<AgentDetailResponseProfileAzureBinding, unknown>;
export declare function agentDetailResponseProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAzureGrant$inboundSchema: z.ZodType<AgentDetailResponseProfileAzureGrant, unknown>;
export declare function agentDetailResponseProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileAzure$inboundSchema: z.ZodType<AgentDetailResponseProfileAzure, unknown>;
export declare function agentDetailResponseProfileAzureFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileAzure, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileConditionResource$inboundSchema: z.ZodType<AgentDetailResponseProfileConditionResource, unknown>;
export declare function agentDetailResponseProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileGcpResource$inboundSchema: z.ZodType<AgentDetailResponseProfileGcpResource, unknown>;
export declare function agentDetailResponseProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileConditionStack$inboundSchema: z.ZodType<AgentDetailResponseProfileConditionStack, unknown>;
export declare function agentDetailResponseProfileConditionStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileGcpStack$inboundSchema: z.ZodType<AgentDetailResponseProfileGcpStack, unknown>;
export declare function agentDetailResponseProfileGcpStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileGcpBinding$inboundSchema: z.ZodType<AgentDetailResponseProfileGcpBinding, unknown>;
export declare function agentDetailResponseProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileGcpGrant$inboundSchema: z.ZodType<AgentDetailResponseProfileGcpGrant, unknown>;
export declare function agentDetailResponseProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileGcp$inboundSchema: z.ZodType<AgentDetailResponseProfileGcp, unknown>;
export declare function agentDetailResponseProfileGcpFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileGcp, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfilePlatforms$inboundSchema: z.ZodType<AgentDetailResponseProfilePlatforms, unknown>;
export declare function agentDetailResponseProfilePlatformsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfile$inboundSchema: z.ZodType<AgentDetailResponseProfile, unknown>;
export declare function agentDetailResponseProfileFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfile, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseProfileUnion$inboundSchema: z.ZodType<AgentDetailResponseProfileUnion, unknown>;
export declare function agentDetailResponseProfileUnionFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseProfileUnion, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePermissions$inboundSchema: z.ZodType<AgentDetailResponsePermissions, unknown>;
export declare function agentDetailResponsePermissionsFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePermissions, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePreparedStackConfig$inboundSchema: z.ZodType<AgentDetailResponsePreparedStackConfig, unknown>;
export declare function agentDetailResponsePreparedStackConfigFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePreparedStackConfig, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePreparedStackDependency$inboundSchema: z.ZodType<AgentDetailResponsePreparedStackDependency, unknown>;
export declare function agentDetailResponsePreparedStackDependencyFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePreparedStackDependency, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePreparedStackLifecycle$inboundSchema: z.ZodEnum<typeof AgentDetailResponsePreparedStackLifecycle>;
/** @internal */
export declare const AgentDetailResponsePreparedStackResources$inboundSchema: z.ZodType<AgentDetailResponsePreparedStackResources, unknown>;
export declare function agentDetailResponsePreparedStackResourcesFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePreparedStackResources, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponsePreparedStack$inboundSchema: z.ZodType<AgentDetailResponsePreparedStack, unknown>;
export declare function agentDetailResponsePreparedStackFromJSON(jsonString: string): SafeParseResult<AgentDetailResponsePreparedStack, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseRuntimeMetadata$inboundSchema: z.ZodType<AgentDetailResponseRuntimeMetadata, unknown>;
export declare function agentDetailResponseRuntimeMetadataFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseRuntimeMetadata, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseError$inboundSchema: z.ZodType<AgentDetailResponseError, unknown>;
export declare function agentDetailResponseErrorFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseError, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseTargetEnvironmentVariables$inboundSchema: z.ZodType<AgentDetailResponseTargetEnvironmentVariables, unknown>;
export declare function agentDetailResponseTargetEnvironmentVariablesFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseTargetEnvironmentVariables, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponseCurrentEnvironmentVariables$inboundSchema: z.ZodType<AgentDetailResponseCurrentEnvironmentVariables, unknown>;
export declare function agentDetailResponseCurrentEnvironmentVariablesFromJSON(jsonString: string): SafeParseResult<AgentDetailResponseCurrentEnvironmentVariables, SDKValidationError>;
/** @internal */
export declare const AgentDetailResponse$inboundSchema: z.ZodType<AgentDetailResponse, unknown>;
export declare function agentDetailResponseFromJSON(jsonString: string): SafeParseResult<AgentDetailResponse, SDKValidationError>;
//# sourceMappingURL=agentdetailresponse.d.ts.map