import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { AWSRegion } from "./awsregion.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const AWSAgentConfigType: {
    readonly Aws: "aws";
};
export type AWSAgentConfigType = ClosedEnum<typeof AWSAgentConfigType>;
/**
 * Configuration for AWS agent.
 */
export type AWSAgentConfig = {
    type: AWSAgentConfigType;
    /**
     * The ARN of the cross-account role for the deployment.
     */
    role: string;
    /**
     * AWS region.
     */
    region: AWSRegion;
};
/** @internal */
export declare const AWSAgentConfigType$inboundSchema: z.ZodNativeEnum<typeof AWSAgentConfigType>;
/** @internal */
export declare const AWSAgentConfigType$outboundSchema: z.ZodNativeEnum<typeof AWSAgentConfigType>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AWSAgentConfigType$ {
    /** @deprecated use `AWSAgentConfigType$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `AWSAgentConfigType$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const AWSAgentConfig$inboundSchema: z.ZodType<AWSAgentConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type AWSAgentConfig$Outbound = {
    type: string;
    role: string;
    region: string;
};
/** @internal */
export declare const AWSAgentConfig$outboundSchema: z.ZodType<AWSAgentConfig$Outbound, z.ZodTypeDef, AWSAgentConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AWSAgentConfig$ {
    /** @deprecated use `AWSAgentConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AWSAgentConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `AWSAgentConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AWSAgentConfig$Outbound, z.ZodTypeDef, AWSAgentConfig>;
    /** @deprecated use `AWSAgentConfig$Outbound` instead. */
    type Outbound = AWSAgentConfig$Outbound;
}
export declare function awsAgentConfigToJSON(awsAgentConfig: AWSAgentConfig): string;
export declare function awsAgentConfigFromJSON(jsonString: string): SafeParseResult<AWSAgentConfig, SDKValidationError>;
//# sourceMappingURL=awsagentconfig.d.ts.map