import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { EnvironmentVariableConfig } from "./environmentvariableconfig.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Deployment status in the deployment lifecycle
 */
export declare const AgentStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type AgentStatus = ClosedEnum<typeof AgentStatus>;
/**
 * Target platform for the agent
 */
export declare const AgentPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Target platform for the agent
 */
export type AgentPlatform = ClosedEnum<typeof AgentPlatform>;
export declare const AgentPlatformTest: {
    readonly Test: "test";
};
export type AgentPlatformTest = ClosedEnum<typeof AgentPlatformTest>;
/**
 * Test platform environment information (mock)
 */
export type AgentEnvironmentInfoTest = {
    /**
     * Test identifier for this environment
     */
    testId: string;
    platform: AgentPlatformTest;
};
export declare const AgentPlatformLocal: {
    readonly Local: "local";
};
export type AgentPlatformLocal = ClosedEnum<typeof AgentPlatformLocal>;
/**
 * Local platform environment information
 */
export type AgentEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: AgentPlatformLocal;
};
export declare const AgentPlatformAzure: {
    readonly Azure: "azure";
};
export type AgentPlatformAzure = ClosedEnum<typeof AgentPlatformAzure>;
/**
 * Azure-specific environment information
 */
export type AgentEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: AgentPlatformAzure;
};
export declare const AgentPlatformGcp: {
    readonly Gcp: "gcp";
};
export type AgentPlatformGcp = ClosedEnum<typeof AgentPlatformGcp>;
/**
 * GCP-specific environment information
 */
export type AgentEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: AgentPlatformGcp;
};
export declare const AgentPlatformAws: {
    readonly Aws: "aws";
};
export type AgentPlatformAws = ClosedEnum<typeof AgentPlatformAws>;
/**
 * AWS-specific environment information
 */
export type AgentEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: AgentPlatformAws;
};
/**
 * Cloud environment information
 */
export type AgentEnvironmentInfoUnion = AgentEnvironmentInfoGcp | AgentEnvironmentInfoAzure | AgentEnvironmentInfoLocal | AgentEnvironmentInfoAws | AgentEnvironmentInfoTest | any;
/**
 * Deployment model: how updates are delivered to the remote environment.
 */
export declare const AgentDeploymentModel: {
    readonly Push: "push";
    readonly Pull: "pull";
};
/**
 * Deployment model: how updates are delivered to the remote environment.
 */
export type AgentDeploymentModel = ClosedEnum<typeof AgentDeploymentModel>;
export type AgentAws = {
    certificateArn: string;
};
export type AgentDomainsAzure = {
    keyVaultCertificateId: string;
};
export type AgentDomainsGcp = {
    certificateName: string;
};
/**
 * Platform-specific certificate references for custom domains.
 */
export type AgentCertificate = {
    aws?: any | null | undefined;
    azure?: any | null | undefined;
    gcp?: any | null | undefined;
};
/**
 * Custom domain configuration for a single resource.
 */
export type AgentCustomDomains = {
    /**
     * Platform-specific certificate references for custom domains.
     */
    certificate: AgentCertificate;
    /**
     * Fully qualified domain name to use.
     */
    domain: string;
};
/**
 * Domain configuration for the stack.
 *
 * @remarks
 *
 * When `custom_domains` is set, the specified resources use customer-provided
 * domains and certificates. Otherwise, Alien auto-generates domains.
 */
export type AgentDomains = {
    /**
     * Custom domain configuration per resource ID.
     */
    customDomains?: {
        [k: string]: AgentCustomDomains;
    } | null | undefined;
};
/**
 * How heartbeat health checks are handled.
 */
export declare const AgentHeartbeats: {
    readonly Off: "off";
    readonly On: "on";
};
/**
 * How heartbeat health checks are handled.
 */
export type AgentHeartbeats = ClosedEnum<typeof AgentHeartbeats>;
export declare const AgentTypeByoVnetAzure: {
    readonly ByoVnetAzure: "byo-vnet-azure";
};
export type AgentTypeByoVnetAzure = ClosedEnum<typeof AgentTypeByoVnetAzure>;
export type AgentNetworkByoVnetAzure = {
    /**
     * Name of the private subnet within the VNet
     */
    privateSubnetName: string;
    /**
     * Name of the public subnet within the VNet
     */
    publicSubnetName: string;
    type: AgentTypeByoVnetAzure;
    /**
     * The full resource ID of the existing VNet
     */
    vnetResourceId: string;
};
export declare const AgentTypeByoVpcGcp: {
    readonly ByoVpcGcp: "byo-vpc-gcp";
};
export type AgentTypeByoVpcGcp = ClosedEnum<typeof AgentTypeByoVpcGcp>;
export type AgentNetworkByoVpcGcp = {
    /**
     * The name of the existing VPC network
     */
    networkName: string;
    /**
     * The region of the subnet
     */
    region: string;
    /**
     * The name of the subnet to use
     */
    subnetName: string;
    type: AgentTypeByoVpcGcp;
};
export declare const AgentTypeByoVpcAws: {
    readonly ByoVpcAws: "byo-vpc-aws";
};
export type AgentTypeByoVpcAws = ClosedEnum<typeof AgentTypeByoVpcAws>;
export type AgentNetworkByoVpcAws = {
    /**
     * IDs of private subnets
     */
    privateSubnetIds: Array<string>;
    /**
     * IDs of public subnets (required for public ingress)
     */
    publicSubnetIds: Array<string>;
    /**
     * Optional security group IDs to use
     */
    securityGroupIds?: Array<string> | undefined;
    type: AgentTypeByoVpcAws;
    /**
     * The ID of the existing VPC
     */
    vpcId: string;
};
export declare const AgentTypeCreate: {
    readonly Create: "create";
};
export type AgentTypeCreate = ClosedEnum<typeof AgentTypeCreate>;
export type AgentNetworkCreate = {
    /**
     * Number of availability zones (default: 2).
     */
    availabilityZones?: number | undefined;
    /**
     * VPC/VNet CIDR block. If not specified, auto-generated from stack ID
     *
     * @remarks
     * to reduce conflicts (e.g., "10.{hash}.0.0/16").
     */
    cidr?: string | null | undefined;
    type: AgentTypeCreate;
};
export declare const AgentTypeUseDefault: {
    readonly UseDefault: "use-default";
};
export type AgentTypeUseDefault = ClosedEnum<typeof AgentTypeUseDefault>;
export type AgentNetworkUseDefault = {
    type: AgentTypeUseDefault;
};
/**
 * How telemetry (logs, metrics, traces) is handled.
 */
export declare const AgentTelemetry: {
    readonly Off: "off";
    readonly Auto: "auto";
    readonly ApprovalRequired: "approval-required";
};
/**
 * How telemetry (logs, metrics, traces) is handled.
 */
export type AgentTelemetry = ClosedEnum<typeof AgentTelemetry>;
/**
 * How updates are delivered to the agent.
 */
export declare const AgentUpdates: {
    readonly Auto: "auto";
    readonly ApprovalRequired: "approval-required";
};
/**
 * How updates are delivered to the agent.
 */
export type AgentUpdates = ClosedEnum<typeof AgentUpdates>;
/**
 * User-provided configuration (network, deployment model, approvals)
 */
export type AgentStackSettings = {
    /**
     * Deployment model: how updates are delivered to the remote environment.
     */
    deploymentModel?: AgentDeploymentModel | undefined;
    domains?: any | null | undefined;
    /**
     * How heartbeat health checks are handled.
     */
    heartbeats?: AgentHeartbeats | undefined;
    network?: any | null | undefined;
    /**
     * How telemetry (logs, metrics, traces) is handled.
     */
    telemetry?: AgentTelemetry | undefined;
    /**
     * How updates are delivered to the agent.
     */
    updates?: AgentUpdates | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const AgentStackStatePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type AgentStackStatePlatform = ClosedEnum<typeof AgentStackStatePlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentStackStateConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type AgentStackStateDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type AgentErrorStackState = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const AgentLifecycleStackState: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type AgentLifecycleStackState = ClosedEnum<typeof AgentLifecycleStackState>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type AgentOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentPreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const AgentStackStateStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type AgentStackStateStatus = ClosedEnum<typeof AgentStackStateStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type AgentStackStateResources = {
    internal?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: AgentStackStateConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<AgentStackStateDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    remoteBindingParams?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: AgentStackStateStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * State of infrastructure components managed by this agent
 */
export type AgentStackState = {
    /**
     * Represents the target cloud platform.
     */
    platform: AgentStackStatePlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: AgentStackStateResources;
    };
};
export declare const AgentManagementEnum: {
    readonly Auto: "auto";
};
export type AgentManagementEnum = ClosedEnum<typeof AgentManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type AgentOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentOverrideUnion = AgentOverride | string;
export type AgentManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<AgentOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type AgentExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentExtendUnion = AgentExtend | string;
export type AgentManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<AgentExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type AgentManagementUnion = AgentManagement1 | AgentManagement2 | AgentManagementEnum;
/**
 * AWS-specific binding specification
 */
export type AgentProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type AgentProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: AgentProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: AgentProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type AgentProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type AgentProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type AgentProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: AgentProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: AgentProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type AgentProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type AgentProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type AgentProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type AgentProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type AgentProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: AgentProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: AgentProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type AgentProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type AgentProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: AgentProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: AgentProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type AgentProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<AgentProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<AgentProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<AgentProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type AgentProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: AgentProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type AgentProfileUnion = AgentProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type AgentPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: AgentManagement1 | AgentManagement2 | AgentManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<AgentProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type AgentPreparedStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type AgentPreparedStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const AgentPreparedStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type AgentPreparedStackLifecycle = ClosedEnum<typeof AgentPreparedStackLifecycle>;
export type AgentPreparedStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: AgentPreparedStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<AgentPreparedStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: AgentPreparedStackLifecycle;
    /**
     * Enable remote bindings for this resource (BYOB use case).
     *
     * @remarks
     * When true, binding params are synced to StackState's `remote_binding_params`.
     * Default: false (prevents sensitive data in synced state).
     */
    remoteAccess?: boolean | undefined;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type AgentPreparedStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: AgentPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: AgentPreparedStackResources;
    };
};
/**
 * Runtime metadata for deployment state persistence
 */
export type AgentRuntimeMetadata = {
    /**
     * Hash of the environment variables snapshot that was last synced to the vault
     *
     * @remarks
     * Used to avoid redundant sync operations during incremental deployment
     */
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/**
 * Latest error information if the agent is in a failed state
 */
export type AgentError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable: boolean;
    source?: any | null | undefined;
};
/**
 * Snapshot of target environment variables for the agent
 */
export type AgentTargetEnvironmentVariables = {
    /**
     * Environment variables in the snapshot
     */
    variables: Array<EnvironmentVariableConfig>;
    /**
     * Deterministic hash of all variables for change detection
     */
    hash: string;
    /**
     * ISO 8601 timestamp when snapshot was created
     */
    createdAt: Date;
};
/**
 * Snapshot of current environment variables for the agent
 */
export type AgentCurrentEnvironmentVariables = {
    /**
     * Environment variables in the snapshot
     */
    variables: Array<EnvironmentVariableConfig>;
    /**
     * Deterministic hash of all variables for change detection
     */
    hash: string;
    /**
     * ISO 8601 timestamp when snapshot was created
     */
    createdAt: Date;
};
export type Agent = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Agent name.
     */
    name: string;
    /**
     * Public subdomain for auto-generated domains
     */
    publicSubdomain?: string | null | undefined;
    /**
     * Deployment status in the deployment lifecycle
     */
    status: AgentStatus;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Target platform for the agent
     */
    platform: AgentPlatform;
    /**
     * ID of deployment group this agent belongs to
     */
    deploymentGroupId: string;
    /**
     * Cloud environment information
     */
    environmentInfo?: AgentEnvironmentInfoGcp | AgentEnvironmentInfoAzure | AgentEnvironmentInfoLocal | AgentEnvironmentInfoAws | AgentEnvironmentInfoTest | any | null | undefined;
    /**
     * User-provided configuration (network, deployment model, approvals)
     */
    stackSettings: AgentStackSettings;
    /**
     * State of infrastructure components managed by this agent
     */
    stackState?: AgentStackState | null | undefined;
    /**
     * Runtime metadata for deployment state persistence
     */
    runtimeMetadata?: AgentRuntimeMetadata | null | undefined;
    /**
     * ID of the currently deployed release (actual state)
     */
    currentReleaseId?: string | null | undefined;
    /**
     * ID of the desired release for deployment/update (desired state)
     */
    desiredReleaseId?: string | null | undefined;
    /**
     * ID of the pinned release
     */
    pinnedReleaseId?: string | null | undefined;
    /**
     * Whether a retry has been requested for a failed agent
     */
    retryRequested: boolean;
    /**
     * Timestamp of the last received heartbeat from the agent
     */
    lastHeartbeatAt?: Date | null | undefined;
    /**
     * Latest error information if the agent is in a failed state
     */
    error?: AgentError | null | undefined;
    /**
     * Configuration of environment variables for the agent
     */
    environmentVariables?: Array<EnvironmentVariableConfig> | null | undefined;
    /**
     * Snapshot of target environment variables for the agent
     */
    targetEnvironmentVariables?: AgentTargetEnvironmentVariables | null | undefined;
    /**
     * Snapshot of current environment variables for the agent
     */
    currentEnvironmentVariables?: AgentCurrentEnvironmentVariables | null | undefined;
    createdAt: Date;
    updatedAt: Date;
    /**
     * ID of the agent manager responsible for this agent
     */
    agentManagerId?: string | null | undefined;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
};
/** @internal */
export declare const AgentStatus$inboundSchema: z.ZodEnum<typeof AgentStatus>;
/** @internal */
export declare const AgentPlatform$inboundSchema: z.ZodEnum<typeof AgentPlatform>;
/** @internal */
export declare const AgentPlatformTest$inboundSchema: z.ZodEnum<typeof AgentPlatformTest>;
/** @internal */
export declare const AgentEnvironmentInfoTest$inboundSchema: z.ZodType<AgentEnvironmentInfoTest, unknown>;
export declare function agentEnvironmentInfoTestFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoTest, SDKValidationError>;
/** @internal */
export declare const AgentPlatformLocal$inboundSchema: z.ZodEnum<typeof AgentPlatformLocal>;
/** @internal */
export declare const AgentEnvironmentInfoLocal$inboundSchema: z.ZodType<AgentEnvironmentInfoLocal, unknown>;
export declare function agentEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const AgentPlatformAzure$inboundSchema: z.ZodEnum<typeof AgentPlatformAzure>;
/** @internal */
export declare const AgentEnvironmentInfoAzure$inboundSchema: z.ZodType<AgentEnvironmentInfoAzure, unknown>;
export declare function agentEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const AgentPlatformGcp$inboundSchema: z.ZodEnum<typeof AgentPlatformGcp>;
/** @internal */
export declare const AgentEnvironmentInfoGcp$inboundSchema: z.ZodType<AgentEnvironmentInfoGcp, unknown>;
export declare function agentEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const AgentPlatformAws$inboundSchema: z.ZodEnum<typeof AgentPlatformAws>;
/** @internal */
export declare const AgentEnvironmentInfoAws$inboundSchema: z.ZodType<AgentEnvironmentInfoAws, unknown>;
export declare function agentEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const AgentEnvironmentInfoUnion$inboundSchema: z.ZodType<AgentEnvironmentInfoUnion, unknown>;
export declare function agentEnvironmentInfoUnionFromJSON(jsonString: string): SafeParseResult<AgentEnvironmentInfoUnion, SDKValidationError>;
/** @internal */
export declare const AgentDeploymentModel$inboundSchema: z.ZodEnum<typeof AgentDeploymentModel>;
/** @internal */
export declare const AgentAws$inboundSchema: z.ZodType<AgentAws, unknown>;
export declare function agentAwsFromJSON(jsonString: string): SafeParseResult<AgentAws, SDKValidationError>;
/** @internal */
export declare const AgentDomainsAzure$inboundSchema: z.ZodType<AgentDomainsAzure, unknown>;
export declare function agentDomainsAzureFromJSON(jsonString: string): SafeParseResult<AgentDomainsAzure, SDKValidationError>;
/** @internal */
export declare const AgentDomainsGcp$inboundSchema: z.ZodType<AgentDomainsGcp, unknown>;
export declare function agentDomainsGcpFromJSON(jsonString: string): SafeParseResult<AgentDomainsGcp, SDKValidationError>;
/** @internal */
export declare const AgentCertificate$inboundSchema: z.ZodType<AgentCertificate, unknown>;
export declare function agentCertificateFromJSON(jsonString: string): SafeParseResult<AgentCertificate, SDKValidationError>;
/** @internal */
export declare const AgentCustomDomains$inboundSchema: z.ZodType<AgentCustomDomains, unknown>;
export declare function agentCustomDomainsFromJSON(jsonString: string): SafeParseResult<AgentCustomDomains, SDKValidationError>;
/** @internal */
export declare const AgentDomains$inboundSchema: z.ZodType<AgentDomains, unknown>;
export declare function agentDomainsFromJSON(jsonString: string): SafeParseResult<AgentDomains, SDKValidationError>;
/** @internal */
export declare const AgentHeartbeats$inboundSchema: z.ZodEnum<typeof AgentHeartbeats>;
/** @internal */
export declare const AgentTypeByoVnetAzure$inboundSchema: z.ZodEnum<typeof AgentTypeByoVnetAzure>;
/** @internal */
export declare const AgentNetworkByoVnetAzure$inboundSchema: z.ZodType<AgentNetworkByoVnetAzure, unknown>;
export declare function agentNetworkByoVnetAzureFromJSON(jsonString: string): SafeParseResult<AgentNetworkByoVnetAzure, SDKValidationError>;
/** @internal */
export declare const AgentTypeByoVpcGcp$inboundSchema: z.ZodEnum<typeof AgentTypeByoVpcGcp>;
/** @internal */
export declare const AgentNetworkByoVpcGcp$inboundSchema: z.ZodType<AgentNetworkByoVpcGcp, unknown>;
export declare function agentNetworkByoVpcGcpFromJSON(jsonString: string): SafeParseResult<AgentNetworkByoVpcGcp, SDKValidationError>;
/** @internal */
export declare const AgentTypeByoVpcAws$inboundSchema: z.ZodEnum<typeof AgentTypeByoVpcAws>;
/** @internal */
export declare const AgentNetworkByoVpcAws$inboundSchema: z.ZodType<AgentNetworkByoVpcAws, unknown>;
export declare function agentNetworkByoVpcAwsFromJSON(jsonString: string): SafeParseResult<AgentNetworkByoVpcAws, SDKValidationError>;
/** @internal */
export declare const AgentTypeCreate$inboundSchema: z.ZodEnum<typeof AgentTypeCreate>;
/** @internal */
export declare const AgentNetworkCreate$inboundSchema: z.ZodType<AgentNetworkCreate, unknown>;
export declare function agentNetworkCreateFromJSON(jsonString: string): SafeParseResult<AgentNetworkCreate, SDKValidationError>;
/** @internal */
export declare const AgentTypeUseDefault$inboundSchema: z.ZodEnum<typeof AgentTypeUseDefault>;
/** @internal */
export declare const AgentNetworkUseDefault$inboundSchema: z.ZodType<AgentNetworkUseDefault, unknown>;
export declare function agentNetworkUseDefaultFromJSON(jsonString: string): SafeParseResult<AgentNetworkUseDefault, SDKValidationError>;
/** @internal */
export declare const AgentTelemetry$inboundSchema: z.ZodEnum<typeof AgentTelemetry>;
/** @internal */
export declare const AgentUpdates$inboundSchema: z.ZodEnum<typeof AgentUpdates>;
/** @internal */
export declare const AgentStackSettings$inboundSchema: z.ZodType<AgentStackSettings, unknown>;
export declare function agentStackSettingsFromJSON(jsonString: string): SafeParseResult<AgentStackSettings, SDKValidationError>;
/** @internal */
export declare const AgentStackStatePlatform$inboundSchema: z.ZodEnum<typeof AgentStackStatePlatform>;
/** @internal */
export declare const AgentStackStateConfig$inboundSchema: z.ZodType<AgentStackStateConfig, unknown>;
export declare function agentStackStateConfigFromJSON(jsonString: string): SafeParseResult<AgentStackStateConfig, SDKValidationError>;
/** @internal */
export declare const AgentStackStateDependency$inboundSchema: z.ZodType<AgentStackStateDependency, unknown>;
export declare function agentStackStateDependencyFromJSON(jsonString: string): SafeParseResult<AgentStackStateDependency, SDKValidationError>;
/** @internal */
export declare const AgentErrorStackState$inboundSchema: z.ZodType<AgentErrorStackState, unknown>;
export declare function agentErrorStackStateFromJSON(jsonString: string): SafeParseResult<AgentErrorStackState, SDKValidationError>;
/** @internal */
export declare const AgentLifecycleStackState$inboundSchema: z.ZodEnum<typeof AgentLifecycleStackState>;
/** @internal */
export declare const AgentOutputs$inboundSchema: z.ZodType<AgentOutputs, unknown>;
export declare function agentOutputsFromJSON(jsonString: string): SafeParseResult<AgentOutputs, SDKValidationError>;
/** @internal */
export declare const AgentPreviousConfig$inboundSchema: z.ZodType<AgentPreviousConfig, unknown>;
export declare function agentPreviousConfigFromJSON(jsonString: string): SafeParseResult<AgentPreviousConfig, SDKValidationError>;
/** @internal */
export declare const AgentStackStateStatus$inboundSchema: z.ZodEnum<typeof AgentStackStateStatus>;
/** @internal */
export declare const AgentStackStateResources$inboundSchema: z.ZodType<AgentStackStateResources, unknown>;
export declare function agentStackStateResourcesFromJSON(jsonString: string): SafeParseResult<AgentStackStateResources, SDKValidationError>;
/** @internal */
export declare const AgentStackState$inboundSchema: z.ZodType<AgentStackState, unknown>;
export declare function agentStackStateFromJSON(jsonString: string): SafeParseResult<AgentStackState, SDKValidationError>;
/** @internal */
export declare const AgentManagementEnum$inboundSchema: z.ZodEnum<typeof AgentManagementEnum>;
/** @internal */
export declare const AgentOverrideAwResource$inboundSchema: z.ZodType<AgentOverrideAwResource, unknown>;
export declare function agentOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<AgentOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAwStack$inboundSchema: z.ZodType<AgentOverrideAwStack, unknown>;
export declare function agentOverrideAwStackFromJSON(jsonString: string): SafeParseResult<AgentOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAwBinding$inboundSchema: z.ZodType<AgentOverrideAwBinding, unknown>;
export declare function agentOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<AgentOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAwGrant$inboundSchema: z.ZodType<AgentOverrideAwGrant, unknown>;
export declare function agentOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<AgentOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAw$inboundSchema: z.ZodType<AgentOverrideAw, unknown>;
export declare function agentOverrideAwFromJSON(jsonString: string): SafeParseResult<AgentOverrideAw, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAzureResource$inboundSchema: z.ZodType<AgentOverrideAzureResource, unknown>;
export declare function agentOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAzureStack$inboundSchema: z.ZodType<AgentOverrideAzureStack, unknown>;
export declare function agentOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<AgentOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAzureBinding$inboundSchema: z.ZodType<AgentOverrideAzureBinding, unknown>;
export declare function agentOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAzureGrant$inboundSchema: z.ZodType<AgentOverrideAzureGrant, unknown>;
export declare function agentOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentOverrideAzure$inboundSchema: z.ZodType<AgentOverrideAzure, unknown>;
export declare function agentOverrideAzureFromJSON(jsonString: string): SafeParseResult<AgentOverrideAzure, SDKValidationError>;
/** @internal */
export declare const AgentOverrideConditionResource$inboundSchema: z.ZodType<AgentOverrideConditionResource, unknown>;
export declare function agentOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentOverrideGcpResource$inboundSchema: z.ZodType<AgentOverrideGcpResource, unknown>;
export declare function agentOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentOverrideConditionStack$inboundSchema: z.ZodType<AgentOverrideConditionStack, unknown>;
export declare function agentOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<AgentOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentOverrideGcpStack$inboundSchema: z.ZodType<AgentOverrideGcpStack, unknown>;
export declare function agentOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<AgentOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentOverrideGcpBinding$inboundSchema: z.ZodType<AgentOverrideGcpBinding, unknown>;
export declare function agentOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentOverrideGcpGrant$inboundSchema: z.ZodType<AgentOverrideGcpGrant, unknown>;
export declare function agentOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentOverrideGcp$inboundSchema: z.ZodType<AgentOverrideGcp, unknown>;
export declare function agentOverrideGcpFromJSON(jsonString: string): SafeParseResult<AgentOverrideGcp, SDKValidationError>;
/** @internal */
export declare const AgentOverridePlatforms$inboundSchema: z.ZodType<AgentOverridePlatforms, unknown>;
export declare function agentOverridePlatformsFromJSON(jsonString: string): SafeParseResult<AgentOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const AgentOverride$inboundSchema: z.ZodType<AgentOverride, unknown>;
export declare function agentOverrideFromJSON(jsonString: string): SafeParseResult<AgentOverride, SDKValidationError>;
/** @internal */
export declare const AgentOverrideUnion$inboundSchema: z.ZodType<AgentOverrideUnion, unknown>;
export declare function agentOverrideUnionFromJSON(jsonString: string): SafeParseResult<AgentOverrideUnion, SDKValidationError>;
/** @internal */
export declare const AgentManagement2$inboundSchema: z.ZodType<AgentManagement2, unknown>;
export declare function agentManagement2FromJSON(jsonString: string): SafeParseResult<AgentManagement2, SDKValidationError>;
/** @internal */
export declare const AgentExtendAwResource$inboundSchema: z.ZodType<AgentExtendAwResource, unknown>;
export declare function agentExtendAwResourceFromJSON(jsonString: string): SafeParseResult<AgentExtendAwResource, SDKValidationError>;
/** @internal */
export declare const AgentExtendAwStack$inboundSchema: z.ZodType<AgentExtendAwStack, unknown>;
export declare function agentExtendAwStackFromJSON(jsonString: string): SafeParseResult<AgentExtendAwStack, SDKValidationError>;
/** @internal */
export declare const AgentExtendAwBinding$inboundSchema: z.ZodType<AgentExtendAwBinding, unknown>;
export declare function agentExtendAwBindingFromJSON(jsonString: string): SafeParseResult<AgentExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentExtendAwGrant$inboundSchema: z.ZodType<AgentExtendAwGrant, unknown>;
export declare function agentExtendAwGrantFromJSON(jsonString: string): SafeParseResult<AgentExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentExtendAw$inboundSchema: z.ZodType<AgentExtendAw, unknown>;
export declare function agentExtendAwFromJSON(jsonString: string): SafeParseResult<AgentExtendAw, SDKValidationError>;
/** @internal */
export declare const AgentExtendAzureResource$inboundSchema: z.ZodType<AgentExtendAzureResource, unknown>;
export declare function agentExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentExtendAzureStack$inboundSchema: z.ZodType<AgentExtendAzureStack, unknown>;
export declare function agentExtendAzureStackFromJSON(jsonString: string): SafeParseResult<AgentExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentExtendAzureBinding$inboundSchema: z.ZodType<AgentExtendAzureBinding, unknown>;
export declare function agentExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentExtendAzureGrant$inboundSchema: z.ZodType<AgentExtendAzureGrant, unknown>;
export declare function agentExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentExtendAzure$inboundSchema: z.ZodType<AgentExtendAzure, unknown>;
export declare function agentExtendAzureFromJSON(jsonString: string): SafeParseResult<AgentExtendAzure, SDKValidationError>;
/** @internal */
export declare const AgentExtendConditionResource$inboundSchema: z.ZodType<AgentExtendConditionResource, unknown>;
export declare function agentExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentExtendGcpResource$inboundSchema: z.ZodType<AgentExtendGcpResource, unknown>;
export declare function agentExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentExtendConditionStack$inboundSchema: z.ZodType<AgentExtendConditionStack, unknown>;
export declare function agentExtendConditionStackFromJSON(jsonString: string): SafeParseResult<AgentExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentExtendGcpStack$inboundSchema: z.ZodType<AgentExtendGcpStack, unknown>;
export declare function agentExtendGcpStackFromJSON(jsonString: string): SafeParseResult<AgentExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentExtendGcpBinding$inboundSchema: z.ZodType<AgentExtendGcpBinding, unknown>;
export declare function agentExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentExtendGcpGrant$inboundSchema: z.ZodType<AgentExtendGcpGrant, unknown>;
export declare function agentExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentExtendGcp$inboundSchema: z.ZodType<AgentExtendGcp, unknown>;
export declare function agentExtendGcpFromJSON(jsonString: string): SafeParseResult<AgentExtendGcp, SDKValidationError>;
/** @internal */
export declare const AgentExtendPlatforms$inboundSchema: z.ZodType<AgentExtendPlatforms, unknown>;
export declare function agentExtendPlatformsFromJSON(jsonString: string): SafeParseResult<AgentExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const AgentExtend$inboundSchema: z.ZodType<AgentExtend, unknown>;
export declare function agentExtendFromJSON(jsonString: string): SafeParseResult<AgentExtend, SDKValidationError>;
/** @internal */
export declare const AgentExtendUnion$inboundSchema: z.ZodType<AgentExtendUnion, unknown>;
export declare function agentExtendUnionFromJSON(jsonString: string): SafeParseResult<AgentExtendUnion, SDKValidationError>;
/** @internal */
export declare const AgentManagement1$inboundSchema: z.ZodType<AgentManagement1, unknown>;
export declare function agentManagement1FromJSON(jsonString: string): SafeParseResult<AgentManagement1, SDKValidationError>;
/** @internal */
export declare const AgentManagementUnion$inboundSchema: z.ZodType<AgentManagementUnion, unknown>;
export declare function agentManagementUnionFromJSON(jsonString: string): SafeParseResult<AgentManagementUnion, SDKValidationError>;
/** @internal */
export declare const AgentProfileAwResource$inboundSchema: z.ZodType<AgentProfileAwResource, unknown>;
export declare function agentProfileAwResourceFromJSON(jsonString: string): SafeParseResult<AgentProfileAwResource, SDKValidationError>;
/** @internal */
export declare const AgentProfileAwStack$inboundSchema: z.ZodType<AgentProfileAwStack, unknown>;
export declare function agentProfileAwStackFromJSON(jsonString: string): SafeParseResult<AgentProfileAwStack, SDKValidationError>;
/** @internal */
export declare const AgentProfileAwBinding$inboundSchema: z.ZodType<AgentProfileAwBinding, unknown>;
export declare function agentProfileAwBindingFromJSON(jsonString: string): SafeParseResult<AgentProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const AgentProfileAwGrant$inboundSchema: z.ZodType<AgentProfileAwGrant, unknown>;
export declare function agentProfileAwGrantFromJSON(jsonString: string): SafeParseResult<AgentProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const AgentProfileAw$inboundSchema: z.ZodType<AgentProfileAw, unknown>;
export declare function agentProfileAwFromJSON(jsonString: string): SafeParseResult<AgentProfileAw, SDKValidationError>;
/** @internal */
export declare const AgentProfileAzureResource$inboundSchema: z.ZodType<AgentProfileAzureResource, unknown>;
export declare function agentProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<AgentProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const AgentProfileAzureStack$inboundSchema: z.ZodType<AgentProfileAzureStack, unknown>;
export declare function agentProfileAzureStackFromJSON(jsonString: string): SafeParseResult<AgentProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const AgentProfileAzureBinding$inboundSchema: z.ZodType<AgentProfileAzureBinding, unknown>;
export declare function agentProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<AgentProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const AgentProfileAzureGrant$inboundSchema: z.ZodType<AgentProfileAzureGrant, unknown>;
export declare function agentProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<AgentProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const AgentProfileAzure$inboundSchema: z.ZodType<AgentProfileAzure, unknown>;
export declare function agentProfileAzureFromJSON(jsonString: string): SafeParseResult<AgentProfileAzure, SDKValidationError>;
/** @internal */
export declare const AgentProfileConditionResource$inboundSchema: z.ZodType<AgentProfileConditionResource, unknown>;
export declare function agentProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<AgentProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const AgentProfileGcpResource$inboundSchema: z.ZodType<AgentProfileGcpResource, unknown>;
export declare function agentProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<AgentProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const AgentProfileConditionStack$inboundSchema: z.ZodType<AgentProfileConditionStack, unknown>;
export declare function agentProfileConditionStackFromJSON(jsonString: string): SafeParseResult<AgentProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const AgentProfileGcpStack$inboundSchema: z.ZodType<AgentProfileGcpStack, unknown>;
export declare function agentProfileGcpStackFromJSON(jsonString: string): SafeParseResult<AgentProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const AgentProfileGcpBinding$inboundSchema: z.ZodType<AgentProfileGcpBinding, unknown>;
export declare function agentProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<AgentProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const AgentProfileGcpGrant$inboundSchema: z.ZodType<AgentProfileGcpGrant, unknown>;
export declare function agentProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<AgentProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const AgentProfileGcp$inboundSchema: z.ZodType<AgentProfileGcp, unknown>;
export declare function agentProfileGcpFromJSON(jsonString: string): SafeParseResult<AgentProfileGcp, SDKValidationError>;
/** @internal */
export declare const AgentProfilePlatforms$inboundSchema: z.ZodType<AgentProfilePlatforms, unknown>;
export declare function agentProfilePlatformsFromJSON(jsonString: string): SafeParseResult<AgentProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const AgentProfile$inboundSchema: z.ZodType<AgentProfile, unknown>;
export declare function agentProfileFromJSON(jsonString: string): SafeParseResult<AgentProfile, SDKValidationError>;
/** @internal */
export declare const AgentProfileUnion$inboundSchema: z.ZodType<AgentProfileUnion, unknown>;
export declare function agentProfileUnionFromJSON(jsonString: string): SafeParseResult<AgentProfileUnion, SDKValidationError>;
/** @internal */
export declare const AgentPermissions$inboundSchema: z.ZodType<AgentPermissions, unknown>;
export declare function agentPermissionsFromJSON(jsonString: string): SafeParseResult<AgentPermissions, SDKValidationError>;
/** @internal */
export declare const AgentPreparedStackConfig$inboundSchema: z.ZodType<AgentPreparedStackConfig, unknown>;
export declare function agentPreparedStackConfigFromJSON(jsonString: string): SafeParseResult<AgentPreparedStackConfig, SDKValidationError>;
/** @internal */
export declare const AgentPreparedStackDependency$inboundSchema: z.ZodType<AgentPreparedStackDependency, unknown>;
export declare function agentPreparedStackDependencyFromJSON(jsonString: string): SafeParseResult<AgentPreparedStackDependency, SDKValidationError>;
/** @internal */
export declare const AgentPreparedStackLifecycle$inboundSchema: z.ZodEnum<typeof AgentPreparedStackLifecycle>;
/** @internal */
export declare const AgentPreparedStackResources$inboundSchema: z.ZodType<AgentPreparedStackResources, unknown>;
export declare function agentPreparedStackResourcesFromJSON(jsonString: string): SafeParseResult<AgentPreparedStackResources, SDKValidationError>;
/** @internal */
export declare const AgentPreparedStack$inboundSchema: z.ZodType<AgentPreparedStack, unknown>;
export declare function agentPreparedStackFromJSON(jsonString: string): SafeParseResult<AgentPreparedStack, SDKValidationError>;
/** @internal */
export declare const AgentRuntimeMetadata$inboundSchema: z.ZodType<AgentRuntimeMetadata, unknown>;
export declare function agentRuntimeMetadataFromJSON(jsonString: string): SafeParseResult<AgentRuntimeMetadata, SDKValidationError>;
/** @internal */
export declare const AgentError$inboundSchema: z.ZodType<AgentError, unknown>;
export declare function agentErrorFromJSON(jsonString: string): SafeParseResult<AgentError, SDKValidationError>;
/** @internal */
export declare const AgentTargetEnvironmentVariables$inboundSchema: z.ZodType<AgentTargetEnvironmentVariables, unknown>;
export declare function agentTargetEnvironmentVariablesFromJSON(jsonString: string): SafeParseResult<AgentTargetEnvironmentVariables, SDKValidationError>;
/** @internal */
export declare const AgentCurrentEnvironmentVariables$inboundSchema: z.ZodType<AgentCurrentEnvironmentVariables, unknown>;
export declare function agentCurrentEnvironmentVariablesFromJSON(jsonString: string): SafeParseResult<AgentCurrentEnvironmentVariables, SDKValidationError>;
/** @internal */
export declare const Agent$inboundSchema: z.ZodType<Agent, unknown>;
export declare function agentFromJSON(jsonString: string): SafeParseResult<Agent, SDKValidationError>;
//# sourceMappingURL=agent.d.ts.map