import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { CommandAgentInfo } from "./commandagentinfo.js";
import { CommandProjectInfo } from "./commandprojectinfo.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Command states in the ARC protocol lifecycle
 */
export declare const CommandListItemResponseState: {
    readonly PendingUpload: "PENDING_UPLOAD";
    readonly Pending: "PENDING";
    readonly Dispatched: "DISPATCHED";
    readonly Succeeded: "SUCCEEDED";
    readonly Failed: "FAILED";
    readonly Expired: "EXPIRED";
};
/**
 * Command states in the ARC protocol lifecycle
 */
export type CommandListItemResponseState = ClosedEnum<typeof CommandListItemResponseState>;
/**
 * Deployment model captured from agent at creation time
 */
export declare const CommandListItemResponseDeploymentModel: {
    readonly Push: "push";
    readonly Pull: "pull";
};
/**
 * Deployment model captured from agent at creation time
 */
export type CommandListItemResponseDeploymentModel = ClosedEnum<typeof CommandListItemResponseDeploymentModel>;
export type CommandListItemResponse = {
    /**
     * Unique identifier for the command.
     */
    id: string;
    /**
     * Unique identifier for the agent.
     */
    agentId: string;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    /**
     * Command name (e.g., 'analyze-repository', 'sync-data')
     */
    name: string;
    /**
     * Command states in the ARC protocol lifecycle
     */
    state: CommandListItemResponseState;
    /**
     * Deployment model captured from agent at creation time
     */
    deploymentModel: CommandListItemResponseDeploymentModel;
    /**
     * Current attempt number
     */
    attempt: number | null;
    /**
     * Optional deadline for command execution
     */
    deadline: Date | null;
    /**
     * Size of command params in bytes
     */
    requestSizeBytes: number | null;
    /**
     * Size of command response in bytes
     */
    responseSizeBytes: number | null;
    /**
     * When the command was created
     */
    createdAt: Date;
    /**
     * When the command was dispatched to the agent
     */
    dispatchedAt: Date | null;
    /**
     * When the command completed
     */
    completedAt: Date | null;
    /**
     * Error details if command failed
     */
    error: {
        [k: string]: any | null;
    } | null;
    agent?: CommandAgentInfo | undefined;
    project?: CommandProjectInfo | undefined;
};
/** @internal */
export declare const CommandListItemResponseState$inboundSchema: z.ZodEnum<typeof CommandListItemResponseState>;
/** @internal */
export declare const CommandListItemResponseDeploymentModel$inboundSchema: z.ZodEnum<typeof CommandListItemResponseDeploymentModel>;
/** @internal */
export declare const CommandListItemResponse$inboundSchema: z.ZodType<CommandListItemResponse, unknown>;
export declare function commandListItemResponseFromJSON(jsonString: string): SafeParseResult<CommandListItemResponse, SDKValidationError>;
//# sourceMappingURL=commandlistitemresponse.d.ts.map