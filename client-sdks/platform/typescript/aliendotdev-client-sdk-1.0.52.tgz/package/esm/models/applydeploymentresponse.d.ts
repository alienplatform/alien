import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const ApplyDeploymentResponseCurrentStackManagementEnum: {
    readonly Auto: "auto";
};
export type ApplyDeploymentResponseCurrentStackManagementEnum = ClosedEnum<typeof ApplyDeploymentResponseCurrentStackManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponseCurrentStackOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponseCurrentStackOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponseCurrentStackOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponseCurrentStackOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponseCurrentStackOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponseCurrentStackOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponseCurrentStackOverrideUnion = ApplyDeploymentResponseCurrentStackOverride | string;
export type ApplyDeploymentResponseCurrentStackManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<ApplyDeploymentResponseCurrentStackOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponseCurrentStackExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponseCurrentStackExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponseCurrentStackExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponseCurrentStackExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponseCurrentStackExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponseCurrentStackExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponseCurrentStackExtendUnion = ApplyDeploymentResponseCurrentStackExtend | string;
export type ApplyDeploymentResponseCurrentStackManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<ApplyDeploymentResponseCurrentStackExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type ApplyDeploymentResponseCurrentStackManagementUnion = ApplyDeploymentResponseCurrentStackManagement1 | ApplyDeploymentResponseCurrentStackManagement2 | ApplyDeploymentResponseCurrentStackManagementEnum;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponseCurrentStackProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponseCurrentStackProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponseCurrentStackProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponseCurrentStackProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponseCurrentStackProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponseCurrentStackProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponseCurrentStackProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponseCurrentStackProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponseCurrentStackProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponseCurrentStackProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponseCurrentStackProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponseCurrentStackProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponseCurrentStackProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponseCurrentStackProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponseCurrentStackProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponseCurrentStackProfileUnion = ApplyDeploymentResponseCurrentStackProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type ApplyDeploymentResponseCurrentStackPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: ApplyDeploymentResponseCurrentStackManagement1 | ApplyDeploymentResponseCurrentStackManagement2 | ApplyDeploymentResponseCurrentStackManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentResponseCurrentStackProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentResponseCurrentStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type ApplyDeploymentResponseCurrentStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const ApplyDeploymentResponseCurrentStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type ApplyDeploymentResponseCurrentStackLifecycle = ClosedEnum<typeof ApplyDeploymentResponseCurrentStackLifecycle>;
export type ApplyDeploymentResponseCurrentStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: ApplyDeploymentResponseCurrentStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<ApplyDeploymentResponseCurrentStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: ApplyDeploymentResponseCurrentStackLifecycle;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type ApplyDeploymentResponseCurrentStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: ApplyDeploymentResponseCurrentStackPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: ApplyDeploymentResponseCurrentStackResources;
    };
};
export declare const ApplyDeploymentResponsePlatformLocal: {
    readonly Local: "local";
};
export type ApplyDeploymentResponsePlatformLocal = ClosedEnum<typeof ApplyDeploymentResponsePlatformLocal>;
/**
 * Local platform environment information
 */
export type ApplyDeploymentResponseEnvironmentInfoLocal = {
    /**
     * Architecture (e.g., "x86_64", "aarch64")
     */
    arch: string;
    /**
     * Hostname of the machine running the agent
     */
    hostname: string;
    /**
     * Operating system (e.g., "linux", "macos", "windows")
     */
    os: string;
    platform: ApplyDeploymentResponsePlatformLocal;
};
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAzure: {
    readonly Azure: "azure";
};
export type ApplyDeploymentResponseEnvironmentInfoPlatformAzure = ClosedEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAzure>;
/**
 * Azure-specific environment information
 */
export type ApplyDeploymentResponseEnvironmentInfoAzure = {
    /**
     * Azure location/region
     */
    location: string;
    /**
     * Azure subscription ID
     */
    subscriptionId: string;
    /**
     * Azure tenant ID
     */
    tenantId: string;
    platform: ApplyDeploymentResponseEnvironmentInfoPlatformAzure;
};
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformGcp: {
    readonly Gcp: "gcp";
};
export type ApplyDeploymentResponseEnvironmentInfoPlatformGcp = ClosedEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformGcp>;
/**
 * GCP-specific environment information
 */
export type ApplyDeploymentResponseEnvironmentInfoGcp = {
    /**
     * GCP project ID (e.g., "my-project")
     */
    projectId: string;
    /**
     * GCP project number (e.g., "123456789012")
     */
    projectNumber: string;
    /**
     * GCP region
     */
    region: string;
    platform: ApplyDeploymentResponseEnvironmentInfoPlatformGcp;
};
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAws: {
    readonly Aws: "aws";
};
export type ApplyDeploymentResponseEnvironmentInfoPlatformAws = ClosedEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAws>;
/**
 * AWS-specific environment information
 */
export type ApplyDeploymentResponseEnvironmentInfoAws = {
    /**
     * AWS account ID
     */
    accountId: string;
    /**
     * AWS region
     */
    region: string;
    platform: ApplyDeploymentResponseEnvironmentInfoPlatformAws;
};
/**
 * Represents the target cloud platform.
 */
export declare const ApplyDeploymentResponsePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type ApplyDeploymentResponsePlatform = ClosedEnum<typeof ApplyDeploymentResponsePlatform>;
export declare const ApplyDeploymentResponsePreparedStackManagementEnum: {
    readonly Auto: "auto";
};
export type ApplyDeploymentResponsePreparedStackManagementEnum = ClosedEnum<typeof ApplyDeploymentResponsePreparedStackManagementEnum>;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackOverrideAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackOverrideAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackOverrideAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackOverrideAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackOverrideAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackOverrideAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackOverrideAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackOverrideAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackOverrideAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackOverrideAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackOverrideAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackOverrideAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackOverrideAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackOverrideAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackOverrideConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackOverrideConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackOverrideGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackOverrideGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackOverrideGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackOverrideGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackOverrideGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackOverrideGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackOverrideGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackOverrideGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponsePreparedStackOverridePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponsePreparedStackOverrideAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponsePreparedStackOverrideAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponsePreparedStackOverrideGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponsePreparedStackOverride = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponsePreparedStackOverridePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponsePreparedStackOverrideUnion = ApplyDeploymentResponsePreparedStackOverride | string;
export type ApplyDeploymentResponsePreparedStackManagement2 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    override: {
        [k: string]: Array<ApplyDeploymentResponsePreparedStackOverride | string>;
    };
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackExtendAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackExtendAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackExtendAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackExtendAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackExtendAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackExtendAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackExtendAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackExtendAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackExtendAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackExtendAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackExtendAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackExtendAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackExtendAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackExtendAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackExtendConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackExtendConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackExtendGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackExtendGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackExtendGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackExtendGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackExtendGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackExtendGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackExtendGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackExtendGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponsePreparedStackExtendPlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponsePreparedStackExtendAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponsePreparedStackExtendAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponsePreparedStackExtendGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponsePreparedStackExtend = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponsePreparedStackExtendPlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponsePreparedStackExtendUnion = ApplyDeploymentResponsePreparedStackExtend | string;
export type ApplyDeploymentResponsePreparedStackManagement1 = {
    /**
     * Permission profile that maps resources to permission sets
     *
     * @remarks
     * Key can be "*" for all resources or resource name for specific resource
     */
    extend: {
        [k: string]: Array<ApplyDeploymentResponsePreparedStackExtend | string>;
    };
};
/**
 * Management permissions configuration for stack management access
 */
export type ApplyDeploymentResponsePreparedStackManagementUnion = ApplyDeploymentResponsePreparedStackManagement1 | ApplyDeploymentResponsePreparedStackManagement2 | ApplyDeploymentResponsePreparedStackManagementEnum;
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileAwResource = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * AWS-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileAwStack = {
    /**
     * Optional condition for additional filtering (rare)
     */
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    /**
     * Resource ARNs to bind to
     */
    resources: Array<string>;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackProfileAwBinding = {
    /**
     * AWS-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackProfileAwResource | undefined;
    /**
     * AWS-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackProfileAwStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackProfileAwGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * AWS-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackProfileAw = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackProfileAwBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackProfileAwGrant;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileAzureResource = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Azure-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileAzureStack = {
    /**
     * Scope (subscription/resource group/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackProfileAzureBinding = {
    /**
     * Azure-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackProfileAzureResource | undefined;
    /**
     * Azure-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackProfileAzureStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackProfileAzureGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * Azure-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackProfileAzure = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackProfileAzureBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackProfileAzureGrant;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackProfileConditionResource = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileGcpResource = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * GCP IAM condition
 */
export type ApplyDeploymentResponsePreparedStackProfileConditionStack = {
    expression: string;
    title: string;
};
/**
 * GCP-specific binding specification
 */
export type ApplyDeploymentResponsePreparedStackProfileGcpStack = {
    condition?: any | null | undefined;
    /**
     * Scope (project/resource level)
     */
    scope: string;
};
/**
 * Generic binding configuration for permissions
 */
export type ApplyDeploymentResponsePreparedStackProfileGcpBinding = {
    /**
     * GCP-specific binding specification
     */
    resource?: ApplyDeploymentResponsePreparedStackProfileGcpResource | undefined;
    /**
     * GCP-specific binding specification
     */
    stack?: ApplyDeploymentResponsePreparedStackProfileGcpStack | undefined;
};
/**
 * Grant permissions for a specific cloud platform
 */
export type ApplyDeploymentResponsePreparedStackProfileGcpGrant = {
    /**
     * AWS IAM actions (only for AWS)
     */
    actions?: Array<string> | null | undefined;
    /**
     * Azure actions (only for Azure)
     */
    dataActions?: Array<string> | null | undefined;
    /**
     * GCP permissions (only for GCP)
     */
    permissions?: Array<string> | null | undefined;
};
/**
 * GCP-specific platform permission configuration
 */
export type ApplyDeploymentResponsePreparedStackProfileGcp = {
    /**
     * Generic binding configuration for permissions
     */
    binding: ApplyDeploymentResponsePreparedStackProfileGcpBinding;
    /**
     * Grant permissions for a specific cloud platform
     */
    grant: ApplyDeploymentResponsePreparedStackProfileGcpGrant;
};
/**
 * Platform-specific permission configurations
 */
export type ApplyDeploymentResponsePreparedStackProfilePlatforms = {
    /**
     * AWS permission configurations
     */
    aws?: Array<ApplyDeploymentResponsePreparedStackProfileAw> | null | undefined;
    /**
     * Azure permission configurations
     */
    azure?: Array<ApplyDeploymentResponsePreparedStackProfileAzure> | null | undefined;
    /**
     * GCP permission configurations
     */
    gcp?: Array<ApplyDeploymentResponsePreparedStackProfileGcp> | null | undefined;
};
/**
 * A permission set that can be applied across different cloud platforms
 */
export type ApplyDeploymentResponsePreparedStackProfile = {
    /**
     * Human-readable description of what this permission set allows
     */
    description: string;
    /**
     * Unique identifier for the permission set (e.g., "storage/data-read")
     */
    id: string;
    /**
     * Platform-specific permission configurations
     */
    platforms: ApplyDeploymentResponsePreparedStackProfilePlatforms;
};
/**
 * Reference to a permission set - either by name or inline definition
 */
export type ApplyDeploymentResponsePreparedStackProfileUnion = ApplyDeploymentResponsePreparedStackProfile | string;
/**
 * Combined permissions configuration that contains both profiles and management
 */
export type ApplyDeploymentResponsePreparedStackPermissions = {
    /**
     * Management permissions configuration for stack management access
     */
    management?: ApplyDeploymentResponsePreparedStackManagement1 | ApplyDeploymentResponsePreparedStackManagement2 | ApplyDeploymentResponsePreparedStackManagementEnum | undefined;
    /**
     * Permission profiles that define access control for compute services
     *
     * @remarks
     * Key is the profile name, value is the permission configuration
     */
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentResponsePreparedStackProfile | string>;
        };
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentResponsePreparedStackConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type ApplyDeploymentResponsePreparedStackDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const ApplyDeploymentResponsePreparedStackLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type ApplyDeploymentResponsePreparedStackLifecycle = ClosedEnum<typeof ApplyDeploymentResponsePreparedStackLifecycle>;
export type ApplyDeploymentResponsePreparedStackResources = {
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: ApplyDeploymentResponsePreparedStackConfig;
    /**
     * Additional dependencies for this resource beyond those defined in the resource itself.
     *
     * @remarks
     * The total dependencies are: resource.get_dependencies() + this list
     */
    dependencies: Array<ApplyDeploymentResponsePreparedStackDependency>;
    /**
     * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
     */
    lifecycle: ApplyDeploymentResponsePreparedStackLifecycle;
};
/**
 * A bag of resources, unaware of any cloud.
 */
export type ApplyDeploymentResponsePreparedStack = {
    /**
     * Unique identifier for the stack
     */
    id: string;
    /**
     * Combined permissions configuration that contains both profiles and management
     */
    permissions?: ApplyDeploymentResponsePreparedStackPermissions | undefined;
    /**
     * Map of resource IDs to their configurations and lifecycle settings
     */
    resources: {
        [k: string]: ApplyDeploymentResponsePreparedStackResources;
    };
};
/**
 * Runtime metadata for deployment
 *
 * @remarks
 *
 * Stores deployment state that needs to persist across step calls.
 */
export type ApplyDeploymentResponseRuntimeMetadata = {
    /**
     * Hash of the environment variables snapshot that was last synced to the vault
     *
     * @remarks
     * Used to avoid redundant sync operations during incremental deployment
     */
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const ApplyDeploymentResponseStackStatePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type ApplyDeploymentResponseStackStatePlatform = ClosedEnum<typeof ApplyDeploymentResponseStackStatePlatform>;
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentResponseStackStateConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * New ResourceRef that works with any resource type.
 *
 * @remarks
 * This can eventually replace the enum-based ResourceRef for full extensibility.
 */
export type ApplyDeploymentResponseStackStateDependency = {
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
};
/**
 * Canonical error container that provides a structured way to represent errors
 *
 * @remarks
 * with rich metadata including error codes, human-readable messages, context,
 * and chaining capabilities for error propagation.
 *
 * This struct is designed to be both machine-readable and user-friendly,
 * supporting serialization for API responses and detailed error reporting
 * in distributed systems.
 */
export type ApplyDeploymentResponseError = {
    /**
     * A unique identifier for the type of error.
     *
     * @remarks
     *
     * This should be a short, machine-readable string that can be used
     * by clients to programmatically handle different error types.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "TIMEOUT"
     */
    code: string;
    context?: any | null | undefined;
    /**
     * HTTP status code for this error.
     *
     * @remarks
     *
     * Used when converting the error to an HTTP response. If None, falls back to
     * the error type's default status code or 500.
     */
    httpStatusCode?: number | null | undefined;
    /**
     * Indicates if this is an internal error that should not be exposed to users.
     *
     * @remarks
     *
     * When `true`, this error contains sensitive information or implementation
     * details that should not be shown to end-users. Such errors should be
     * logged for debugging but replaced with generic error messages in responses.
     */
    internal: boolean;
    /**
     * Human-readable error message.
     *
     * @remarks
     *
     * This message should be clear and actionable for developers or end-users,
     * providing context about what went wrong and potentially how to fix it.
     */
    message: string;
    /**
     * Indicates whether the operation that caused the error should be retried.
     *
     * @remarks
     *
     * When `true`, the error is transient and the operation might succeed
     * if attempted again. When `false`, retrying the same operation is
     * unlikely to succeed without changes.
     */
    retryable?: boolean | undefined;
    source?: any | null | undefined;
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export declare const ApplyDeploymentResponseStackStateLifecycle: {
    readonly Frozen: "frozen";
    readonly Live: "live";
    readonly LiveOnSetup: "live-on-setup";
};
/**
 * Describes the lifecycle of a resource within a stack, determining how it's managed and deployed.
 */
export type ApplyDeploymentResponseStackStateLifecycle = ClosedEnum<typeof ApplyDeploymentResponseStackStateLifecycle>;
/**
 * Resource outputs that can hold output data for any resource type in the Alien system. All resource outputs share a common 'type' field with additional type-specific output properties.
 */
export type ApplyDeploymentResponseOutputs = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
 */
export type ApplyDeploymentResponsePreviousConfig = {
    /**
     * The unique identifier for this specific resource instance. Must contain only alphanumeric characters, hyphens, and underscores ([A-Za-z0-9-_]). Maximum 64 characters.
     */
    id: string;
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    additionalProperties?: {
        [k: string]: any | null;
    };
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export declare const ApplyDeploymentResponseStackStateStatus: {
    readonly Pending: "pending";
    readonly Provisioning: "provisioning";
    readonly ProvisionFailed: "provision-failed";
    readonly Running: "running";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
    readonly RefreshFailed: "refresh-failed";
};
/**
 * Represents the high-level status of a resource during its lifecycle.
 */
export type ApplyDeploymentResponseStackStateStatus = ClosedEnum<typeof ApplyDeploymentResponseStackStateStatus>;
/**
 * Represents the state of a single resource within the stack for a specific platform.
 */
export type ApplyDeploymentResponseStackStateResources = {
    internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    /**
     * Resource that can hold any resource type in the Alien system. All resources share common 'type' and 'id' fields with additional type-specific properties.
     */
    config: ApplyDeploymentResponseStackStateConfig;
    /**
     * Complete list of dependencies for this resource, including infrastructure dependencies.
     *
     * @remarks
     * This preserves the full dependency information from the stack definition.
     */
    dependencies?: Array<ApplyDeploymentResponseStackStateDependency> | undefined;
    error?: any | null | undefined;
    /**
     * True if the resource was provisioned by an external system (e.g., CloudFormation).
     *
     * @remarks
     * Defaults to false, indicating dynamic provisioning by the executor.
     */
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    /**
     * Tracks consecutive retry attempts for the current state transition.
     */
    retryAttempt?: number | undefined;
    /**
     * Represents the high-level status of a resource during its lifecycle.
     */
    status: ApplyDeploymentResponseStackStateStatus;
    /**
     * The high-level type of the resource (e.g., Function::RESOURCE_TYPE, Storage::RESOURCE_TYPE).
     */
    type: string;
};
/**
 * Represents the target cloud platform.
 */
export declare const ApplyDeploymentResponseKubernetesInfrastructurePlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
};
/**
 * Represents the target cloud platform.
 */
export type ApplyDeploymentResponseKubernetesInfrastructurePlatform = ClosedEnum<typeof ApplyDeploymentResponseKubernetesInfrastructurePlatform>;
export declare const ApplyDeploymentResponsePlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type ApplyDeploymentResponsePlatformKubernetes = ClosedEnum<typeof ApplyDeploymentResponsePlatformKubernetes>;
export type ApplyDeploymentResponseManagementKubernetes = {
    platform: ApplyDeploymentResponsePlatformKubernetes;
};
/**
 * Image pull credentials for container registries
 */
export type ApplyDeploymentResponseImagePullCredentials = {
    /**
     * Password for the container registry
     */
    password: string;
    /**
     * Username for the container registry
     */
    username: string;
};
export declare const ApplyDeploymentResponseStackStatePlatformAzure: {
    readonly Azure: "azure";
};
export type ApplyDeploymentResponseStackStatePlatformAzure = ClosedEnum<typeof ApplyDeploymentResponseStackStatePlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type ApplyDeploymentResponseManagementAzure = {
    imagePullCredentials?: any | null | undefined;
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: ApplyDeploymentResponseStackStatePlatformAzure;
};
export declare const ApplyDeploymentResponseStackStatePlatformGcp: {
    readonly Gcp: "gcp";
};
export type ApplyDeploymentResponseStackStatePlatformGcp = ClosedEnum<typeof ApplyDeploymentResponseStackStatePlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type ApplyDeploymentResponseManagementGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: ApplyDeploymentResponseStackStatePlatformGcp;
};
export declare const ApplyDeploymentResponseStackStatePlatformAws: {
    readonly Aws: "aws";
};
export type ApplyDeploymentResponseStackStatePlatformAws = ClosedEnum<typeof ApplyDeploymentResponseStackStatePlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type ApplyDeploymentResponseManagementAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: ApplyDeploymentResponseStackStatePlatformAws;
};
/**
 * Remote capabilities configuration for agents
 */
export type ApplyDeploymentResponseRemoteCapabilities = {
    /**
     * Whether the agent supports automatic updates
     */
    autoUpdates: boolean;
    /**
     * Whether the agent supports heartbeat functionality
     */
    heartbeat: boolean;
    /**
     * Whether the agent supports monitoring
     */
    monitoring: boolean;
};
/**
 * Stack-level settings that customize deployment behavior
 */
export type ApplyDeploymentResponseSettings = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    /**
     * Remote capabilities configuration for agents
     */
    remoteCapabilities: ApplyDeploymentResponseRemoteCapabilities;
};
/**
 * Represents the collective state of all resources in a stack, including platform and pending actions.
 */
export type ApplyDeploymentResponseStackState = {
    /**
     * Represents the target cloud platform.
     */
    platform: ApplyDeploymentResponseStackStatePlatform;
    /**
     * A prefix used for resource naming to ensure uniqueness across deployments.
     */
    resourcePrefix: string;
    /**
     * The state of individual resources, keyed by resource ID.
     */
    resources: {
        [k: string]: ApplyDeploymentResponseStackStateResources;
    };
    /**
     * Stack-level settings that customize deployment behavior
     */
    settings: ApplyDeploymentResponseSettings;
};
/**
 * Deployment status in the deployment lifecycle
 */
export declare const ApplyDeploymentResponseStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type ApplyDeploymentResponseStatus = ClosedEnum<typeof ApplyDeploymentResponseStatus>;
/**
 * Updated deployment state (null if released)
 */
export type ApplyDeploymentResponseCurrent = {
    currentStack?: any | null | undefined;
    environmentInfo?: any | null | undefined;
    /**
     * Represents the target cloud platform.
     */
    platform: ApplyDeploymentResponsePlatform;
    /**
     * Whether a retry has been requested for a failed deployment
     *
     * @remarks
     * When true and status is a failed state, the deployment system will retry failed resources
     */
    retryRequested?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    /**
     * Deployment status in the deployment lifecycle
     */
    status: ApplyDeploymentResponseStatus;
};
/**
 * Updated deployment state (target_stack and config are immutable during session)
 */
export type ApplyDeploymentResponse = {
    /**
     * Updated deployment state (null if released)
     */
    current: ApplyDeploymentResponseCurrent | null;
    /**
     * Session (null if released)
     */
    session: string | null;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagementEnum$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseCurrentStackManagementEnum>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagementEnum$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseCurrentStackManagementEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackManagementEnum$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagementEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagementEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAwResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAwResourceToJSON(applyDeploymentResponseCurrentStackOverrideAwResource: ApplyDeploymentResponseCurrentStackOverrideAwResource): string;
export declare function applyDeploymentResponseCurrentStackOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAwStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAwStackToJSON(applyDeploymentResponseCurrentStackOverrideAwStack: ApplyDeploymentResponseCurrentStackOverrideAwStack): string;
export declare function applyDeploymentResponseCurrentStackOverrideAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackOverrideAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackOverrideAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAwBindingToJSON(applyDeploymentResponseCurrentStackOverrideAwBinding: ApplyDeploymentResponseCurrentStackOverrideAwBinding): string;
export declare function applyDeploymentResponseCurrentStackOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAwGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAwGrantToJSON(applyDeploymentResponseCurrentStackOverrideAwGrant: ApplyDeploymentResponseCurrentStackOverrideAwGrant): string;
export declare function applyDeploymentResponseCurrentStackOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAw$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAw$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackOverrideAwBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackOverrideAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAw$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAw$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAw>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAw$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAwToJSON(applyDeploymentResponseCurrentStackOverrideAw: ApplyDeploymentResponseCurrentStackOverrideAw): string;
export declare function applyDeploymentResponseCurrentStackOverrideAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAzureResourceToJSON(applyDeploymentResponseCurrentStackOverrideAzureResource: ApplyDeploymentResponseCurrentStackOverrideAzureResource): string;
export declare function applyDeploymentResponseCurrentStackOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAzureStackToJSON(applyDeploymentResponseCurrentStackOverrideAzureStack: ApplyDeploymentResponseCurrentStackOverrideAzureStack): string;
export declare function applyDeploymentResponseCurrentStackOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackOverrideAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackOverrideAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAzureBindingToJSON(applyDeploymentResponseCurrentStackOverrideAzureBinding: ApplyDeploymentResponseCurrentStackOverrideAzureBinding): string;
export declare function applyDeploymentResponseCurrentStackOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAzureGrantToJSON(applyDeploymentResponseCurrentStackOverrideAzureGrant: ApplyDeploymentResponseCurrentStackOverrideAzureGrant): string;
export declare function applyDeploymentResponseCurrentStackOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzure$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackOverrideAzureBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackOverrideAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideAzure$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideAzure$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideAzure>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideAzureToJSON(applyDeploymentResponseCurrentStackOverrideAzure: ApplyDeploymentResponseCurrentStackOverrideAzure): string;
export declare function applyDeploymentResponseCurrentStackOverrideAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideConditionResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideConditionResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideConditionResourceToJSON(applyDeploymentResponseCurrentStackOverrideConditionResource: ApplyDeploymentResponseCurrentStackOverrideConditionResource): string;
export declare function applyDeploymentResponseCurrentStackOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideGcpResourceToJSON(applyDeploymentResponseCurrentStackOverrideGcpResource: ApplyDeploymentResponseCurrentStackOverrideGcpResource): string;
export declare function applyDeploymentResponseCurrentStackOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideConditionStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideConditionStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideConditionStackToJSON(applyDeploymentResponseCurrentStackOverrideConditionStack: ApplyDeploymentResponseCurrentStackOverrideConditionStack): string;
export declare function applyDeploymentResponseCurrentStackOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideGcpStackToJSON(applyDeploymentResponseCurrentStackOverrideGcpStack: ApplyDeploymentResponseCurrentStackOverrideGcpStack): string;
export declare function applyDeploymentResponseCurrentStackOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackOverrideGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackOverrideGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideGcpBindingToJSON(applyDeploymentResponseCurrentStackOverrideGcpBinding: ApplyDeploymentResponseCurrentStackOverrideGcpBinding): string;
export declare function applyDeploymentResponseCurrentStackOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideGcpGrantToJSON(applyDeploymentResponseCurrentStackOverrideGcpGrant: ApplyDeploymentResponseCurrentStackOverrideGcpGrant): string;
export declare function applyDeploymentResponseCurrentStackOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcp$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackOverrideGcpBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackOverrideGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideGcp$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideGcp$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideGcp>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideGcpToJSON(applyDeploymentResponseCurrentStackOverrideGcp: ApplyDeploymentResponseCurrentStackOverrideGcp): string;
export declare function applyDeploymentResponseCurrentStackOverrideGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverridePlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverridePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponseCurrentStackOverrideAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponseCurrentStackOverrideAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponseCurrentStackOverrideGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverridePlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverridePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverridePlatforms$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverridePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverridePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverridePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverridePlatforms>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverridePlatformsToJSON(applyDeploymentResponseCurrentStackOverridePlatforms: ApplyDeploymentResponseCurrentStackOverridePlatforms): string;
export declare function applyDeploymentResponseCurrentStackOverridePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverride$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverride, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverride$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponseCurrentStackOverridePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverride$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverride$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverride>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverride$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverride$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverride, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverride$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverride$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverride>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverride$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverride$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideToJSON(applyDeploymentResponseCurrentStackOverride: ApplyDeploymentResponseCurrentStackOverride): string;
export declare function applyDeploymentResponseCurrentStackOverrideFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverride, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideUnion$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackOverrideUnion$Outbound = ApplyDeploymentResponseCurrentStackOverride$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackOverrideUnion$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackOverrideUnion$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackOverrideUnion>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackOverrideUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackOverrideUnion$Outbound;
}
export declare function applyDeploymentResponseCurrentStackOverrideUnionToJSON(applyDeploymentResponseCurrentStackOverrideUnion: ApplyDeploymentResponseCurrentStackOverrideUnion): string;
export declare function applyDeploymentResponseCurrentStackOverrideUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackOverrideUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagement2$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement2, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackManagement2$Outbound = {
    override: {
        [k: string]: Array<ApplyDeploymentResponseCurrentStackOverride$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagement2$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagement2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackManagement2$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement2, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagement2>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement2$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackManagement2$Outbound;
}
export declare function applyDeploymentResponseCurrentStackManagement2ToJSON(applyDeploymentResponseCurrentStackManagement2: ApplyDeploymentResponseCurrentStackManagement2): string;
export declare function applyDeploymentResponseCurrentStackManagement2FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackManagement2, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAwResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAwResourceToJSON(applyDeploymentResponseCurrentStackExtendAwResource: ApplyDeploymentResponseCurrentStackExtendAwResource): string;
export declare function applyDeploymentResponseCurrentStackExtendAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAwStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAwStackToJSON(applyDeploymentResponseCurrentStackExtendAwStack: ApplyDeploymentResponseCurrentStackExtendAwStack): string;
export declare function applyDeploymentResponseCurrentStackExtendAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackExtendAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackExtendAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAwBindingToJSON(applyDeploymentResponseCurrentStackExtendAwBinding: ApplyDeploymentResponseCurrentStackExtendAwBinding): string;
export declare function applyDeploymentResponseCurrentStackExtendAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAwGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAwGrantToJSON(applyDeploymentResponseCurrentStackExtendAwGrant: ApplyDeploymentResponseCurrentStackExtendAwGrant): string;
export declare function applyDeploymentResponseCurrentStackExtendAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAw$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAw$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackExtendAwBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackExtendAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAw$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAw$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAw>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAw$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAwToJSON(applyDeploymentResponseCurrentStackExtendAw: ApplyDeploymentResponseCurrentStackExtendAw): string;
export declare function applyDeploymentResponseCurrentStackExtendAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAzureResourceToJSON(applyDeploymentResponseCurrentStackExtendAzureResource: ApplyDeploymentResponseCurrentStackExtendAzureResource): string;
export declare function applyDeploymentResponseCurrentStackExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAzureStackToJSON(applyDeploymentResponseCurrentStackExtendAzureStack: ApplyDeploymentResponseCurrentStackExtendAzureStack): string;
export declare function applyDeploymentResponseCurrentStackExtendAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackExtendAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackExtendAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAzureBindingToJSON(applyDeploymentResponseCurrentStackExtendAzureBinding: ApplyDeploymentResponseCurrentStackExtendAzureBinding): string;
export declare function applyDeploymentResponseCurrentStackExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAzureGrantToJSON(applyDeploymentResponseCurrentStackExtendAzureGrant: ApplyDeploymentResponseCurrentStackExtendAzureGrant): string;
export declare function applyDeploymentResponseCurrentStackExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzure$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendAzure$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackExtendAzureBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackExtendAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendAzure$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendAzure$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendAzure>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendAzure$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendAzureToJSON(applyDeploymentResponseCurrentStackExtendAzure: ApplyDeploymentResponseCurrentStackExtendAzure): string;
export declare function applyDeploymentResponseCurrentStackExtendAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendConditionResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendConditionResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendConditionResourceToJSON(applyDeploymentResponseCurrentStackExtendConditionResource: ApplyDeploymentResponseCurrentStackExtendConditionResource): string;
export declare function applyDeploymentResponseCurrentStackExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendGcpResourceToJSON(applyDeploymentResponseCurrentStackExtendGcpResource: ApplyDeploymentResponseCurrentStackExtendGcpResource): string;
export declare function applyDeploymentResponseCurrentStackExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendConditionStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendConditionStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendConditionStackToJSON(applyDeploymentResponseCurrentStackExtendConditionStack: ApplyDeploymentResponseCurrentStackExtendConditionStack): string;
export declare function applyDeploymentResponseCurrentStackExtendConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendGcpStackToJSON(applyDeploymentResponseCurrentStackExtendGcpStack: ApplyDeploymentResponseCurrentStackExtendGcpStack): string;
export declare function applyDeploymentResponseCurrentStackExtendGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackExtendGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackExtendGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendGcpBindingToJSON(applyDeploymentResponseCurrentStackExtendGcpBinding: ApplyDeploymentResponseCurrentStackExtendGcpBinding): string;
export declare function applyDeploymentResponseCurrentStackExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendGcpGrantToJSON(applyDeploymentResponseCurrentStackExtendGcpGrant: ApplyDeploymentResponseCurrentStackExtendGcpGrant): string;
export declare function applyDeploymentResponseCurrentStackExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcp$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendGcp$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackExtendGcpBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackExtendGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendGcp$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendGcp$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendGcp>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendGcp$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendGcpToJSON(applyDeploymentResponseCurrentStackExtendGcp: ApplyDeploymentResponseCurrentStackExtendGcp): string;
export declare function applyDeploymentResponseCurrentStackExtendGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendPlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponseCurrentStackExtendAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponseCurrentStackExtendAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponseCurrentStackExtendGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendPlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendPlatforms$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendPlatforms>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendPlatformsToJSON(applyDeploymentResponseCurrentStackExtendPlatforms: ApplyDeploymentResponseCurrentStackExtendPlatforms): string;
export declare function applyDeploymentResponseCurrentStackExtendPlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtend$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtend, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtend$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponseCurrentStackExtendPlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtend$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtend$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtend>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtend$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtend$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtend, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtend$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtend$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtend>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtend$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtend$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendToJSON(applyDeploymentResponseCurrentStackExtend: ApplyDeploymentResponseCurrentStackExtend): string;
export declare function applyDeploymentResponseCurrentStackExtendFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtend, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendUnion$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackExtendUnion$Outbound = ApplyDeploymentResponseCurrentStackExtend$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackExtendUnion$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackExtendUnion$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackExtendUnion>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackExtendUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackExtendUnion$Outbound;
}
export declare function applyDeploymentResponseCurrentStackExtendUnionToJSON(applyDeploymentResponseCurrentStackExtendUnion: ApplyDeploymentResponseCurrentStackExtendUnion): string;
export declare function applyDeploymentResponseCurrentStackExtendUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackExtendUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagement1$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement1, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackManagement1$Outbound = {
    extend: {
        [k: string]: Array<ApplyDeploymentResponseCurrentStackExtend$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagement1$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagement1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackManagement1$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement1, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagement1>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagement1$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackManagement1$Outbound;
}
export declare function applyDeploymentResponseCurrentStackManagement1ToJSON(applyDeploymentResponseCurrentStackManagement1: ApplyDeploymentResponseCurrentStackManagement1): string;
export declare function applyDeploymentResponseCurrentStackManagement1FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackManagement1, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagementUnion$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackManagementUnion$Outbound = ApplyDeploymentResponseCurrentStackManagement1$Outbound | ApplyDeploymentResponseCurrentStackManagement2$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackManagementUnion$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackManagementUnion$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackManagementUnion>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackManagementUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackManagementUnion$Outbound;
}
export declare function applyDeploymentResponseCurrentStackManagementUnionToJSON(applyDeploymentResponseCurrentStackManagementUnion: ApplyDeploymentResponseCurrentStackManagementUnion): string;
export declare function applyDeploymentResponseCurrentStackManagementUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackManagementUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAwResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAwResourceToJSON(applyDeploymentResponseCurrentStackProfileAwResource: ApplyDeploymentResponseCurrentStackProfileAwResource): string;
export declare function applyDeploymentResponseCurrentStackProfileAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAwStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAwStackToJSON(applyDeploymentResponseCurrentStackProfileAwStack: ApplyDeploymentResponseCurrentStackProfileAwStack): string;
export declare function applyDeploymentResponseCurrentStackProfileAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackProfileAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackProfileAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAwBindingToJSON(applyDeploymentResponseCurrentStackProfileAwBinding: ApplyDeploymentResponseCurrentStackProfileAwBinding): string;
export declare function applyDeploymentResponseCurrentStackProfileAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAwGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAwGrantToJSON(applyDeploymentResponseCurrentStackProfileAwGrant: ApplyDeploymentResponseCurrentStackProfileAwGrant): string;
export declare function applyDeploymentResponseCurrentStackProfileAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAw$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAw$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackProfileAwBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackProfileAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAw$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAw$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAw>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAw$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAwToJSON(applyDeploymentResponseCurrentStackProfileAw: ApplyDeploymentResponseCurrentStackProfileAw): string;
export declare function applyDeploymentResponseCurrentStackProfileAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAzureResourceToJSON(applyDeploymentResponseCurrentStackProfileAzureResource: ApplyDeploymentResponseCurrentStackProfileAzureResource): string;
export declare function applyDeploymentResponseCurrentStackProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAzureStackToJSON(applyDeploymentResponseCurrentStackProfileAzureStack: ApplyDeploymentResponseCurrentStackProfileAzureStack): string;
export declare function applyDeploymentResponseCurrentStackProfileAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackProfileAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackProfileAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAzureBindingToJSON(applyDeploymentResponseCurrentStackProfileAzureBinding: ApplyDeploymentResponseCurrentStackProfileAzureBinding): string;
export declare function applyDeploymentResponseCurrentStackProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAzureGrantToJSON(applyDeploymentResponseCurrentStackProfileAzureGrant: ApplyDeploymentResponseCurrentStackProfileAzureGrant): string;
export declare function applyDeploymentResponseCurrentStackProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzure$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileAzure$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackProfileAzureBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackProfileAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileAzure$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileAzure$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileAzure>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileAzure$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileAzureToJSON(applyDeploymentResponseCurrentStackProfileAzure: ApplyDeploymentResponseCurrentStackProfileAzure): string;
export declare function applyDeploymentResponseCurrentStackProfileAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileConditionResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileConditionResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileConditionResourceToJSON(applyDeploymentResponseCurrentStackProfileConditionResource: ApplyDeploymentResponseCurrentStackProfileConditionResource): string;
export declare function applyDeploymentResponseCurrentStackProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpResource>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileGcpResourceToJSON(applyDeploymentResponseCurrentStackProfileGcpResource: ApplyDeploymentResponseCurrentStackProfileGcpResource): string;
export declare function applyDeploymentResponseCurrentStackProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileConditionStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileConditionStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileConditionStackToJSON(applyDeploymentResponseCurrentStackProfileConditionStack: ApplyDeploymentResponseCurrentStackProfileConditionStack): string;
export declare function applyDeploymentResponseCurrentStackProfileConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileGcpStackToJSON(applyDeploymentResponseCurrentStackProfileGcpStack: ApplyDeploymentResponseCurrentStackProfileGcpStack): string;
export declare function applyDeploymentResponseCurrentStackProfileGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponseCurrentStackProfileGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponseCurrentStackProfileGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileGcpBindingToJSON(applyDeploymentResponseCurrentStackProfileGcpBinding: ApplyDeploymentResponseCurrentStackProfileGcpBinding): string;
export declare function applyDeploymentResponseCurrentStackProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileGcpGrantToJSON(applyDeploymentResponseCurrentStackProfileGcpGrant: ApplyDeploymentResponseCurrentStackProfileGcpGrant): string;
export declare function applyDeploymentResponseCurrentStackProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcp$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileGcp$Outbound = {
    binding: ApplyDeploymentResponseCurrentStackProfileGcpBinding$Outbound;
    grant: ApplyDeploymentResponseCurrentStackProfileGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileGcp$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileGcp$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileGcp>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileGcp$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileGcpToJSON(applyDeploymentResponseCurrentStackProfileGcp: ApplyDeploymentResponseCurrentStackProfileGcp): string;
export declare function applyDeploymentResponseCurrentStackProfileGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfilePlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfilePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponseCurrentStackProfileAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponseCurrentStackProfileAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponseCurrentStackProfileGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfilePlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfilePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfilePlatforms$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfilePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfilePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfilePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfilePlatforms>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfilePlatformsToJSON(applyDeploymentResponseCurrentStackProfilePlatforms: ApplyDeploymentResponseCurrentStackProfilePlatforms): string;
export declare function applyDeploymentResponseCurrentStackProfilePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfile$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfile, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfile$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponseCurrentStackProfilePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfile$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfile$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfile>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfile$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfile$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfile, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfile$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfile$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfile>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfile$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfile$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileToJSON(applyDeploymentResponseCurrentStackProfile: ApplyDeploymentResponseCurrentStackProfile): string;
export declare function applyDeploymentResponseCurrentStackProfileFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfile, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileUnion$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackProfileUnion$Outbound = ApplyDeploymentResponseCurrentStackProfile$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackProfileUnion$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackProfileUnion$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackProfileUnion>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackProfileUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackProfileUnion$Outbound;
}
export declare function applyDeploymentResponseCurrentStackProfileUnionToJSON(applyDeploymentResponseCurrentStackProfileUnion: ApplyDeploymentResponseCurrentStackProfileUnion): string;
export declare function applyDeploymentResponseCurrentStackProfileUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackProfileUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackPermissions$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackPermissions$Outbound = {
    management?: ApplyDeploymentResponseCurrentStackManagement1$Outbound | ApplyDeploymentResponseCurrentStackManagement2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentResponseCurrentStackProfile$Outbound | string>;
        };
    };
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackPermissions$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackPermissions$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackPermissions>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackPermissions$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackPermissions$Outbound;
}
export declare function applyDeploymentResponseCurrentStackPermissionsToJSON(applyDeploymentResponseCurrentStackPermissions: ApplyDeploymentResponseCurrentStackPermissions): string;
export declare function applyDeploymentResponseCurrentStackPermissionsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackPermissions, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackConfig$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackConfig$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackConfig$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackConfig>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackConfig$Outbound;
}
export declare function applyDeploymentResponseCurrentStackConfigToJSON(applyDeploymentResponseCurrentStackConfig: ApplyDeploymentResponseCurrentStackConfig): string;
export declare function applyDeploymentResponseCurrentStackConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackDependency$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackDependency$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackDependency$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackDependency>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackDependency$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackDependency$Outbound;
}
export declare function applyDeploymentResponseCurrentStackDependencyToJSON(applyDeploymentResponseCurrentStackDependency: ApplyDeploymentResponseCurrentStackDependency): string;
export declare function applyDeploymentResponseCurrentStackDependencyFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackDependency, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseCurrentStackLifecycle>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseCurrentStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackLifecycle$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackResources$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStackResources$Outbound = {
    config: ApplyDeploymentResponseCurrentStackConfig$Outbound;
    dependencies: Array<ApplyDeploymentResponseCurrentStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStackResources$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStackResources$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStackResources>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStackResources$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStackResources$Outbound;
}
export declare function applyDeploymentResponseCurrentStackResourcesToJSON(applyDeploymentResponseCurrentStackResources: ApplyDeploymentResponseCurrentStackResources): string;
export declare function applyDeploymentResponseCurrentStackResourcesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStackResources, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseCurrentStack$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrentStack$Outbound = {
    id: string;
    permissions?: ApplyDeploymentResponseCurrentStackPermissions$Outbound | undefined;
    resources: {
        [k: string]: ApplyDeploymentResponseCurrentStackResources$Outbound;
    };
};
/** @internal */
export declare const ApplyDeploymentResponseCurrentStack$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrentStack$ {
    /** @deprecated use `ApplyDeploymentResponseCurrentStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrentStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrentStack>;
    /** @deprecated use `ApplyDeploymentResponseCurrentStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrentStack$Outbound;
}
export declare function applyDeploymentResponseCurrentStackToJSON(applyDeploymentResponseCurrentStack: ApplyDeploymentResponseCurrentStack): string;
export declare function applyDeploymentResponseCurrentStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrentStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePlatformLocal$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatformLocal>;
/** @internal */
export declare const ApplyDeploymentResponsePlatformLocal$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatformLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePlatformLocal$ {
    /** @deprecated use `ApplyDeploymentResponsePlatformLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentResponsePlatformLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoLocal$inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseEnvironmentInfoLocal$Outbound = {
    arch: string;
    hostname: string;
    os: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoLocal$outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoLocal$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoLocal>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoLocal$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoLocal$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoLocal, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoLocal$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoLocal$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoLocal>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoLocal$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseEnvironmentInfoLocal$Outbound;
}
export declare function applyDeploymentResponseEnvironmentInfoLocalToJSON(applyDeploymentResponseEnvironmentInfoLocal: ApplyDeploymentResponseEnvironmentInfoLocal): string;
export declare function applyDeploymentResponseEnvironmentInfoLocalFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseEnvironmentInfoLocal, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAzure$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAzure>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAzure$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoPlatformAzure$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoAzure$inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseEnvironmentInfoAzure$Outbound = {
    location: string;
    subscriptionId: string;
    tenantId: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoAzure$outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoAzure$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoAzure>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseEnvironmentInfoAzure$Outbound;
}
export declare function applyDeploymentResponseEnvironmentInfoAzureToJSON(applyDeploymentResponseEnvironmentInfoAzure: ApplyDeploymentResponseEnvironmentInfoAzure): string;
export declare function applyDeploymentResponseEnvironmentInfoAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseEnvironmentInfoAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformGcp$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformGcp>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformGcp$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoPlatformGcp$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoGcp$inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseEnvironmentInfoGcp$Outbound = {
    projectId: string;
    projectNumber: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoGcp$outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoGcp$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoGcp>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseEnvironmentInfoGcp$Outbound;
}
export declare function applyDeploymentResponseEnvironmentInfoGcpToJSON(applyDeploymentResponseEnvironmentInfoGcp: ApplyDeploymentResponseEnvironmentInfoGcp): string;
export declare function applyDeploymentResponseEnvironmentInfoGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseEnvironmentInfoGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAws$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAws>;
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoPlatformAws$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseEnvironmentInfoPlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoPlatformAws$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoPlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoAws$inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAws, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseEnvironmentInfoAws$Outbound = {
    accountId: string;
    region: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseEnvironmentInfoAws$outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAws$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseEnvironmentInfoAws$ {
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseEnvironmentInfoAws$Outbound, z.ZodTypeDef, ApplyDeploymentResponseEnvironmentInfoAws>;
    /** @deprecated use `ApplyDeploymentResponseEnvironmentInfoAws$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseEnvironmentInfoAws$Outbound;
}
export declare function applyDeploymentResponseEnvironmentInfoAwsToJSON(applyDeploymentResponseEnvironmentInfoAws: ApplyDeploymentResponseEnvironmentInfoAws): string;
export declare function applyDeploymentResponseEnvironmentInfoAwsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseEnvironmentInfoAws, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePlatform$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatform>;
/** @internal */
export declare const ApplyDeploymentResponsePlatform$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePlatform$ {
    /** @deprecated use `ApplyDeploymentResponsePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentResponsePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagementEnum$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePreparedStackManagementEnum>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagementEnum$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePreparedStackManagementEnum>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackManagementEnum$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagementEnum$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagementEnum$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Auto: "auto";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAwResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAwResourceToJSON(applyDeploymentResponsePreparedStackOverrideAwResource: ApplyDeploymentResponsePreparedStackOverrideAwResource): string;
export declare function applyDeploymentResponsePreparedStackOverrideAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAwStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAwStackToJSON(applyDeploymentResponsePreparedStackOverrideAwStack: ApplyDeploymentResponsePreparedStackOverrideAwStack): string;
export declare function applyDeploymentResponsePreparedStackOverrideAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackOverrideAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackOverrideAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAwBindingToJSON(applyDeploymentResponsePreparedStackOverrideAwBinding: ApplyDeploymentResponsePreparedStackOverrideAwBinding): string;
export declare function applyDeploymentResponsePreparedStackOverrideAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAwGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAwGrantToJSON(applyDeploymentResponsePreparedStackOverrideAwGrant: ApplyDeploymentResponsePreparedStackOverrideAwGrant): string;
export declare function applyDeploymentResponsePreparedStackOverrideAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAw$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAw$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackOverrideAwBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackOverrideAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAw$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAw$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAw>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAw$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAwToJSON(applyDeploymentResponsePreparedStackOverrideAw: ApplyDeploymentResponsePreparedStackOverrideAw): string;
export declare function applyDeploymentResponsePreparedStackOverrideAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAzureResourceToJSON(applyDeploymentResponsePreparedStackOverrideAzureResource: ApplyDeploymentResponsePreparedStackOverrideAzureResource): string;
export declare function applyDeploymentResponsePreparedStackOverrideAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAzureStackToJSON(applyDeploymentResponsePreparedStackOverrideAzureStack: ApplyDeploymentResponsePreparedStackOverrideAzureStack): string;
export declare function applyDeploymentResponsePreparedStackOverrideAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackOverrideAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackOverrideAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAzureBindingToJSON(applyDeploymentResponsePreparedStackOverrideAzureBinding: ApplyDeploymentResponsePreparedStackOverrideAzureBinding): string;
export declare function applyDeploymentResponsePreparedStackOverrideAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAzureGrantToJSON(applyDeploymentResponsePreparedStackOverrideAzureGrant: ApplyDeploymentResponsePreparedStackOverrideAzureGrant): string;
export declare function applyDeploymentResponsePreparedStackOverrideAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzure$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackOverrideAzureBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackOverrideAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideAzure$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideAzure$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideAzure>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideAzureToJSON(applyDeploymentResponsePreparedStackOverrideAzure: ApplyDeploymentResponsePreparedStackOverrideAzure): string;
export declare function applyDeploymentResponsePreparedStackOverrideAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideConditionResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideConditionResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideConditionResourceToJSON(applyDeploymentResponsePreparedStackOverrideConditionResource: ApplyDeploymentResponsePreparedStackOverrideConditionResource): string;
export declare function applyDeploymentResponsePreparedStackOverrideConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideGcpResourceToJSON(applyDeploymentResponsePreparedStackOverrideGcpResource: ApplyDeploymentResponsePreparedStackOverrideGcpResource): string;
export declare function applyDeploymentResponsePreparedStackOverrideGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideConditionStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideConditionStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideConditionStackToJSON(applyDeploymentResponsePreparedStackOverrideConditionStack: ApplyDeploymentResponsePreparedStackOverrideConditionStack): string;
export declare function applyDeploymentResponsePreparedStackOverrideConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideGcpStackToJSON(applyDeploymentResponsePreparedStackOverrideGcpStack: ApplyDeploymentResponsePreparedStackOverrideGcpStack): string;
export declare function applyDeploymentResponsePreparedStackOverrideGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackOverrideGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackOverrideGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideGcpBindingToJSON(applyDeploymentResponsePreparedStackOverrideGcpBinding: ApplyDeploymentResponsePreparedStackOverrideGcpBinding): string;
export declare function applyDeploymentResponsePreparedStackOverrideGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideGcpGrantToJSON(applyDeploymentResponsePreparedStackOverrideGcpGrant: ApplyDeploymentResponsePreparedStackOverrideGcpGrant): string;
export declare function applyDeploymentResponsePreparedStackOverrideGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcp$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackOverrideGcpBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackOverrideGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideGcp$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideGcp$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideGcp>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideGcpToJSON(applyDeploymentResponsePreparedStackOverrideGcp: ApplyDeploymentResponsePreparedStackOverrideGcp): string;
export declare function applyDeploymentResponsePreparedStackOverrideGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverridePlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverridePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponsePreparedStackOverrideAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponsePreparedStackOverrideAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponsePreparedStackOverrideGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverridePlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverridePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverridePlatforms$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverridePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverridePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverridePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverridePlatforms>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverridePlatformsToJSON(applyDeploymentResponsePreparedStackOverridePlatforms: ApplyDeploymentResponsePreparedStackOverridePlatforms): string;
export declare function applyDeploymentResponsePreparedStackOverridePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverridePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverride$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverride, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverride$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponsePreparedStackOverridePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverride$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverride$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverride>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverride$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverride$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverride, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverride$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverride$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverride>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverride$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverride$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideToJSON(applyDeploymentResponsePreparedStackOverride: ApplyDeploymentResponsePreparedStackOverride): string;
export declare function applyDeploymentResponsePreparedStackOverrideFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverride, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideUnion$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackOverrideUnion$Outbound = ApplyDeploymentResponsePreparedStackOverride$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackOverrideUnion$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackOverrideUnion$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackOverrideUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackOverrideUnion>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackOverrideUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackOverrideUnion$Outbound;
}
export declare function applyDeploymentResponsePreparedStackOverrideUnionToJSON(applyDeploymentResponsePreparedStackOverrideUnion: ApplyDeploymentResponsePreparedStackOverrideUnion): string;
export declare function applyDeploymentResponsePreparedStackOverrideUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackOverrideUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagement2$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement2, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackManagement2$Outbound = {
    override: {
        [k: string]: Array<ApplyDeploymentResponsePreparedStackOverride$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagement2$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagement2>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackManagement2$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement2$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement2, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement2$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement2$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagement2>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement2$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackManagement2$Outbound;
}
export declare function applyDeploymentResponsePreparedStackManagement2ToJSON(applyDeploymentResponsePreparedStackManagement2: ApplyDeploymentResponsePreparedStackManagement2): string;
export declare function applyDeploymentResponsePreparedStackManagement2FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackManagement2, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAwResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAwResourceToJSON(applyDeploymentResponsePreparedStackExtendAwResource: ApplyDeploymentResponsePreparedStackExtendAwResource): string;
export declare function applyDeploymentResponsePreparedStackExtendAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAwStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAwStackToJSON(applyDeploymentResponsePreparedStackExtendAwStack: ApplyDeploymentResponsePreparedStackExtendAwStack): string;
export declare function applyDeploymentResponsePreparedStackExtendAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackExtendAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackExtendAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAwBindingToJSON(applyDeploymentResponsePreparedStackExtendAwBinding: ApplyDeploymentResponsePreparedStackExtendAwBinding): string;
export declare function applyDeploymentResponsePreparedStackExtendAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAwGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAwGrantToJSON(applyDeploymentResponsePreparedStackExtendAwGrant: ApplyDeploymentResponsePreparedStackExtendAwGrant): string;
export declare function applyDeploymentResponsePreparedStackExtendAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAw$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAw$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackExtendAwBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackExtendAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAw$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAw$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAw>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAw$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAwToJSON(applyDeploymentResponsePreparedStackExtendAw: ApplyDeploymentResponsePreparedStackExtendAw): string;
export declare function applyDeploymentResponsePreparedStackExtendAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAzureResourceToJSON(applyDeploymentResponsePreparedStackExtendAzureResource: ApplyDeploymentResponsePreparedStackExtendAzureResource): string;
export declare function applyDeploymentResponsePreparedStackExtendAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAzureStackToJSON(applyDeploymentResponsePreparedStackExtendAzureStack: ApplyDeploymentResponsePreparedStackExtendAzureStack): string;
export declare function applyDeploymentResponsePreparedStackExtendAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackExtendAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackExtendAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAzureBindingToJSON(applyDeploymentResponsePreparedStackExtendAzureBinding: ApplyDeploymentResponsePreparedStackExtendAzureBinding): string;
export declare function applyDeploymentResponsePreparedStackExtendAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAzureGrantToJSON(applyDeploymentResponsePreparedStackExtendAzureGrant: ApplyDeploymentResponsePreparedStackExtendAzureGrant): string;
export declare function applyDeploymentResponsePreparedStackExtendAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzure$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendAzure$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackExtendAzureBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackExtendAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendAzure$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendAzure$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendAzure>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendAzure$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendAzureToJSON(applyDeploymentResponsePreparedStackExtendAzure: ApplyDeploymentResponsePreparedStackExtendAzure): string;
export declare function applyDeploymentResponsePreparedStackExtendAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendConditionResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendConditionResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendConditionResourceToJSON(applyDeploymentResponsePreparedStackExtendConditionResource: ApplyDeploymentResponsePreparedStackExtendConditionResource): string;
export declare function applyDeploymentResponsePreparedStackExtendConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendGcpResourceToJSON(applyDeploymentResponsePreparedStackExtendGcpResource: ApplyDeploymentResponsePreparedStackExtendGcpResource): string;
export declare function applyDeploymentResponsePreparedStackExtendGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendConditionStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendConditionStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendConditionStackToJSON(applyDeploymentResponsePreparedStackExtendConditionStack: ApplyDeploymentResponsePreparedStackExtendConditionStack): string;
export declare function applyDeploymentResponsePreparedStackExtendConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendGcpStackToJSON(applyDeploymentResponsePreparedStackExtendGcpStack: ApplyDeploymentResponsePreparedStackExtendGcpStack): string;
export declare function applyDeploymentResponsePreparedStackExtendGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackExtendGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackExtendGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendGcpBindingToJSON(applyDeploymentResponsePreparedStackExtendGcpBinding: ApplyDeploymentResponsePreparedStackExtendGcpBinding): string;
export declare function applyDeploymentResponsePreparedStackExtendGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendGcpGrantToJSON(applyDeploymentResponsePreparedStackExtendGcpGrant: ApplyDeploymentResponsePreparedStackExtendGcpGrant): string;
export declare function applyDeploymentResponsePreparedStackExtendGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcp$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendGcp$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackExtendGcpBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackExtendGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendGcp$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendGcp$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendGcp>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendGcp$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendGcpToJSON(applyDeploymentResponsePreparedStackExtendGcp: ApplyDeploymentResponsePreparedStackExtendGcp): string;
export declare function applyDeploymentResponsePreparedStackExtendGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendPlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendPlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponsePreparedStackExtendAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponsePreparedStackExtendAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponsePreparedStackExtendGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendPlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendPlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendPlatforms$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendPlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendPlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendPlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendPlatforms>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendPlatformsToJSON(applyDeploymentResponsePreparedStackExtendPlatforms: ApplyDeploymentResponsePreparedStackExtendPlatforms): string;
export declare function applyDeploymentResponsePreparedStackExtendPlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendPlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtend$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtend, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtend$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponsePreparedStackExtendPlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtend$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtend$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtend>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtend$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtend$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtend, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtend$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtend$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtend>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtend$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtend$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendToJSON(applyDeploymentResponsePreparedStackExtend: ApplyDeploymentResponsePreparedStackExtend): string;
export declare function applyDeploymentResponsePreparedStackExtendFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtend, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendUnion$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackExtendUnion$Outbound = ApplyDeploymentResponsePreparedStackExtend$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackExtendUnion$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackExtendUnion$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackExtendUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackExtendUnion>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackExtendUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackExtendUnion$Outbound;
}
export declare function applyDeploymentResponsePreparedStackExtendUnionToJSON(applyDeploymentResponsePreparedStackExtendUnion: ApplyDeploymentResponsePreparedStackExtendUnion): string;
export declare function applyDeploymentResponsePreparedStackExtendUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackExtendUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagement1$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement1, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackManagement1$Outbound = {
    extend: {
        [k: string]: Array<ApplyDeploymentResponsePreparedStackExtend$Outbound | string>;
    };
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagement1$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagement1>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackManagement1$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement1$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement1, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement1$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagement1$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagement1>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagement1$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackManagement1$Outbound;
}
export declare function applyDeploymentResponsePreparedStackManagement1ToJSON(applyDeploymentResponsePreparedStackManagement1: ApplyDeploymentResponsePreparedStackManagement1): string;
export declare function applyDeploymentResponsePreparedStackManagement1FromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackManagement1, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagementUnion$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagementUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackManagementUnion$Outbound = ApplyDeploymentResponsePreparedStackManagement1$Outbound | ApplyDeploymentResponsePreparedStackManagement2$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackManagementUnion$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagementUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackManagementUnion$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagementUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagementUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagementUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackManagementUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackManagementUnion>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackManagementUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackManagementUnion$Outbound;
}
export declare function applyDeploymentResponsePreparedStackManagementUnionToJSON(applyDeploymentResponsePreparedStackManagementUnion: ApplyDeploymentResponsePreparedStackManagementUnion): string;
export declare function applyDeploymentResponsePreparedStackManagementUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackManagementUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAwResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAwResourceToJSON(applyDeploymentResponsePreparedStackProfileAwResource: ApplyDeploymentResponsePreparedStackProfileAwResource): string;
export declare function applyDeploymentResponsePreparedStackProfileAwResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAwResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound = {
    condition?: {
        [k: string]: {
            [k: string]: string;
        };
    } | null | undefined;
    resources: Array<string>;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAwStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAwStackToJSON(applyDeploymentResponsePreparedStackProfileAwStack: ApplyDeploymentResponsePreparedStackProfileAwStack): string;
export declare function applyDeploymentResponsePreparedStackProfileAwStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAwStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackProfileAwResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackProfileAwStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAwBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAwBindingToJSON(applyDeploymentResponsePreparedStackProfileAwBinding: ApplyDeploymentResponsePreparedStackProfileAwBinding): string;
export declare function applyDeploymentResponsePreparedStackProfileAwBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAwBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAwGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAwGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAwGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAwGrantToJSON(applyDeploymentResponsePreparedStackProfileAwGrant: ApplyDeploymentResponsePreparedStackProfileAwGrant): string;
export declare function applyDeploymentResponsePreparedStackProfileAwGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAwGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAw$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAw, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAw$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackProfileAwBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackProfileAwGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAw$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAw>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAw$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAw$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAw, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAw$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAw$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAw>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAw$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAw$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAwToJSON(applyDeploymentResponsePreparedStackProfileAw: ApplyDeploymentResponsePreparedStackProfileAw): string;
export declare function applyDeploymentResponsePreparedStackProfileAwFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAw, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAzureResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAzureResourceToJSON(applyDeploymentResponsePreparedStackProfileAzureResource: ApplyDeploymentResponsePreparedStackProfileAzureResource): string;
export declare function applyDeploymentResponsePreparedStackProfileAzureResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAzureResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound = {
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAzureStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAzureStackToJSON(applyDeploymentResponsePreparedStackProfileAzureStack: ApplyDeploymentResponsePreparedStackProfileAzureStack): string;
export declare function applyDeploymentResponsePreparedStackProfileAzureStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAzureStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackProfileAzureResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackProfileAzureStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAzureBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAzureBindingToJSON(applyDeploymentResponsePreparedStackProfileAzureBinding: ApplyDeploymentResponsePreparedStackProfileAzureBinding): string;
export declare function applyDeploymentResponsePreparedStackProfileAzureBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAzureBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzureGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAzureGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzureGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAzureGrantToJSON(applyDeploymentResponsePreparedStackProfileAzureGrant: ApplyDeploymentResponsePreparedStackProfileAzureGrant): string;
export declare function applyDeploymentResponsePreparedStackProfileAzureGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAzureGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzure$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileAzure$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackProfileAzureBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackProfileAzureGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileAzure$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileAzure$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileAzure>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileAzure$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileAzureToJSON(applyDeploymentResponsePreparedStackProfileAzure: ApplyDeploymentResponsePreparedStackProfileAzure): string;
export declare function applyDeploymentResponsePreparedStackProfileAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileConditionResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileConditionResource$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileConditionResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileConditionResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileConditionResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileConditionResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileConditionResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileConditionResourceToJSON(applyDeploymentResponsePreparedStackProfileConditionResource: ApplyDeploymentResponsePreparedStackProfileConditionResource): string;
export declare function applyDeploymentResponsePreparedStackProfileConditionResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileConditionResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpResource$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpResource, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpResource$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpResource>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileGcpResource$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpResource$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpResource, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpResource$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpResource>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileGcpResourceToJSON(applyDeploymentResponsePreparedStackProfileGcpResource: ApplyDeploymentResponsePreparedStackProfileGcpResource): string;
export declare function applyDeploymentResponsePreparedStackProfileGcpResourceFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileGcpResource, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileConditionStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileConditionStack$Outbound = {
    expression: string;
    title: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileConditionStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileConditionStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileConditionStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileConditionStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileConditionStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileConditionStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileConditionStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileConditionStackToJSON(applyDeploymentResponsePreparedStackProfileConditionStack: ApplyDeploymentResponsePreparedStackProfileConditionStack): string;
export declare function applyDeploymentResponsePreparedStackProfileConditionStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileConditionStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound = {
    condition?: any | null | undefined;
    scope: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileGcpStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileGcpStackToJSON(applyDeploymentResponsePreparedStackProfileGcpStack: ApplyDeploymentResponsePreparedStackProfileGcpStack): string;
export declare function applyDeploymentResponsePreparedStackProfileGcpStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileGcpStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpBinding$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpBinding, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound = {
    resource?: ApplyDeploymentResponsePreparedStackProfileGcpResource$Outbound | undefined;
    stack?: ApplyDeploymentResponsePreparedStackProfileGcpStack$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpBinding$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpBinding>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileGcpBinding$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpBinding$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpBinding, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpBinding$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpBinding>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileGcpBindingToJSON(applyDeploymentResponsePreparedStackProfileGcpBinding: ApplyDeploymentResponsePreparedStackProfileGcpBinding): string;
export declare function applyDeploymentResponsePreparedStackProfileGcpBindingFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileGcpBinding, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpGrant$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpGrant, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound = {
    actions?: Array<string> | null | undefined;
    dataActions?: Array<string> | null | undefined;
    permissions?: Array<string> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcpGrant$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpGrant>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileGcpGrant$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpGrant$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpGrant, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpGrant$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcpGrant>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileGcpGrantToJSON(applyDeploymentResponsePreparedStackProfileGcpGrant: ApplyDeploymentResponsePreparedStackProfileGcpGrant): string;
export declare function applyDeploymentResponsePreparedStackProfileGcpGrantFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileGcpGrant, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcp$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileGcp$Outbound = {
    binding: ApplyDeploymentResponsePreparedStackProfileGcpBinding$Outbound;
    grant: ApplyDeploymentResponsePreparedStackProfileGcpGrant$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileGcp$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileGcp$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileGcp>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileGcp$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileGcpToJSON(applyDeploymentResponsePreparedStackProfileGcp: ApplyDeploymentResponsePreparedStackProfileGcp): string;
export declare function applyDeploymentResponsePreparedStackProfileGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfilePlatforms$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfilePlatforms, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound = {
    aws?: Array<ApplyDeploymentResponsePreparedStackProfileAw$Outbound> | null | undefined;
    azure?: Array<ApplyDeploymentResponsePreparedStackProfileAzure$Outbound> | null | undefined;
    gcp?: Array<ApplyDeploymentResponsePreparedStackProfileGcp$Outbound> | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfilePlatforms$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfilePlatforms>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfilePlatforms$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfilePlatforms$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfilePlatforms, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfilePlatforms$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfilePlatforms>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfilePlatformsToJSON(applyDeploymentResponsePreparedStackProfilePlatforms: ApplyDeploymentResponsePreparedStackProfilePlatforms): string;
export declare function applyDeploymentResponsePreparedStackProfilePlatformsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfilePlatforms, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfile$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfile, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfile$Outbound = {
    description: string;
    id: string;
    platforms: ApplyDeploymentResponsePreparedStackProfilePlatforms$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfile$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfile$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfile>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfile$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfile$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfile, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfile$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfile$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfile>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfile$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfile$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileToJSON(applyDeploymentResponsePreparedStackProfile: ApplyDeploymentResponsePreparedStackProfile): string;
export declare function applyDeploymentResponsePreparedStackProfileFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfile, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileUnion$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileUnion, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackProfileUnion$Outbound = ApplyDeploymentResponsePreparedStackProfile$Outbound | string;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackProfileUnion$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileUnion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackProfileUnion$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileUnion$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileUnion, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileUnion$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackProfileUnion$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackProfileUnion>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackProfileUnion$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackProfileUnion$Outbound;
}
export declare function applyDeploymentResponsePreparedStackProfileUnionToJSON(applyDeploymentResponsePreparedStackProfileUnion: ApplyDeploymentResponsePreparedStackProfileUnion): string;
export declare function applyDeploymentResponsePreparedStackProfileUnionFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackProfileUnion, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackPermissions$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackPermissions, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackPermissions$Outbound = {
    management?: ApplyDeploymentResponsePreparedStackManagement1$Outbound | ApplyDeploymentResponsePreparedStackManagement2$Outbound | string | undefined;
    profiles: {
        [k: string]: {
            [k: string]: Array<ApplyDeploymentResponsePreparedStackProfile$Outbound | string>;
        };
    };
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackPermissions$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackPermissions>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackPermissions$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackPermissions$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackPermissions, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackPermissions$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackPermissions$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackPermissions>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackPermissions$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackPermissions$Outbound;
}
export declare function applyDeploymentResponsePreparedStackPermissionsToJSON(applyDeploymentResponsePreparedStackPermissions: ApplyDeploymentResponsePreparedStackPermissions): string;
export declare function applyDeploymentResponsePreparedStackPermissionsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackPermissions, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackConfig$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackConfig$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackConfig$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackConfig>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackConfig$Outbound;
}
export declare function applyDeploymentResponsePreparedStackConfigToJSON(applyDeploymentResponsePreparedStackConfig: ApplyDeploymentResponsePreparedStackConfig): string;
export declare function applyDeploymentResponsePreparedStackConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackDependency$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackDependency$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackDependency$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackDependency>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackDependency$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackDependency$Outbound;
}
export declare function applyDeploymentResponsePreparedStackDependencyToJSON(applyDeploymentResponsePreparedStackDependency: ApplyDeploymentResponsePreparedStackDependency): string;
export declare function applyDeploymentResponsePreparedStackDependencyFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackDependency, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackLifecycle$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePreparedStackLifecycle>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackLifecycle$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePreparedStackLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackLifecycle$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackResources$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackResources, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStackResources$Outbound = {
    config: ApplyDeploymentResponsePreparedStackConfig$Outbound;
    dependencies: Array<ApplyDeploymentResponsePreparedStackDependency$Outbound>;
    lifecycle: string;
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStackResources$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStackResources$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStackResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStackResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStackResources>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStackResources$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStackResources$Outbound;
}
export declare function applyDeploymentResponsePreparedStackResourcesToJSON(applyDeploymentResponsePreparedStackResources: ApplyDeploymentResponsePreparedStackResources): string;
export declare function applyDeploymentResponsePreparedStackResourcesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStackResources, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreparedStack$inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStack, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreparedStack$Outbound = {
    id: string;
    permissions?: ApplyDeploymentResponsePreparedStackPermissions$Outbound | undefined;
    resources: {
        [k: string]: ApplyDeploymentResponsePreparedStackResources$Outbound;
    };
};
/** @internal */
export declare const ApplyDeploymentResponsePreparedStack$outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStack>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreparedStack$ {
    /** @deprecated use `ApplyDeploymentResponsePreparedStack$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStack, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStack$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreparedStack$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreparedStack>;
    /** @deprecated use `ApplyDeploymentResponsePreparedStack$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreparedStack$Outbound;
}
export declare function applyDeploymentResponsePreparedStackToJSON(applyDeploymentResponsePreparedStack: ApplyDeploymentResponsePreparedStack): string;
export declare function applyDeploymentResponsePreparedStackFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreparedStack, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseRuntimeMetadata$inboundSchema: z.ZodType<ApplyDeploymentResponseRuntimeMetadata, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseRuntimeMetadata$Outbound = {
    lastSyncedEnvVarsHash?: string | null | undefined;
    preparedStack?: any | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseRuntimeMetadata$outboundSchema: z.ZodType<ApplyDeploymentResponseRuntimeMetadata$Outbound, z.ZodTypeDef, ApplyDeploymentResponseRuntimeMetadata>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseRuntimeMetadata$ {
    /** @deprecated use `ApplyDeploymentResponseRuntimeMetadata$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseRuntimeMetadata, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseRuntimeMetadata$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseRuntimeMetadata$Outbound, z.ZodTypeDef, ApplyDeploymentResponseRuntimeMetadata>;
    /** @deprecated use `ApplyDeploymentResponseRuntimeMetadata$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseRuntimeMetadata$Outbound;
}
export declare function applyDeploymentResponseRuntimeMetadataToJSON(applyDeploymentResponseRuntimeMetadata: ApplyDeploymentResponseRuntimeMetadata): string;
export declare function applyDeploymentResponseRuntimeMetadataFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseRuntimeMetadata, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatform$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatform>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatform$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStatePlatform$ {
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseStackStateConfig$inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseStackStateConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentResponseStackStateConfig$outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStateConfig$ {
    /** @deprecated use `ApplyDeploymentResponseStackStateConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseStackStateConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateConfig>;
    /** @deprecated use `ApplyDeploymentResponseStackStateConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseStackStateConfig$Outbound;
}
export declare function applyDeploymentResponseStackStateConfigToJSON(applyDeploymentResponseStackStateConfig: ApplyDeploymentResponseStackStateConfig): string;
export declare function applyDeploymentResponseStackStateConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseStackStateConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStateDependency$inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateDependency, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseStackStateDependency$Outbound = {
    id: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentResponseStackStateDependency$outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateDependency>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStateDependency$ {
    /** @deprecated use `ApplyDeploymentResponseStackStateDependency$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateDependency, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseStackStateDependency$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateDependency$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateDependency>;
    /** @deprecated use `ApplyDeploymentResponseStackStateDependency$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseStackStateDependency$Outbound;
}
export declare function applyDeploymentResponseStackStateDependencyToJSON(applyDeploymentResponseStackStateDependency: ApplyDeploymentResponseStackStateDependency): string;
export declare function applyDeploymentResponseStackStateDependencyFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseStackStateDependency, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseError$inboundSchema: z.ZodType<ApplyDeploymentResponseError, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseError$Outbound = {
    code: string;
    context?: any | null | undefined;
    httpStatusCode?: number | null | undefined;
    internal: boolean;
    message: string;
    retryable: boolean;
    source?: any | null | undefined;
};
/** @internal */
export declare const ApplyDeploymentResponseError$outboundSchema: z.ZodType<ApplyDeploymentResponseError$Outbound, z.ZodTypeDef, ApplyDeploymentResponseError>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseError$ {
    /** @deprecated use `ApplyDeploymentResponseError$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseError, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseError$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseError$Outbound, z.ZodTypeDef, ApplyDeploymentResponseError>;
    /** @deprecated use `ApplyDeploymentResponseError$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseError$Outbound;
}
export declare function applyDeploymentResponseErrorToJSON(applyDeploymentResponseError: ApplyDeploymentResponseError): string;
export declare function applyDeploymentResponseErrorFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseError, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStateLifecycle$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStateLifecycle>;
/** @internal */
export declare const ApplyDeploymentResponseStackStateLifecycle$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStateLifecycle>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStateLifecycle$ {
    /** @deprecated use `ApplyDeploymentResponseStackStateLifecycle$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStateLifecycle$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Frozen: "frozen";
        readonly Live: "live";
        readonly LiveOnSetup: "live-on-setup";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseOutputs$inboundSchema: z.ZodType<ApplyDeploymentResponseOutputs, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseOutputs$Outbound = {
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentResponseOutputs$outboundSchema: z.ZodType<ApplyDeploymentResponseOutputs$Outbound, z.ZodTypeDef, ApplyDeploymentResponseOutputs>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseOutputs$ {
    /** @deprecated use `ApplyDeploymentResponseOutputs$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseOutputs, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseOutputs$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseOutputs$Outbound, z.ZodTypeDef, ApplyDeploymentResponseOutputs>;
    /** @deprecated use `ApplyDeploymentResponseOutputs$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseOutputs$Outbound;
}
export declare function applyDeploymentResponseOutputsToJSON(applyDeploymentResponseOutputs: ApplyDeploymentResponseOutputs): string;
export declare function applyDeploymentResponseOutputsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseOutputs, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponsePreviousConfig$inboundSchema: z.ZodType<ApplyDeploymentResponsePreviousConfig, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponsePreviousConfig$Outbound = {
    id: string;
    type: string;
    [additionalProperties: string]: unknown;
};
/** @internal */
export declare const ApplyDeploymentResponsePreviousConfig$outboundSchema: z.ZodType<ApplyDeploymentResponsePreviousConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreviousConfig>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePreviousConfig$ {
    /** @deprecated use `ApplyDeploymentResponsePreviousConfig$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponsePreviousConfig, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponsePreviousConfig$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponsePreviousConfig$Outbound, z.ZodTypeDef, ApplyDeploymentResponsePreviousConfig>;
    /** @deprecated use `ApplyDeploymentResponsePreviousConfig$Outbound` instead. */
    type Outbound = ApplyDeploymentResponsePreviousConfig$Outbound;
}
export declare function applyDeploymentResponsePreviousConfigToJSON(applyDeploymentResponsePreviousConfig: ApplyDeploymentResponsePreviousConfig): string;
export declare function applyDeploymentResponsePreviousConfigFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponsePreviousConfig, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStateStatus$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStateStatus>;
/** @internal */
export declare const ApplyDeploymentResponseStackStateStatus$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStateStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStateStatus$ {
    /** @deprecated use `ApplyDeploymentResponseStackStateStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStateStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly Provisioning: "provisioning";
        readonly ProvisionFailed: "provision-failed";
        readonly Running: "running";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
        readonly RefreshFailed: "refresh-failed";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseStackStateResources$inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateResources, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseStackStateResources$Outbound = {
    _internal?: any | null | undefined;
    bindingParams?: any | null | undefined;
    config: ApplyDeploymentResponseStackStateConfig$Outbound;
    dependencies?: Array<ApplyDeploymentResponseStackStateDependency$Outbound> | undefined;
    error?: any | null | undefined;
    isExternallyProvisioned?: boolean | undefined;
    lastFailedState?: any | null | undefined;
    lifecycle?: any | null | undefined;
    outputs?: any | null | undefined;
    previousConfig?: any | null | undefined;
    retryAttempt?: number | undefined;
    status: string;
    type: string;
};
/** @internal */
export declare const ApplyDeploymentResponseStackStateResources$outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateResources>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStateResources$ {
    /** @deprecated use `ApplyDeploymentResponseStackStateResources$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseStackStateResources, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseStackStateResources$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseStackStateResources$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackStateResources>;
    /** @deprecated use `ApplyDeploymentResponseStackStateResources$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseStackStateResources$Outbound;
}
export declare function applyDeploymentResponseStackStateResourcesToJSON(applyDeploymentResponseStackStateResources: ApplyDeploymentResponseStackStateResources): string;
export declare function applyDeploymentResponseStackStateResourcesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseStackStateResources, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseKubernetesInfrastructurePlatform$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseKubernetesInfrastructurePlatform>;
/** @internal */
export declare const ApplyDeploymentResponseKubernetesInfrastructurePlatform$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseKubernetesInfrastructurePlatform>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseKubernetesInfrastructurePlatform$ {
    /** @deprecated use `ApplyDeploymentResponseKubernetesInfrastructurePlatform$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
    /** @deprecated use `ApplyDeploymentResponseKubernetesInfrastructurePlatform$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
        readonly Gcp: "gcp";
        readonly Azure: "azure";
        readonly Kubernetes: "kubernetes";
        readonly Local: "local";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponsePlatformKubernetes$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatformKubernetes>;
/** @internal */
export declare const ApplyDeploymentResponsePlatformKubernetes$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponsePlatformKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponsePlatformKubernetes$ {
    /** @deprecated use `ApplyDeploymentResponsePlatformKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
    /** @deprecated use `ApplyDeploymentResponsePlatformKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Kubernetes: "kubernetes";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseManagementKubernetes$inboundSchema: z.ZodType<ApplyDeploymentResponseManagementKubernetes, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseManagementKubernetes$Outbound = {
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseManagementKubernetes$outboundSchema: z.ZodType<ApplyDeploymentResponseManagementKubernetes$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementKubernetes>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseManagementKubernetes$ {
    /** @deprecated use `ApplyDeploymentResponseManagementKubernetes$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseManagementKubernetes, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseManagementKubernetes$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseManagementKubernetes$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementKubernetes>;
    /** @deprecated use `ApplyDeploymentResponseManagementKubernetes$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseManagementKubernetes$Outbound;
}
export declare function applyDeploymentResponseManagementKubernetesToJSON(applyDeploymentResponseManagementKubernetes: ApplyDeploymentResponseManagementKubernetes): string;
export declare function applyDeploymentResponseManagementKubernetesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseManagementKubernetes, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseImagePullCredentials$inboundSchema: z.ZodType<ApplyDeploymentResponseImagePullCredentials, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseImagePullCredentials$Outbound = {
    password: string;
    username: string;
};
/** @internal */
export declare const ApplyDeploymentResponseImagePullCredentials$outboundSchema: z.ZodType<ApplyDeploymentResponseImagePullCredentials$Outbound, z.ZodTypeDef, ApplyDeploymentResponseImagePullCredentials>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseImagePullCredentials$ {
    /** @deprecated use `ApplyDeploymentResponseImagePullCredentials$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseImagePullCredentials, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseImagePullCredentials$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseImagePullCredentials$Outbound, z.ZodTypeDef, ApplyDeploymentResponseImagePullCredentials>;
    /** @deprecated use `ApplyDeploymentResponseImagePullCredentials$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseImagePullCredentials$Outbound;
}
export declare function applyDeploymentResponseImagePullCredentialsToJSON(applyDeploymentResponseImagePullCredentials: ApplyDeploymentResponseImagePullCredentials): string;
export declare function applyDeploymentResponseImagePullCredentialsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseImagePullCredentials, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformAzure$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformAzure>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformAzure$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStatePlatformAzure$ {
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Azure: "azure";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseManagementAzure$inboundSchema: z.ZodType<ApplyDeploymentResponseManagementAzure, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseManagementAzure$Outbound = {
    imagePullCredentials?: any | null | undefined;
    managementPrincipalId: string;
    managingTenantId: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseManagementAzure$outboundSchema: z.ZodType<ApplyDeploymentResponseManagementAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementAzure>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseManagementAzure$ {
    /** @deprecated use `ApplyDeploymentResponseManagementAzure$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseManagementAzure, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseManagementAzure$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseManagementAzure$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementAzure>;
    /** @deprecated use `ApplyDeploymentResponseManagementAzure$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseManagementAzure$Outbound;
}
export declare function applyDeploymentResponseManagementAzureToJSON(applyDeploymentResponseManagementAzure: ApplyDeploymentResponseManagementAzure): string;
export declare function applyDeploymentResponseManagementAzureFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseManagementAzure, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformGcp$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformGcp>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformGcp$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStatePlatformGcp$ {
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Gcp: "gcp";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseManagementGcp$inboundSchema: z.ZodType<ApplyDeploymentResponseManagementGcp, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseManagementGcp$Outbound = {
    serviceAccountEmail: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseManagementGcp$outboundSchema: z.ZodType<ApplyDeploymentResponseManagementGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementGcp>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseManagementGcp$ {
    /** @deprecated use `ApplyDeploymentResponseManagementGcp$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseManagementGcp, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseManagementGcp$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseManagementGcp$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementGcp>;
    /** @deprecated use `ApplyDeploymentResponseManagementGcp$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseManagementGcp$Outbound;
}
export declare function applyDeploymentResponseManagementGcpToJSON(applyDeploymentResponseManagementGcp: ApplyDeploymentResponseManagementGcp): string;
export declare function applyDeploymentResponseManagementGcpFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseManagementGcp, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformAws$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformAws>;
/** @internal */
export declare const ApplyDeploymentResponseStackStatePlatformAws$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStackStatePlatformAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackStatePlatformAws$ {
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformAws$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStackStatePlatformAws$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Aws: "aws";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseManagementAws$inboundSchema: z.ZodType<ApplyDeploymentResponseManagementAws, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseManagementAws$Outbound = {
    managingRoleArn: string;
    platform: string;
};
/** @internal */
export declare const ApplyDeploymentResponseManagementAws$outboundSchema: z.ZodType<ApplyDeploymentResponseManagementAws$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementAws>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseManagementAws$ {
    /** @deprecated use `ApplyDeploymentResponseManagementAws$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseManagementAws, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseManagementAws$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseManagementAws$Outbound, z.ZodTypeDef, ApplyDeploymentResponseManagementAws>;
    /** @deprecated use `ApplyDeploymentResponseManagementAws$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseManagementAws$Outbound;
}
export declare function applyDeploymentResponseManagementAwsToJSON(applyDeploymentResponseManagementAws: ApplyDeploymentResponseManagementAws): string;
export declare function applyDeploymentResponseManagementAwsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseManagementAws, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseRemoteCapabilities$inboundSchema: z.ZodType<ApplyDeploymentResponseRemoteCapabilities, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseRemoteCapabilities$Outbound = {
    autoUpdates: boolean;
    heartbeat: boolean;
    monitoring: boolean;
};
/** @internal */
export declare const ApplyDeploymentResponseRemoteCapabilities$outboundSchema: z.ZodType<ApplyDeploymentResponseRemoteCapabilities$Outbound, z.ZodTypeDef, ApplyDeploymentResponseRemoteCapabilities>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseRemoteCapabilities$ {
    /** @deprecated use `ApplyDeploymentResponseRemoteCapabilities$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseRemoteCapabilities, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseRemoteCapabilities$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseRemoteCapabilities$Outbound, z.ZodTypeDef, ApplyDeploymentResponseRemoteCapabilities>;
    /** @deprecated use `ApplyDeploymentResponseRemoteCapabilities$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseRemoteCapabilities$Outbound;
}
export declare function applyDeploymentResponseRemoteCapabilitiesToJSON(applyDeploymentResponseRemoteCapabilities: ApplyDeploymentResponseRemoteCapabilities): string;
export declare function applyDeploymentResponseRemoteCapabilitiesFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseRemoteCapabilities, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseSettings$inboundSchema: z.ZodType<ApplyDeploymentResponseSettings, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseSettings$Outbound = {
    kubernetesInfrastructurePlatform?: any | null | undefined;
    management?: any | null | undefined;
    remoteCapabilities: ApplyDeploymentResponseRemoteCapabilities$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseSettings$outboundSchema: z.ZodType<ApplyDeploymentResponseSettings$Outbound, z.ZodTypeDef, ApplyDeploymentResponseSettings>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseSettings$ {
    /** @deprecated use `ApplyDeploymentResponseSettings$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseSettings, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseSettings$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseSettings$Outbound, z.ZodTypeDef, ApplyDeploymentResponseSettings>;
    /** @deprecated use `ApplyDeploymentResponseSettings$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseSettings$Outbound;
}
export declare function applyDeploymentResponseSettingsToJSON(applyDeploymentResponseSettings: ApplyDeploymentResponseSettings): string;
export declare function applyDeploymentResponseSettingsFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseSettings, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStackState$inboundSchema: z.ZodType<ApplyDeploymentResponseStackState, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseStackState$Outbound = {
    platform: string;
    resourcePrefix: string;
    resources: {
        [k: string]: ApplyDeploymentResponseStackStateResources$Outbound;
    };
    settings: ApplyDeploymentResponseSettings$Outbound;
};
/** @internal */
export declare const ApplyDeploymentResponseStackState$outboundSchema: z.ZodType<ApplyDeploymentResponseStackState$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackState>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStackState$ {
    /** @deprecated use `ApplyDeploymentResponseStackState$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseStackState, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseStackState$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseStackState$Outbound, z.ZodTypeDef, ApplyDeploymentResponseStackState>;
    /** @deprecated use `ApplyDeploymentResponseStackState$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseStackState$Outbound;
}
export declare function applyDeploymentResponseStackStateToJSON(applyDeploymentResponseStackState: ApplyDeploymentResponseStackState): string;
export declare function applyDeploymentResponseStackStateFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseStackState, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponseStatus$inboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStatus>;
/** @internal */
export declare const ApplyDeploymentResponseStatus$outboundSchema: z.ZodNativeEnum<typeof ApplyDeploymentResponseStatus>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseStatus$ {
    /** @deprecated use `ApplyDeploymentResponseStatus$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
    /** @deprecated use `ApplyDeploymentResponseStatus$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly Pending: "pending";
        readonly InitialSetup: "initial-setup";
        readonly InitialSetupFailed: "initial-setup-failed";
        readonly Provisioning: "provisioning";
        readonly ProvisioningFailed: "provisioning-failed";
        readonly Running: "running";
        readonly RefreshFailed: "refresh-failed";
        readonly UpdatePending: "update-pending";
        readonly Updating: "updating";
        readonly UpdateFailed: "update-failed";
        readonly DeletePending: "delete-pending";
        readonly Deleting: "deleting";
        readonly DeleteFailed: "delete-failed";
        readonly Deleted: "deleted";
    }>;
}
/** @internal */
export declare const ApplyDeploymentResponseCurrent$inboundSchema: z.ZodType<ApplyDeploymentResponseCurrent, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponseCurrent$Outbound = {
    currentStack?: any | null | undefined;
    environmentInfo?: any | null | undefined;
    platform: string;
    retryRequested?: boolean | undefined;
    runtimeMetadata?: any | null | undefined;
    stackState?: any | null | undefined;
    status: string;
};
/** @internal */
export declare const ApplyDeploymentResponseCurrent$outboundSchema: z.ZodType<ApplyDeploymentResponseCurrent$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrent>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponseCurrent$ {
    /** @deprecated use `ApplyDeploymentResponseCurrent$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponseCurrent, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponseCurrent$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponseCurrent$Outbound, z.ZodTypeDef, ApplyDeploymentResponseCurrent>;
    /** @deprecated use `ApplyDeploymentResponseCurrent$Outbound` instead. */
    type Outbound = ApplyDeploymentResponseCurrent$Outbound;
}
export declare function applyDeploymentResponseCurrentToJSON(applyDeploymentResponseCurrent: ApplyDeploymentResponseCurrent): string;
export declare function applyDeploymentResponseCurrentFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponseCurrent, SDKValidationError>;
/** @internal */
export declare const ApplyDeploymentResponse$inboundSchema: z.ZodType<ApplyDeploymentResponse, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentResponse$Outbound = {
    current: ApplyDeploymentResponseCurrent$Outbound | null;
    session: string | null;
};
/** @internal */
export declare const ApplyDeploymentResponse$outboundSchema: z.ZodType<ApplyDeploymentResponse$Outbound, z.ZodTypeDef, ApplyDeploymentResponse>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentResponse$ {
    /** @deprecated use `ApplyDeploymentResponse$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentResponse, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentResponse$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentResponse$Outbound, z.ZodTypeDef, ApplyDeploymentResponse>;
    /** @deprecated use `ApplyDeploymentResponse$Outbound` instead. */
    type Outbound = ApplyDeploymentResponse$Outbound;
}
export declare function applyDeploymentResponseToJSON(applyDeploymentResponse: ApplyDeploymentResponse): string;
export declare function applyDeploymentResponseFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentResponse, SDKValidationError>;
//# sourceMappingURL=applydeploymentresponse.d.ts.map