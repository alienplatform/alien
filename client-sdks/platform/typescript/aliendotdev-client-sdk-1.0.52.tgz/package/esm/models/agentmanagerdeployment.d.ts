import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Deployment status of the internal agent
 */
export declare const AgentManagerDeploymentStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status of the internal agent
 */
export type AgentManagerDeploymentStatus = ClosedEnum<typeof AgentManagerDeploymentStatus>;
export type AgentManagerDeploymentResources = {
    /**
     * Resource type
     */
    type: string;
    /**
     * Resource status
     */
    status: string;
    /**
     * Resource outputs
     */
    outputs?: {
        [k: string]: any | null;
    } | undefined;
};
export type AgentManagerDeployment = {
    /**
     * Platform of the internal agent
     */
    platform: string;
    /**
     * Deployment status of the internal agent
     */
    status: AgentManagerDeploymentStatus;
    /**
     * Latest provision / upgrade / delete error
     */
    error?: any | null | undefined;
    /**
     * Simplified stack state resources
     */
    resources: {
        [k: string]: AgentManagerDeploymentResources;
    };
    /**
     * Agent manager environment info
     */
    environmentInfo?: any | null | undefined;
};
/** @internal */
export declare const AgentManagerDeploymentStatus$inboundSchema: z.ZodEnum<typeof AgentManagerDeploymentStatus>;
/** @internal */
export declare const AgentManagerDeploymentResources$inboundSchema: z.ZodType<AgentManagerDeploymentResources, unknown>;
export declare function agentManagerDeploymentResourcesFromJSON(jsonString: string): SafeParseResult<AgentManagerDeploymentResources, SDKValidationError>;
/** @internal */
export declare const AgentManagerDeployment$inboundSchema: z.ZodType<AgentManagerDeployment, unknown>;
export declare function agentManagerDeploymentFromJSON(jsonString: string): SafeParseResult<AgentManagerDeployment, SDKValidationError>;
//# sourceMappingURL=agentmanagerdeployment.d.ts.map