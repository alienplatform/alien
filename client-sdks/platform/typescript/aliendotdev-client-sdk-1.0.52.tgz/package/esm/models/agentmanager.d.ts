import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { AgentManagerStatus } from "./agentmanagerstatus.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Represents the target cloud platform.
 */
export declare const AgentManagerTarget: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type AgentManagerTarget = ClosedEnum<typeof AgentManagerTarget>;
export declare const AgentManagerPlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type AgentManagerPlatformKubernetes = ClosedEnum<typeof AgentManagerPlatformKubernetes>;
export type AgentManagerManagementConfigKubernetes = {
    platform: AgentManagerPlatformKubernetes;
};
export declare const AgentManagerPlatformAzure: {
    readonly Azure: "azure";
};
export type AgentManagerPlatformAzure = ClosedEnum<typeof AgentManagerPlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type AgentManagerManagementConfigAzure = {
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: AgentManagerPlatformAzure;
};
export declare const AgentManagerPlatformGcp: {
    readonly Gcp: "gcp";
};
export type AgentManagerPlatformGcp = ClosedEnum<typeof AgentManagerPlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type AgentManagerManagementConfigGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: AgentManagerPlatformGcp;
};
export declare const AgentManagerPlatformAws: {
    readonly Aws: "aws";
};
export type AgentManagerPlatformAws = ClosedEnum<typeof AgentManagerPlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type AgentManagerManagementConfigAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: AgentManagerPlatformAws;
};
/**
 * Management configuration for cross-account access (self-reported via heartbeat)
 */
export type AgentManagerManagementConfigUnion = AgentManagerManagementConfigAzure | AgentManagerManagementConfigAws | AgentManagerManagementConfigGcp | AgentManagerManagementConfigKubernetes | any;
/**
 * Agent manager schema
 */
export type AgentManager = {
    id: string;
    /**
     * Display name of the agent manager
     */
    name: string;
    /**
     * Platforms this agent manager can handle
     */
    targets: Array<AgentManagerTarget>;
    /**
     * Agent Manager URL (self-reported via heartbeat). DeepStore endpoints are exposed through this URL (e.g., {url}/v1/logs)
     */
    url?: string | null | undefined;
    /**
     * Management configuration for cross-account access (self-reported via heartbeat)
     */
    managementConfig?: AgentManagerManagementConfigAzure | AgentManagerManagementConfigAws | AgentManagerManagementConfigGcp | AgentManagerManagementConfigKubernetes | any | null | undefined;
    /**
     * Whether this is a system agent manager (Alien-hosted)
     */
    isSystem: boolean;
    /**
     * The workspace ID (for system managers, this is ALIEN_WORKSPACE_ID)
     */
    workspaceId: string;
    /**
     * Current health status
     */
    status: AgentManagerStatus;
    /**
     * Agent Manager version (self-reported via heartbeat)
     */
    version?: string | null | undefined;
    /**
     * Timestamp of the last received heartbeat from the agent manager
     */
    lastHeartbeatAt?: Date | null | undefined;
    /**
     * ID of the logs database associated with this agent manager
     */
    logsDatabaseId?: string | null | undefined;
    /**
     * Number of agents currently being managed by this agent manager
     */
    managedAgentCount: number;
    /**
     * Timestamp when the agent manager was created
     */
    createdAt: Date;
};
/** @internal */
export declare const AgentManagerTarget$inboundSchema: z.ZodEnum<typeof AgentManagerTarget>;
/** @internal */
export declare const AgentManagerPlatformKubernetes$inboundSchema: z.ZodEnum<typeof AgentManagerPlatformKubernetes>;
/** @internal */
export declare const AgentManagerManagementConfigKubernetes$inboundSchema: z.ZodType<AgentManagerManagementConfigKubernetes, unknown>;
export declare function agentManagerManagementConfigKubernetesFromJSON(jsonString: string): SafeParseResult<AgentManagerManagementConfigKubernetes, SDKValidationError>;
/** @internal */
export declare const AgentManagerPlatformAzure$inboundSchema: z.ZodEnum<typeof AgentManagerPlatformAzure>;
/** @internal */
export declare const AgentManagerManagementConfigAzure$inboundSchema: z.ZodType<AgentManagerManagementConfigAzure, unknown>;
export declare function agentManagerManagementConfigAzureFromJSON(jsonString: string): SafeParseResult<AgentManagerManagementConfigAzure, SDKValidationError>;
/** @internal */
export declare const AgentManagerPlatformGcp$inboundSchema: z.ZodEnum<typeof AgentManagerPlatformGcp>;
/** @internal */
export declare const AgentManagerManagementConfigGcp$inboundSchema: z.ZodType<AgentManagerManagementConfigGcp, unknown>;
export declare function agentManagerManagementConfigGcpFromJSON(jsonString: string): SafeParseResult<AgentManagerManagementConfigGcp, SDKValidationError>;
/** @internal */
export declare const AgentManagerPlatformAws$inboundSchema: z.ZodEnum<typeof AgentManagerPlatformAws>;
/** @internal */
export declare const AgentManagerManagementConfigAws$inboundSchema: z.ZodType<AgentManagerManagementConfigAws, unknown>;
export declare function agentManagerManagementConfigAwsFromJSON(jsonString: string): SafeParseResult<AgentManagerManagementConfigAws, SDKValidationError>;
/** @internal */
export declare const AgentManagerManagementConfigUnion$inboundSchema: z.ZodType<AgentManagerManagementConfigUnion, unknown>;
export declare function agentManagerManagementConfigUnionFromJSON(jsonString: string): SafeParseResult<AgentManagerManagementConfigUnion, SDKValidationError>;
/** @internal */
export declare const AgentManager$inboundSchema: z.ZodType<AgentManager, unknown>;
export declare function agentManagerFromJSON(jsonString: string): SafeParseResult<AgentManager, SDKValidationError>;
//# sourceMappingURL=agentmanager.d.ts.map