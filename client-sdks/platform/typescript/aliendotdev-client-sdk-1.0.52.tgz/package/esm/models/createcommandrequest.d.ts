import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
/**
 * Initial state (PENDING_UPLOAD if params require upload, PENDING if inline)
 */
export declare const InitialState: {
    readonly PendingUpload: "PENDING_UPLOAD";
    readonly Pending: "PENDING";
    readonly Dispatched: "DISPATCHED";
    readonly Succeeded: "SUCCEEDED";
    readonly Failed: "FAILED";
    readonly Expired: "EXPIRED";
};
/**
 * Initial state (PENDING_UPLOAD if params require upload, PENDING if inline)
 */
export type InitialState = ClosedEnum<typeof InitialState>;
export type CreateCommandRequest = {
    /**
     * Target agent ID
     */
    agentId: string;
    /**
     * Command name (e.g., 'analyze-repository')
     */
    name: string;
    /**
     * Initial state (PENDING_UPLOAD if params require upload, PENDING if inline)
     */
    initialState?: InitialState | undefined;
    /**
     * Optional deadline for command execution
     */
    deadline?: Date | null | undefined;
    /**
     * Size of command params in bytes
     */
    requestSizeBytes?: number | undefined;
};
/** @internal */
export declare const InitialState$outboundSchema: z.ZodEnum<typeof InitialState>;
/** @internal */
export type CreateCommandRequest$Outbound = {
    agentId: string;
    name: string;
    initialState?: string | undefined;
    deadline?: string | null | undefined;
    requestSizeBytes?: number | undefined;
};
/** @internal */
export declare const CreateCommandRequest$outboundSchema: z.ZodType<CreateCommandRequest$Outbound, CreateCommandRequest>;
export declare function createCommandRequestToJSON(createCommandRequest: CreateCommandRequest): string;
//# sourceMappingURL=createcommandrequest.d.ts.map