import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export declare const APIKeyType: {
    readonly Workspace: "workspace";
    readonly Project: "project";
    readonly Agent: "agent";
    readonly DeploymentGroup: "deployment-group";
    readonly AgentManager: "agent-manager";
};
export type APIKeyType = ClosedEnum<typeof APIKeyType>;
/**
 * User information associated with the API key
 */
export type CreatedByUser = {
    id: string;
    email: string;
    image: string | null;
};
/**
 * API key information
 */
export type APIKey = {
    /**
     * Unique identifier for the api key.
     */
    id: string;
    description: string | null;
    keyPrefix: string;
    type: APIKeyType;
    role: string;
    workspaceId: string;
    projectId: string | null;
    agentId: string | null;
    deploymentGroupId: string | null;
    agentManagerId: string | null;
    enabled: boolean;
    createdAt: Date;
    expiresAt: Date | null;
    lastUsedAt: Date | null;
    revokedAt: Date | null;
    /**
     * User information associated with the API key
     */
    createdByUser: CreatedByUser | null;
};
/** @internal */
export declare const APIKeyType$inboundSchema: z.ZodEnum<typeof APIKeyType>;
/** @internal */
export declare const CreatedByUser$inboundSchema: z.ZodType<CreatedByUser, unknown>;
export declare function createdByUserFromJSON(jsonString: string): SafeParseResult<CreatedByUser, SDKValidationError>;
/** @internal */
export declare const APIKey$inboundSchema: z.ZodType<APIKey, unknown>;
export declare function apiKeyFromJSON(jsonString: string): SafeParseResult<APIKey, SDKValidationError>;
//# sourceMappingURL=apikey.d.ts.map