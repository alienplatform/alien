import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type Arc = {
    /**
     * Agent Manager URL for ARC commands
     */
    url: string;
    /**
     * Agent ID to use in ARC requests
     */
    agentId: string;
};
export type AgentInfoResources = {
    /**
     * Resource type identifier that determines the specific kind of resource. This field is used for polymorphic deserialization and resource-specific behavior.
     */
    type: string;
    /**
     * Public URL if resource has public ingress
     */
    publicUrl?: string | undefined;
};
/**
 * Deployment status in the deployment lifecycle
 */
export declare const AgentInfoStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type AgentInfoStatus = ClosedEnum<typeof AgentInfoStatus>;
export type AgentInfo = {
    arc: Arc;
    /**
     * Deployed resources and their URLs
     */
    resources: {
        [k: string]: AgentInfoResources;
    };
    /**
     * Deployment status in the deployment lifecycle
     */
    status: AgentInfoStatus;
    platform: string;
};
/** @internal */
export declare const Arc$inboundSchema: z.ZodType<Arc, unknown>;
export declare function arcFromJSON(jsonString: string): SafeParseResult<Arc, SDKValidationError>;
/** @internal */
export declare const AgentInfoResources$inboundSchema: z.ZodType<AgentInfoResources, unknown>;
export declare function agentInfoResourcesFromJSON(jsonString: string): SafeParseResult<AgentInfoResources, SDKValidationError>;
/** @internal */
export declare const AgentInfoStatus$inboundSchema: z.ZodEnum<typeof AgentInfoStatus>;
/** @internal */
export declare const AgentInfo$inboundSchema: z.ZodType<AgentInfo, unknown>;
export declare function agentInfoFromJSON(jsonString: string): SafeParseResult<AgentInfo, SDKValidationError>;
//# sourceMappingURL=agentinfo.d.ts.map