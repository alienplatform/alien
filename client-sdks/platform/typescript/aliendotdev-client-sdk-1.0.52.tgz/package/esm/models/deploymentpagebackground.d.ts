import * as z from "zod/v4";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
/**
 * Type of animated background to display on the deployment page.
 */
export declare const DeploymentPageBackgroundType: {
    readonly GradientMesh: "gradient-mesh";
    readonly FloatingOrbs: "floating-orbs";
    readonly FlickeringGrid: "flickering-grid";
    readonly BubbleGlow: "bubble-glow";
    readonly ParticleField: "particle-field";
};
/**
 * Type of animated background to display on the deployment page.
 */
export type DeploymentPageBackgroundType = ClosedEnum<typeof DeploymentPageBackgroundType>;
/**
 * Color mode for the background animation.
 */
export declare const DeploymentPageBackgroundMode: {
    readonly Dark: "dark";
    readonly Light: "light";
};
/**
 * Color mode for the background animation.
 */
export type DeploymentPageBackgroundMode = ClosedEnum<typeof DeploymentPageBackgroundMode>;
/**
 * Color scheme for the background animation.
 */
export declare const DeploymentPageBackgroundColorScheme: {
    readonly Blue: "blue";
    readonly Purple: "purple";
    readonly Green: "green";
    readonly Orange: "orange";
    readonly Pink: "pink";
};
/**
 * Color scheme for the background animation.
 */
export type DeploymentPageBackgroundColorScheme = ClosedEnum<typeof DeploymentPageBackgroundColorScheme>;
export type DeploymentPageBackground = {
    /**
     * Type of animated background to display on the deployment page.
     */
    type: DeploymentPageBackgroundType;
    /**
     * Color mode for the background animation.
     */
    mode: DeploymentPageBackgroundMode;
    /**
     * Color scheme for the background animation.
     */
    colorScheme: DeploymentPageBackgroundColorScheme;
};
/** @internal */
export declare const DeploymentPageBackgroundType$inboundSchema: z.ZodEnum<typeof DeploymentPageBackgroundType>;
/** @internal */
export declare const DeploymentPageBackgroundMode$inboundSchema: z.ZodEnum<typeof DeploymentPageBackgroundMode>;
/** @internal */
export declare const DeploymentPageBackgroundColorScheme$inboundSchema: z.ZodEnum<typeof DeploymentPageBackgroundColorScheme>;
/** @internal */
export declare const DeploymentPageBackground$inboundSchema: z.ZodType<DeploymentPageBackground, unknown>;
export declare function deploymentPageBackgroundFromJSON(jsonString: string): SafeParseResult<DeploymentPageBackground, SDKValidationError>;
//# sourceMappingURL=deploymentpagebackground.d.ts.map