import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type CommandPayloadResponse = {
    /**
     * Unique identifier for the command.
     */
    commandId: string;
    /**
     * Command input parameters (decoded from agent manager KV)
     */
    params?: any | null | undefined;
    /**
     * Command response data (decoded from agent manager KV)
     */
    response?: any | null | undefined;
};
/** @internal */
export declare const CommandPayloadResponse$inboundSchema: z.ZodType<CommandPayloadResponse, unknown>;
export declare function commandPayloadResponseFromJSON(jsonString: string): SafeParseResult<CommandPayloadResponse, SDKValidationError>;
//# sourceMappingURL=commandpayloadresponse.d.ts.map