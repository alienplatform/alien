import * as z from "zod/v4";
export type DeleteAPIKeysRequest = {
    ids: Array<string>;
};
/** @internal */
export type DeleteAPIKeysRequest$Outbound = {
    ids: Array<string>;
};
/** @internal */
export declare const DeleteAPIKeysRequest$outboundSchema: z.ZodType<DeleteAPIKeysRequest$Outbound, DeleteAPIKeysRequest>;
export declare function deleteAPIKeysRequestToJSON(deleteAPIKeysRequest: DeleteAPIKeysRequest): string;
//# sourceMappingURL=deleteapikeysrequest.d.ts.map