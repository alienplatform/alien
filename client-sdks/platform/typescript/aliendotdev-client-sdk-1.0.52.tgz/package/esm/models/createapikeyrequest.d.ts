import * as z from "zod/v4";
import { Scope, Scope$Outbound } from "./scope.js";
/**
 * Request schema for creating a new API key
 */
export type CreateAPIKeyRequest = {
    description: string | null;
    /**
     * Scope and role configuration for service accounts
     */
    scope: Scope;
    /**
     * Optional expiration date for the API key
     */
    expiresAt: Date | null;
};
/** @internal */
export type CreateAPIKeyRequest$Outbound = {
    description: string | null;
    scope: Scope$Outbound;
    expiresAt: string | null;
};
/** @internal */
export declare const CreateAPIKeyRequest$outboundSchema: z.ZodType<CreateAPIKeyRequest$Outbound, CreateAPIKeyRequest>;
export declare function createAPIKeyRequestToJSON(createAPIKeyRequest: CreateAPIKeyRequest): string;
//# sourceMappingURL=createapikeyrequest.d.ts.map