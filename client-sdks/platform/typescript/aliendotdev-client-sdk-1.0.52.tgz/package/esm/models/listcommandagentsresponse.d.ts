import * as z from "zod/v4";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./errors/sdkvalidationerror.js";
export type ListCommandAgentsResponseDeploymentGroup = {
    id: string;
    name: string;
};
export type ListCommandAgentsResponseAgent = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    name: string;
    deploymentGroup?: ListCommandAgentsResponseDeploymentGroup | undefined;
};
export type ListCommandAgentsResponse = {
    agents: Array<ListCommandAgentsResponseAgent>;
};
/** @internal */
export declare const ListCommandAgentsResponseDeploymentGroup$inboundSchema: z.ZodType<ListCommandAgentsResponseDeploymentGroup, unknown>;
export declare function listCommandAgentsResponseDeploymentGroupFromJSON(jsonString: string): SafeParseResult<ListCommandAgentsResponseDeploymentGroup, SDKValidationError>;
/** @internal */
export declare const ListCommandAgentsResponseAgent$inboundSchema: z.ZodType<ListCommandAgentsResponseAgent, unknown>;
export declare function listCommandAgentsResponseAgentFromJSON(jsonString: string): SafeParseResult<ListCommandAgentsResponseAgent, SDKValidationError>;
/** @internal */
export declare const ListCommandAgentsResponse$inboundSchema: z.ZodType<ListCommandAgentsResponse, unknown>;
export declare function listCommandAgentsResponseFromJSON(jsonString: string): SafeParseResult<ListCommandAgentsResponse, SDKValidationError>;
//# sourceMappingURL=listcommandagentsresponse.d.ts.map