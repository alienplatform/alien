import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
/**
 * Deployment status in the deployment lifecycle
 */
export declare const ListAgentsStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type ListAgentsStatus = ClosedEnum<typeof ListAgentsStatus>;
/**
 * Represents the target cloud platform.
 */
export declare const ListAgentsPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type ListAgentsPlatform = ClosedEnum<typeof ListAgentsPlatform>;
export declare const ListAgentsInclude: {
    readonly Release: "release";
    readonly DeploymentGroup: "deploymentGroup";
    readonly Project: "project";
};
export type ListAgentsInclude = ClosedEnum<typeof ListAgentsInclude>;
export type ListAgentsRequest = {
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Filter by deployment group ID or name
     */
    deploymentGroup?: string | undefined;
    /**
     * Filter by agent manager ID
     */
    agentManagerId?: string | undefined;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Search agents by name or deployment group name
     */
    search?: string | undefined;
    /**
     * Filter agents by status
     */
    status?: Array<ListAgentsStatus> | undefined;
    /**
     * Filter agents by platform
     */
    platform?: Array<ListAgentsPlatform> | undefined;
    /**
     * Optional fields to include: release, deploymentGroup, project
     */
    include?: Array<ListAgentsInclude> | undefined;
    /**
     * Maximum number of items to return per page
     */
    limit?: number | undefined;
    /**
     * Cursor for pagination - omit for first page
     */
    cursor?: string | undefined;
};
/**
 * Paginated response
 */
export type ListAgentsResponse = {
    /**
     * Items in this page
     */
    items: Array<models.AgentListItemResponse>;
    /**
     * Cursor for the next page, null if last page
     */
    nextCursor: string | null;
};
/** @internal */
export declare const ListAgentsStatus$outboundSchema: z.ZodEnum<typeof ListAgentsStatus>;
/** @internal */
export declare const ListAgentsPlatform$outboundSchema: z.ZodEnum<typeof ListAgentsPlatform>;
/** @internal */
export declare const ListAgentsInclude$outboundSchema: z.ZodEnum<typeof ListAgentsInclude>;
/** @internal */
export type ListAgentsRequest$Outbound = {
    project?: string | undefined;
    deploymentGroup?: string | undefined;
    agentManagerId?: string | undefined;
    workspace?: string | undefined;
    search?: string | undefined;
    status?: Array<string> | undefined;
    platform?: Array<string> | undefined;
    include?: Array<string> | undefined;
    limit: number;
    cursor?: string | undefined;
};
/** @internal */
export declare const ListAgentsRequest$outboundSchema: z.ZodType<ListAgentsRequest$Outbound, ListAgentsRequest>;
export declare function listAgentsRequestToJSON(listAgentsRequest: ListAgentsRequest): string;
/** @internal */
export declare const ListAgentsResponse$inboundSchema: z.ZodType<ListAgentsResponse, unknown>;
export declare function listAgentsResponseFromJSON(jsonString: string): SafeParseResult<ListAgentsResponse, SDKValidationError>;
//# sourceMappingURL=listagents.d.ts.map