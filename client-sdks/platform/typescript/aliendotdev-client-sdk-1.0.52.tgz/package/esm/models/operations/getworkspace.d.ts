import * as z from "zod/v4";
export type GetWorkspaceRequest = {
    /**
     * Unique identifier for the workspace.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetWorkspaceRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetWorkspaceRequest$outboundSchema: z.ZodType<GetWorkspaceRequest$Outbound, GetWorkspaceRequest>;
export declare function getWorkspaceRequestToJSON(getWorkspaceRequest: GetWorkspaceRequest): string;
//# sourceMappingURL=getworkspace.d.ts.map