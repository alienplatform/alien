import * as z from "zod/v4";
export type GetAgentManagerRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetAgentManagerRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentManagerRequest$outboundSchema: z.ZodType<GetAgentManagerRequest$Outbound, GetAgentManagerRequest>;
export declare function getAgentManagerRequestToJSON(getAgentManagerRequest: GetAgentManagerRequest): string;
//# sourceMappingURL=getagentmanager.d.ts.map