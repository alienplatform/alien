import * as z from "zod/v4";
export type GetAgentManagerDeploymentRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetAgentManagerDeploymentRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentManagerDeploymentRequest$outboundSchema: z.ZodType<GetAgentManagerDeploymentRequest$Outbound, GetAgentManagerDeploymentRequest>;
export declare function getAgentManagerDeploymentRequestToJSON(getAgentManagerDeploymentRequest: GetAgentManagerDeploymentRequest): string;
//# sourceMappingURL=getagentmanagerdeployment.d.ts.map