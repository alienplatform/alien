import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type ConnectAgentToGoogleCloudRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    redirectUrl?: string | undefined;
    /**
     * The current workspace. If not provided, the user's last workspace will be used.
     */
    workspace?: string | undefined;
    /**
     * GCP project ID
     */
    projectId: string;
    /**
     * GCP region
     */
    region: string;
};
/** @internal */
export declare const ConnectAgentToGoogleCloudRequest$inboundSchema: z.ZodType<ConnectAgentToGoogleCloudRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type ConnectAgentToGoogleCloudRequest$Outbound = {
    id: string;
    redirectUrl?: string | undefined;
    workspace?: string | undefined;
    projectId: string;
    region: string;
};
/** @internal */
export declare const ConnectAgentToGoogleCloudRequest$outboundSchema: z.ZodType<ConnectAgentToGoogleCloudRequest$Outbound, z.ZodTypeDef, ConnectAgentToGoogleCloudRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ConnectAgentToGoogleCloudRequest$ {
    /** @deprecated use `ConnectAgentToGoogleCloudRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ConnectAgentToGoogleCloudRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `ConnectAgentToGoogleCloudRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ConnectAgentToGoogleCloudRequest$Outbound, z.ZodTypeDef, ConnectAgentToGoogleCloudRequest>;
    /** @deprecated use `ConnectAgentToGoogleCloudRequest$Outbound` instead. */
    type Outbound = ConnectAgentToGoogleCloudRequest$Outbound;
}
export declare function connectAgentToGoogleCloudRequestToJSON(connectAgentToGoogleCloudRequest: ConnectAgentToGoogleCloudRequest): string;
export declare function connectAgentToGoogleCloudRequestFromJSON(jsonString: string): SafeParseResult<ConnectAgentToGoogleCloudRequest, SDKValidationError>;
//# sourceMappingURL=connectagenttogooglecloud.d.ts.map