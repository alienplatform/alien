import * as z from "zod/v4";
export type GetProjectRequest = {
    /**
     * Project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetProjectRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetProjectRequest$outboundSchema: z.ZodType<GetProjectRequest$Outbound, GetProjectRequest>;
export declare function getProjectRequestToJSON(getProjectRequest: GetProjectRequest): string;
//# sourceMappingURL=getproject.d.ts.map