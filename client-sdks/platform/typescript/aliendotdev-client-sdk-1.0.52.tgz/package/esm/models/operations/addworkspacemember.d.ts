import * as z from "zod/v4";
import * as models from "../index.js";
export type AddWorkspaceMemberRequestBody = {
    /**
     * Email of the user to add
     */
    email: string;
    role: models.WorkspaceRole;
};
export type AddWorkspaceMemberRequest = {
    /**
     * Unique identifier for the workspace.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    requestBody?: AddWorkspaceMemberRequestBody | undefined;
};
/** @internal */
export type AddWorkspaceMemberRequestBody$Outbound = {
    email: string;
    role: string;
};
/** @internal */
export declare const AddWorkspaceMemberRequestBody$outboundSchema: z.ZodType<AddWorkspaceMemberRequestBody$Outbound, AddWorkspaceMemberRequestBody>;
export declare function addWorkspaceMemberRequestBodyToJSON(addWorkspaceMemberRequestBody: AddWorkspaceMemberRequestBody): string;
/** @internal */
export type AddWorkspaceMemberRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    RequestBody?: AddWorkspaceMemberRequestBody$Outbound | undefined;
};
/** @internal */
export declare const AddWorkspaceMemberRequest$outboundSchema: z.ZodType<AddWorkspaceMemberRequest$Outbound, AddWorkspaceMemberRequest>;
export declare function addWorkspaceMemberRequestToJSON(addWorkspaceMemberRequest: AddWorkspaceMemberRequest): string;
//# sourceMappingURL=addworkspacemember.d.ts.map