import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateAPIKeyRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createAPIKeyRequest?: models.CreateAPIKeyRequest | undefined;
};
/** @internal */
export type CreateAPIKeyRequest$Outbound = {
    workspace?: string | undefined;
    CreateAPIKeyRequest?: models.CreateAPIKeyRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateAPIKeyRequest$outboundSchema: z.ZodType<CreateAPIKeyRequest$Outbound, CreateAPIKeyRequest>;
export declare function createAPIKeyRequestToJSON(createAPIKeyRequest: CreateAPIKeyRequest): string;
//# sourceMappingURL=createapikey.d.ts.map