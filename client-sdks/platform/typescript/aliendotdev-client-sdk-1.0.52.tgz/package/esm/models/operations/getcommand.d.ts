import * as z from "zod/v4";
export type GetCommandRequest = {
    /**
     * Unique identifier for the command.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetCommandRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetCommandRequest$outboundSchema: z.ZodType<GetCommandRequest$Outbound, GetCommandRequest>;
export declare function getCommandRequestToJSON(getCommandRequest: GetCommandRequest): string;
//# sourceMappingURL=getcommand.d.ts.map