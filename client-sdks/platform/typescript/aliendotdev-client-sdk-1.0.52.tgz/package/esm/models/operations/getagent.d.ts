import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
export declare const GetAgentInclude: {
    readonly Release: "release";
    readonly DeploymentGroup: "deploymentGroup";
    readonly Project: "project";
};
export type GetAgentInclude = ClosedEnum<typeof GetAgentInclude>;
export type GetAgentRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Optional fields to include: release, deploymentGroup, project
     */
    include?: Array<GetAgentInclude> | undefined;
};
/** @internal */
export declare const GetAgentInclude$outboundSchema: z.ZodEnum<typeof GetAgentInclude>;
/** @internal */
export type GetAgentRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    include?: Array<string> | undefined;
};
/** @internal */
export declare const GetAgentRequest$outboundSchema: z.ZodType<GetAgentRequest$Outbound, GetAgentRequest>;
export declare function getAgentRequestToJSON(getAgentRequest: GetAgentRequest): string;
//# sourceMappingURL=getagent.d.ts.map