import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type ApplyDeploymentRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    applyDeploymentRequest?: models.ApplyDeploymentRequest | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequest$inboundSchema: z.ZodType<ApplyDeploymentRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type ApplyDeploymentRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    ApplyDeploymentRequest?: models.ApplyDeploymentRequest$Outbound | undefined;
};
/** @internal */
export declare const ApplyDeploymentRequest$outboundSchema: z.ZodType<ApplyDeploymentRequest$Outbound, z.ZodTypeDef, ApplyDeploymentRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ApplyDeploymentRequest$ {
    /** @deprecated use `ApplyDeploymentRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ApplyDeploymentRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `ApplyDeploymentRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ApplyDeploymentRequest$Outbound, z.ZodTypeDef, ApplyDeploymentRequest>;
    /** @deprecated use `ApplyDeploymentRequest$Outbound` instead. */
    type Outbound = ApplyDeploymentRequest$Outbound;
}
export declare function applyDeploymentRequestToJSON(applyDeploymentRequest: ApplyDeploymentRequest): string;
export declare function applyDeploymentRequestFromJSON(jsonString: string): SafeParseResult<ApplyDeploymentRequest, SDKValidationError>;
//# sourceMappingURL=applydeployment.d.ts.map