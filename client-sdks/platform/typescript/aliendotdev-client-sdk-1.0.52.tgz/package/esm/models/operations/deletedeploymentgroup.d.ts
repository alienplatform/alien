import * as z from "zod/v4";
export type DeleteDeploymentGroupRequest = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type DeleteDeploymentGroupRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteDeploymentGroupRequest$outboundSchema: z.ZodType<DeleteDeploymentGroupRequest$Outbound, DeleteDeploymentGroupRequest>;
export declare function deleteDeploymentGroupRequestToJSON(deleteDeploymentGroupRequest: DeleteDeploymentGroupRequest): string;
//# sourceMappingURL=deletedeploymentgroup.d.ts.map