import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type AcquireDeploymentRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    acquireDeploymentRequest?: models.AcquireDeploymentRequest | undefined;
};
/** @internal */
export declare const AcquireDeploymentRequest$inboundSchema: z.ZodType<AcquireDeploymentRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type AcquireDeploymentRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    AcquireDeploymentRequest?: models.AcquireDeploymentRequest$Outbound | undefined;
};
/** @internal */
export declare const AcquireDeploymentRequest$outboundSchema: z.ZodType<AcquireDeploymentRequest$Outbound, z.ZodTypeDef, AcquireDeploymentRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace AcquireDeploymentRequest$ {
    /** @deprecated use `AcquireDeploymentRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<AcquireDeploymentRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `AcquireDeploymentRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<AcquireDeploymentRequest$Outbound, z.ZodTypeDef, AcquireDeploymentRequest>;
    /** @deprecated use `AcquireDeploymentRequest$Outbound` instead. */
    type Outbound = AcquireDeploymentRequest$Outbound;
}
export declare function acquireDeploymentRequestToJSON(acquireDeploymentRequest: AcquireDeploymentRequest): string;
export declare function acquireDeploymentRequestFromJSON(jsonString: string): SafeParseResult<AcquireDeploymentRequest, SDKValidationError>;
//# sourceMappingURL=acquiredeployment.d.ts.map