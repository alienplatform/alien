import * as z from "zod/v4";
export type GetProjectActiveReleaseRequest = {
    /**
     * Project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Optional agent ID to check for pinned release
     */
    agentId?: string | undefined;
};
/** @internal */
export type GetProjectActiveReleaseRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
    agentId?: string | undefined;
};
/** @internal */
export declare const GetProjectActiveReleaseRequest$outboundSchema: z.ZodType<GetProjectActiveReleaseRequest$Outbound, GetProjectActiveReleaseRequest>;
export declare function getProjectActiveReleaseRequestToJSON(getProjectActiveReleaseRequest: GetProjectActiveReleaseRequest): string;
//# sourceMappingURL=getprojectactiverelease.d.ts.map