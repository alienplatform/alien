import * as z from "zod/v4";
export type GetAgentInfoRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetAgentInfoRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentInfoRequest$outboundSchema: z.ZodType<GetAgentInfoRequest$Outbound, GetAgentInfoRequest>;
export declare function getAgentInfoRequestToJSON(getAgentInfoRequest: GetAgentInfoRequest): string;
//# sourceMappingURL=getagentinfo.d.ts.map