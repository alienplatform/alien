import * as z from "zod/v4";
export type GetEventRequest = {
    /**
     * Unique identifier for the event.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetEventRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetEventRequest$outboundSchema: z.ZodType<GetEventRequest$Outbound, GetEventRequest>;
export declare function getEventRequestToJSON(getEventRequest: GetEventRequest): string;
//# sourceMappingURL=getevent.d.ts.map