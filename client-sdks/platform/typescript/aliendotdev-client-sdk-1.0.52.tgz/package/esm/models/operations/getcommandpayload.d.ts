import * as z from "zod/v4";
export type GetCommandPayloadRequest = {
    /**
     * Unique identifier for the command.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetCommandPayloadRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetCommandPayloadRequest$outboundSchema: z.ZodType<GetCommandPayloadRequest$Outbound, GetCommandPayloadRequest>;
export declare function getCommandPayloadRequestToJSON(getCommandPayloadRequest: GetCommandPayloadRequest): string;
//# sourceMappingURL=getcommandpayload.d.ts.map