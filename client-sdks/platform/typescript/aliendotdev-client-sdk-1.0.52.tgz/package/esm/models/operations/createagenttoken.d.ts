import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateAgentTokenRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createAgentTokenRequest?: models.CreateAgentTokenRequest | undefined;
};
/** @internal */
export type CreateAgentTokenRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    CreateAgentTokenRequest?: models.CreateAgentTokenRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateAgentTokenRequest$outboundSchema: z.ZodType<CreateAgentTokenRequest$Outbound, CreateAgentTokenRequest>;
export declare function createAgentTokenRequestToJSON(createAgentTokenRequest: CreateAgentTokenRequest): string;
//# sourceMappingURL=createagenttoken.d.ts.map