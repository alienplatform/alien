import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type ListAgentFilterPlatformsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const ListAgentFilterPlatformsItem: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type ListAgentFilterPlatformsItem = ClosedEnum<typeof ListAgentFilterPlatformsItem>;
/**
 * Distinct platforms retrieved.
 */
export type ListAgentFilterPlatformsResponse = {
    items: Array<ListAgentFilterPlatformsItem>;
};
/** @internal */
export type ListAgentFilterPlatformsRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
};
/** @internal */
export declare const ListAgentFilterPlatformsRequest$outboundSchema: z.ZodType<ListAgentFilterPlatformsRequest$Outbound, ListAgentFilterPlatformsRequest>;
export declare function listAgentFilterPlatformsRequestToJSON(listAgentFilterPlatformsRequest: ListAgentFilterPlatformsRequest): string;
/** @internal */
export declare const ListAgentFilterPlatformsItem$inboundSchema: z.ZodEnum<typeof ListAgentFilterPlatformsItem>;
/** @internal */
export declare const ListAgentFilterPlatformsResponse$inboundSchema: z.ZodType<ListAgentFilterPlatformsResponse, unknown>;
export declare function listAgentFilterPlatformsResponseFromJSON(jsonString: string): SafeParseResult<ListAgentFilterPlatformsResponse, SDKValidationError>;
//# sourceMappingURL=listagentfilterplatforms.d.ts.map