import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateDeploymentGroupRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createDeploymentGroupRequest?: models.CreateDeploymentGroupRequest | undefined;
};
/** @internal */
export type CreateDeploymentGroupRequest$Outbound = {
    workspace?: string | undefined;
    CreateDeploymentGroupRequest?: models.CreateDeploymentGroupRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateDeploymentGroupRequest$outboundSchema: z.ZodType<CreateDeploymentGroupRequest$Outbound, CreateDeploymentGroupRequest>;
export declare function createDeploymentGroupRequestToJSON(createDeploymentGroupRequest: CreateDeploymentGroupRequest): string;
//# sourceMappingURL=createdeploymentgroup.d.ts.map