import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type CreateProjectDeploymentTokenRequest = {
    /**
     * Filter by project ID or name.
     */
    idOrName: string;
    /**
     * The current workspace. If not provided, the user's last workspace will be used.
     */
    workspace?: string | undefined;
    createDeploymentTokenRequest?: models.CreateDeploymentTokenRequest | undefined;
};
/** @internal */
export declare const CreateProjectDeploymentTokenRequest$inboundSchema: z.ZodType<CreateProjectDeploymentTokenRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateProjectDeploymentTokenRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
    CreateDeploymentTokenRequest?: models.CreateDeploymentTokenRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateProjectDeploymentTokenRequest$outboundSchema: z.ZodType<CreateProjectDeploymentTokenRequest$Outbound, z.ZodTypeDef, CreateProjectDeploymentTokenRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CreateProjectDeploymentTokenRequest$ {
    /** @deprecated use `CreateProjectDeploymentTokenRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<CreateProjectDeploymentTokenRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `CreateProjectDeploymentTokenRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<CreateProjectDeploymentTokenRequest$Outbound, z.ZodTypeDef, CreateProjectDeploymentTokenRequest>;
    /** @deprecated use `CreateProjectDeploymentTokenRequest$Outbound` instead. */
    type Outbound = CreateProjectDeploymentTokenRequest$Outbound;
}
export declare function createProjectDeploymentTokenRequestToJSON(createProjectDeploymentTokenRequest: CreateProjectDeploymentTokenRequest): string;
export declare function createProjectDeploymentTokenRequestFromJSON(jsonString: string): SafeParseResult<CreateProjectDeploymentTokenRequest, SDKValidationError>;
//# sourceMappingURL=createprojectdeploymenttoken.d.ts.map