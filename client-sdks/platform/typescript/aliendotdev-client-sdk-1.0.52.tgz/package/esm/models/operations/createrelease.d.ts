import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateReleaseRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createReleaseRequest?: models.CreateReleaseRequest | undefined;
};
/** @internal */
export type CreateReleaseRequest$Outbound = {
    workspace?: string | undefined;
    CreateReleaseRequest?: models.CreateReleaseRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateReleaseRequest$outboundSchema: z.ZodType<CreateReleaseRequest$Outbound, CreateReleaseRequest>;
export declare function createReleaseRequestToJSON(createReleaseRequest: CreateReleaseRequest): string;
//# sourceMappingURL=createrelease.d.ts.map