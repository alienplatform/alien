import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
/**
 * Represents the target cloud platform.
 */
export declare const GetAgentStatsPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type GetAgentStatsPlatform = ClosedEnum<typeof GetAgentStatsPlatform>;
/**
 * Deployment status in the deployment lifecycle
 */
export declare const GetAgentStatsStatus: {
    readonly Pending: "pending";
    readonly InitialSetup: "initial-setup";
    readonly InitialSetupFailed: "initial-setup-failed";
    readonly Provisioning: "provisioning";
    readonly ProvisioningFailed: "provisioning-failed";
    readonly Running: "running";
    readonly RefreshFailed: "refresh-failed";
    readonly UpdatePending: "update-pending";
    readonly Updating: "updating";
    readonly UpdateFailed: "update-failed";
    readonly DeletePending: "delete-pending";
    readonly Deleting: "deleting";
    readonly DeleteFailed: "delete-failed";
    readonly Deleted: "deleted";
};
/**
 * Deployment status in the deployment lifecycle
 */
export type GetAgentStatsStatus = ClosedEnum<typeof GetAgentStatsStatus>;
export type GetAgentStatsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Filter by deployment group ID or name
     */
    deploymentGroup?: string | undefined;
    /**
     * Filter by agent manager ID
     */
    agentManagerId?: string | undefined;
    /**
     * Filter agents by platform
     */
    platform?: Array<GetAgentStatsPlatform> | undefined;
    /**
     * Filter agents by status
     */
    status?: Array<GetAgentStatsStatus> | undefined;
    /**
     * Search agents by name or deployment group name
     */
    search?: string | undefined;
};
/** @internal */
export declare const GetAgentStatsPlatform$outboundSchema: z.ZodEnum<typeof GetAgentStatsPlatform>;
/** @internal */
export declare const GetAgentStatsStatus$outboundSchema: z.ZodEnum<typeof GetAgentStatsStatus>;
/** @internal */
export type GetAgentStatsRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    deploymentGroup?: string | undefined;
    agentManagerId?: string | undefined;
    platform?: Array<string> | undefined;
    status?: Array<string> | undefined;
    search?: string | undefined;
};
/** @internal */
export declare const GetAgentStatsRequest$outboundSchema: z.ZodType<GetAgentStatsRequest$Outbound, GetAgentStatsRequest>;
export declare function getAgentStatsRequestToJSON(getAgentStatsRequest: GetAgentStatsRequest): string;
//# sourceMappingURL=getagentstats.d.ts.map