import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetContainerAttentionRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
export declare const GetContainerAttentionType: {
    readonly Crashloop: "crashloop";
    readonly SchedulingFailure: "scheduling_failure";
    readonly UnhealthyMachine: "unhealthy_machine";
};
export type GetContainerAttentionType = ClosedEnum<typeof GetContainerAttentionType>;
export type Issue = {
    type: GetContainerAttentionType;
    containerName?: string | undefined;
    machineId?: string | undefined;
    message: string;
};
export type GetContainerAttentionDeployment = {
    clusterId: string;
    /**
     * Deployment (agent) ID for linking to the deployment
     */
    agentId: string;
    /**
     * Deployment name for display
     */
    agentName: string;
    /**
     * Deployment group ID for linking
     */
    deploymentGroupId?: string | null | undefined;
    deploymentGroupName?: string | null | undefined;
    projectName?: string | null | undefined;
    issues: Array<Issue>;
};
/**
 * Deployments needing attention.
 */
export type GetContainerAttentionResponse = {
    /**
     * Deployments with issues needing attention
     */
    deployments: Array<GetContainerAttentionDeployment>;
};
/** @internal */
export type GetContainerAttentionRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
/** @internal */
export declare const GetContainerAttentionRequest$outboundSchema: z.ZodType<GetContainerAttentionRequest$Outbound, GetContainerAttentionRequest>;
export declare function getContainerAttentionRequestToJSON(getContainerAttentionRequest: GetContainerAttentionRequest): string;
/** @internal */
export declare const GetContainerAttentionType$inboundSchema: z.ZodEnum<typeof GetContainerAttentionType>;
/** @internal */
export declare const Issue$inboundSchema: z.ZodType<Issue, unknown>;
export declare function issueFromJSON(jsonString: string): SafeParseResult<Issue, SDKValidationError>;
/** @internal */
export declare const GetContainerAttentionDeployment$inboundSchema: z.ZodType<GetContainerAttentionDeployment, unknown>;
export declare function getContainerAttentionDeploymentFromJSON(jsonString: string): SafeParseResult<GetContainerAttentionDeployment, SDKValidationError>;
/** @internal */
export declare const GetContainerAttentionResponse$inboundSchema: z.ZodType<GetContainerAttentionResponse, unknown>;
export declare function getContainerAttentionResponseFromJSON(jsonString: string): SafeParseResult<GetContainerAttentionResponse, SDKValidationError>;
//# sourceMappingURL=getcontainerattention.d.ts.map