import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateDeploymentGroupTokenRequest = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createDeploymentGroupTokenRequest?: models.CreateDeploymentGroupTokenRequest | undefined;
};
/** @internal */
export type CreateDeploymentGroupTokenRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    CreateDeploymentGroupTokenRequest?: models.CreateDeploymentGroupTokenRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateDeploymentGroupTokenRequest$outboundSchema: z.ZodType<CreateDeploymentGroupTokenRequest$Outbound, CreateDeploymentGroupTokenRequest>;
export declare function createDeploymentGroupTokenRequestToJSON(createDeploymentGroupTokenRequest: CreateDeploymentGroupTokenRequest): string;
//# sourceMappingURL=createdeploymentgrouptoken.d.ts.map