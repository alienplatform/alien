import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type EnqueueProjectPackagesRequest = {
    /**
     * Filter by project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Packages enqueued successfully.
 */
export type EnqueueProjectPackagesResponse = {
    /**
     * Number of packages enqueued
     */
    packagesEnqueued: number;
};
/** @internal */
export declare const EnqueueProjectPackagesRequest$inboundSchema: z.ZodType<EnqueueProjectPackagesRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type EnqueueProjectPackagesRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const EnqueueProjectPackagesRequest$outboundSchema: z.ZodType<EnqueueProjectPackagesRequest$Outbound, z.ZodTypeDef, EnqueueProjectPackagesRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnqueueProjectPackagesRequest$ {
    /** @deprecated use `EnqueueProjectPackagesRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnqueueProjectPackagesRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnqueueProjectPackagesRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnqueueProjectPackagesRequest$Outbound, z.ZodTypeDef, EnqueueProjectPackagesRequest>;
    /** @deprecated use `EnqueueProjectPackagesRequest$Outbound` instead. */
    type Outbound = EnqueueProjectPackagesRequest$Outbound;
}
export declare function enqueueProjectPackagesRequestToJSON(enqueueProjectPackagesRequest: EnqueueProjectPackagesRequest): string;
export declare function enqueueProjectPackagesRequestFromJSON(jsonString: string): SafeParseResult<EnqueueProjectPackagesRequest, SDKValidationError>;
/** @internal */
export declare const EnqueueProjectPackagesResponse$inboundSchema: z.ZodType<EnqueueProjectPackagesResponse, z.ZodTypeDef, unknown>;
/** @internal */
export type EnqueueProjectPackagesResponse$Outbound = {
    packagesEnqueued: number;
};
/** @internal */
export declare const EnqueueProjectPackagesResponse$outboundSchema: z.ZodType<EnqueueProjectPackagesResponse$Outbound, z.ZodTypeDef, EnqueueProjectPackagesResponse>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace EnqueueProjectPackagesResponse$ {
    /** @deprecated use `EnqueueProjectPackagesResponse$inboundSchema` instead. */
    const inboundSchema: z.ZodType<EnqueueProjectPackagesResponse, z.ZodTypeDef, unknown>;
    /** @deprecated use `EnqueueProjectPackagesResponse$outboundSchema` instead. */
    const outboundSchema: z.ZodType<EnqueueProjectPackagesResponse$Outbound, z.ZodTypeDef, EnqueueProjectPackagesResponse>;
    /** @deprecated use `EnqueueProjectPackagesResponse$Outbound` instead. */
    type Outbound = EnqueueProjectPackagesResponse$Outbound;
}
export declare function enqueueProjectPackagesResponseToJSON(enqueueProjectPackagesResponse: EnqueueProjectPackagesResponse): string;
export declare function enqueueProjectPackagesResponseFromJSON(jsonString: string): SafeParseResult<EnqueueProjectPackagesResponse, SDKValidationError>;
//# sourceMappingURL=enqueueprojectpackages.d.ts.map