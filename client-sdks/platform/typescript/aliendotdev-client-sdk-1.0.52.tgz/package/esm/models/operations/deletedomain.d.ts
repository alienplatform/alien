import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type DeleteDomainRequest = {
    /**
     * Unique identifier for the domain.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Domain deletion requested.
 */
export type DeleteDomainResponse = {
    success: boolean;
};
/** @internal */
export type DeleteDomainRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteDomainRequest$outboundSchema: z.ZodType<DeleteDomainRequest$Outbound, DeleteDomainRequest>;
export declare function deleteDomainRequestToJSON(deleteDomainRequest: DeleteDomainRequest): string;
/** @internal */
export declare const DeleteDomainResponse$inboundSchema: z.ZodType<DeleteDomainResponse, unknown>;
export declare function deleteDomainResponseFromJSON(jsonString: string): SafeParseResult<DeleteDomainResponse, SDKValidationError>;
//# sourceMappingURL=deletedomain.d.ts.map