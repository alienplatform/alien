import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export declare const ListDeploymentContainerEventsQueryParamType: {
    readonly Info: "info";
    readonly Warning: "warning";
    readonly Error: "error";
};
export type ListDeploymentContainerEventsQueryParamType = ClosedEnum<typeof ListDeploymentContainerEventsQueryParamType>;
export type ListDeploymentContainerEventsRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    type?: ListDeploymentContainerEventsQueryParamType | undefined;
    involvedObjectType?: string | undefined;
    involvedObjectId?: string | undefined;
    reason?: string | undefined;
    limit?: number | undefined;
};
export declare const ListDeploymentContainerEventsEventType: {
    readonly Info: "info";
    readonly Warning: "warning";
    readonly Error: "error";
};
export type ListDeploymentContainerEventsEventType = ClosedEnum<typeof ListDeploymentContainerEventsEventType>;
export type ListDeploymentContainerEventsInvolvedObject = {
    type: string;
    id: string;
};
export type ListDeploymentContainerEventsEvent = {
    eventId: string;
    type: ListDeploymentContainerEventsEventType;
    reason: string;
    message?: string | undefined;
    involvedObject: ListDeploymentContainerEventsInvolvedObject;
    firstTimestamp: string;
    lastTimestamp: string;
    count: number;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * List of orchestration events.
 */
export type ListDeploymentContainerEventsResponse = {
    events: Array<ListDeploymentContainerEventsEvent>;
};
/** @internal */
export declare const ListDeploymentContainerEventsQueryParamType$outboundSchema: z.ZodEnum<typeof ListDeploymentContainerEventsQueryParamType>;
/** @internal */
export type ListDeploymentContainerEventsRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    type?: string | undefined;
    involvedObjectType?: string | undefined;
    involvedObjectId?: string | undefined;
    reason?: string | undefined;
    limit: number;
};
/** @internal */
export declare const ListDeploymentContainerEventsRequest$outboundSchema: z.ZodType<ListDeploymentContainerEventsRequest$Outbound, ListDeploymentContainerEventsRequest>;
export declare function listDeploymentContainerEventsRequestToJSON(listDeploymentContainerEventsRequest: ListDeploymentContainerEventsRequest): string;
/** @internal */
export declare const ListDeploymentContainerEventsEventType$inboundSchema: z.ZodEnum<typeof ListDeploymentContainerEventsEventType>;
/** @internal */
export declare const ListDeploymentContainerEventsInvolvedObject$inboundSchema: z.ZodType<ListDeploymentContainerEventsInvolvedObject, unknown>;
export declare function listDeploymentContainerEventsInvolvedObjectFromJSON(jsonString: string): SafeParseResult<ListDeploymentContainerEventsInvolvedObject, SDKValidationError>;
/** @internal */
export declare const ListDeploymentContainerEventsEvent$inboundSchema: z.ZodType<ListDeploymentContainerEventsEvent, unknown>;
export declare function listDeploymentContainerEventsEventFromJSON(jsonString: string): SafeParseResult<ListDeploymentContainerEventsEvent, SDKValidationError>;
/** @internal */
export declare const ListDeploymentContainerEventsResponse$inboundSchema: z.ZodType<ListDeploymentContainerEventsResponse, unknown>;
export declare function listDeploymentContainerEventsResponseFromJSON(jsonString: string): SafeParseResult<ListDeploymentContainerEventsResponse, SDKValidationError>;
//# sourceMappingURL=listdeploymentcontainerevents.d.ts.map