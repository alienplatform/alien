import * as z from "zod/v4";
export type ListAgentManagersRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type ListAgentManagersRequest$Outbound = {
    workspace?: string | undefined;
};
/** @internal */
export declare const ListAgentManagersRequest$outboundSchema: z.ZodType<ListAgentManagersRequest$Outbound, ListAgentManagersRequest>;
export declare function listAgentManagersRequestToJSON(listAgentManagersRequest: ListAgentManagersRequest): string;
//# sourceMappingURL=listagentmanagers.d.ts.map