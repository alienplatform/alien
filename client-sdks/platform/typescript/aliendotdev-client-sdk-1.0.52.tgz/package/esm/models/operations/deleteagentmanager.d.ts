import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type DeleteAgentManagerRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Agent manager deletion enqueued successfully.
 */
export type DeleteAgentManagerResponse = {
    message: string;
};
/** @internal */
export type DeleteAgentManagerRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteAgentManagerRequest$outboundSchema: z.ZodType<DeleteAgentManagerRequest$Outbound, DeleteAgentManagerRequest>;
export declare function deleteAgentManagerRequestToJSON(deleteAgentManagerRequest: DeleteAgentManagerRequest): string;
/** @internal */
export declare const DeleteAgentManagerResponse$inboundSchema: z.ZodType<DeleteAgentManagerResponse, unknown>;
export declare function deleteAgentManagerResponseFromJSON(jsonString: string): SafeParseResult<DeleteAgentManagerResponse, SDKValidationError>;
//# sourceMappingURL=deleteagentmanager.d.ts.map