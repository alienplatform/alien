import * as z from "zod/v4";
export type GetDeploymentInfoRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetDeploymentInfoRequest$Outbound = {
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeploymentInfoRequest$outboundSchema: z.ZodType<GetDeploymentInfoRequest$Outbound, GetDeploymentInfoRequest>;
export declare function getDeploymentInfoRequestToJSON(getDeploymentInfoRequest: GetDeploymentInfoRequest): string;
//# sourceMappingURL=getdeploymentinfo.d.ts.map