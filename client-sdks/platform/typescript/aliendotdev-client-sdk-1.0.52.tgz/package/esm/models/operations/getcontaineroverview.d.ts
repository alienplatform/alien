import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetContainerOverviewRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
export type ContainerDefinition = {
    /**
     * Container definition name (same across all deployments)
     */
    name: string;
    /**
     * Project ID this container belongs to
     */
    projectId: string | null;
    /**
     * Project name for display (null at workspace level)
     */
    projectName: string | null;
    /**
     * Total deployments running this container
     */
    totalInstances: number;
    runningInstances: number;
    failingInstances: number;
    pendingInstances: number;
    stoppedInstances: number;
    avgCpuPercent: number | null;
    avgMemoryPercent: number | null;
    totalReplicas: number;
    healthyReplicas: number;
    /**
     * Deployments with issues (failing or scheduling failures)
     */
    attentionCount: number;
    /**
     * Container image from a representative deployment
     */
    image: string | null;
    stateful: boolean | null;
    hasAutoscaling: boolean | null;
    /**
     * Average p95 HTTP latency across replicas
     */
    avgLatencyP95Ms: number | null;
    /**
     * Average HTTP error rate (5xx/total), 0-1
     */
    avgErrorRate: number | null;
};
export type GetContainerOverviewMachinesByStatus = {
    running: number;
    unhealthy: number;
    initializing: number;
    draining: number;
};
export type GetContainerOverviewTotals = {
    /**
     * Total deployments with containers
     */
    deployments: number;
    containerInstances: number;
    machines: number;
    machinesByStatus: GetContainerOverviewMachinesByStatus;
    /**
     * Clusters where rescheduling is frozen
     */
    reschedulingFrozenCount: number;
};
/**
 * Container overview across all deployments.
 */
export type GetContainerOverviewResponse = {
    containerDefinitions: Array<ContainerDefinition>;
    totals: GetContainerOverviewTotals;
};
/** @internal */
export type GetContainerOverviewRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
/** @internal */
export declare const GetContainerOverviewRequest$outboundSchema: z.ZodType<GetContainerOverviewRequest$Outbound, GetContainerOverviewRequest>;
export declare function getContainerOverviewRequestToJSON(getContainerOverviewRequest: GetContainerOverviewRequest): string;
/** @internal */
export declare const ContainerDefinition$inboundSchema: z.ZodType<ContainerDefinition, unknown>;
export declare function containerDefinitionFromJSON(jsonString: string): SafeParseResult<ContainerDefinition, SDKValidationError>;
/** @internal */
export declare const GetContainerOverviewMachinesByStatus$inboundSchema: z.ZodType<GetContainerOverviewMachinesByStatus, unknown>;
export declare function getContainerOverviewMachinesByStatusFromJSON(jsonString: string): SafeParseResult<GetContainerOverviewMachinesByStatus, SDKValidationError>;
/** @internal */
export declare const GetContainerOverviewTotals$inboundSchema: z.ZodType<GetContainerOverviewTotals, unknown>;
export declare function getContainerOverviewTotalsFromJSON(jsonString: string): SafeParseResult<GetContainerOverviewTotals, SDKValidationError>;
/** @internal */
export declare const GetContainerOverviewResponse$inboundSchema: z.ZodType<GetContainerOverviewResponse, unknown>;
export declare function getContainerOverviewResponseFromJSON(jsonString: string): SafeParseResult<GetContainerOverviewResponse, SDKValidationError>;
//# sourceMappingURL=getcontaineroverview.d.ts.map