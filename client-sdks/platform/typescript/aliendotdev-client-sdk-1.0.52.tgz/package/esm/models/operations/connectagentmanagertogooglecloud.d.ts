import * as z from "zod/v4";
export type ConnectAgentManagerToGoogleCloudRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    redirectUrl?: string | undefined;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * GCP project ID where the agent manager will be deployed
     */
    projectId: string;
    /**
     * GCP region where the agent manager will be deployed
     */
    region: string;
};
/** @internal */
export type ConnectAgentManagerToGoogleCloudRequest$Outbound = {
    id: string;
    redirectUrl?: string | undefined;
    workspace?: string | undefined;
    projectId: string;
    region: string;
};
/** @internal */
export declare const ConnectAgentManagerToGoogleCloudRequest$outboundSchema: z.ZodType<ConnectAgentManagerToGoogleCloudRequest$Outbound, ConnectAgentManagerToGoogleCloudRequest>;
export declare function connectAgentManagerToGoogleCloudRequestToJSON(connectAgentManagerToGoogleCloudRequest: ConnectAgentManagerToGoogleCloudRequest): string;
//# sourceMappingURL=connectagentmanagertogooglecloud.d.ts.map