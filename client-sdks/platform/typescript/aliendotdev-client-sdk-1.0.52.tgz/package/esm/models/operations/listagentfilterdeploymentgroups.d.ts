import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type ListAgentFilterDeploymentGroupsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Search deployment groups by name
     */
    search?: string | null | undefined;
    /**
     * Maximum number of items to return
     */
    limit?: number | undefined;
};
export type ListAgentFilterDeploymentGroupsItem = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    name: string;
    agentCount: number;
    /**
     * Number of agents in 'running' status
     */
    runningCount: number;
    /**
     * Number of agents in a failed status
     */
    failedCount: number;
    /**
     * Number of agents in an in-progress status (provisioning, updating, etc.)
     */
    inProgressCount: number;
};
/**
 * Deployment groups for filter retrieved.
 */
export type ListAgentFilterDeploymentGroupsResponse = {
    items: Array<ListAgentFilterDeploymentGroupsItem>;
};
/** @internal */
export type ListAgentFilterDeploymentGroupsRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    search?: string | null | undefined;
    limit: number;
};
/** @internal */
export declare const ListAgentFilterDeploymentGroupsRequest$outboundSchema: z.ZodType<ListAgentFilterDeploymentGroupsRequest$Outbound, ListAgentFilterDeploymentGroupsRequest>;
export declare function listAgentFilterDeploymentGroupsRequestToJSON(listAgentFilterDeploymentGroupsRequest: ListAgentFilterDeploymentGroupsRequest): string;
/** @internal */
export declare const ListAgentFilterDeploymentGroupsItem$inboundSchema: z.ZodType<ListAgentFilterDeploymentGroupsItem, unknown>;
export declare function listAgentFilterDeploymentGroupsItemFromJSON(jsonString: string): SafeParseResult<ListAgentFilterDeploymentGroupsItem, SDKValidationError>;
/** @internal */
export declare const ListAgentFilterDeploymentGroupsResponse$inboundSchema: z.ZodType<ListAgentFilterDeploymentGroupsResponse, unknown>;
export declare function listAgentFilterDeploymentGroupsResponseFromJSON(jsonString: string): SafeParseResult<ListAgentFilterDeploymentGroupsResponse, SDKValidationError>;
//# sourceMappingURL=listagentfilterdeploymentgroups.d.ts.map