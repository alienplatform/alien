import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type CreateProjectEnvironmentVariableRequest = {
    /**
     * Filter by project ID or name.
     */
    idOrName: string;
    /**
     * The current workspace. If not provided, the user's last workspace will be used.
     */
    workspace?: string | undefined;
    environmentVariableInput?: models.EnvironmentVariableInput | undefined;
};
/** @internal */
export declare const CreateProjectEnvironmentVariableRequest$inboundSchema: z.ZodType<CreateProjectEnvironmentVariableRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateProjectEnvironmentVariableRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
    EnvironmentVariableInput?: models.EnvironmentVariableInput$Outbound | undefined;
};
/** @internal */
export declare const CreateProjectEnvironmentVariableRequest$outboundSchema: z.ZodType<CreateProjectEnvironmentVariableRequest$Outbound, z.ZodTypeDef, CreateProjectEnvironmentVariableRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace CreateProjectEnvironmentVariableRequest$ {
    /** @deprecated use `CreateProjectEnvironmentVariableRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<CreateProjectEnvironmentVariableRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `CreateProjectEnvironmentVariableRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<CreateProjectEnvironmentVariableRequest$Outbound, z.ZodTypeDef, CreateProjectEnvironmentVariableRequest>;
    /** @deprecated use `CreateProjectEnvironmentVariableRequest$Outbound` instead. */
    type Outbound = CreateProjectEnvironmentVariableRequest$Outbound;
}
export declare function createProjectEnvironmentVariableRequestToJSON(createProjectEnvironmentVariableRequest: CreateProjectEnvironmentVariableRequest): string;
export declare function createProjectEnvironmentVariableRequestFromJSON(jsonString: string): SafeParseResult<CreateProjectEnvironmentVariableRequest, SDKValidationError>;
//# sourceMappingURL=createprojectenvironmentvariable.d.ts.map