import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type ListAgentManagerEventsRequest = {
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Retrieved events.
 */
export type ListAgentManagerEventsResponse = {
    items: Array<models.Event>;
};
/** @internal */
export type ListAgentManagerEventsRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const ListAgentManagerEventsRequest$outboundSchema: z.ZodType<ListAgentManagerEventsRequest$Outbound, ListAgentManagerEventsRequest>;
export declare function listAgentManagerEventsRequestToJSON(listAgentManagerEventsRequest: ListAgentManagerEventsRequest): string;
/** @internal */
export declare const ListAgentManagerEventsResponse$inboundSchema: z.ZodType<ListAgentManagerEventsResponse, unknown>;
export declare function listAgentManagerEventsResponseFromJSON(jsonString: string): SafeParseResult<ListAgentManagerEventsResponse, SDKValidationError>;
//# sourceMappingURL=listagentmanagerevents.d.ts.map