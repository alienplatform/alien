import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
/**
 * The Git Provider of the repository
 */
export declare const CreateProjectTypeRequest: {
    readonly Github: "github";
};
/**
 * The Git Provider of the repository
 */
export type CreateProjectTypeRequest = ClosedEnum<typeof CreateProjectTypeRequest>;
/**
 * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
 */
export type CreateProjectGitRepositoryRequest = {
    /**
     * The Git Provider of the repository
     */
    type: CreateProjectTypeRequest;
    /**
     * The name of the git repository
     */
    repo: string;
};
/**
 * CLI package configuration. If null, CLI packages will not be generated.
 */
export type CreateProjectCliRequest = {
    /**
     * Human-friendly display name for help banners and about text
     */
    displayName: string;
    /**
     * Binary name displayed in help and usage (e.g., "my-cli")
     */
    name: string;
    /**
     * Whether CLI package generation is enabled
     */
    enabled: boolean;
};
/**
 * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
 */
export type CreateProjectCloudformationRequest = {
    /**
     * Whether CloudFormation package generation is enabled
     */
    enabled: boolean;
};
/**
 * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
 */
export type CreateProjectOperatorImageRequest = {
    /**
     * Human-friendly display name for logs and startup messages
     */
    displayName: string;
    /**
     * Binary name (e.g., "acme-operator")
     */
    name: string;
    /**
     * Whether operator image package generation is enabled
     */
    enabled: boolean;
};
/**
 * Helm chart package configuration. If null, Helm packages will not be generated.
 */
export type CreateProjectHelmRequest = {
    /**
     * Chart name (e.g., "acme-operator")
     */
    chartName: string;
    /**
     * Human-friendly description of the chart
     */
    description: string;
    /**
     * Whether Helm chart package generation is enabled
     */
    enabled: boolean;
};
/**
 * Terraform provider package configuration. If null, Terraform packages will not be generated.
 */
export type CreateProjectTerraformRequest = {
    /**
     * Terraform provider name (e.g., "acme")
     */
    providerName: string;
    /**
     * Terraform resource type name (e.g., "agent")
     */
    resourceType: string;
    /**
     * Whether Terraform provider package generation is enabled
     */
    enabled: boolean;
};
/**
 * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
 */
export type CreateProjectPackagesConfigRequest = {
    /**
     * CLI package configuration. If null, CLI packages will not be generated.
     */
    cli?: CreateProjectCliRequest | null | undefined;
    /**
     * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
     */
    cloudformation?: CreateProjectCloudformationRequest | null | undefined;
    /**
     * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
     */
    operatorImage?: CreateProjectOperatorImageRequest | null | undefined;
    /**
     * Helm chart package configuration. If null, Helm packages will not be generated.
     */
    helm?: CreateProjectHelmRequest | null | undefined;
    /**
     * Terraform provider package configuration. If null, Terraform packages will not be generated.
     */
    terraform?: CreateProjectTerraformRequest | null | undefined;
};
export type CreateProjectRequestBody = {
    /**
     * Project name.
     */
    name: string;
    /**
     * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
     */
    gitRepository?: CreateProjectGitRepositoryRequest | null | undefined;
    /**
     * The name of a directory or relative path to the source code of your project. When null is used it will default to the project root
     */
    rootDirectory?: string | null | undefined;
    /**
     * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
     */
    packagesConfig?: CreateProjectPackagesConfigRequest | null | undefined;
};
export type CreateProjectRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    requestBody?: CreateProjectRequestBody | undefined;
};
/**
 * The Git Provider of the repository
 */
export declare const CreateProjectTypeGithubResponse: {
    readonly Github: "github";
};
/**
 * The Git Provider of the repository
 */
export type CreateProjectTypeGithubResponse = ClosedEnum<typeof CreateProjectTypeGithubResponse>;
/**
 * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
 */
export type CreateProjectGitRepositoryResponse = {
    /**
     * The Git Provider of the repository
     */
    type: CreateProjectTypeGithubResponse;
    /**
     * The name of the git repository
     */
    repo: string;
};
/**
 * Type of animated background to display on the deployment page.
 */
export declare const CreateProjectDeploymentPageBackgroundType: {
    readonly GradientMesh: "gradient-mesh";
    readonly FloatingOrbs: "floating-orbs";
    readonly FlickeringGrid: "flickering-grid";
    readonly BubbleGlow: "bubble-glow";
    readonly ParticleField: "particle-field";
};
/**
 * Type of animated background to display on the deployment page.
 */
export type CreateProjectDeploymentPageBackgroundType = ClosedEnum<typeof CreateProjectDeploymentPageBackgroundType>;
/**
 * Color mode for the background animation.
 */
export declare const CreateProjectMode: {
    readonly Dark: "dark";
    readonly Light: "light";
};
/**
 * Color mode for the background animation.
 */
export type CreateProjectMode = ClosedEnum<typeof CreateProjectMode>;
/**
 * Color scheme for the background animation.
 */
export declare const CreateProjectColorScheme: {
    readonly Blue: "blue";
    readonly Purple: "purple";
    readonly Green: "green";
    readonly Orange: "orange";
    readonly Pink: "pink";
};
/**
 * Color scheme for the background animation.
 */
export type CreateProjectColorScheme = ClosedEnum<typeof CreateProjectColorScheme>;
/**
 * Customization settings for the deployment page background animation.
 */
export type CreateProjectDeploymentPageBackground = {
    /**
     * Type of animated background to display on the deployment page.
     */
    type: CreateProjectDeploymentPageBackgroundType;
    /**
     * Color mode for the background animation.
     */
    mode: CreateProjectMode;
    /**
     * Color scheme for the background animation.
     */
    colorScheme: CreateProjectColorScheme;
};
/**
 * CLI package configuration. If null, CLI packages will not be generated.
 */
export type CreateProjectCliResponse = {
    /**
     * Human-friendly display name for help banners and about text
     */
    displayName: string;
    /**
     * Binary name displayed in help and usage (e.g., "my-cli")
     */
    name: string;
    /**
     * Whether CLI package generation is enabled
     */
    enabled: boolean;
};
/**
 * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
 */
export type CreateProjectCloudformationResponse = {
    /**
     * Whether CloudFormation package generation is enabled
     */
    enabled: boolean;
};
/**
 * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
 */
export type CreateProjectOperatorImageResponse = {
    /**
     * Human-friendly display name for logs and startup messages
     */
    displayName: string;
    /**
     * Binary name (e.g., "acme-operator")
     */
    name: string;
    /**
     * Whether operator image package generation is enabled
     */
    enabled: boolean;
};
/**
 * Helm chart package configuration. If null, Helm packages will not be generated.
 */
export type CreateProjectHelmResponse = {
    /**
     * Chart name (e.g., "acme-operator")
     */
    chartName: string;
    /**
     * Human-friendly description of the chart
     */
    description: string;
    /**
     * Whether Helm chart package generation is enabled
     */
    enabled: boolean;
};
/**
 * Terraform provider package configuration. If null, Terraform packages will not be generated.
 */
export type CreateProjectTerraformResponse = {
    /**
     * Terraform provider name (e.g., "acme")
     */
    providerName: string;
    /**
     * Terraform resource type name (e.g., "agent")
     */
    resourceType: string;
    /**
     * Whether Terraform provider package generation is enabled
     */
    enabled: boolean;
};
/**
 * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
 */
export type CreateProjectPackagesConfigResponse = {
    /**
     * CLI package configuration. If null, CLI packages will not be generated.
     */
    cli?: CreateProjectCliResponse | null | undefined;
    /**
     * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
     */
    cloudformation?: CreateProjectCloudformationResponse | null | undefined;
    /**
     * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
     */
    operatorImage?: CreateProjectOperatorImageResponse | null | undefined;
    /**
     * Helm chart package configuration. If null, Helm packages will not be generated.
     */
    helm?: CreateProjectHelmResponse | null | undefined;
    /**
     * Terraform provider package configuration. If null, Terraform packages will not be generated.
     */
    terraform?: CreateProjectTerraformResponse | null | undefined;
};
export type CreateProjectGithubSetup = {
    /**
     * URL to the pull request with the Alien build workflow
     */
    pullRequestUrl: string;
    /**
     * URL to the GitHub Actions workflow
     */
    workflowUrl: string;
};
/**
 * Project created successfully.
 */
export type CreateProjectResponse = {
    /**
     * Unique identifier for the project.
     */
    id: string;
    /**
     * Project name.
     */
    name: string;
    /**
     * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
     */
    gitRepository?: CreateProjectGitRepositoryResponse | null | undefined;
    /**
     * The name of a directory or relative path to the source code of your project. When null is used it will default to the project root
     */
    rootDirectory?: string | null | undefined;
    /**
     * Customization settings for the deployment page background animation.
     */
    deploymentPageBackground?: CreateProjectDeploymentPageBackground | null | undefined;
    /**
     * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
     */
    packagesConfig?: CreateProjectPackagesConfigResponse | null | undefined;
    /**
     * Selected domain for this project (null = default system domain)
     */
    domainId?: string | null | undefined;
    createdAt: Date;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    githubSetup?: CreateProjectGithubSetup | undefined;
};
/** @internal */
export declare const CreateProjectTypeRequest$outboundSchema: z.ZodEnum<typeof CreateProjectTypeRequest>;
/** @internal */
export type CreateProjectGitRepositoryRequest$Outbound = {
    type: string;
    repo: string;
};
/** @internal */
export declare const CreateProjectGitRepositoryRequest$outboundSchema: z.ZodType<CreateProjectGitRepositoryRequest$Outbound, CreateProjectGitRepositoryRequest>;
export declare function createProjectGitRepositoryRequestToJSON(createProjectGitRepositoryRequest: CreateProjectGitRepositoryRequest): string;
/** @internal */
export type CreateProjectCliRequest$Outbound = {
    displayName: string;
    name: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectCliRequest$outboundSchema: z.ZodType<CreateProjectCliRequest$Outbound, CreateProjectCliRequest>;
export declare function createProjectCliRequestToJSON(createProjectCliRequest: CreateProjectCliRequest): string;
/** @internal */
export type CreateProjectCloudformationRequest$Outbound = {
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectCloudformationRequest$outboundSchema: z.ZodType<CreateProjectCloudformationRequest$Outbound, CreateProjectCloudformationRequest>;
export declare function createProjectCloudformationRequestToJSON(createProjectCloudformationRequest: CreateProjectCloudformationRequest): string;
/** @internal */
export type CreateProjectOperatorImageRequest$Outbound = {
    displayName: string;
    name: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectOperatorImageRequest$outboundSchema: z.ZodType<CreateProjectOperatorImageRequest$Outbound, CreateProjectOperatorImageRequest>;
export declare function createProjectOperatorImageRequestToJSON(createProjectOperatorImageRequest: CreateProjectOperatorImageRequest): string;
/** @internal */
export type CreateProjectHelmRequest$Outbound = {
    chartName: string;
    description: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectHelmRequest$outboundSchema: z.ZodType<CreateProjectHelmRequest$Outbound, CreateProjectHelmRequest>;
export declare function createProjectHelmRequestToJSON(createProjectHelmRequest: CreateProjectHelmRequest): string;
/** @internal */
export type CreateProjectTerraformRequest$Outbound = {
    providerName: string;
    resourceType: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectTerraformRequest$outboundSchema: z.ZodType<CreateProjectTerraformRequest$Outbound, CreateProjectTerraformRequest>;
export declare function createProjectTerraformRequestToJSON(createProjectTerraformRequest: CreateProjectTerraformRequest): string;
/** @internal */
export type CreateProjectPackagesConfigRequest$Outbound = {
    cli?: CreateProjectCliRequest$Outbound | null | undefined;
    cloudformation?: CreateProjectCloudformationRequest$Outbound | null | undefined;
    operatorImage?: CreateProjectOperatorImageRequest$Outbound | null | undefined;
    helm?: CreateProjectHelmRequest$Outbound | null | undefined;
    terraform?: CreateProjectTerraformRequest$Outbound | null | undefined;
};
/** @internal */
export declare const CreateProjectPackagesConfigRequest$outboundSchema: z.ZodType<CreateProjectPackagesConfigRequest$Outbound, CreateProjectPackagesConfigRequest>;
export declare function createProjectPackagesConfigRequestToJSON(createProjectPackagesConfigRequest: CreateProjectPackagesConfigRequest): string;
/** @internal */
export type CreateProjectRequestBody$Outbound = {
    name: string;
    gitRepository?: CreateProjectGitRepositoryRequest$Outbound | null | undefined;
    rootDirectory?: string | null | undefined;
    packagesConfig?: CreateProjectPackagesConfigRequest$Outbound | null | undefined;
};
/** @internal */
export declare const CreateProjectRequestBody$outboundSchema: z.ZodType<CreateProjectRequestBody$Outbound, CreateProjectRequestBody>;
export declare function createProjectRequestBodyToJSON(createProjectRequestBody: CreateProjectRequestBody): string;
/** @internal */
export type CreateProjectRequest$Outbound = {
    workspace?: string | undefined;
    RequestBody?: CreateProjectRequestBody$Outbound | undefined;
};
/** @internal */
export declare const CreateProjectRequest$outboundSchema: z.ZodType<CreateProjectRequest$Outbound, CreateProjectRequest>;
export declare function createProjectRequestToJSON(createProjectRequest: CreateProjectRequest): string;
/** @internal */
export declare const CreateProjectTypeGithubResponse$inboundSchema: z.ZodEnum<typeof CreateProjectTypeGithubResponse>;
/** @internal */
export declare const CreateProjectGitRepositoryResponse$inboundSchema: z.ZodType<CreateProjectGitRepositoryResponse, unknown>;
export declare function createProjectGitRepositoryResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectGitRepositoryResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectDeploymentPageBackgroundType$inboundSchema: z.ZodEnum<typeof CreateProjectDeploymentPageBackgroundType>;
/** @internal */
export declare const CreateProjectMode$inboundSchema: z.ZodEnum<typeof CreateProjectMode>;
/** @internal */
export declare const CreateProjectColorScheme$inboundSchema: z.ZodEnum<typeof CreateProjectColorScheme>;
/** @internal */
export declare const CreateProjectDeploymentPageBackground$inboundSchema: z.ZodType<CreateProjectDeploymentPageBackground, unknown>;
export declare function createProjectDeploymentPageBackgroundFromJSON(jsonString: string): SafeParseResult<CreateProjectDeploymentPageBackground, SDKValidationError>;
/** @internal */
export declare const CreateProjectCliResponse$inboundSchema: z.ZodType<CreateProjectCliResponse, unknown>;
export declare function createProjectCliResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectCliResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectCloudformationResponse$inboundSchema: z.ZodType<CreateProjectCloudformationResponse, unknown>;
export declare function createProjectCloudformationResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectCloudformationResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectOperatorImageResponse$inboundSchema: z.ZodType<CreateProjectOperatorImageResponse, unknown>;
export declare function createProjectOperatorImageResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectOperatorImageResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectHelmResponse$inboundSchema: z.ZodType<CreateProjectHelmResponse, unknown>;
export declare function createProjectHelmResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectHelmResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectTerraformResponse$inboundSchema: z.ZodType<CreateProjectTerraformResponse, unknown>;
export declare function createProjectTerraformResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectTerraformResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectPackagesConfigResponse$inboundSchema: z.ZodType<CreateProjectPackagesConfigResponse, unknown>;
export declare function createProjectPackagesConfigResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectPackagesConfigResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectGithubSetup$inboundSchema: z.ZodType<CreateProjectGithubSetup, unknown>;
export declare function createProjectGithubSetupFromJSON(jsonString: string): SafeParseResult<CreateProjectGithubSetup, SDKValidationError>;
/** @internal */
export declare const CreateProjectResponse$inboundSchema: z.ZodType<CreateProjectResponse, unknown>;
export declare function createProjectResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectResponse, SDKValidationError>;
//# sourceMappingURL=createproject.d.ts.map