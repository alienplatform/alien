import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type GetDeploymentGroupInfoRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
export type Project = {
    id: string;
    name: string;
};
/**
 * Deployment info
 */
export type GetDeploymentGroupInfoResponse = {
    deploymentGroup: models.DeploymentGroup;
    project: Project;
    packages: Array<any | null>;
};
/** @internal */
export type GetDeploymentGroupInfoRequest$Outbound = {
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeploymentGroupInfoRequest$outboundSchema: z.ZodType<GetDeploymentGroupInfoRequest$Outbound, GetDeploymentGroupInfoRequest>;
export declare function getDeploymentGroupInfoRequestToJSON(getDeploymentGroupInfoRequest: GetDeploymentGroupInfoRequest): string;
/** @internal */
export declare const Project$inboundSchema: z.ZodType<Project, unknown>;
export declare function projectFromJSON(jsonString: string): SafeParseResult<Project, SDKValidationError>;
/** @internal */
export declare const GetDeploymentGroupInfoResponse$inboundSchema: z.ZodType<GetDeploymentGroupInfoResponse, unknown>;
export declare function getDeploymentGroupInfoResponseFromJSON(jsonString: string): SafeParseResult<GetDeploymentGroupInfoResponse, SDKValidationError>;
//# sourceMappingURL=getdeploymentgroupinfo.d.ts.map