import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetDeepstoreTokenRequest = {
    /**
     * Filter by project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeepstoreTokenRequest$inboundSchema: z.ZodType<GetDeepstoreTokenRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type GetDeepstoreTokenRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeepstoreTokenRequest$outboundSchema: z.ZodType<GetDeepstoreTokenRequest$Outbound, z.ZodTypeDef, GetDeepstoreTokenRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GetDeepstoreTokenRequest$ {
    /** @deprecated use `GetDeepstoreTokenRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<GetDeepstoreTokenRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `GetDeepstoreTokenRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<GetDeepstoreTokenRequest$Outbound, z.ZodTypeDef, GetDeepstoreTokenRequest>;
    /** @deprecated use `GetDeepstoreTokenRequest$Outbound` instead. */
    type Outbound = GetDeepstoreTokenRequest$Outbound;
}
export declare function getDeepstoreTokenRequestToJSON(getDeepstoreTokenRequest: GetDeepstoreTokenRequest): string;
export declare function getDeepstoreTokenRequestFromJSON(jsonString: string): SafeParseResult<GetDeepstoreTokenRequest, SDKValidationError>;
//# sourceMappingURL=getdeepstoretoken.d.ts.map