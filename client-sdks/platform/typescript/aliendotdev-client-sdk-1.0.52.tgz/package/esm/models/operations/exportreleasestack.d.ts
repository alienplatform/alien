import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type ExportReleaseStackRequest = {
    /**
     * Unique identifier for the release.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    templateType?: models.TemplateType | undefined;
};
/** @internal */
export declare const ExportReleaseStackRequest$inboundSchema: z.ZodType<ExportReleaseStackRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type ExportReleaseStackRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    TemplateType?: models.TemplateType$Outbound | undefined;
};
/** @internal */
export declare const ExportReleaseStackRequest$outboundSchema: z.ZodType<ExportReleaseStackRequest$Outbound, z.ZodTypeDef, ExportReleaseStackRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace ExportReleaseStackRequest$ {
    /** @deprecated use `ExportReleaseStackRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<ExportReleaseStackRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `ExportReleaseStackRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<ExportReleaseStackRequest$Outbound, z.ZodTypeDef, ExportReleaseStackRequest>;
    /** @deprecated use `ExportReleaseStackRequest$Outbound` instead. */
    type Outbound = ExportReleaseStackRequest$Outbound;
}
export declare function exportReleaseStackRequestToJSON(exportReleaseStackRequest: ExportReleaseStackRequest): string;
export declare function exportReleaseStackRequestFromJSON(jsonString: string): SafeParseResult<ExportReleaseStackRequest, SDKValidationError>;
//# sourceMappingURL=exportreleasestack.d.ts.map