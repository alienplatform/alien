import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetContainerDefinitionDeploymentsRequest = {
    containerName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
export type GetContainerDefinitionDeploymentsDeployment = {
    clusterId: string;
    /**
     * Deployment (agent) ID for building deep-link URLs
     */
    agentId: string;
    /**
     * Deployment name for display
     */
    agentName: string;
    deploymentGroupId?: string | null | undefined;
    deploymentGroupName?: string | undefined;
    projectName?: string | null | undefined;
    status: string;
    statusReason: string | null;
    statusMessage: string | null;
    image: string | null;
    currentReplicas: number;
    healthyReplicas: number;
    avgCpuPercent: number | null;
    avgMemoryPercent: number | null;
    avgLatencyP95Ms: number | null;
    avgErrorRate: number | null;
    avgInFlightRequests: number | null;
};
/**
 * Per-deployment breakdown.
 */
export type GetContainerDefinitionDeploymentsResponse = {
    containerName: string;
    deployments: Array<GetContainerDefinitionDeploymentsDeployment>;
};
/** @internal */
export type GetContainerDefinitionDeploymentsRequest$Outbound = {
    containerName: string;
    workspace?: string | undefined;
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
/** @internal */
export declare const GetContainerDefinitionDeploymentsRequest$outboundSchema: z.ZodType<GetContainerDefinitionDeploymentsRequest$Outbound, GetContainerDefinitionDeploymentsRequest>;
export declare function getContainerDefinitionDeploymentsRequestToJSON(getContainerDefinitionDeploymentsRequest: GetContainerDefinitionDeploymentsRequest): string;
/** @internal */
export declare const GetContainerDefinitionDeploymentsDeployment$inboundSchema: z.ZodType<GetContainerDefinitionDeploymentsDeployment, unknown>;
export declare function getContainerDefinitionDeploymentsDeploymentFromJSON(jsonString: string): SafeParseResult<GetContainerDefinitionDeploymentsDeployment, SDKValidationError>;
/** @internal */
export declare const GetContainerDefinitionDeploymentsResponse$inboundSchema: z.ZodType<GetContainerDefinitionDeploymentsResponse, unknown>;
export declare function getContainerDefinitionDeploymentsResponseFromJSON(jsonString: string): SafeParseResult<GetContainerDefinitionDeploymentsResponse, SDKValidationError>;
//# sourceMappingURL=getcontainerdefinitiondeployments.d.ts.map