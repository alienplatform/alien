import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetDeploymentGroupRequest = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Deployment group details
 */
export type GetDeploymentGroupResponse = {
    /**
     * Unique identifier for the deployment group.
     */
    id: string;
    /**
     * Deployment group name.
     */
    name: string;
    /**
     * Unique identifier for the project.
     */
    projectId: string;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    /**
     * Maximum number of agents allowed in this deployment group
     */
    maxAgents: number;
    createdAt: Date;
    /**
     * Current number of agents in this deployment group
     */
    agentCount: number;
};
/** @internal */
export type GetDeploymentGroupRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeploymentGroupRequest$outboundSchema: z.ZodType<GetDeploymentGroupRequest$Outbound, GetDeploymentGroupRequest>;
export declare function getDeploymentGroupRequestToJSON(getDeploymentGroupRequest: GetDeploymentGroupRequest): string;
/** @internal */
export declare const GetDeploymentGroupResponse$inboundSchema: z.ZodType<GetDeploymentGroupResponse, unknown>;
export declare function getDeploymentGroupResponseFromJSON(jsonString: string): SafeParseResult<GetDeploymentGroupResponse, SDKValidationError>;
//# sourceMappingURL=getdeploymentgroup.d.ts.map