import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
/**
 * Represents the target cloud platform.
 */
export declare const GetProjectBuildConfigPlatform: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type GetProjectBuildConfigPlatform = ClosedEnum<typeof GetProjectBuildConfigPlatform>;
export type GetProjectBuildConfigRequest = {
    /**
     * Project ID or name.
     */
    idOrName: string;
    /**
     * Represents the target cloud platform.
     */
    platform: GetProjectBuildConfigPlatform;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Build configuration retrieved successfully.
 */
export type GetProjectBuildConfigResponse = {
    /**
     * URL of the agent manager for this platform
     */
    agentManagerUrl: string;
    /**
     * Name of the artifact repository
     */
    repositoryName: string;
    /**
     * URI of the repository (if available)
     */
    repositoryUri?: string | undefined;
};
/** @internal */
export declare const GetProjectBuildConfigPlatform$outboundSchema: z.ZodEnum<typeof GetProjectBuildConfigPlatform>;
/** @internal */
export type GetProjectBuildConfigRequest$Outbound = {
    idOrName: string;
    platform: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetProjectBuildConfigRequest$outboundSchema: z.ZodType<GetProjectBuildConfigRequest$Outbound, GetProjectBuildConfigRequest>;
export declare function getProjectBuildConfigRequestToJSON(getProjectBuildConfigRequest: GetProjectBuildConfigRequest): string;
/** @internal */
export declare const GetProjectBuildConfigResponse$inboundSchema: z.ZodType<GetProjectBuildConfigResponse, unknown>;
export declare function getProjectBuildConfigResponseFromJSON(jsonString: string): SafeParseResult<GetProjectBuildConfigResponse, SDKValidationError>;
//# sourceMappingURL=getprojectbuildconfig.d.ts.map