import * as z from "zod/v4";
import * as models from "../index.js";
export type GenerateDeepstoreTokenRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    generateDeepstoreTokenRequest?: models.GenerateDeepstoreTokenRequest | undefined;
};
/** @internal */
export type GenerateDeepstoreTokenRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    GenerateDeepstoreTokenRequest?: models.GenerateDeepstoreTokenRequest$Outbound | undefined;
};
/** @internal */
export declare const GenerateDeepstoreTokenRequest$outboundSchema: z.ZodType<GenerateDeepstoreTokenRequest$Outbound, GenerateDeepstoreTokenRequest>;
export declare function generateDeepstoreTokenRequestToJSON(generateDeepstoreTokenRequest: GenerateDeepstoreTokenRequest): string;
//# sourceMappingURL=generatedeepstoretoken.d.ts.map