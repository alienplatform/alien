import * as z from "zod/v4";
export type ListCommandAgentsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Search agent or deployment group names
     */
    search?: string | undefined;
};
/** @internal */
export type ListCommandAgentsRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    search?: string | undefined;
};
/** @internal */
export declare const ListCommandAgentsRequest$outboundSchema: z.ZodType<ListCommandAgentsRequest$Outbound, ListCommandAgentsRequest>;
export declare function listCommandAgentsRequestToJSON(listCommandAgentsRequest: ListCommandAgentsRequest): string;
//# sourceMappingURL=listcommandagents.d.ts.map