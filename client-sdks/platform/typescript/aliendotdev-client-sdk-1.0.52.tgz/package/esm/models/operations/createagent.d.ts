import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateAgentRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    newAgentRequest?: models.NewAgentRequest | undefined;
};
/** @internal */
export type CreateAgentRequest$Outbound = {
    workspace?: string | undefined;
    NewAgentRequest?: models.NewAgentRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateAgentRequest$outboundSchema: z.ZodType<CreateAgentRequest$Outbound, CreateAgentRequest>;
export declare function createAgentRequestToJSON(createAgentRequest: CreateAgentRequest): string;
//# sourceMappingURL=createagent.d.ts.map