import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetContainerMachinesRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
export type DeploymentMachinesByStatus = {
    running: number;
    unhealthy: number;
    initializing: number;
    draining: number;
};
export type Recommendation = {
    groupId: string;
    currentMachines: number;
    desiredMachines: number;
    reason: string;
    utilizationPercent?: number | null | undefined;
    unschedulableReplicas?: number | undefined;
};
export type CapacityGroup = {
    groupId: string;
    machines: number;
    unhealthyMachines: number;
    utilizationPercent: number | null;
    recommendation: Recommendation | null;
};
export type GetContainerMachinesDeployment = {
    clusterId: string;
    agentId: string;
    agentName: string;
    deploymentGroupId?: string | null | undefined;
    deploymentGroupName?: string | null | undefined;
    projectName?: string | null | undefined;
    totalMachines: number;
    machinesByStatus: DeploymentMachinesByStatus;
    capacityGroups: Array<CapacityGroup>;
};
export type GetContainerMachinesTotalsMachinesByStatus = {
    running: number;
    unhealthy: number;
    initializing: number;
    draining: number;
};
export type GetContainerMachinesTotals = {
    machines: number;
    machinesByStatus: GetContainerMachinesTotalsMachinesByStatus;
};
/**
 * Machine health across all deployments.
 */
export type GetContainerMachinesResponse = {
    deployments: Array<GetContainerMachinesDeployment>;
    totals: GetContainerMachinesTotals;
};
/** @internal */
export type GetContainerMachinesRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    deploymentGroupId?: string | undefined;
};
/** @internal */
export declare const GetContainerMachinesRequest$outboundSchema: z.ZodType<GetContainerMachinesRequest$Outbound, GetContainerMachinesRequest>;
export declare function getContainerMachinesRequestToJSON(getContainerMachinesRequest: GetContainerMachinesRequest): string;
/** @internal */
export declare const DeploymentMachinesByStatus$inboundSchema: z.ZodType<DeploymentMachinesByStatus, unknown>;
export declare function deploymentMachinesByStatusFromJSON(jsonString: string): SafeParseResult<DeploymentMachinesByStatus, SDKValidationError>;
/** @internal */
export declare const Recommendation$inboundSchema: z.ZodType<Recommendation, unknown>;
export declare function recommendationFromJSON(jsonString: string): SafeParseResult<Recommendation, SDKValidationError>;
/** @internal */
export declare const CapacityGroup$inboundSchema: z.ZodType<CapacityGroup, unknown>;
export declare function capacityGroupFromJSON(jsonString: string): SafeParseResult<CapacityGroup, SDKValidationError>;
/** @internal */
export declare const GetContainerMachinesDeployment$inboundSchema: z.ZodType<GetContainerMachinesDeployment, unknown>;
export declare function getContainerMachinesDeploymentFromJSON(jsonString: string): SafeParseResult<GetContainerMachinesDeployment, SDKValidationError>;
/** @internal */
export declare const GetContainerMachinesTotalsMachinesByStatus$inboundSchema: z.ZodType<GetContainerMachinesTotalsMachinesByStatus, unknown>;
export declare function getContainerMachinesTotalsMachinesByStatusFromJSON(jsonString: string): SafeParseResult<GetContainerMachinesTotalsMachinesByStatus, SDKValidationError>;
/** @internal */
export declare const GetContainerMachinesTotals$inboundSchema: z.ZodType<GetContainerMachinesTotals, unknown>;
export declare function getContainerMachinesTotalsFromJSON(jsonString: string): SafeParseResult<GetContainerMachinesTotals, SDKValidationError>;
/** @internal */
export declare const GetContainerMachinesResponse$inboundSchema: z.ZodType<GetContainerMachinesResponse, unknown>;
export declare function getContainerMachinesResponseFromJSON(jsonString: string): SafeParseResult<GetContainerMachinesResponse, SDKValidationError>;
//# sourceMappingURL=getcontainermachines.d.ts.map