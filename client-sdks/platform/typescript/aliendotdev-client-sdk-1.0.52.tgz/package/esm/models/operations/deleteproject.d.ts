import * as z from "zod/v4";
export type DeleteProjectRequest = {
    /**
     * Project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type DeleteProjectRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteProjectRequest$outboundSchema: z.ZodType<DeleteProjectRequest$Outbound, DeleteProjectRequest>;
export declare function deleteProjectRequestToJSON(deleteProjectRequest: DeleteProjectRequest): string;
//# sourceMappingURL=deleteproject.d.ts.map