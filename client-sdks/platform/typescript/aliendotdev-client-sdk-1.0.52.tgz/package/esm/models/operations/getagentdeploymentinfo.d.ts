import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetAgentDeploymentInfoRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentDeploymentInfoRequest$inboundSchema: z.ZodType<GetAgentDeploymentInfoRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type GetAgentDeploymentInfoRequest$Outbound = {
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentDeploymentInfoRequest$outboundSchema: z.ZodType<GetAgentDeploymentInfoRequest$Outbound, z.ZodTypeDef, GetAgentDeploymentInfoRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GetAgentDeploymentInfoRequest$ {
    /** @deprecated use `GetAgentDeploymentInfoRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<GetAgentDeploymentInfoRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `GetAgentDeploymentInfoRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<GetAgentDeploymentInfoRequest$Outbound, z.ZodTypeDef, GetAgentDeploymentInfoRequest>;
    /** @deprecated use `GetAgentDeploymentInfoRequest$Outbound` instead. */
    type Outbound = GetAgentDeploymentInfoRequest$Outbound;
}
export declare function getAgentDeploymentInfoRequestToJSON(getAgentDeploymentInfoRequest: GetAgentDeploymentInfoRequest): string;
export declare function getAgentDeploymentInfoRequestFromJSON(jsonString: string): SafeParseResult<GetAgentDeploymentInfoRequest, SDKValidationError>;
//# sourceMappingURL=getagentdeploymentinfo.d.ts.map