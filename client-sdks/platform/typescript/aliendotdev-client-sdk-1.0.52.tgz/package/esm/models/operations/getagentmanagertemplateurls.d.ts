import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetAgentManagerTemplateUrlsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
export type GetAgentManagerTemplateUrlsAws = {
    templateUrl: string;
    launchStackUrl: string;
};
/**
 * Template URLs retrieved successfully.
 */
export type GetAgentManagerTemplateUrlsResponse = {
    aws?: GetAgentManagerTemplateUrlsAws | undefined;
};
/** @internal */
export type GetAgentManagerTemplateUrlsRequest$Outbound = {
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentManagerTemplateUrlsRequest$outboundSchema: z.ZodType<GetAgentManagerTemplateUrlsRequest$Outbound, GetAgentManagerTemplateUrlsRequest>;
export declare function getAgentManagerTemplateUrlsRequestToJSON(getAgentManagerTemplateUrlsRequest: GetAgentManagerTemplateUrlsRequest): string;
/** @internal */
export declare const GetAgentManagerTemplateUrlsAws$inboundSchema: z.ZodType<GetAgentManagerTemplateUrlsAws, unknown>;
export declare function getAgentManagerTemplateUrlsAwsFromJSON(jsonString: string): SafeParseResult<GetAgentManagerTemplateUrlsAws, SDKValidationError>;
/** @internal */
export declare const GetAgentManagerTemplateUrlsResponse$inboundSchema: z.ZodType<GetAgentManagerTemplateUrlsResponse, unknown>;
export declare function getAgentManagerTemplateUrlsResponseFromJSON(jsonString: string): SafeParseResult<GetAgentManagerTemplateUrlsResponse, SDKValidationError>;
//# sourceMappingURL=getagentmanagertemplateurls.d.ts.map