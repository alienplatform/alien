import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type DeleteAPIKeysRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    deleteAPIKeysRequest?: models.DeleteAPIKeysRequest | undefined;
};
/**
 * API keys deleted successfully.
 */
export type DeleteAPIKeysResponse = {
    deletedCount: number;
};
/** @internal */
export type DeleteAPIKeysRequest$Outbound = {
    workspace?: string | undefined;
    DeleteAPIKeysRequest?: models.DeleteAPIKeysRequest$Outbound | undefined;
};
/** @internal */
export declare const DeleteAPIKeysRequest$outboundSchema: z.ZodType<DeleteAPIKeysRequest$Outbound, DeleteAPIKeysRequest>;
export declare function deleteAPIKeysRequestToJSON(deleteAPIKeysRequest: DeleteAPIKeysRequest): string;
/** @internal */
export declare const DeleteAPIKeysResponse$inboundSchema: z.ZodType<DeleteAPIKeysResponse, unknown>;
export declare function deleteAPIKeysResponseFromJSON(jsonString: string): SafeParseResult<DeleteAPIKeysResponse, SDKValidationError>;
//# sourceMappingURL=deleteapikeys.d.ts.map