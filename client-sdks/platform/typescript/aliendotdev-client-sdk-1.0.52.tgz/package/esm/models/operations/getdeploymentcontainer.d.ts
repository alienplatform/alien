import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetDeploymentContainerRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    containerName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
export declare const GetDeploymentContainerStatus: {
    readonly Pending: "pending";
    readonly Running: "running";
    readonly Stopped: "stopped";
    readonly Failing: "failing";
};
export type GetDeploymentContainerStatus = ClosedEnum<typeof GetDeploymentContainerStatus>;
export type Autoscaling = {
    min: number;
    desired: number;
    max: number;
    targetCpuPercent?: number | undefined;
    targetMemoryPercent?: number | undefined;
    targetHttpInFlightPerReplica?: number | undefined;
    maxHttpP95LatencyMs?: number | undefined;
};
export type GetDeploymentContainerCpu = {
    min: string;
    desired: string;
};
export type GetDeploymentContainerMemory = {
    min: string;
    desired: string;
};
export type GetDeploymentContainerGpu = {
    type: string;
    count: number;
};
export type Resources = {
    cpu?: GetDeploymentContainerCpu | undefined;
    memory?: GetDeploymentContainerMemory | undefined;
    ephemeralStorage?: string | undefined;
    gpu?: GetDeploymentContainerGpu | undefined;
};
export type HealthCheck = {
    path: string;
    port?: number | undefined;
    method?: string | undefined;
    timeoutSeconds?: number | undefined;
    failureThreshold?: number | undefined;
};
export type TopEndpoint = {
    path: string;
    method: string;
    statusClass: string;
    requests: number;
    latencyP95Ms: number;
    latencyP99Ms: number;
    errorRate: number;
};
export type Http = {
    inFlightRequests?: number | undefined;
    totalRequests?: number | undefined;
    latencyP95Ms?: number | undefined;
    latencyP99Ms?: number | undefined;
    status2xx?: number | undefined;
    status4xx?: number | undefined;
    status5xx?: number | undefined;
    topEndpoints?: Array<TopEndpoint> | undefined;
};
export type Metrics = {
    status: string;
    cpuUsage?: number | undefined;
    cpuUsagePercent?: number | undefined;
    memoryUsedBytes?: number | undefined;
    memoryUsagePercent?: number | undefined;
    healthy?: boolean | undefined;
    lastUpdated?: Date | undefined;
    http?: Http | undefined;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
export type ReplicasInfo = {
    replicaId: string;
    machineId: string;
    ip: string;
    status: string;
    healthy: boolean;
    consecutiveFailures: number;
    metrics?: Metrics | undefined;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/**
 * Container details with replica metrics.
 */
export type GetDeploymentContainerResponse = {
    name: string;
    image: string;
    status: GetDeploymentContainerStatus;
    statusReason?: string | null | undefined;
    statusMessage?: string | null | undefined;
    clusterId: string;
    capacityGroup?: string | undefined;
    stateful?: boolean | undefined;
    replicas?: number | undefined;
    autoscaling?: Autoscaling | undefined;
    resources?: Resources | undefined;
    ports?: Array<number> | undefined;
    healthCheck?: HealthCheck | undefined;
    envCount?: number | undefined;
    volumeCount?: number | undefined;
    replicasInfo: Array<ReplicasInfo>;
    createdAt: string;
    updatedAt: string;
    additionalProperties?: {
        [k: string]: any | null;
    } | undefined;
};
/** @internal */
export type GetDeploymentContainerRequest$Outbound = {
    id: string;
    containerName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeploymentContainerRequest$outboundSchema: z.ZodType<GetDeploymentContainerRequest$Outbound, GetDeploymentContainerRequest>;
export declare function getDeploymentContainerRequestToJSON(getDeploymentContainerRequest: GetDeploymentContainerRequest): string;
/** @internal */
export declare const GetDeploymentContainerStatus$inboundSchema: z.ZodEnum<typeof GetDeploymentContainerStatus>;
/** @internal */
export declare const Autoscaling$inboundSchema: z.ZodType<Autoscaling, unknown>;
export declare function autoscalingFromJSON(jsonString: string): SafeParseResult<Autoscaling, SDKValidationError>;
/** @internal */
export declare const GetDeploymentContainerCpu$inboundSchema: z.ZodType<GetDeploymentContainerCpu, unknown>;
export declare function getDeploymentContainerCpuFromJSON(jsonString: string): SafeParseResult<GetDeploymentContainerCpu, SDKValidationError>;
/** @internal */
export declare const GetDeploymentContainerMemory$inboundSchema: z.ZodType<GetDeploymentContainerMemory, unknown>;
export declare function getDeploymentContainerMemoryFromJSON(jsonString: string): SafeParseResult<GetDeploymentContainerMemory, SDKValidationError>;
/** @internal */
export declare const GetDeploymentContainerGpu$inboundSchema: z.ZodType<GetDeploymentContainerGpu, unknown>;
export declare function getDeploymentContainerGpuFromJSON(jsonString: string): SafeParseResult<GetDeploymentContainerGpu, SDKValidationError>;
/** @internal */
export declare const Resources$inboundSchema: z.ZodType<Resources, unknown>;
export declare function resourcesFromJSON(jsonString: string): SafeParseResult<Resources, SDKValidationError>;
/** @internal */
export declare const HealthCheck$inboundSchema: z.ZodType<HealthCheck, unknown>;
export declare function healthCheckFromJSON(jsonString: string): SafeParseResult<HealthCheck, SDKValidationError>;
/** @internal */
export declare const TopEndpoint$inboundSchema: z.ZodType<TopEndpoint, unknown>;
export declare function topEndpointFromJSON(jsonString: string): SafeParseResult<TopEndpoint, SDKValidationError>;
/** @internal */
export declare const Http$inboundSchema: z.ZodType<Http, unknown>;
export declare function httpFromJSON(jsonString: string): SafeParseResult<Http, SDKValidationError>;
/** @internal */
export declare const Metrics$inboundSchema: z.ZodType<Metrics, unknown>;
export declare function metricsFromJSON(jsonString: string): SafeParseResult<Metrics, SDKValidationError>;
/** @internal */
export declare const ReplicasInfo$inboundSchema: z.ZodType<ReplicasInfo, unknown>;
export declare function replicasInfoFromJSON(jsonString: string): SafeParseResult<ReplicasInfo, SDKValidationError>;
/** @internal */
export declare const GetDeploymentContainerResponse$inboundSchema: z.ZodType<GetDeploymentContainerResponse, unknown>;
export declare function getDeploymentContainerResponseFromJSON(jsonString: string): SafeParseResult<GetDeploymentContainerResponse, SDKValidationError>;
//# sourceMappingURL=getdeploymentcontainer.d.ts.map