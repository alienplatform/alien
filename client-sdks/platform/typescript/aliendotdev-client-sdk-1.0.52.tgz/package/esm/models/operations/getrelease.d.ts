import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
export declare const GetReleaseInclude: {
    readonly Project: "project";
};
export type GetReleaseInclude = ClosedEnum<typeof GetReleaseInclude>;
export type GetReleaseRequest = {
    /**
     * Unique identifier for the release.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Optional fields to include: project
     */
    include?: Array<GetReleaseInclude> | undefined;
};
/** @internal */
export declare const GetReleaseInclude$outboundSchema: z.ZodEnum<typeof GetReleaseInclude>;
/** @internal */
export type GetReleaseRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
    include?: Array<string> | undefined;
};
/** @internal */
export declare const GetReleaseRequest$outboundSchema: z.ZodType<GetReleaseRequest$Outbound, GetReleaseRequest>;
export declare function getReleaseRequestToJSON(getReleaseRequest: GetReleaseRequest): string;
//# sourceMappingURL=getrelease.d.ts.map