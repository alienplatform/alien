import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
/**
 * Filter by command state
 */
export declare const State: {
    readonly PendingUpload: "PENDING_UPLOAD";
    readonly Pending: "PENDING";
    readonly Dispatched: "DISPATCHED";
    readonly Succeeded: "SUCCEEDED";
    readonly Failed: "FAILED";
    readonly Expired: "EXPIRED";
};
/**
 * Filter by command state
 */
export type State = ClosedEnum<typeof State>;
export declare const ListCommandsInclude: {
    readonly Agent: "agent";
    readonly Project: "project";
};
export type ListCommandsInclude = ClosedEnum<typeof ListCommandsInclude>;
export type ListCommandsRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Filter by agent ID
     */
    agentId?: string | undefined;
    /**
     * Filter by command state
     */
    state?: State | undefined;
    /**
     * Filter by command name
     */
    name?: string | undefined;
    /**
     * Filter commands created after this date (ISO 8601)
     */
    createdAfter?: Date | null | undefined;
    /**
     * Filter commands created before this date (ISO 8601)
     */
    createdBefore?: Date | null | undefined;
    /**
     * Optional fields to include: agent, project
     */
    include?: Array<ListCommandsInclude> | undefined;
    /**
     * Maximum number of items to return per page
     */
    limit?: number | undefined;
    /**
     * Cursor for pagination - omit for first page
     */
    cursor?: string | undefined;
};
/**
 * Paginated response
 */
export type ListCommandsResponse = {
    /**
     * Items in this page
     */
    items: Array<models.CommandListItemResponse>;
    /**
     * Cursor for the next page, null if last page
     */
    nextCursor: string | null;
};
/** @internal */
export declare const State$outboundSchema: z.ZodEnum<typeof State>;
/** @internal */
export declare const ListCommandsInclude$outboundSchema: z.ZodEnum<typeof ListCommandsInclude>;
/** @internal */
export type ListCommandsRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    agentId?: string | undefined;
    state?: string | undefined;
    name?: string | undefined;
    createdAfter?: string | null | undefined;
    createdBefore?: string | null | undefined;
    include?: Array<string> | undefined;
    limit: number;
    cursor?: string | undefined;
};
/** @internal */
export declare const ListCommandsRequest$outboundSchema: z.ZodType<ListCommandsRequest$Outbound, ListCommandsRequest>;
export declare function listCommandsRequestToJSON(listCommandsRequest: ListCommandsRequest): string;
/** @internal */
export declare const ListCommandsResponse$inboundSchema: z.ZodType<ListCommandsResponse, unknown>;
export declare function listCommandsResponseFromJSON(jsonString: string): SafeParseResult<ListCommandsResponse, SDKValidationError>;
//# sourceMappingURL=listcommands.d.ts.map