import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type CreateAgentManagerRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    newAgentManagerRequest?: models.NewAgentManagerRequest | undefined;
};
/**
 * Represents the target cloud platform.
 */
export declare const Target: {
    readonly Aws: "aws";
    readonly Gcp: "gcp";
    readonly Azure: "azure";
    readonly Kubernetes: "kubernetes";
    readonly Local: "local";
    readonly Test: "test";
};
/**
 * Represents the target cloud platform.
 */
export type Target = ClosedEnum<typeof Target>;
export declare const CreateAgentManagerPlatformKubernetes: {
    readonly Kubernetes: "kubernetes";
};
export type CreateAgentManagerPlatformKubernetes = ClosedEnum<typeof CreateAgentManagerPlatformKubernetes>;
export type ManagementConfigKubernetes = {
    platform: CreateAgentManagerPlatformKubernetes;
};
export declare const CreateAgentManagerPlatformAzure: {
    readonly Azure: "azure";
};
export type CreateAgentManagerPlatformAzure = ClosedEnum<typeof CreateAgentManagerPlatformAzure>;
/**
 * Azure management configuration extracted from stack settings
 */
export type ManagementConfigAzure = {
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: CreateAgentManagerPlatformAzure;
};
export declare const CreateAgentManagerPlatformGcp: {
    readonly Gcp: "gcp";
};
export type CreateAgentManagerPlatformGcp = ClosedEnum<typeof CreateAgentManagerPlatformGcp>;
/**
 * GCP management configuration extracted from stack settings
 */
export type ManagementConfigGcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: CreateAgentManagerPlatformGcp;
};
export declare const CreateAgentManagerPlatformAws: {
    readonly Aws: "aws";
};
export type CreateAgentManagerPlatformAws = ClosedEnum<typeof CreateAgentManagerPlatformAws>;
/**
 * AWS management configuration extracted from stack settings
 */
export type ManagementConfigAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: CreateAgentManagerPlatformAws;
};
/**
 * Management configuration for cross-account access (self-reported via heartbeat)
 */
export type ManagementConfig = ManagementConfigAzure | ManagementConfigAws | ManagementConfigGcp | ManagementConfigKubernetes | any;
/**
 * Agent manager schema
 */
export type CreateAgentManagerResponse = {
    id: string;
    /**
     * Display name of the agent manager
     */
    name: string;
    /**
     * Platforms this agent manager can handle
     */
    targets: Array<Target>;
    /**
     * Agent Manager URL (self-reported via heartbeat). DeepStore endpoints are exposed through this URL (e.g., {url}/v1/logs)
     */
    url?: string | null | undefined;
    /**
     * Management configuration for cross-account access (self-reported via heartbeat)
     */
    managementConfig?: ManagementConfigAzure | ManagementConfigAws | ManagementConfigGcp | ManagementConfigKubernetes | any | null | undefined;
    /**
     * Whether this is a system agent manager (Alien-hosted)
     */
    isSystem: boolean;
    /**
     * The workspace ID (for system managers, this is ALIEN_WORKSPACE_ID)
     */
    workspaceId: string;
    /**
     * Current health status
     */
    status: models.AgentManagerStatus;
    /**
     * Agent Manager version (self-reported via heartbeat)
     */
    version?: string | null | undefined;
    /**
     * Timestamp of the last received heartbeat from the agent manager
     */
    lastHeartbeatAt?: Date | null | undefined;
    /**
     * ID of the logs database associated with this agent manager
     */
    logsDatabaseId?: string | null | undefined;
    /**
     * Number of agents currently being managed by this agent manager
     */
    managedAgentCount: number;
    /**
     * Timestamp when the agent manager was created
     */
    createdAt: Date;
    /**
     * Deployment link for the web deployment page
     */
    deploymentLink: string;
    /**
     * Agent token for CLI deployment (use with `alien deploy --token=...`)
     */
    token: string;
};
/** @internal */
export type CreateAgentManagerRequest$Outbound = {
    workspace?: string | undefined;
    NewAgentManagerRequest?: models.NewAgentManagerRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateAgentManagerRequest$outboundSchema: z.ZodType<CreateAgentManagerRequest$Outbound, CreateAgentManagerRequest>;
export declare function createAgentManagerRequestToJSON(createAgentManagerRequest: CreateAgentManagerRequest): string;
/** @internal */
export declare const Target$inboundSchema: z.ZodEnum<typeof Target>;
/** @internal */
export declare const CreateAgentManagerPlatformKubernetes$inboundSchema: z.ZodEnum<typeof CreateAgentManagerPlatformKubernetes>;
/** @internal */
export declare const ManagementConfigKubernetes$inboundSchema: z.ZodType<ManagementConfigKubernetes, unknown>;
export declare function managementConfigKubernetesFromJSON(jsonString: string): SafeParseResult<ManagementConfigKubernetes, SDKValidationError>;
/** @internal */
export declare const CreateAgentManagerPlatformAzure$inboundSchema: z.ZodEnum<typeof CreateAgentManagerPlatformAzure>;
/** @internal */
export declare const ManagementConfigAzure$inboundSchema: z.ZodType<ManagementConfigAzure, unknown>;
export declare function managementConfigAzureFromJSON(jsonString: string): SafeParseResult<ManagementConfigAzure, SDKValidationError>;
/** @internal */
export declare const CreateAgentManagerPlatformGcp$inboundSchema: z.ZodEnum<typeof CreateAgentManagerPlatformGcp>;
/** @internal */
export declare const ManagementConfigGcp$inboundSchema: z.ZodType<ManagementConfigGcp, unknown>;
export declare function managementConfigGcpFromJSON(jsonString: string): SafeParseResult<ManagementConfigGcp, SDKValidationError>;
/** @internal */
export declare const CreateAgentManagerPlatformAws$inboundSchema: z.ZodEnum<typeof CreateAgentManagerPlatformAws>;
/** @internal */
export declare const ManagementConfigAws$inboundSchema: z.ZodType<ManagementConfigAws, unknown>;
export declare function managementConfigAwsFromJSON(jsonString: string): SafeParseResult<ManagementConfigAws, SDKValidationError>;
/** @internal */
export declare const ManagementConfig$inboundSchema: z.ZodType<ManagementConfig, unknown>;
export declare function managementConfigFromJSON(jsonString: string): SafeParseResult<ManagementConfig, SDKValidationError>;
/** @internal */
export declare const CreateAgentManagerResponse$inboundSchema: z.ZodType<CreateAgentManagerResponse, unknown>;
export declare function createAgentManagerResponseFromJSON(jsonString: string): SafeParseResult<CreateAgentManagerResponse, SDKValidationError>;
//# sourceMappingURL=createagentmanager.d.ts.map