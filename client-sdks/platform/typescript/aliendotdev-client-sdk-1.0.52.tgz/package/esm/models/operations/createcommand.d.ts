import * as z from "zod/v4";
import * as models from "../index.js";
export type CreateCommandRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    createCommandRequest?: models.CreateCommandRequest | undefined;
};
/** @internal */
export type CreateCommandRequest$Outbound = {
    workspace?: string | undefined;
    CreateCommandRequest?: models.CreateCommandRequest$Outbound | undefined;
};
/** @internal */
export declare const CreateCommandRequest$outboundSchema: z.ZodType<CreateCommandRequest$Outbound, CreateCommandRequest>;
export declare function createCommandRequestToJSON(createCommandRequest: CreateCommandRequest): string;
//# sourceMappingURL=createcommand.d.ts.map