import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetProjectTemplateUrlsRequest = {
    /**
     * Project ID or name.
     */
    idOrName: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Template URLs for deploying an AWS agent
 */
export type GetProjectTemplateUrlsAws = {
    /**
     * URL to download the CloudFormation template
     */
    templateUrl: string;
    /**
     * URL to launch the template in the AWS CloudFormation console
     */
    launchStackUrl: string;
};
/**
 * Template URLs retrieved successfully.
 */
export type GetProjectTemplateUrlsResponse = {
    /**
     * Template URLs for deploying an AWS agent
     */
    aws?: GetProjectTemplateUrlsAws | null | undefined;
};
/** @internal */
export type GetProjectTemplateUrlsRequest$Outbound = {
    idOrName: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetProjectTemplateUrlsRequest$outboundSchema: z.ZodType<GetProjectTemplateUrlsRequest$Outbound, GetProjectTemplateUrlsRequest>;
export declare function getProjectTemplateUrlsRequestToJSON(getProjectTemplateUrlsRequest: GetProjectTemplateUrlsRequest): string;
/** @internal */
export declare const GetProjectTemplateUrlsAws$inboundSchema: z.ZodType<GetProjectTemplateUrlsAws, unknown>;
export declare function getProjectTemplateUrlsAwsFromJSON(jsonString: string): SafeParseResult<GetProjectTemplateUrlsAws, SDKValidationError>;
/** @internal */
export declare const GetProjectTemplateUrlsResponse$inboundSchema: z.ZodType<GetProjectTemplateUrlsResponse, unknown>;
export declare function getProjectTemplateUrlsResponseFromJSON(jsonString: string): SafeParseResult<GetProjectTemplateUrlsResponse, SDKValidationError>;
//# sourceMappingURL=getprojecttemplateurls.d.ts.map