import * as z from "zod/v4";
import * as models from "../index.js";
export type ImportAgentRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    importAgentRequest?: models.ImportAgentRequest | undefined;
};
/** @internal */
export type ImportAgentRequest$Outbound = {
    workspace?: string | undefined;
    ImportAgentRequest?: models.ImportAgentRequest$Outbound | undefined;
};
/** @internal */
export declare const ImportAgentRequest$outboundSchema: z.ZodType<ImportAgentRequest$Outbound, ImportAgentRequest>;
export declare function importAgentRequestToJSON(importAgentRequest: ImportAgentRequest): string;
//# sourceMappingURL=importagent.d.ts.map