import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
import * as models from "../index.js";
export type ListAPIKeysRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Maximum number of items to return per page
     */
    limit?: number | undefined;
    /**
     * Cursor for pagination - omit for first page
     */
    cursor?: string | undefined;
};
/**
 * Paginated response
 */
export type ListAPIKeysResponse = {
    /**
     * Items in this page
     */
    items: Array<models.APIKey>;
    /**
     * Cursor for the next page, null if last page
     */
    nextCursor: string | null;
};
/** @internal */
export type ListAPIKeysRequest$Outbound = {
    workspace?: string | undefined;
    limit: number;
    cursor?: string | undefined;
};
/** @internal */
export declare const ListAPIKeysRequest$outboundSchema: z.ZodType<ListAPIKeysRequest$Outbound, ListAPIKeysRequest>;
export declare function listAPIKeysRequestToJSON(listAPIKeysRequest: ListAPIKeysRequest): string;
/** @internal */
export declare const ListAPIKeysResponse$inboundSchema: z.ZodType<ListAPIKeysResponse, unknown>;
export declare function listAPIKeysResponseFromJSON(jsonString: string): SafeParseResult<ListAPIKeysResponse, SDKValidationError>;
//# sourceMappingURL=listapikeys.d.ts.map