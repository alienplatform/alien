import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetAgentManagerManagementConfigRequest = {
    /**
     * Unique identifier for an agent manager.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
export type Kubernetes = {
    platform: "kubernetes";
};
/**
 * Azure management configuration extracted from stack settings
 */
export type Azure = {
    /**
     * The principal ID of the service principal in the management account
     */
    managementPrincipalId: string;
    /**
     * The managing Azure Tenant ID for cross-tenant access
     */
    managingTenantId: string;
    platform: "azure";
};
/**
 * GCP management configuration extracted from stack settings
 */
export type Gcp = {
    /**
     * Service account email for management roles
     */
    serviceAccountEmail: string;
    platform: "gcp";
};
/**
 * AWS management configuration extracted from stack settings
 */
export type GetAgentManagerManagementConfigAws = {
    /**
     * The managing AWS IAM role ARN that can assume cross-account roles
     */
    managingRoleArn: string;
    platform: "aws";
};
/**
 * Management configuration for different cloud platforms.
 *
 * @remarks
 *
 * Platform-derived configuration for cross-account/cross-tenant access.
 * This is NOT user-specified - it's derived from the Agent Manager's ServiceAccount.
 */
export type GetAgentManagerManagementConfigResponse = GetAgentManagerManagementConfigAws | Gcp | Azure | Kubernetes;
/** @internal */
export type GetAgentManagerManagementConfigRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAgentManagerManagementConfigRequest$outboundSchema: z.ZodType<GetAgentManagerManagementConfigRequest$Outbound, GetAgentManagerManagementConfigRequest>;
export declare function getAgentManagerManagementConfigRequestToJSON(getAgentManagerManagementConfigRequest: GetAgentManagerManagementConfigRequest): string;
/** @internal */
export declare const Kubernetes$inboundSchema: z.ZodType<Kubernetes, unknown>;
export declare function kubernetesFromJSON(jsonString: string): SafeParseResult<Kubernetes, SDKValidationError>;
/** @internal */
export declare const Azure$inboundSchema: z.ZodType<Azure, unknown>;
export declare function azureFromJSON(jsonString: string): SafeParseResult<Azure, SDKValidationError>;
/** @internal */
export declare const Gcp$inboundSchema: z.ZodType<Gcp, unknown>;
export declare function gcpFromJSON(jsonString: string): SafeParseResult<Gcp, SDKValidationError>;
/** @internal */
export declare const GetAgentManagerManagementConfigAws$inboundSchema: z.ZodType<GetAgentManagerManagementConfigAws, unknown>;
export declare function getAgentManagerManagementConfigAwsFromJSON(jsonString: string): SafeParseResult<GetAgentManagerManagementConfigAws, SDKValidationError>;
/** @internal */
export declare const GetAgentManagerManagementConfigResponse$inboundSchema: z.ZodType<GetAgentManagerManagementConfigResponse, unknown>;
export declare function getAgentManagerManagementConfigResponseFromJSON(jsonString: string): SafeParseResult<GetAgentManagerManagementConfigResponse, SDKValidationError>;
//# sourceMappingURL=getagentmanagermanagementconfig.d.ts.map