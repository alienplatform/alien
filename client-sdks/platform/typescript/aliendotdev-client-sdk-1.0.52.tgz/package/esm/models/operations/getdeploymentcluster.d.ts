import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type GetDeploymentClusterRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
export type GetDeploymentClusterCpu = {
    total: number;
    available: number;
};
export type GetDeploymentClusterMemory = {
    total: number;
    available: number;
};
export type EphemeralStorage = {
    total: number;
    available: number;
};
export type Capacity = {
    cpu: GetDeploymentClusterCpu;
    memory: GetDeploymentClusterMemory;
    ephemeralStorage: EphemeralStorage;
};
/**
 * Cluster overview.
 */
export type GetDeploymentClusterResponse = {
    machineCount: number;
    containerCount: number;
    capacity: Capacity;
};
/** @internal */
export type GetDeploymentClusterRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDeploymentClusterRequest$outboundSchema: z.ZodType<GetDeploymentClusterRequest$Outbound, GetDeploymentClusterRequest>;
export declare function getDeploymentClusterRequestToJSON(getDeploymentClusterRequest: GetDeploymentClusterRequest): string;
/** @internal */
export declare const GetDeploymentClusterCpu$inboundSchema: z.ZodType<GetDeploymentClusterCpu, unknown>;
export declare function getDeploymentClusterCpuFromJSON(jsonString: string): SafeParseResult<GetDeploymentClusterCpu, SDKValidationError>;
/** @internal */
export declare const GetDeploymentClusterMemory$inboundSchema: z.ZodType<GetDeploymentClusterMemory, unknown>;
export declare function getDeploymentClusterMemoryFromJSON(jsonString: string): SafeParseResult<GetDeploymentClusterMemory, SDKValidationError>;
/** @internal */
export declare const EphemeralStorage$inboundSchema: z.ZodType<EphemeralStorage, unknown>;
export declare function ephemeralStorageFromJSON(jsonString: string): SafeParseResult<EphemeralStorage, SDKValidationError>;
/** @internal */
export declare const Capacity$inboundSchema: z.ZodType<Capacity, unknown>;
export declare function capacityFromJSON(jsonString: string): SafeParseResult<Capacity, SDKValidationError>;
/** @internal */
export declare const GetDeploymentClusterResponse$inboundSchema: z.ZodType<GetDeploymentClusterResponse, unknown>;
export declare function getDeploymentClusterResponseFromJSON(jsonString: string): SafeParseResult<GetDeploymentClusterResponse, SDKValidationError>;
//# sourceMappingURL=getdeploymentcluster.d.ts.map