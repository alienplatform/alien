import * as z from "zod/v4";
import { ClosedEnum } from "../../types/enums.js";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
/**
 * Template root directory inside aliendotdev/alien
 */
export declare const TemplatePathRequest: {
    readonly ExamplesMinimalCloudAgent: "examples/minimal-cloud-agent";
    readonly ExamplesEndpointAgent: "examples/endpoint-agent";
    readonly ExamplesByocDatabase: "examples/byoc-database";
    readonly ExamplesGithubAgentPackagesRemoteAgent: "examples/github-agent/packages/remote-agent";
};
/**
 * Template root directory inside aliendotdev/alien
 */
export type TemplatePathRequest = ClosedEnum<typeof TemplatePathRequest>;
/**
 * CLI package configuration. If null, CLI packages will not be generated.
 */
export type CreateProjectFromTemplateCliRequest = {
    /**
     * Human-friendly display name for help banners and about text
     */
    displayName: string;
    /**
     * Binary name displayed in help and usage (e.g., "my-cli")
     */
    name: string;
    /**
     * Whether CLI package generation is enabled
     */
    enabled: boolean;
};
/**
 * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
 */
export type CreateProjectFromTemplateCloudformationRequest = {
    /**
     * Whether CloudFormation package generation is enabled
     */
    enabled: boolean;
};
/**
 * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
 */
export type CreateProjectFromTemplateOperatorImageRequest = {
    /**
     * Human-friendly display name for logs and startup messages
     */
    displayName: string;
    /**
     * Binary name (e.g., "acme-operator")
     */
    name: string;
    /**
     * Whether operator image package generation is enabled
     */
    enabled: boolean;
};
/**
 * Helm chart package configuration. If null, Helm packages will not be generated.
 */
export type CreateProjectFromTemplateHelmRequest = {
    /**
     * Chart name (e.g., "acme-operator")
     */
    chartName: string;
    /**
     * Human-friendly description of the chart
     */
    description: string;
    /**
     * Whether Helm chart package generation is enabled
     */
    enabled: boolean;
};
/**
 * Terraform provider package configuration. If null, Terraform packages will not be generated.
 */
export type CreateProjectFromTemplateTerraformRequest = {
    /**
     * Terraform provider name (e.g., "acme")
     */
    providerName: string;
    /**
     * Terraform resource type name (e.g., "agent")
     */
    resourceType: string;
    /**
     * Whether Terraform provider package generation is enabled
     */
    enabled: boolean;
};
/**
 * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
 */
export type CreateProjectFromTemplatePackagesConfigRequest = {
    /**
     * CLI package configuration. If null, CLI packages will not be generated.
     */
    cli?: CreateProjectFromTemplateCliRequest | null | undefined;
    /**
     * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
     */
    cloudformation?: CreateProjectFromTemplateCloudformationRequest | null | undefined;
    /**
     * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
     */
    operatorImage?: CreateProjectFromTemplateOperatorImageRequest | null | undefined;
    /**
     * Helm chart package configuration. If null, Helm packages will not be generated.
     */
    helm?: CreateProjectFromTemplateHelmRequest | null | undefined;
    /**
     * Terraform provider package configuration. If null, Terraform packages will not be generated.
     */
    terraform?: CreateProjectFromTemplateTerraformRequest | null | undefined;
};
export type CreateProjectFromTemplateRequestBody = {
    /**
     * Project name.
     */
    name: string;
    /**
     * GitHub owner namespace (user or organization) that will receive the fork
     */
    targetNamespace: string;
    /**
     * Template root directory inside aliendotdev/alien
     */
    templatePath: TemplatePathRequest;
    /**
     * The name of a directory or relative path to the source code of your project. When null is used it will default to the project root
     */
    rootDirectory?: string | null | undefined;
    /**
     * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
     */
    packagesConfig?: CreateProjectFromTemplatePackagesConfigRequest | null | undefined;
};
export type CreateProjectFromTemplateRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    requestBody?: CreateProjectFromTemplateRequestBody | undefined;
};
/**
 * The Git Provider of the repository
 */
export declare const CreateProjectFromTemplateTypeGithub: {
    readonly Github: "github";
};
/**
 * The Git Provider of the repository
 */
export type CreateProjectFromTemplateTypeGithub = ClosedEnum<typeof CreateProjectFromTemplateTypeGithub>;
/**
 * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
 */
export type CreateProjectFromTemplateGitRepository = {
    /**
     * The Git Provider of the repository
     */
    type: CreateProjectFromTemplateTypeGithub;
    /**
     * The name of the git repository
     */
    repo: string;
};
/**
 * Type of animated background to display on the deployment page.
 */
export declare const CreateProjectFromTemplateDeploymentPageBackgroundType: {
    readonly GradientMesh: "gradient-mesh";
    readonly FloatingOrbs: "floating-orbs";
    readonly FlickeringGrid: "flickering-grid";
    readonly BubbleGlow: "bubble-glow";
    readonly ParticleField: "particle-field";
};
/**
 * Type of animated background to display on the deployment page.
 */
export type CreateProjectFromTemplateDeploymentPageBackgroundType = ClosedEnum<typeof CreateProjectFromTemplateDeploymentPageBackgroundType>;
/**
 * Color mode for the background animation.
 */
export declare const CreateProjectFromTemplateMode: {
    readonly Dark: "dark";
    readonly Light: "light";
};
/**
 * Color mode for the background animation.
 */
export type CreateProjectFromTemplateMode = ClosedEnum<typeof CreateProjectFromTemplateMode>;
/**
 * Color scheme for the background animation.
 */
export declare const CreateProjectFromTemplateColorScheme: {
    readonly Blue: "blue";
    readonly Purple: "purple";
    readonly Green: "green";
    readonly Orange: "orange";
    readonly Pink: "pink";
};
/**
 * Color scheme for the background animation.
 */
export type CreateProjectFromTemplateColorScheme = ClosedEnum<typeof CreateProjectFromTemplateColorScheme>;
/**
 * Customization settings for the deployment page background animation.
 */
export type CreateProjectFromTemplateDeploymentPageBackground = {
    /**
     * Type of animated background to display on the deployment page.
     */
    type: CreateProjectFromTemplateDeploymentPageBackgroundType;
    /**
     * Color mode for the background animation.
     */
    mode: CreateProjectFromTemplateMode;
    /**
     * Color scheme for the background animation.
     */
    colorScheme: CreateProjectFromTemplateColorScheme;
};
/**
 * CLI package configuration. If null, CLI packages will not be generated.
 */
export type CreateProjectFromTemplateCliResponse = {
    /**
     * Human-friendly display name for help banners and about text
     */
    displayName: string;
    /**
     * Binary name displayed in help and usage (e.g., "my-cli")
     */
    name: string;
    /**
     * Whether CLI package generation is enabled
     */
    enabled: boolean;
};
/**
 * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
 */
export type CreateProjectFromTemplateCloudformationResponse = {
    /**
     * Whether CloudFormation package generation is enabled
     */
    enabled: boolean;
};
/**
 * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
 */
export type CreateProjectFromTemplateOperatorImageResponse = {
    /**
     * Human-friendly display name for logs and startup messages
     */
    displayName: string;
    /**
     * Binary name (e.g., "acme-operator")
     */
    name: string;
    /**
     * Whether operator image package generation is enabled
     */
    enabled: boolean;
};
/**
 * Helm chart package configuration. If null, Helm packages will not be generated.
 */
export type CreateProjectFromTemplateHelmResponse = {
    /**
     * Chart name (e.g., "acme-operator")
     */
    chartName: string;
    /**
     * Human-friendly description of the chart
     */
    description: string;
    /**
     * Whether Helm chart package generation is enabled
     */
    enabled: boolean;
};
/**
 * Terraform provider package configuration. If null, Terraform packages will not be generated.
 */
export type CreateProjectFromTemplateTerraformResponse = {
    /**
     * Terraform provider name (e.g., "acme")
     */
    providerName: string;
    /**
     * Terraform resource type name (e.g., "agent")
     */
    resourceType: string;
    /**
     * Whether Terraform provider package generation is enabled
     */
    enabled: boolean;
};
/**
 * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
 */
export type CreateProjectFromTemplatePackagesConfigResponse = {
    /**
     * CLI package configuration. If null, CLI packages will not be generated.
     */
    cli?: CreateProjectFromTemplateCliResponse | null | undefined;
    /**
     * CloudFormation package configuration. If null, CloudFormation packages will not be generated.
     */
    cloudformation?: CreateProjectFromTemplateCloudformationResponse | null | undefined;
    /**
     * Operator image package configuration. Required when Helm is enabled. If null, operator image packages will not be generated.
     */
    operatorImage?: CreateProjectFromTemplateOperatorImageResponse | null | undefined;
    /**
     * Helm chart package configuration. If null, Helm packages will not be generated.
     */
    helm?: CreateProjectFromTemplateHelmResponse | null | undefined;
    /**
     * Terraform provider package configuration. If null, Terraform packages will not be generated.
     */
    terraform?: CreateProjectFromTemplateTerraformResponse | null | undefined;
};
export type CreateProjectFromTemplateGithubSetup = {
    /**
     * URL to the pull request with the Alien build workflow
     */
    pullRequestUrl: string;
    /**
     * URL to the GitHub Actions workflow
     */
    workflowUrl: string;
};
export declare const SourceRepository: {
    readonly AliendotdevAlien: "aliendotdev/alien";
};
export type SourceRepository = ClosedEnum<typeof SourceRepository>;
/**
 * Template root directory inside aliendotdev/alien
 */
export declare const TemplatePathResponse: {
    readonly ExamplesMinimalCloudAgent: "examples/minimal-cloud-agent";
    readonly ExamplesEndpointAgent: "examples/endpoint-agent";
    readonly ExamplesByocDatabase: "examples/byoc-database";
    readonly ExamplesGithubAgentPackagesRemoteAgent: "examples/github-agent/packages/remote-agent";
};
/**
 * Template root directory inside aliendotdev/alien
 */
export type TemplatePathResponse = ClosedEnum<typeof TemplatePathResponse>;
export type Template = {
    sourceRepository: SourceRepository;
    /**
     * Fork repository in <owner>/<repo> format
     */
    forkRepository: string;
    /**
     * Template root directory inside aliendotdev/alien
     */
    templatePath: TemplatePathResponse;
    resolvedRootDirectory: string;
};
/**
 * Project created successfully from template.
 */
export type CreateProjectFromTemplateResponse = {
    /**
     * Unique identifier for the project.
     */
    id: string;
    /**
     * Project name.
     */
    name: string;
    /**
     * The Git Repository that will be connected to the project. When this is defined, any pushes to the specified connected Git Repository will be automatically deployed
     */
    gitRepository?: CreateProjectFromTemplateGitRepository | null | undefined;
    /**
     * The name of a directory or relative path to the source code of your project. When null is used it will default to the project root
     */
    rootDirectory?: string | null | undefined;
    /**
     * Customization settings for the deployment page background animation.
     */
    deploymentPageBackground?: CreateProjectFromTemplateDeploymentPageBackground | null | undefined;
    /**
     * Configuration for embedded packages (CLI, CloudFormation, Helm, Terraform)
     */
    packagesConfig?: CreateProjectFromTemplatePackagesConfigResponse | null | undefined;
    /**
     * Selected domain for this project (null = default system domain)
     */
    domainId?: string | null | undefined;
    createdAt: Date;
    /**
     * Unique identifier for the workspace.
     */
    workspaceId: string;
    githubSetup?: CreateProjectFromTemplateGithubSetup | undefined;
    template: Template;
};
/** @internal */
export declare const TemplatePathRequest$outboundSchema: z.ZodEnum<typeof TemplatePathRequest>;
/** @internal */
export type CreateProjectFromTemplateCliRequest$Outbound = {
    displayName: string;
    name: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectFromTemplateCliRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateCliRequest$Outbound, CreateProjectFromTemplateCliRequest>;
export declare function createProjectFromTemplateCliRequestToJSON(createProjectFromTemplateCliRequest: CreateProjectFromTemplateCliRequest): string;
/** @internal */
export type CreateProjectFromTemplateCloudformationRequest$Outbound = {
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectFromTemplateCloudformationRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateCloudformationRequest$Outbound, CreateProjectFromTemplateCloudformationRequest>;
export declare function createProjectFromTemplateCloudformationRequestToJSON(createProjectFromTemplateCloudformationRequest: CreateProjectFromTemplateCloudformationRequest): string;
/** @internal */
export type CreateProjectFromTemplateOperatorImageRequest$Outbound = {
    displayName: string;
    name: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectFromTemplateOperatorImageRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateOperatorImageRequest$Outbound, CreateProjectFromTemplateOperatorImageRequest>;
export declare function createProjectFromTemplateOperatorImageRequestToJSON(createProjectFromTemplateOperatorImageRequest: CreateProjectFromTemplateOperatorImageRequest): string;
/** @internal */
export type CreateProjectFromTemplateHelmRequest$Outbound = {
    chartName: string;
    description: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectFromTemplateHelmRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateHelmRequest$Outbound, CreateProjectFromTemplateHelmRequest>;
export declare function createProjectFromTemplateHelmRequestToJSON(createProjectFromTemplateHelmRequest: CreateProjectFromTemplateHelmRequest): string;
/** @internal */
export type CreateProjectFromTemplateTerraformRequest$Outbound = {
    providerName: string;
    resourceType: string;
    enabled: boolean;
};
/** @internal */
export declare const CreateProjectFromTemplateTerraformRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateTerraformRequest$Outbound, CreateProjectFromTemplateTerraformRequest>;
export declare function createProjectFromTemplateTerraformRequestToJSON(createProjectFromTemplateTerraformRequest: CreateProjectFromTemplateTerraformRequest): string;
/** @internal */
export type CreateProjectFromTemplatePackagesConfigRequest$Outbound = {
    cli?: CreateProjectFromTemplateCliRequest$Outbound | null | undefined;
    cloudformation?: CreateProjectFromTemplateCloudformationRequest$Outbound | null | undefined;
    operatorImage?: CreateProjectFromTemplateOperatorImageRequest$Outbound | null | undefined;
    helm?: CreateProjectFromTemplateHelmRequest$Outbound | null | undefined;
    terraform?: CreateProjectFromTemplateTerraformRequest$Outbound | null | undefined;
};
/** @internal */
export declare const CreateProjectFromTemplatePackagesConfigRequest$outboundSchema: z.ZodType<CreateProjectFromTemplatePackagesConfigRequest$Outbound, CreateProjectFromTemplatePackagesConfigRequest>;
export declare function createProjectFromTemplatePackagesConfigRequestToJSON(createProjectFromTemplatePackagesConfigRequest: CreateProjectFromTemplatePackagesConfigRequest): string;
/** @internal */
export type CreateProjectFromTemplateRequestBody$Outbound = {
    name: string;
    targetNamespace: string;
    templatePath: string;
    rootDirectory?: string | null | undefined;
    packagesConfig?: CreateProjectFromTemplatePackagesConfigRequest$Outbound | null | undefined;
};
/** @internal */
export declare const CreateProjectFromTemplateRequestBody$outboundSchema: z.ZodType<CreateProjectFromTemplateRequestBody$Outbound, CreateProjectFromTemplateRequestBody>;
export declare function createProjectFromTemplateRequestBodyToJSON(createProjectFromTemplateRequestBody: CreateProjectFromTemplateRequestBody): string;
/** @internal */
export type CreateProjectFromTemplateRequest$Outbound = {
    workspace?: string | undefined;
    RequestBody?: CreateProjectFromTemplateRequestBody$Outbound | undefined;
};
/** @internal */
export declare const CreateProjectFromTemplateRequest$outboundSchema: z.ZodType<CreateProjectFromTemplateRequest$Outbound, CreateProjectFromTemplateRequest>;
export declare function createProjectFromTemplateRequestToJSON(createProjectFromTemplateRequest: CreateProjectFromTemplateRequest): string;
/** @internal */
export declare const CreateProjectFromTemplateTypeGithub$inboundSchema: z.ZodEnum<typeof CreateProjectFromTemplateTypeGithub>;
/** @internal */
export declare const CreateProjectFromTemplateGitRepository$inboundSchema: z.ZodType<CreateProjectFromTemplateGitRepository, unknown>;
export declare function createProjectFromTemplateGitRepositoryFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateGitRepository, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateDeploymentPageBackgroundType$inboundSchema: z.ZodEnum<typeof CreateProjectFromTemplateDeploymentPageBackgroundType>;
/** @internal */
export declare const CreateProjectFromTemplateMode$inboundSchema: z.ZodEnum<typeof CreateProjectFromTemplateMode>;
/** @internal */
export declare const CreateProjectFromTemplateColorScheme$inboundSchema: z.ZodEnum<typeof CreateProjectFromTemplateColorScheme>;
/** @internal */
export declare const CreateProjectFromTemplateDeploymentPageBackground$inboundSchema: z.ZodType<CreateProjectFromTemplateDeploymentPageBackground, unknown>;
export declare function createProjectFromTemplateDeploymentPageBackgroundFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateDeploymentPageBackground, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateCliResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateCliResponse, unknown>;
export declare function createProjectFromTemplateCliResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateCliResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateCloudformationResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateCloudformationResponse, unknown>;
export declare function createProjectFromTemplateCloudformationResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateCloudformationResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateOperatorImageResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateOperatorImageResponse, unknown>;
export declare function createProjectFromTemplateOperatorImageResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateOperatorImageResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateHelmResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateHelmResponse, unknown>;
export declare function createProjectFromTemplateHelmResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateHelmResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateTerraformResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateTerraformResponse, unknown>;
export declare function createProjectFromTemplateTerraformResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateTerraformResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplatePackagesConfigResponse$inboundSchema: z.ZodType<CreateProjectFromTemplatePackagesConfigResponse, unknown>;
export declare function createProjectFromTemplatePackagesConfigResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplatePackagesConfigResponse, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateGithubSetup$inboundSchema: z.ZodType<CreateProjectFromTemplateGithubSetup, unknown>;
export declare function createProjectFromTemplateGithubSetupFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateGithubSetup, SDKValidationError>;
/** @internal */
export declare const SourceRepository$inboundSchema: z.ZodEnum<typeof SourceRepository>;
/** @internal */
export declare const TemplatePathResponse$inboundSchema: z.ZodEnum<typeof TemplatePathResponse>;
/** @internal */
export declare const Template$inboundSchema: z.ZodType<Template, unknown>;
export declare function templateFromJSON(jsonString: string): SafeParseResult<Template, SDKValidationError>;
/** @internal */
export declare const CreateProjectFromTemplateResponse$inboundSchema: z.ZodType<CreateProjectFromTemplateResponse, unknown>;
export declare function createProjectFromTemplateResponseFromJSON(jsonString: string): SafeParseResult<CreateProjectFromTemplateResponse, SDKValidationError>;
//# sourceMappingURL=createprojectfromtemplate.d.ts.map