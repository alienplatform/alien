import * as z from "zod/v4";
export type CreateDomainRequestBody = {
    domain: string;
};
export type CreateDomainRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    requestBody?: CreateDomainRequestBody | undefined;
};
/** @internal */
export type CreateDomainRequestBody$Outbound = {
    domain: string;
};
/** @internal */
export declare const CreateDomainRequestBody$outboundSchema: z.ZodType<CreateDomainRequestBody$Outbound, CreateDomainRequestBody>;
export declare function createDomainRequestBodyToJSON(createDomainRequestBody: CreateDomainRequestBody): string;
/** @internal */
export type CreateDomainRequest$Outbound = {
    workspace?: string | undefined;
    RequestBody?: CreateDomainRequestBody$Outbound | undefined;
};
/** @internal */
export declare const CreateDomainRequest$outboundSchema: z.ZodType<CreateDomainRequest$Outbound, CreateDomainRequest>;
export declare function createDomainRequestToJSON(createDomainRequest: CreateDomainRequest): string;
//# sourceMappingURL=createdomain.d.ts.map