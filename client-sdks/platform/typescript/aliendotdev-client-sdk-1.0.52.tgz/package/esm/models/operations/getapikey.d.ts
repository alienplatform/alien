import * as z from "zod/v4";
export type GetAPIKeyRequest = {
    /**
     * Unique identifier for the api key.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetAPIKeyRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetAPIKeyRequest$outboundSchema: z.ZodType<GetAPIKeyRequest$Outbound, GetAPIKeyRequest>;
export declare function getAPIKeyRequestToJSON(getAPIKeyRequest: GetAPIKeyRequest): string;
//# sourceMappingURL=getapikey.d.ts.map