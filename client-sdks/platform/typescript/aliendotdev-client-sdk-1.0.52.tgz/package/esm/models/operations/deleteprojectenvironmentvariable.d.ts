import * as z from "zod";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type DeleteProjectEnvironmentVariableRequest = {
    /**
     * Filter by project ID or name.
     */
    idOrName: string;
    /**
     * Environment variable ID
     */
    envId: string;
    /**
     * The current workspace. If not provided, the user's last workspace will be used.
     */
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteProjectEnvironmentVariableRequest$inboundSchema: z.ZodType<DeleteProjectEnvironmentVariableRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type DeleteProjectEnvironmentVariableRequest$Outbound = {
    idOrName: string;
    envId: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteProjectEnvironmentVariableRequest$outboundSchema: z.ZodType<DeleteProjectEnvironmentVariableRequest$Outbound, z.ZodTypeDef, DeleteProjectEnvironmentVariableRequest>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace DeleteProjectEnvironmentVariableRequest$ {
    /** @deprecated use `DeleteProjectEnvironmentVariableRequest$inboundSchema` instead. */
    const inboundSchema: z.ZodType<DeleteProjectEnvironmentVariableRequest, z.ZodTypeDef, unknown>;
    /** @deprecated use `DeleteProjectEnvironmentVariableRequest$outboundSchema` instead. */
    const outboundSchema: z.ZodType<DeleteProjectEnvironmentVariableRequest$Outbound, z.ZodTypeDef, DeleteProjectEnvironmentVariableRequest>;
    /** @deprecated use `DeleteProjectEnvironmentVariableRequest$Outbound` instead. */
    type Outbound = DeleteProjectEnvironmentVariableRequest$Outbound;
}
export declare function deleteProjectEnvironmentVariableRequestToJSON(deleteProjectEnvironmentVariableRequest: DeleteProjectEnvironmentVariableRequest): string;
export declare function deleteProjectEnvironmentVariableRequestFromJSON(jsonString: string): SafeParseResult<DeleteProjectEnvironmentVariableRequest, SDKValidationError>;
//# sourceMappingURL=deleteprojectenvironmentvariable.d.ts.map