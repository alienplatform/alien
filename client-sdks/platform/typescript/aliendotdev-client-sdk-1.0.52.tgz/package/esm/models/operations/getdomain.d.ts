import * as z from "zod/v4";
export type GetDomainRequest = {
    /**
     * Unique identifier for the domain.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type GetDomainRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const GetDomainRequest$outboundSchema: z.ZodType<GetDomainRequest$Outbound, GetDomainRequest>;
export declare function getDomainRequestToJSON(getDomainRequest: GetDomainRequest): string;
//# sourceMappingURL=getdomain.d.ts.map