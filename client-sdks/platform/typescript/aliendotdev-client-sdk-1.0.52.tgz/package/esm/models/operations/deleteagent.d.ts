import * as z from "zod/v4";
import { Result as SafeParseResult } from "../../types/fp.js";
import { SDKValidationError } from "../errors/sdkvalidationerror.js";
export type DeleteAgentRequest = {
    /**
     * Unique identifier for the agent.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/**
 * Agent deletion enqueued successfully.
 */
export type DeleteAgentResponse = {
    message: string;
};
/** @internal */
export type DeleteAgentRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteAgentRequest$outboundSchema: z.ZodType<DeleteAgentRequest$Outbound, DeleteAgentRequest>;
export declare function deleteAgentRequestToJSON(deleteAgentRequest: DeleteAgentRequest): string;
/** @internal */
export declare const DeleteAgentResponse$inboundSchema: z.ZodType<DeleteAgentResponse, unknown>;
export declare function deleteAgentResponseFromJSON(jsonString: string): SafeParseResult<DeleteAgentResponse, SDKValidationError>;
//# sourceMappingURL=deleteagent.d.ts.map