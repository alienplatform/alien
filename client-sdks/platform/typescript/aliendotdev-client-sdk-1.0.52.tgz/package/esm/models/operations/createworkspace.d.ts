import * as z from "zod/v4";
export type CreateWorkspaceRequest = {
    /**
     * Workspace name
     */
    name: string;
    /**
     * Optional workspace logo URL
     */
    logoUrl?: string | undefined;
};
/** @internal */
export type CreateWorkspaceRequest$Outbound = {
    name: string;
    logoUrl?: string | undefined;
};
/** @internal */
export declare const CreateWorkspaceRequest$outboundSchema: z.ZodType<CreateWorkspaceRequest$Outbound, CreateWorkspaceRequest>;
export declare function createWorkspaceRequestToJSON(createWorkspaceRequest: CreateWorkspaceRequest): string;
//# sourceMappingURL=createworkspace.d.ts.map