import * as z from "zod/v4";
export type DeleteWorkspaceRequest = {
    /**
     * Unique identifier for the workspace.
     */
    id: string;
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
};
/** @internal */
export type DeleteWorkspaceRequest$Outbound = {
    id: string;
    workspace?: string | undefined;
};
/** @internal */
export declare const DeleteWorkspaceRequest$outboundSchema: z.ZodType<DeleteWorkspaceRequest$Outbound, DeleteWorkspaceRequest>;
export declare function deleteWorkspaceRequestToJSON(deleteWorkspaceRequest: DeleteWorkspaceRequest): string;
//# sourceMappingURL=deleteworkspace.d.ts.map