import * as z from "zod/v4";
export type ListCommandNamesRequest = {
    /**
     * Workspace name. Defaults to your last workspace (user auth) or your API key's workspace (token auth). When using an API key, if provided, must match the key's workspace.
     */
    workspace?: string | undefined;
    /**
     * Filter by project ID or name.
     */
    project?: string | undefined;
    /**
     * Search command names (prefix match)
     */
    search?: string | undefined;
};
/** @internal */
export type ListCommandNamesRequest$Outbound = {
    workspace?: string | undefined;
    project?: string | undefined;
    search?: string | undefined;
};
/** @internal */
export declare const ListCommandNamesRequest$outboundSchema: z.ZodType<ListCommandNamesRequest$Outbound, ListCommandNamesRequest>;
export declare function listCommandNamesRequestToJSON(listCommandNamesRequest: ListCommandNamesRequest): string;
//# sourceMappingURL=listcommandnames.d.ts.map