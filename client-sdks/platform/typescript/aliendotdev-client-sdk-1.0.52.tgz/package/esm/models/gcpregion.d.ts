import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * Google Cloud region.
 */
export declare const GCPRegion: {
    readonly UsCentral1: "us-central1";
    readonly UsEast1: "us-east1";
    readonly UsEast4: "us-east4";
    readonly UsWest1: "us-west1";
    readonly UsWest2: "us-west2";
    readonly UsWest3: "us-west3";
    readonly UsWest4: "us-west4";
    readonly EuropeWest1: "europe-west1";
    readonly EuropeWest2: "europe-west2";
    readonly EuropeWest3: "europe-west3";
    readonly EuropeWest4: "europe-west4";
    readonly EuropeWest6: "europe-west6";
    readonly EuropeNorth1: "europe-north1";
    readonly AsiaEast1: "asia-east1";
    readonly AsiaEast2: "asia-east2";
    readonly AsiaNortheast1: "asia-northeast1";
    readonly AsiaNortheast2: "asia-northeast2";
    readonly AsiaNortheast3: "asia-northeast3";
    readonly AsiaSouth1: "asia-south1";
    readonly AsiaSoutheast1: "asia-southeast1";
    readonly AsiaSoutheast2: "asia-southeast2";
    readonly AustraliaSoutheast1: "australia-southeast1";
    readonly SouthamericaEast1: "southamerica-east1";
};
/**
 * Google Cloud region.
 */
export type GCPRegion = ClosedEnum<typeof GCPRegion>;
/** @internal */
export declare const GCPRegion$inboundSchema: z.ZodNativeEnum<typeof GCPRegion>;
/** @internal */
export declare const GCPRegion$outboundSchema: z.ZodNativeEnum<typeof GCPRegion>;
/**
 * @internal
 * @deprecated This namespace will be removed in future versions. Use schemas and types that are exported directly from this module.
 */
export declare namespace GCPRegion$ {
    /** @deprecated use `GCPRegion$inboundSchema` instead. */
    const inboundSchema: z.ZodNativeEnum<{
        readonly UsCentral1: "us-central1";
        readonly UsEast1: "us-east1";
        readonly UsEast4: "us-east4";
        readonly UsWest1: "us-west1";
        readonly UsWest2: "us-west2";
        readonly UsWest3: "us-west3";
        readonly UsWest4: "us-west4";
        readonly EuropeWest1: "europe-west1";
        readonly EuropeWest2: "europe-west2";
        readonly EuropeWest3: "europe-west3";
        readonly EuropeWest4: "europe-west4";
        readonly EuropeWest6: "europe-west6";
        readonly EuropeNorth1: "europe-north1";
        readonly AsiaEast1: "asia-east1";
        readonly AsiaEast2: "asia-east2";
        readonly AsiaNortheast1: "asia-northeast1";
        readonly AsiaNortheast2: "asia-northeast2";
        readonly AsiaNortheast3: "asia-northeast3";
        readonly AsiaSouth1: "asia-south1";
        readonly AsiaSoutheast1: "asia-southeast1";
        readonly AsiaSoutheast2: "asia-southeast2";
        readonly AustraliaSoutheast1: "australia-southeast1";
        readonly SouthamericaEast1: "southamerica-east1";
    }>;
    /** @deprecated use `GCPRegion$outboundSchema` instead. */
    const outboundSchema: z.ZodNativeEnum<{
        readonly UsCentral1: "us-central1";
        readonly UsEast1: "us-east1";
        readonly UsEast4: "us-east4";
        readonly UsWest1: "us-west1";
        readonly UsWest2: "us-west2";
        readonly UsWest3: "us-west3";
        readonly UsWest4: "us-west4";
        readonly EuropeWest1: "europe-west1";
        readonly EuropeWest2: "europe-west2";
        readonly EuropeWest3: "europe-west3";
        readonly EuropeWest4: "europe-west4";
        readonly EuropeWest6: "europe-west6";
        readonly EuropeNorth1: "europe-north1";
        readonly AsiaEast1: "asia-east1";
        readonly AsiaEast2: "asia-east2";
        readonly AsiaNortheast1: "asia-northeast1";
        readonly AsiaNortheast2: "asia-northeast2";
        readonly AsiaNortheast3: "asia-northeast3";
        readonly AsiaSouth1: "asia-south1";
        readonly AsiaSoutheast1: "asia-southeast1";
        readonly AsiaSoutheast2: "asia-southeast2";
        readonly AustraliaSoutheast1: "australia-southeast1";
        readonly SouthamericaEast1: "southamerica-east1";
    }>;
}
//# sourceMappingURL=gcpregion.d.ts.map