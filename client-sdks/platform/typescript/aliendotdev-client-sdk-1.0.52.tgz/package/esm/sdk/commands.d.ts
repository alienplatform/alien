import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Commands extends ClientSDK {
    /**
     * Retrieve commands. Use for dashboard analytics and command history.
     */
    list(request?: operations.ListCommandsRequest | undefined, options?: RequestOptions): Promise<operations.ListCommandsResponse>;
    /**
     * Create command metadata. Called by Agent Manager when processing ARC commands. Returns project info for routing decisions.
     */
    create(request?: operations.CreateCommandRequest | undefined, options?: RequestOptions): Promise<models.CreateCommandResponse>;
    /**
     * List distinct command names. Use for filter dropdowns in the dashboard.
     */
    listNames(request?: operations.ListCommandNamesRequest | undefined, options?: RequestOptions): Promise<models.ListCommandNamesResponse>;
    /**
     * List distinct agents that have commands, including deployment group info. Use for filter dropdowns in the dashboard.
     */
    listAgents(request?: operations.ListCommandAgentsRequest | undefined, options?: RequestOptions): Promise<models.ListCommandAgentsResponse>;
    /**
     * Retrieve a command by ID.
     */
    get(request: operations.GetCommandRequest, options?: RequestOptions): Promise<models.Command>;
    /**
     * Update command state. Called by Agent Manager when command is dispatched or completes.
     */
    update(request: operations.UpdateCommandRequest, options?: RequestOptions): Promise<models.Command>;
}
//# sourceMappingURL=commands.d.ts.map