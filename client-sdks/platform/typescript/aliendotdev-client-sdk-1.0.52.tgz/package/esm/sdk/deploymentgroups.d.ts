import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class DeploymentGroups extends ClientSDK {
    /**
     * List deployment groups
     */
    listDeploymentGroups(request?: operations.ListDeploymentGroupsRequest | undefined, options?: RequestOptions): Promise<operations.ListDeploymentGroupsResponse>;
    /**
     * Create a new deployment group
     */
    createDeploymentGroup(request?: operations.CreateDeploymentGroupRequest | undefined, options?: RequestOptions): Promise<models.DeploymentGroup>;
    /**
     * Get deployment group details
     */
    getDeploymentGroup(request: operations.GetDeploymentGroupRequest, options?: RequestOptions): Promise<operations.GetDeploymentGroupResponse>;
    /**
     * Delete deployment group
     */
    deleteDeploymentGroup(request: operations.DeleteDeploymentGroupRequest, options?: RequestOptions): Promise<void>;
    /**
     * Update deployment group
     */
    updateDeploymentGroup(request: operations.UpdateDeploymentGroupRequest, options?: RequestOptions): Promise<models.DeploymentGroup>;
    /**
     * Create deployment group token
     *
     * @remarks
     * Creates a deployment-group scoped API key and returns both the token and formatted deployment link
     */
    createDeploymentGroupToken(request: operations.CreateDeploymentGroupTokenRequest, options?: RequestOptions): Promise<models.CreateDeploymentGroupTokenResponse>;
}
//# sourceMappingURL=deploymentgroups.d.ts.map