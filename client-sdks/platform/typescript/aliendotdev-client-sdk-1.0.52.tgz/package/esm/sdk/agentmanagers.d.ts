import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class AgentManagers extends ClientSDK {
    /**
     * Retrieve all agent managers.
     */
    list(request?: operations.ListAgentManagersRequest | undefined, options?: RequestOptions): Promise<Array<models.AgentManager>>;
    /**
     * Create a new agent manager.
     */
    create(request?: operations.CreateAgentManagerRequest | undefined, options?: RequestOptions): Promise<operations.CreateAgentManagerResponse>;
    /**
     * Retrieve an agent manager by ID.
     */
    get(request: operations.GetAgentManagerRequest, options?: RequestOptions): Promise<models.AgentManager>;
    /**
     * Delete an agent manager by ID.
     */
    delete(request: operations.DeleteAgentManagerRequest, options?: RequestOptions): Promise<operations.DeleteAgentManagerResponse>;
    /**
     * Get the management configuration for an agent manager.
     */
    getManagementConfig(request: operations.GetAgentManagerManagementConfigRequest, options?: RequestOptions): Promise<operations.GetAgentManagerManagementConfigResponse>;
    /**
     * Enqueue provisioning for an agent manager by ID.
     */
    provision(request: operations.ProvisionAgentManagerRequest, options?: RequestOptions): Promise<operations.ProvisionAgentManagerResponse>;
    /**
     * Update an agent manager to a specific release ID or active release.
     */
    update(request: operations.UpdateAgentManagerRequest, options?: RequestOptions): Promise<operations.UpdateAgentManagerResponse>;
    /**
     * Retrieve all events of an agent manager.
     */
    listEvents(request: operations.ListAgentManagerEventsRequest, options?: RequestOptions): Promise<operations.ListAgentManagerEventsResponse>;
    /**
     * Generate a JWT token and connection info for querying agent manager logs directly. Returns everything the browser needs to create a DeepstoreClient and query the data plane without routing log data through the platform API (end-to-end encryption).
     */
    generateDeepstoreToken(request: operations.GenerateDeepstoreTokenRequest, options?: RequestOptions): Promise<models.GenerateDeepstoreTokenResponse>;
    /**
     * Report Agent Manager health status and metrics.
     */
    reportHeartbeat(request: operations.ReportAgentManagerHeartbeatRequest, options?: RequestOptions): Promise<models.AgentManagerHeartbeatResponse>;
    /**
     * Get deployment details for a user agent manager (internal agent platform, status, resources).
     */
    getDeployment(request: operations.GetAgentManagerDeploymentRequest, options?: RequestOptions): Promise<models.AgentManagerDeployment>;
    /**
     * Connect a Google Cloud agent manager via OAuth.
     */
    googleCloudConnect(request: operations.ConnectAgentManagerToGoogleCloudRequest, options?: RequestOptions): Promise<void>;
}
//# sourceMappingURL=agentmanagers.d.ts.map