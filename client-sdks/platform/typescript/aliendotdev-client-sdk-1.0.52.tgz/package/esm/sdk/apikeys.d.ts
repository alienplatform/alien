import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class ApiKeys extends ClientSDK {
    /**
     * Retrieve all API keys for the current workspace.
     */
    list(request?: operations.ListAPIKeysRequest | undefined, options?: RequestOptions): Promise<operations.ListAPIKeysResponse>;
    /**
     * Create a new API key.
     */
    create(request?: operations.CreateAPIKeyRequest | undefined, options?: RequestOptions): Promise<models.CreateAPIKeyResponse>;
    /**
     * Retrieve a specific API key.
     */
    get(request: operations.GetAPIKeyRequest, options?: RequestOptions): Promise<models.APIKey>;
    /**
     * Revoke (soft delete) an API key.
     */
    revoke(request: operations.RevokeAPIKeyRequest, options?: RequestOptions): Promise<void>;
    /**
     * Update an API key (enable/disable, change description).
     */
    update(request: operations.UpdateAPIKeyRequest, options?: RequestOptions): Promise<models.APIKey>;
    /**
     * Permanently delete multiple API keys.
     */
    deleteMultiple(request?: operations.DeleteAPIKeysRequest | undefined, options?: RequestOptions): Promise<operations.DeleteAPIKeysResponse>;
}
//# sourceMappingURL=apikeys.d.ts.map