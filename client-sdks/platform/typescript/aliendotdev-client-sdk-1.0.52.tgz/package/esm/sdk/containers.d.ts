import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as operations from "../models/operations/index.js";
export declare class Containers extends ClientSDK {
    /**
     * Bird's-eye view of all container definitions across all deployments, with aggregate health stats, machine health breakdown, and HTTP performance metrics.
     */
    getOverview(request?: operations.GetContainerOverviewRequest | undefined, options?: RequestOptions): Promise<operations.GetContainerOverviewResponse>;
    /**
     * Returns deployments that need attention: crash loops, scheduling failures, unhealthy machines.
     */
    getAttention(request?: operations.GetContainerAttentionRequest | undefined, options?: RequestOptions): Promise<operations.GetContainerAttentionResponse>;
    /**
     * Per-deployment breakdown for a container: status, replicas, metrics, and HTTP performance across all deployments running this container.
     */
    getDeployments(request: operations.GetContainerDefinitionDeploymentsRequest, options?: RequestOptions): Promise<operations.GetContainerDefinitionDeploymentsResponse>;
    /**
     * Cross-deployment machine health: per-deployment machine counts by status, capacity group utilization, and scaling recommendations.
     */
    getMachines(request?: operations.GetContainerMachinesRequest | undefined, options?: RequestOptions): Promise<operations.GetContainerMachinesResponse>;
    /**
     * Container cluster overview for a specific deployment: machine count, container count, and capacity.
     */
    getDeploymentCluster(request: operations.GetDeploymentClusterRequest, options?: RequestOptions): Promise<operations.GetDeploymentClusterResponse>;
    /**
     * List all containers running in a specific deployment.
     */
    listDeploymentContainers(request: operations.ListDeploymentContainersRequest, options?: RequestOptions): Promise<operations.ListDeploymentContainersResponse>;
    /**
     * Get detailed status, configuration, and replica metrics for a specific container in a deployment.
     */
    getDeploymentContainer(request: operations.GetDeploymentContainerRequest, options?: RequestOptions): Promise<operations.GetDeploymentContainerResponse>;
    /**
     * List all compute machines in a deployment's container cluster.
     */
    listDeploymentMachines(request: operations.ListDeploymentMachinesRequest, options?: RequestOptions): Promise<operations.ListDeploymentMachinesResponse>;
    /**
     * List orchestration events for a deployment's container cluster.
     */
    listDeploymentEvents(request: operations.ListDeploymentContainerEventsRequest, options?: RequestOptions): Promise<operations.ListDeploymentContainerEventsResponse>;
    /**
     * List orchestration events for a specific container in a deployment.
     */
    listDeploymentContainerInstanceEvents(request: operations.ListDeploymentContainerInstanceEventsRequest, options?: RequestOptions): Promise<operations.ListDeploymentContainerInstanceEventsResponse>;
}
//# sourceMappingURL=containers.d.ts.map