import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Events extends ClientSDK {
    /**
     * Retrieve all events.
     */
    list(request?: operations.ListEventsRequest | undefined, options?: RequestOptions): Promise<operations.ListEventsResponse>;
    /**
     * Retrieve an event by ID.
     */
    get(request: operations.GetEventRequest, options?: RequestOptions): Promise<models.Event>;
}
//# sourceMappingURL=events.d.ts.map