import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Agents extends ClientSDK {
    /**
     * Retrieve all agents.
     */
    list(request?: operations.ListAgentsRequest | undefined, options?: RequestOptions): Promise<operations.ListAgentsResponse>;
    /**
     * Create a new agent. Deployment group tokens automatically use their group. Workspace/project tokens must provide deploymentGroupId.
     */
    create(request?: operations.CreateAgentRequest | undefined, options?: RequestOptions): Promise<models.CreateAgentResponse>;
    /**
     * Get aggregated agent statistics. Returns total count and breakdown by status.
     */
    getStats(request?: operations.GetAgentStatsRequest | undefined, options?: RequestOptions): Promise<models.AgentStats>;
    /**
     * List distinct platforms used by agents. Used for filter dropdowns.
     */
    listFilterPlatforms(request?: operations.ListAgentFilterPlatformsRequest | undefined, options?: RequestOptions): Promise<operations.ListAgentFilterPlatformsResponse>;
    /**
     * List deployment groups with agent counts. Used for filter dropdowns.
     */
    listFilterDeploymentGroups(request?: operations.ListAgentFilterDeploymentGroupsRequest | undefined, options?: RequestOptions): Promise<operations.ListAgentFilterDeploymentGroupsResponse>;
    /**
     * Retrieve an agent by ID.
     */
    get(request: operations.GetAgentRequest, options?: RequestOptions): Promise<models.AgentDetailResponse>;
    /**
     * Delete an agent by ID. This can be used to start deletion or retry failed deletions.
     */
    delete(request: operations.DeleteAgentRequest, options?: RequestOptions): Promise<operations.DeleteAgentResponse>;
    /**
     * Get agent connection information including ARC endpoint and resource URLs.
     */
    getInfo(request: operations.GetAgentInfoRequest, options?: RequestOptions): Promise<models.AgentInfo>;
    /**
     * Import an agent from existing infrastructure (e.g., CloudFormation stack). The agent ID is automatically generated.
     */
    import(request?: operations.ImportAgentRequest | undefined, options?: RequestOptions): Promise<models.Agent>;
    /**
     * Redeploy a running agent with the same release and fresh environment variables. Sets status to update-pending.
     */
    redeploy(request: operations.RedeployAgentRequest, options?: RequestOptions): Promise<operations.RedeployAgentResponse>;
    /**
     * Pin or unpin agent to a specific release. Only works for running agents. Controller will automatically trigger update to target release.
     */
    pinRelease(request: operations.PinAgentReleaseRequest, options?: RequestOptions): Promise<operations.PinAgentReleaseResponse>;
    /**
     * Retry a failed agent operation. Uses alien-infra's retry mechanisms to resume from exact failure point.
     */
    retry(request: operations.RetryAgentRequest, options?: RequestOptions): Promise<operations.RetryAgentResponse>;
    /**
     * Update an agent's environment variables. If the agent is running and not locked, the status will be changed to update-pending to trigger a deployment.
     */
    updateEnvironmentVariables(request: operations.UpdateAgentEnvironmentVariablesRequest, options?: RequestOptions): Promise<operations.UpdateAgentEnvironmentVariablesResponse>;
    /**
     * Create an agent token (agent-scoped API key) for this agent. The agent must exist before creating a token.
     */
    createToken(request: operations.CreateAgentTokenRequest, options?: RequestOptions): Promise<models.CreateAgentTokenResponse>;
}
//# sourceMappingURL=agents.d.ts.map