import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Deployment extends ClientSDK {
    /**
     * Get deployment information for the deployment page. Accepts both agent-scoped and deployment-group-scoped API keys. Returns project information, package status/outputs, and either agent or deployment group details depending on the token type. Poll this endpoint to check if packages are ready.
     */
    getInfo(request?: operations.GetDeploymentInfoRequest | undefined, options?: RequestOptions): Promise<models.DeploymentInfo>;
}
//# sourceMappingURL=deployment.d.ts.map