import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
export declare class Auth extends ClientSDK {
    /**
     * Get current authenticated principal information (user or service account). Works with both session cookies and API keys.
     */
    whoami(options?: RequestOptions): Promise<models.Subject>;
}
//# sourceMappingURL=auth.d.ts.map