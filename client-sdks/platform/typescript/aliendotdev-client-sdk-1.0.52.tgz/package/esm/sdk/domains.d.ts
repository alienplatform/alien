import { ClientSDK, RequestOptions } from "../lib/sdks.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
export declare class Domains extends ClientSDK {
    /**
     * List system domains and workspace domains.
     */
    list(request?: operations.ListDomainsRequest | undefined, options?: RequestOptions): Promise<operations.ListDomainsResponse>;
    /**
     * Create a workspace domain.
     */
    create(request?: operations.CreateDomainRequest | undefined, options?: RequestOptions): Promise<models.Domain>;
    /**
     * Get domain by ID.
     */
    get(request: operations.GetDomainRequest, options?: RequestOptions): Promise<models.Domain>;
    /**
     * Delete a workspace domain.
     */
    delete(request: operations.DeleteDomainRequest, options?: RequestOptions): Promise<operations.DeleteDomainResponse>;
}
//# sourceMappingURL=domains.d.ts.map