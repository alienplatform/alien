import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * List deployment groups
 */
export declare function deploymentGroupsListDeploymentGroups(client: AlienCore, request?: operations.ListDeploymentGroupsRequest | undefined, options?: RequestOptions): APIPromise<Result<operations.ListDeploymentGroupsResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=deploymentGroupsListDeploymentGroups.d.ts.map