import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Update an agent's environment variables. If the agent is running and not locked, the status will be changed to update-pending to trigger a deployment.
 */
export declare function agentsUpdateEnvironmentVariables(client: AlienCore, request: operations.UpdateAgentEnvironmentVariablesRequest, options?: RequestOptions): APIPromise<Result<operations.UpdateAgentEnvironmentVariablesResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=agentsUpdateEnvironmentVariables.d.ts.map