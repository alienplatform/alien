import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Cross-deployment machine health: per-deployment machine counts by status, capacity group utilization, and scaling recommendations.
 */
export declare function containersGetMachines(client: AlienCore, request?: operations.GetContainerMachinesRequest | undefined, options?: RequestOptions): APIPromise<Result<operations.GetContainerMachinesResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=containersGetMachines.d.ts.map