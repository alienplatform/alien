import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Create deployment group token
 *
 * @remarks
 * Creates a deployment-group scoped API key and returns both the token and formatted deployment link
 */
export declare function deploymentGroupsCreateDeploymentGroupToken(client: AlienCore, request: operations.CreateDeploymentGroupTokenRequest, options?: RequestOptions): APIPromise<Result<models.CreateDeploymentGroupTokenResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=deploymentGroupsCreateDeploymentGroupToken.d.ts.map