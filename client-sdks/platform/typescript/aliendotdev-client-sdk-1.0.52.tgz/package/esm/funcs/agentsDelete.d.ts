import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Delete an agent by ID. This can be used to start deletion or retry failed deletions.
 */
export declare function agentsDelete(client: AlienCore, request: operations.DeleteAgentRequest, options?: RequestOptions): APIPromise<Result<operations.DeleteAgentResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=agentsDelete.d.ts.map