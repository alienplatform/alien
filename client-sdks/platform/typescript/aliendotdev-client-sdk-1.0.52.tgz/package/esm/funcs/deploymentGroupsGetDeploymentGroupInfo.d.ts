import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Get deployment info for deployment page
 *
 * @remarks
 * Returns deployment group info, project info, and packages. Uses Bearer deployment group token.
 */
export declare function deploymentGroupsGetDeploymentGroupInfo(client: AlienCore, request?: operations.GetDeploymentGroupInfoRequest | undefined, options?: RequestOptions): APIPromise<Result<operations.GetDeploymentGroupInfoResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=deploymentGroupsGetDeploymentGroupInfo.d.ts.map