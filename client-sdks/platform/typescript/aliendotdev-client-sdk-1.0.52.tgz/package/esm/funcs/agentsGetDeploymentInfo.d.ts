import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as models from "../models/index.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Get all information needed to deploy an agent. This endpoint requires an agent-scoped token and returns agent details along with project information needed for deployment. The agent is identified from the token, so no agent ID parameter is needed.
 */
export declare function agentsGetDeploymentInfo(client: AlienCore, request?: operations.GetAgentDeploymentInfoRequest | undefined, options?: RequestOptions): APIPromise<Result<models.AgentDeploymentInfo, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=agentsGetDeploymentInfo.d.ts.map