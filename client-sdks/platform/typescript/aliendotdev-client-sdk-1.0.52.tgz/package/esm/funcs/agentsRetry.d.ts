import { AlienCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { AlienError } from "../models/errors/alienerror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import * as errors from "../models/errors/index.js";
import { ResponseValidationError } from "../models/errors/responsevalidationerror.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import * as operations from "../models/operations/index.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Retry a failed agent operation. Uses alien-infra's retry mechanisms to resume from exact failure point.
 */
export declare function agentsRetry(client: AlienCore, request: operations.RetryAgentRequest, options?: RequestOptions): APIPromise<Result<operations.RetryAgentResponse, errors.APIError | AlienError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=agentsRetry.d.ts.map